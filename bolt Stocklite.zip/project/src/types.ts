export type UserRole = 'super_admin' | 'admin' | 'caissier' | 'gerant' | 'commercial' | 'controleur';
export type UserStatus = 'pending' | 'active' | 'suspended';

export interface SalesLocation {
  id: string;
  name: string;
  address: string;
  city: string;
  phone: string;
  active: boolean;
  sort_order: number;
  created_at: string;
}

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  status: UserStatus;
  location_id: string | null;
  location?: SalesLocation;
  commercial_id: string | null;
  commercial?: Commercial;
  tenant_id: string | null;
  created_at: string;
}

export const ROLE_LABELS: Record<UserRole, string> = {
  super_admin: 'Super Admin',
  admin: 'Administrateur',
  caissier: 'Caissier',
  gerant: 'Gérant',
  commercial: 'Commercial',
  controleur: 'Contrôleur de caisse',
};

export const STATUS_USER_LABELS: Record<UserStatus, string> = {
  pending: 'En attente',
  active: 'Actif',
  suspended: 'Suspendu',
};

export interface CompanySettings {
  id: string;
  name: string;
  address: string;
  city: string;
  phone: string;
  email: string;
  tax_id: string;
  invoice_footer: string;
  delivery_notice: string | null;
  currency: string;
  logo_url: string | null;
  fne_ncc: string | null;
  fne_api_key: string | null;
  fne_point_of_sale: string | null;
  fne_establishment: string | null;
  fne_api_url: string | null;
  fne_bank_reference: string | null;
  fne_tax_regime: string | null;
  fne_tax_center: string | null;
  fne_rne: string | null;
}

export interface FneSettings {
  ncc: string;
  apiKey: string;
  pointOfSale: string;
  establishment: string;
  apiUrl: string;
}

export interface LocationStock {
  id: string;
  product_id: string;
  location_id: string;
  stock_quantity: number;
  stock_min: number;
  price: number | null;
  updated_at: string;
}

export interface ProductFamily {
  id: string;
  name: string;
  color: string;
  sort_order: number;
  printer_name: string | null;
  created_at: string;
}

export interface ProductSupplier {
  product_id: string;
  supplier_id: string;
  is_default: boolean;
  supply_price: number | null;
  supply_unit: string | null;
  supplier?: Pick<Supplier, 'id' | 'name' | 'phone' | 'email'>;
}

export interface Product {
  id: string;
  name: string;
  reference: string | null;
  description: string;
  unit: string;
  price: number;
  purchase_price: number;
  stock_quantity: number;
  stock_min: number;
  track_stock: boolean;
  active: boolean;
  photo_url: string | null;
  family_id: string | null;
  family?: ProductFamily;
  prices?: ProductPriceType[];
  suppliers?: ProductSupplier[];
  created_at: string;
}

export type CustomerType = 'particulier' | 'entreprise';

export interface Customer {
  id: string;
  code: string | null;
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  notes: string;
  location_id: string | null;
  type: CustomerType;
  ncc: string | null;
  created_at: string;
}

export interface CustomerContact {
  id: string;
  customer_id: string;
  name: string;
  title: string | null;
  phone: string;
  email: string;
  is_default: boolean;
  notes: string;
  created_at: string;
  updated_at: string;
}

export type InvoiceStatus = 'brouillon' | 'envoyee' | 'payee' | 'partielle' | 'annulee';

export type PaymentMethod =
  | 'especes'
  | 'carte'
  | 'virement'
  | 'cheque'
  | 'orange_money'
  | 'wave'
  | 'mtn_money'
  | 'moov_money'
  | 'avoir'
  | 'autre';

export const ALL_PAYMENT_METHODS: { value: PaymentMethod; label: string; icon: string; color: string }[] = [
  { value: 'especes',     label: 'Espèces',           icon: '💵', color: 'bg-emerald-500/10 text-emerald-400 ring-emerald-500/30' },
  { value: 'carte',       label: 'Carte bancaire',     icon: '💳', color: 'bg-blue-500/10 text-blue-400 ring-blue-500/30' },
  { value: 'orange_money',label: 'Orange Money',       icon: '🟠', color: 'bg-orange-500/10 text-orange-400 ring-orange-500/30' },
  { value: 'wave',        label: 'Wave',               icon: '🌊', color: 'bg-sky-500/10 text-sky-400 ring-sky-500/30' },
  { value: 'mtn_money',   label: 'MTN Mobile Money',   icon: '🟡', color: 'bg-yellow-500/10 text-yellow-400 ring-yellow-500/30' },
  { value: 'moov_money',  label: 'Moov Money',         icon: '🔵', color: 'bg-indigo-500/10 text-indigo-400 ring-indigo-500/30' },
  { value: 'virement',    label: 'Virement bancaire',  icon: '🏦', color: 'bg-violet-500/10 text-violet-400 ring-violet-500/30' },
  { value: 'cheque',      label: 'Chèque',             icon: '📄', color: 'bg-slate-500/10 text-slate-400 ring-slate-500/30' },
  { value: 'avoir',       label: 'Avoir / Crédit',     icon: '🔄', color: 'bg-pink-500/10 text-pink-400 ring-pink-500/30' },
  { value: 'autre',       label: 'Autre',              icon: '💰', color: 'bg-slate-500/10 text-slate-400 ring-slate-500/30' },
];

export const METHOD_LABELS: Record<PaymentMethod, string> = Object.fromEntries(
  ALL_PAYMENT_METHODS.map(m => [m.value, m.label])
) as Record<PaymentMethod, string>;

export interface InvoiceItem {
  id: string;
  invoice_id: string;
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
  discount: number;
  total: number;
  sort_order: number;
  fne_dgi_item_id?: string | null;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  customer_id: string;
  customer?: Customer;
  date: string;
  due_date: string | null;
  status: InvoiceStatus;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  total: number;
  amount_paid: number;
  balance_due: number;
  remise: number;
  notes: string;
  created_at: string;
  items?: InvoiceItem[];
  fne_reference?: string | null;
  fne_token?: string | null;
  fne_ncc?: string | null;
  fne_status?: 'pending' | 'certified' | 'error' | null;
  fne_error?: string | null;
  fne_certified_at?: string | null;
  fne_warning?: boolean | null;
  fne_warning_message?: string | null;
  fne_balance_sticker?: number | null;
  fne_dgi_invoice_id?: string | null;
  is_credit_note?: boolean;
  credit_note_of?: string | null;
  location_id?: string | null;
  order_number?: string | null;
  order_advance?: number | null;
  delivery_delay?: string | null;
  payment_mode?: string | null;
  created_by?: string | null;
  creator?: { full_name: string; email: string } | null;
  contact_name?: string | null;
  contact_email?: string | null;
  contact_phone?: string | null;
  airsi?: number;
  airsi_amount?: number;
}

export interface Payment {
  id: string;
  customer_id: string;
  invoice_id: string | null;
  amount: number;
  method: PaymentMethod;
  payment_date: string;
  notes: string;
  created_at: string;
  invoice?: Pick<Invoice, 'id' | 'invoice_number' | 'total'>;
}

export type StockMovementType = 'entree' | 'sortie' | 'ajustement' | 'vente' | 'retour';

export interface StockMovement {
  id: string;
  product_id: string;
  product?: Pick<Product, 'id' | 'name' | 'unit'>;
  type: StockMovementType;
  quantity: number;
  unit_cost: number;
  reference: string;
  notes: string;
  created_at: string;
  stock_after?: number | null;
}

export interface PosSaleItem {
  id: string;
  sale_id: string;
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
  total: number;
}

export interface PosPayment {
  id: string;
  sale_id: string;
  method: PaymentMethod;
  amount: number;
  reference: string;
  created_at: string;
}

export interface PosSale {
  id: string;
  sale_number: string;
  customer_id: string | null;
  user_id: string | null;
  caisse_id: string | null;
  customer?: Customer;
  vendor?: { full_name: string; email: string } | null;
  subtotal: number;
  discount_pct: number;
  discount_amount: number;
  tax_rate: number;
  tax_amount: number;
  total: number;
  notes: string;
  created_at: string;
  items?: PosSaleItem[];
  payments?: PosPayment[];
}

export type CaisseStatus = 'ouverte' | 'cloturee';

export interface Caisse {
  id: string;
  user_id: string;
  location_id: string | null;
  status: CaisseStatus;
  opened_at: string;
  closed_at: string | null;
  opening_amount: number;
  closing_amount: number | null;
  notes: string;
  created_at: string;
  updated_at: string;
}

export const STATUS_LABELS: Record<InvoiceStatus, string> = {
  brouillon: 'Devis',
  envoyee: 'Facture',
  payee: 'Payée',
  partielle: 'Partielle',
  annulee: 'Annulée',
};

export const MOVEMENT_LABELS: Record<StockMovementType, string> = {
  entree: 'Entrée de stock',
  sortie: 'Sortie de stock',
  ajustement: 'Ajustement',
  vente: 'Vente caisse',
  retour: 'Retour en stock',
};

export interface Commercial {
  id: string;
  name: string;
  phone: string;
  active: boolean;
  location_id: string | null;
  created_at: string;
}

export interface PriceType {
  id: string;
  name: string;
  color: string;
  sort_order: number;
  active: boolean;
  is_default: boolean;
  created_at: string;
}

export interface ProductPriceType {
  id: string;
  product_id: string;
  price_type_id: string;
  price_type?: PriceType;
  price: number;
  created_at: string;
}

export interface LocationProductPriceType {
  id: string;
  product_id: string;
  location_id: string;
  price_type_id: string;
  price: number;
  created_at: string;
  updated_at: string;
}

export type StockTransferStatus = 'en_attente' | 'valide' | 'annule';

export interface StockTransferItem {
  id: string;
  transfer_id: string;
  product_id: string;
  product?: Pick<Product, 'id' | 'name' | 'unit'>;
  quantity: number;
  created_at: string;
}

export interface StockTransfer {
  id: string;
  product_id: string | null;
  product?: Pick<Product, 'id' | 'name' | 'unit'> | null;
  from_location_id: string;
  from_location?: Pick<SalesLocation, 'id' | 'name'>;
  to_location_id: string;
  to_location?: Pick<SalesLocation, 'id' | 'name'>;
  quantity: number | null;
  notes: string;
  status: StockTransferStatus;
  created_by: string | null;
  created_at: string;
  validated_by: string | null;
  validated_at: string | null;
  items?: StockTransferItem[];
}

export interface HeldCartItem {
  key: string;
  product_id: string | null;
  description: string;
  unit_price: number;
  quantity: number;
}

export interface HeldCart {
  id: string;
  label: string;
  commercial_id: string | null;
  commercial?: Commercial;
  customer_id: string | null;
  customer?: Pick<Customer, 'id' | 'name'>;
  items: HeldCartItem[];
  discount_pct: number;
  discount_amount?: number;
  tax_rate: number;
  notes: string;
  location_id: string | null;
  created_by: string | null;
  created_at: string;
}

export interface Service {
  id: string;
  name: string;
  location_id: string;
  active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface DotationItem {
  id: string;
  dotation_id: string;
  product_id: string;
  product?: Pick<Product, 'id' | 'name' | 'unit'>;
  quantity: number;
  unit_cost: number;
  created_at: string;
}

export interface Dotation {
  id: string;
  dotation_number: string;
  location_id: string;
  location?: Pick<SalesLocation, 'id' | 'name'>;
  service_id: string;
  service?: Pick<Service, 'id' | 'name'>;
  notes: string;
  effectif: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  items?: DotationItem[];
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  active: boolean;
  location_id: string | null;
  created_at: string;
}

export interface DeliveryNoteItem {
  id: string;
  delivery_note_id: string;
  product_id: string;
  product?: Pick<Product, 'id' | 'name' | 'unit'>;
  location_id: string | null;
  quantity: number;
  unit_cost: number;
  total: number;
  created_at: string;
}

export interface DeliveryNote {
  id: string;
  note_number: string;
  supplier_id: string;
  supplier?: Pick<Supplier, 'id' | 'name'>;
  location_id: string | null;
  note_date: string;
  status: 'brouillon' | 'valide';
  total_amount: number;
  notes: string;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  items?: DeliveryNoteItem[];
}

export interface SupplierPayment {
  id: string;
  supplier_id: string;
  supplier?: Pick<Supplier, 'id' | 'name'>;
  delivery_note_id: string | null;
  delivery_note?: Pick<DeliveryNote, 'id' | 'note_number'> | null;
  amount: number;
  method: PaymentMethod;
  payment_date: string;
  notes: string;
  location_id: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export type OrderStatus = 'brouillon' | 'validee' | 'convertie' | 'annulee';

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  brouillon: 'Brouillon',
  validee: 'Validée',
  convertie: 'Convertie',
  annulee: 'Annulée',
};

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
  total: number;
  sort_order: number;
  printed_at?: string | null;
}

export interface Order {
  id: string;
  order_number: string;
  customer_id: string;
  customer?: Customer;
  commercial_id: string | null;
  commercial?: Commercial;
  location_id: string | null;
  date: string;
  status: OrderStatus;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  total: number;
  notes: string;
  contact_name?: string | null;
  contact_email?: string | null;
  contact_phone?: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  items?: OrderItem[];
}

export interface CustomUnit {
  id: string;
  name: string;
  tenant_id: string | null;
  created_at: string;
}

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  active: boolean;
  license_expires_at: string | null;
  max_users: number;
  created_at: string;
}

export interface Deconditioning {
  id: string;
  pack_product_id: string;
  detail_product_id: string;
  pack_product?: Pick<Product, 'id' | 'name' | 'unit'>;
  detail_product?: Pick<Product, 'id' | 'name' | 'unit'>;
  pack_quantity: number;
  units_per_pack: number;
  detail_quantity: number;
  location_id: string | null;
  location?: Pick<SalesLocation, 'id' | 'name'>;
  notes: string;
  created_by: string | null;
  created_at: string;
}

export type SubscriptionStatus = 'pending' | 'active' | 'expired' | 'cancelled';

export interface LicensePlan {
  id: string;
  name: string;
  duration_days: number;
  price: number;
  currency: string;
  active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface Subscription {
  id: string;
  tenant_id: string;
  amount: number;
  currency: string;
  payment_method: string;
  payment_reference: string | null;
  starts_at: string;
  ends_at: string;
  status: SubscriptionStatus;
  plan_id: string | null;
  plan?: LicensePlan | null;
  created_at: string;
}

export interface SalesContract {
  id: string;
  title: string;
  intro_text: string;
  terms: string[];
  signature_label: string;
  is_active: boolean;
  tenant_id: string | null;
  created_at: string;
  updated_at: string;
}
