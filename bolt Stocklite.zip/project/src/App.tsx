import { useState, useMemo, useCallback, useEffect } from 'react';
import { Menu, MapPin, WifiOff, RefreshCw, Cloud } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { InvoicesPage } from './components/InvoicesPage';
import { InvoiceForm } from './components/InvoiceForm';
import { InvoiceDetail } from './components/InvoiceDetail';
import { OrdersPage } from './components/OrdersPage';
import { OrderForm } from './components/OrderForm';
import { OrderDetail } from './components/OrderDetail';
import { CustomersPage } from './components/CustomersPage';
import { CustomerDetail } from './components/CustomerDetail';
import { ProductsPage } from './components/ProductsPage';
import { SettingsPage } from './components/SettingsPage';
import { PosPage } from './components/PosPage';
import { StockPage } from './components/StockPage';
import { InventoryPage } from './components/InventoryPage';
import { CaisseClosingPage } from './components/CaisseClosingPage';
import { AccountingPage } from './components/AccountingPage';
import { CashOpsPage } from './components/CashOpsPage';
import { ApprovisionnementPage } from './components/ApprovisionnementPage';
import DeconditioningPage from './components/DeconditioningPage';
import { StatementPage } from './components/StatementPage';
import AdminUsersPage from './components/AdminUsersPage';
import CommerciauxPage from './components/CommerciauxPage';
import PriceTypesPage from './components/PriceTypesPage';
import StockTransferPage from './components/StockTransferPage';
import DotationsPage from './components/DotationsPage';
import AuthPage from './components/AuthPage';
import PendingApproval from './components/PendingApproval';
import { TenantsPage } from './components/TenantsPage';
import { PendingSalesPage } from './components/PendingSalesPage';
import { InvoiceReportPage } from './components/InvoiceReportPage';
import { SalesSummaryPage } from './components/SalesSummaryPage';
import { useAuth } from './hooks/useAuth';
import { useInvoices } from './hooks/useInvoices';
import { useCustomers } from './hooks/useCustomers';
import { useProducts } from './hooks/useProducts';
import { useProductFamilies } from './hooks/useProductFamilies';
import { useSettings } from './hooks/useSettings';
import { useSalesContracts } from './hooks/useSalesContracts';
import { usePayments } from './hooks/usePayments';
import { usePosSales } from './hooks/usePosSales';
import { useStock } from './hooks/useStock';
import { useSalesLocations } from './hooks/useSalesLocations';
import { useCommerciaux } from './hooks/useCommerciaux';
import { useHeldCarts } from './hooks/useHeldCarts';
import { useCaisses } from './hooks/useCaisses';
import { usePriceTypes } from './hooks/usePriceTypes';
import { useStockTransfers } from './hooks/useStockTransfers';
import { useDotations } from './hooks/useDotations';
import { useCaisseClosing } from './hooks/useCaisseClosing';
import { useApprovisionnement } from './hooks/useApprovisionnement';
import { useOrders } from './hooks/useOrders';
import { useSupplierPayments } from './hooks/useSupplierPayments';
import { useDeconditioning } from './hooks/useDeconditioning';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { usePwaUpdate } from './hooks/usePwaUpdate';
import { supabase } from './lib/supabase';
import { setMeta as cacheMeta, getMeta as getCachedMeta } from './lib/offlineDb';
import { syncPendingOps, syncPendingCustomers } from './lib/syncManager';

export type Route =
  | { page: 'dashboard' }
  | { page: 'pos' }
  | { page: 'caisse-closing' }
  | { page: 'accounting' }
  | { page: 'cash-ops' }
  | { page: 'invoices' }
  | { page: 'invoice-form'; customerId?: string; editId?: string }
  | { page: 'invoice-detail'; id: string }
  | { page: 'orders' }
  | { page: 'order-form'; customerId?: string; editId?: string }
  | { page: 'order-detail'; id: string }
  | { page: 'customers' }
  | { page: 'customer-detail'; id: string }
  | { page: 'products' }
  | { page: 'stock' }
  | { page: 'inventory' }
  | { page: 'stock-transfers' }
  | { page: 'dotations' }
  | { page: 'approvisionnement' }
  | { page: 'deconditionnement' }
  | { page: 'statement-client' }
  | { page: 'statement-supplier' }
  | { page: 'settings' }
  | { page: 'commerciaux' }
  | { page: 'price-types' }
  | { page: 'admin-users' }
  | { page: 'tenants' }
  | { page: 'pending-sales' }
  | { page: 'invoice-report' }
  | { page: 'sales-summary' };

function AppShell({ profile, signOut, tenantName }: { profile: import('./types').UserProfile; signOut: () => Promise<{ hadPendingData: boolean }>; tenantName: string | null }) {
  const [route, setRoute] = useState<Route>(
    profile.role === 'super_admin' ? { page: 'tenants' } :
    profile.role === 'caissier' ? { page: 'pos' } :
    profile.role === 'gerant'   ? { page: 'pos' } :
    profile.role === 'commercial' ? { page: 'orders' } :
    { page: 'dashboard' }
  );
  const [mobileOpen, setMobileOpen] = useState(false);

  const isAdmin = profile.role === 'admin';
  const isSuperAdmin = profile.role === 'super_admin';

  // Non-admin users are locked to their assigned location; admins can switch
  const [activeLocationId, setActiveLocationId] = useState<string | null>(
    isAdmin ? null : (profile.location_id ?? null)
  );

  const { locations } = useSalesLocations(profile.tenant_id);
  const { commerciaux, loading: commLoading, fetch: fetchCommerciaux, save: saveCommercial, remove: removeCommercial } = useCommerciaux(activeLocationId, profile.tenant_id);
  const { heldCarts, fetch: fetchHeldCarts, save: saveHeldCart, remove: removeHeldCart } = useHeldCarts(activeLocationId);
  const { priceTypes, loading: ptLoading, fetch: fetchPriceTypes, save: savePriceType, remove: removePriceType, saveProductPrices, fetchLocationProductPrices, saveLocationProductPrices } = usePriceTypes(profile.tenant_id);
  const { transfers, loading: transfersLoading, fetch: fetchTransfers, create: createTransfer, validate: validateTransfer, cancel: cancelTransfer } = useStockTransfers(activeLocationId, profile.tenant_id);
  const { services: dotationServices, dotations, loading: dotationsLoading, saveService: saveDotationService, removeService: removeDotationService, createDotation } = useDotations(activeLocationId, profile.tenant_id);
  const {
    suppliers: appSuppliers, deliveryNotes: appDeliveryNotes, loading: appLoading,
    saveSupplier: saveAppSupplier, removeSupplier: removeAppSupplier,
    createDeliveryNote: createDeliveryNote, validateDeliveryNote: validateDeliveryNote, deleteDeliveryNote: deleteDeliveryNote,
  } = useApprovisionnement(activeLocationId, profile.tenant_id);

  const { invoices, loading: invLoading, fetchOne, create, update, applyPayment, remove: removeInvoice, createCreditNote, refetch: refetchInvoices, returnInvoiceItems } = useInvoices(activeLocationId, profile.tenant_id);
  const { orders, fetchOne: fetchOneOrder, create: createOrder, update: updateOrder, remove: removeOrder, convertToInvoice, markItemsPrinted } = useOrders(activeLocationId, profile.tenant_id);
  const { customers, loading: custLoading, save: saveCustomer, remove: removeCustomer, fetchContacts, saveContact, removeContact } = useCustomers(activeLocationId, profile.tenant_id);
  const { products, save: saveProduct, remove: removeProduct, bulkImport, refetch: refetchProducts, fetchProductLocations, saveProductLocations, fetchProductSuppliers, saveProductSuppliers } = useProducts(activeLocationId);
  const { families, saveFamily, removeFamily } = useProductFamilies(profile.tenant_id);
  const { settings, save: saveSettings } = useSettings(profile?.tenant_id);
  const { contracts: salesContracts } = useSalesContracts(profile?.tenant_id);
  const activeContract = salesContracts.find(c => c.is_active) ?? null;
  const { fetchForCustomer, record: recordPayment } = usePayments();
  const { fetchForSupplier: fetchSupplierPayments, record: recordSupplierPayment, remove: removeSupplierPayment } = useSupplierPayments(profile.tenant_id);
  const { sales: posSales, fetchSales, createSale, pendingCount, queuedSales, manualSync, cancelQueuedSale, deleteSale, returnSaleItems } = usePosSales(activeLocationId, profile.tenant_id);
  const { movements, loading: movementsLoading, fetchMovements, addMovement, validateInventory } = useStock(activeLocationId);
  const { caisses, activeCaisse, openCaisse, closeCaisse, deleteCaisse } = useCaisses(activeLocationId);
  const { closings, loading: closingsLoading, fetchClosings, computeExpected, computeProductSales, computePosJournal, computeInvoiceJournal, computePaymentSummary, computeCashSummary, saveClosing, caisseId: caisseClosingCaisseId, setCaisseId: setCaisseClosingCaisseId } = useCaisseClosing(activeLocationId, profile.tenant_id);
  const { deconditionings, loading: decondLoading, fetch: fetchDeconditionings, execute: executeDeconditioning } = useDeconditioning(activeLocationId);
  const myOpenCaisses = useMemo(
    () => caisses.filter(c => c.status === 'ouverte' && c.user_id === activeCaisse?.user_id),
    [caisses, activeCaisse],
  );

  const isOnline = useOnlineStatus();
  usePwaUpdate();
  const [syncing, setSyncing] = useState(false);

  const handleManualSync = useCallback(async () => {
    setSyncing(true);
    try {
      await manualSync();
      await syncPendingOps(profile.tenant_id);
      await syncPendingCustomers(profile.tenant_id);
    } finally { setSyncing(false); }
  }, [manualSync, profile.tenant_id]);

  const currency = settings?.currency ?? 'FCFA';

  useEffect(() => { fetchSales(); }, [fetchSales]);
  useEffect(() => { fetchCommerciaux(); }, [fetchCommerciaux]);
  useEffect(() => { fetchHeldCarts(); }, [fetchHeldCarts]);
  useEffect(() => { fetchPriceTypes(); }, [fetchPriceTypes]);
  useEffect(() => { fetchTransfers(); }, [fetchTransfers]);

  const invoiceSummary = useMemo(() => {
    const map: Record<string, { total: number; paid: number; balance: number }> = {};
    for (const inv of invoices) {
      if (!map[inv.customer_id]) map[inv.customer_id] = { total: 0, paid: 0, balance: 0 };
      map[inv.customer_id].total += inv.total;
      map[inv.customer_id].paid += inv.amount_paid;
      map[inv.customer_id].balance += inv.balance_due;
    }
    return map;
  }, [invoices]);

  const lowStockCount = useMemo(() =>
    products.filter(p => p.track_stock && p.active && p.stock_quantity <= p.stock_min).length,
    [products]
  );

  const fetchCustomerInvoices = useCallback(async (customerId: string) => {
    const { data } = await supabase
      .from('invoices')
      .select('*')
      .eq('customer_id', customerId)
      .order('date', { ascending: false });
    return (data ?? []) as import('./types').Invoice[];
  }, []);

  function navigate(r: Route) {
    setRoute(r);
    setMobileOpen(false);
    window.scrollTo(0, 0);
  }

  async function handleAddMovement(payload: Parameters<typeof addMovement>[0]) {
    await addMovement(payload);
    refetchProducts();
  }

  const isCaissier = profile.role === 'caissier';
  const isGerant   = profile.role === 'gerant';
  const isCommercial = profile.role === 'commercial';
  const isControleur = profile.role === 'controleur';

  const loading = invLoading || custLoading;

  function renderPage() {
    // Route guards by role — gérant has full boutique access (all except settings/admin-users)
    if (route.page === 'dashboard'    && !isAdmin && !isGerant && !isControleur)  return null;
    if (route.page === 'settings'     && !isAdmin)               return null;
    if (route.page === 'admin-users'  && !isAdmin && !isSuperAdmin)   return null;
    if (route.page === 'pos'          && !isAdmin && !isCaissier && !isGerant && !isControleur) return null;
    if (route.page === 'accounting'   && !isAdmin && !isGerant)  return null;
    if (route.page === 'caisse-closing' && !isAdmin && !isCaissier && !isGerant && !isControleur) return null;
    if (route.page === 'cash-ops'     && !isAdmin && !isCaissier && !isGerant && !isControleur) return null;
    if (route.page === 'invoices'     && !isAdmin && !isCaissier && !isGerant && !isCommercial && !isControleur) return null;
    if (route.page === 'invoice-report' && !isAdmin && !isGerant && !isControleur) return null;
    if (route.page === 'invoice-form' && !isAdmin && !isCaissier && !isGerant && !isCommercial && !isControleur) return null;
    if (route.page === 'invoice-detail' && !isAdmin && !isCaissier && !isGerant && !isCommercial && !isControleur) return null;
    if (route.page === 'orders'      && !isAdmin && !isCaissier && !isGerant && !isCommercial) return null;
    if (route.page === 'order-form'  && !isAdmin && !isCaissier && !isGerant && !isCommercial) return null;
    if (route.page === 'order-detail' && !isAdmin && !isCaissier && !isGerant && !isCommercial) return null;
    if (route.page === 'customers'    && !isAdmin && !isCaissier && !isGerant && !isCommercial) return null;
    if (route.page === 'customer-detail' && !isAdmin && !isCaissier && !isGerant && !isCommercial) return null;
    if (route.page === 'stock'          && !isAdmin && !isGerant && !isCommercial && !isCaissier)  return null;
    if (route.page === 'inventory'     && !isAdmin && !isGerant)  return null;
    if (route.page === 'products'       && !isAdmin && !isGerant && !isCommercial)  return null;
    if (route.page === 'commerciaux'    && !isAdmin && !isGerant)  return null;
    if (route.page === 'price-types'    && !isAdmin && !isGerant)  return null;
    if (route.page === 'stock-transfers'&& !isAdmin && !isGerant)  return null;
    if (route.page === 'dotations'      && !isAdmin && !isGerant)  return null;
    if (route.page === 'approvisionnement' && !isAdmin && !isGerant && !isCommercial) return null;
    if (route.page === 'deconditionnement' && !isAdmin && !isGerant) return null;

    if (loading && (route.page === 'dashboard')) {
      return (
        <div className="space-y-4 animate-pulse">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => <div key={i} className="h-28 rounded-xl bg-gray-200/60" />)}
          </div>
          <div className="h-64 rounded-xl bg-gray-100" />
        </div>
      );
    }

    switch (route.page) {
      case 'dashboard':
        return (
          <Dashboard
            invoices={invoices}
            customers={customers}
            products={products}
            posSales={posSales}
            currency={currency}
            onNavigate={navigate}
          />
        );

      case 'pos':
        return (
          <PosPage
            posSales={posSales}
            products={products}
            customers={customers}
            settings={settings}
            families={families}
            commerciaux={commerciaux}
            heldCarts={heldCarts}
            priceTypes={priceTypes}
            locationId={activeLocationId}
            activeCaisseId={activeCaisse?.id ?? null}
            caisseOpenedAt={activeCaisse?.opened_at ?? null}
            caisseOpeningAmount={activeCaisse?.opening_amount ?? null}
            openCaisses={myOpenCaisses}
            onOpenCaisse={async input => { await openCaisse(input); }}
            onCloseCaisse={async (caisseId, input) => { await closeCaisse(caisseId, input); }}
            onCreateSale={async input => {
              const sale = await createSale(input);
              refetchProducts();
              return sale;
            }}
            onHoldCart={saveHeldCart}
            onDeleteHeldCart={removeHeldCart}
            isAdmin={isAdmin}
            onDeleteSale={isAdmin ? async saleId => {
              await deleteSale(saleId);
              refetchProducts();
            } : undefined}
            {...(isAdmin || isSuperAdmin || isGerant ? {
              onReturnSaleItems: async (saleId: string, returns: { item_id: string; product_id: string | null; quantity: number }[], reason: string) => {
                await returnSaleItems(saleId, returns, reason);
                refetchProducts();
              }
            } : {})}
          />
        );

      case 'stock':
        return (
          <StockPage
            products={products}
            currency={currency}
            onAddMovement={handleAddMovement}
            fetchMovements={fetchMovements}
            movements={movements}
            movementsLoading={movementsLoading}
            locations={locations}
            activeLocationId={activeLocationId}
            readOnly={isCaissier || isCommercial}
            showPurchasePrice={isAdmin || isSuperAdmin || isGerant || isCommercial}
          />
        );

      case 'inventory':
        return (
          <InventoryPage
            products={products}
            onValidate={async entries => {
              await validateInventory(entries);
              refetchProducts();
            }}
          />
        );

      case 'invoices':
        return <InvoicesPage invoices={invoices} onNavigate={navigate} recordPayment={recordPayment} refetchInvoices={refetchInvoices} currency={currency} />;

      case 'invoice-report':
        return <InvoiceReportPage invoices={invoices} currency={currency} />;

      case 'sales-summary':
        return (
          <SalesSummaryPage
            settings={settings}
            locationId={activeLocationId}
            computeProductSales={computeProductSales}
            families={families}
          />
        );

      case 'invoice-form':
        return (
          <InvoiceForm
            customers={customers}
            products={products}
            preselectedCustomerId={route.customerId}
            editId={route.editId}
            fetchOne={fetchOne}
            onSave={create}
            onUpdate={update}
            onNavigate={navigate}
            onCreateProduct={saveProduct}
            onSaveProductPrices={saveProductPrices}
            families={families}
            priceTypes={priceTypes}
            locationId={activeLocationId}
            locations={locations}
            fetchCustomerContacts={fetchContacts}
          />
        );

      case 'invoice-detail':
        return (
          <InvoiceDetail
            invoiceId={route.id}
            settings={settings}
            activeContract={activeContract}
            fetchOne={fetchOne}
            onUpdateStatus={update}
            onNavigate={navigate}
            recordPayment={recordPayment}
            onCreateCreditNote={async id => {
              const avoir = await createCreditNote(id);
              if (avoir) navigate({ page: 'invoice-detail', id: avoir.id });
            }}
            {...(isAdmin || isSuperAdmin ? {
              onDelete: async id => {
                await removeInvoice(id);
                navigate({ page: 'invoices' });
              }
            } : {})}
            {...(isAdmin || isSuperAdmin || isGerant ? {
              onReturnInvoiceItems: async (invoiceId: string, returns: { item_id: string; product_id: string | null; quantity: number }[], reason: string) => {
                await returnInvoiceItems(invoiceId, returns, reason);
                refetchProducts();
              }
            } : {})}
            refetchInvoices={refetchInvoices}
          />
        );

      case 'orders':
        return (
          <OrdersPage
            orders={orders}
            onNavigate={navigate}
            canValidate={isAdmin || isGerant}
            onValidate={async id => { await updateOrder(id, { status: 'validee' }); }}
            onConvert={async id => {
              const inv = await convertToInvoice(id, create);
              if (inv) navigate({ page: 'invoice-detail', id: inv.id });
            }}
            {...(isAdmin || isSuperAdmin ? {
              onDelete: async id => { await removeOrder(id); }
            } : {})}
          />
        );

      case 'order-form':
        return (
          <OrderForm
            customers={customers}
            products={products}
            commerciaux={commerciaux}
            families={families}
            preselectedCustomerId={route.customerId}
            editId={route.editId}
            fetchOne={fetchOneOrder}
            onSave={createOrder}
            onUpdate={updateOrder}
            onNavigate={navigate}
            defaultCommercialId={profile.commercial_id ?? null}
            fetchCustomerContacts={fetchContacts}
          />
        );

      case 'order-detail':
        return (
          <OrderDetail
            orderId={route.id}
            fetchOne={fetchOneOrder}
            onNavigate={navigate}
            canValidate={isAdmin || isGerant}
            onValidate={async id => { await updateOrder(id, { status: 'validee' }); }}
            onConvert={async id => {
              const inv = await convertToInvoice(id, create);
              if (inv) navigate({ page: 'invoice-detail', id: inv.id });
            }}
            families={families}
            products={products}
            settings={settings}
            onMarkItemsPrinted={markItemsPrinted}
          />
        );

      case 'customers':
        return (
          <CustomersPage
            customers={customers}
            invoiceSummary={invoiceSummary}
            onSave={saveCustomer}
            onRemove={removeCustomer}
            onNavigate={navigate}
            canDelete={!isCommercial}
            locationId={activeLocationId}
            locations={isAdmin ? locations : locations.filter(l => l.id === activeLocationId)}
          />
        );

      case 'customer-detail': {
        const customer = customers.find(c => c.id === route.id);
        if (!customer) return <div className="py-20 text-center text-slate-500">Client introuvable.</div>;
        return (
          <CustomerDetail
            customer={customer}
            onNavigate={navigate}
            fetchInvoices={fetchCustomerInvoices}
            recordPayment={recordPayment}
            applyPaymentToInvoice={applyPayment}
            fetchPayments={fetchForCustomer}
            fetchContacts={fetchContacts}
            onSaveContact={saveContact}
            onRemoveContact={removeContact}
          />
        );
      }

      case 'caisse-closing':
        return (
          <CaisseClosingPage
            settings={settings}
            isAdmin={isAdmin}
            computeExpected={computeExpected}
            computeProductSales={computeProductSales}
            computePosJournal={computePosJournal}
            computeInvoiceJournal={computeInvoiceJournal}
            computePaymentSummary={computePaymentSummary}
            computeCashSummary={computeCashSummary}
            saveClosing={saveClosing}
            closings={closings}
            loading={closingsLoading}
            fetchClosings={fetchClosings}
            caisses={caisses}
            caisseId={caisseClosingCaisseId}
            onCaisseChange={setCaisseClosingCaisseId}
            onCloseCaisse={async (caisseId, input) => { await closeCaisse(caisseId, input); }}
            activeCaisseId={activeCaisse?.id ?? null}
            onDeleteCaisse={isAdmin ? async caisseId => { await deleteCaisse(caisseId); } : undefined}
          />
        );

      case 'accounting':
        return <AccountingPage settings={settings} locationId={activeLocationId} />;

      case 'cash-ops':
        return <CashOpsPage settings={settings} locationId={activeLocationId} activeCaisseId={activeCaisse?.id ?? null} caisseStatus={activeCaisse?.status ?? null} tenantId={profile.tenant_id} />;

      case 'products':
        return (
          <ProductsPage
            products={products}
            families={families}
            priceTypes={priceTypes}
            suppliers={appSuppliers}
            onSave={saveProduct}
            onSavePrices={saveProductPrices}
            onRemove={removeProduct}
            onSaveFamily={saveFamily}
            onRemoveFamily={removeFamily}
            onBulkImport={async (rows, locId, onProgress) => {
              const res = await bulkImport(rows, locId, onProgress);
              refetchProducts();
              return res;
            }}
            onFetchProductLocations={fetchProductLocations}
            onSaveProductLocations={saveProductLocations}
            onFetchLocationProductPrices={fetchLocationProductPrices}
            onSaveLocationProductPrices={saveLocationProductPrices}
            onFetchProductSuppliers={fetchProductSuppliers}
            onSaveProductSuppliers={saveProductSuppliers}
            currency={currency}
            locationId={activeLocationId}
            locations={locations}
            tenantId={profile.tenant_id}
          />
        );

      case 'settings':
        return <SettingsPage settings={settings} onSave={saveSettings} tenantId={profile.tenant_id} activeContract={activeContract} />;

      case 'price-types':
        return (
          <PriceTypesPage
            priceTypes={priceTypes}
            loading={ptLoading}
            onSave={savePriceType}
            onRemove={removePriceType}
          />
        );

      case 'stock-transfers':
        return (
          <StockTransferPage
            products={products}
            locations={locations}
            transfers={transfers}
            loading={transfersLoading}
            onCreate={async input => {
              await createTransfer(input);
              refetchProducts();
            }}
            onValidate={async id => {
              await validateTransfer(id);
              refetchProducts();
            }}
            onCancel={async id => {
              await cancelTransfer(id);
            }}
          />
        );

      case 'dotations':
        return (
          <DotationsPage
            products={products}
            locations={locations}
            services={dotationServices}
            dotations={dotations}
            loading={dotationsLoading}
            activeLocationId={activeLocationId}
            onSaveService={saveDotationService}
            onRemoveService={removeDotationService}
            onCreateDotation={createDotation}
            onAfterDotation={refetchProducts}
          />
        );

      case 'approvisionnement':
        return (
          <ApprovisionnementPage
            settings={settings}
            products={products}
            locationId={activeLocationId}
            locations={isAdmin ? locations : locations.filter(l => l.id === activeLocationId)}
            suppliers={appSuppliers}
            deliveryNotes={appDeliveryNotes}
            loading={appLoading}
            onSaveSupplier={saveAppSupplier}
            onRemoveSupplier={removeAppSupplier}
            onCreateNote={createDeliveryNote}
            onValidateNote={validateDeliveryNote}
            onDeleteNote={deleteDeliveryNote}
            onRecordSupplierPayment={recordSupplierPayment}
            onRemoveSupplierPayment={removeSupplierPayment}
          />
        );

      case 'deconditionnement':
        return (
          <DeconditioningPage
            products={products}
            locations={locations}
            deconditionings={deconditionings}
            loading={decondLoading}
            onExecute={async input => {
              await executeDeconditioning(input);
              refetchProducts();
            }}
            activeLocationId={activeLocationId}
          />
        );

      case 'statement-client':
        return (
          <StatementPage
            mode="client"
            customers={customers}
            suppliers={appSuppliers}
            deliveryNotes={appDeliveryNotes}
            onNavigate={navigate}
            fetchInvoices={fetchCustomerInvoices}
            fetchPayments={fetchForCustomer}
            currency={currency}
          />
        );

      case 'statement-supplier':
        return (
          <StatementPage
            mode="supplier"
            customers={customers}
            suppliers={appSuppliers}
            deliveryNotes={appDeliveryNotes}
            onNavigate={navigate}
            fetchInvoices={fetchCustomerInvoices}
            fetchPayments={fetchForCustomer}
            fetchSupplierPayments={fetchSupplierPayments}
            currency={currency}
          />
        );

      case 'admin-users':
        return <AdminUsersPage currentUserId={profile.id} />;

      case 'tenants':
        return <TenantsPage />;

      case 'pending-sales':
        return (
          <PendingSalesPage
            queuedSales={queuedSales}
            isOnline={isOnline}
            pendingCount={pendingCount}
            onSync={handleManualSync}
            onCancel={cancelQueuedSale}
            currency={currency}
          />
        );

      case 'commerciaux':
        return (
          <CommerciauxPage
            commerciaux={commerciaux}
            loading={commLoading}
            onSave={saveCommercial}
            onRemove={removeCommercial}
            locations={locations}
            activeLocationId={activeLocationId}
          />
        );

      default:
        return null;
    }
  }

  const isPosPage = route.page === 'pos' || route.page === 'order-form';

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar
        route={route}
        onNavigate={navigate}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        lowStockCount={lowStockCount}
        profile={profile}
        onSignOut={async () => { await signOut(); }}
        locations={locations}
        activeLocationId={activeLocationId}
        onLocationChange={isAdmin ? setActiveLocationId : undefined}
        tenantName={tenantName}
        pendingCount={pendingCount}
      />

      <div className="flex flex-1 flex-col overflow-hidden">
        <div className="flex h-14 items-center border-b border-slate-200 bg-white px-4 lg:hidden no-print">
          <button onClick={() => setMobileOpen(true)} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-900">
            <Menu className="h-5 w-5" />
          </button>
          <div className="ml-3 flex flex-col leading-tight">
            <span className="text-sm font-extrabold text-slate-900">Stock<span className="text-blue-600">lite</span></span>
            {tenantName && (
              <span className="text-[10px] font-semibold text-slate-400 truncate max-w-[120px]">{tenantName}</span>
            )}
            {!isAdmin && profile.location && (
              <span className="text-[10px] font-semibold text-blue-600">{profile.location.name}</span>
            )}
          </div>
        </div>

        {isAdmin && (
          <div className="hidden lg:flex h-14 items-center justify-between border-b border-slate-200 bg-white px-6 no-print">
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-extrabold text-slate-900">Stock<span className="text-blue-600">lite</span></span>
              {tenantName && (
                <span className="text-[10px] font-semibold text-slate-400">{tenantName}</span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 rounded-full bg-blue-50 px-3 py-1.5">
                <MapPin className="h-3.5 w-3.5 text-blue-600" />
                <span className="text-xs font-bold text-blue-700">
                  {activeLocationId
                    ? (locations.find(l => l.id === activeLocationId)?.name ?? 'Boutique')
                    : 'Toutes les boutiques'}
                </span>
              </div>
            </div>
          </div>
        )}

        <main className={`flex-1 overflow-y-auto bg-slate-50 ${isPosPage ? '' : 'p-5 lg:p-7'}`}>
          <div className={isPosPage ? 'h-full' : 'mx-auto max-w-6xl'}>
            {(!isOnline || pendingCount > 0) && (
              <div className={`mb-4 flex items-center justify-between gap-3 rounded-xl border px-4 py-3 text-sm ${
                !isOnline
                  ? 'border-amber-300 bg-amber-50 text-amber-900'
                  : 'border-blue-300 bg-blue-50 text-blue-900'
              }`}>
                <div className="flex items-center gap-2">
                  {!isOnline ? (
                    <>
                      <WifiOff className="h-4.5 w-4.5 shrink-0" />
                      <span className="font-bold">Hors ligne</span>
                      <span className="text-amber-700">
                        {pendingCount > 0 ? `— ${pendingCount} vente(s) en attente de synchro` : '— les ventes seront synchronisées au retour du réseau'}
                      </span>
                    </>
                  ) : (
                    <>
                      <Cloud className="h-4.5 w-4.5 shrink-0" />
                      <span className="font-bold">En ligne</span>
                      <span className="text-blue-700">
                        {pendingCount > 0 ? `— ${pendingCount} vente(s) en attente de synchro` : ''}
                      </span>
                    </>
                  )}
                </div>
                {isOnline && pendingCount > 0 && (
                  <button
                    onClick={handleManualSync}
                    disabled={syncing}
                    className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-blue-500 disabled:opacity-50 transition"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${syncing ? 'animate-spin' : ''}`} />
                    {syncing ? 'Synchro…' : 'Synchroniser'}
                  </button>
                )}
              </div>
            )}
            {renderPage()}
          </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  const { session, profile, loading, signIn, signUp, signOut, refreshProfile } = useAuth();
  const [tenantInfo, setTenantInfo] = useState<{ name: string; license_expires_at: string | null } | null>(null);

  useEffect(() => {
    if (!profile || profile.role === 'super_admin' || !profile.tenant_id) {
      setTenantInfo(null);
      return;
    }
    supabase.from('tenants').select('name, license_expires_at').eq('id', profile.tenant_id).maybeSingle()
      .then(async ({ data }) => {
        const info = data as { name: string; license_expires_at: string | null } | null;
        setTenantInfo(info);
        if (info) await cacheMeta('tenant_info', info);
      })
      .catch(async () => {
        const cached = await getCachedMeta<{ name: string; license_expires_at: string | null }>('tenant_info');
        setTenantInfo(cached ?? null);
      });
  }, [profile]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 rounded-full border-2 border-blue-600 border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!session) {
    return <AuthPage onSignIn={signIn} onSignUp={signUp} />;
  }

  if (!profile || profile.status === 'pending') {
    return (
      <PendingApproval
        profile={profile ?? { id: '', email: session.user.email ?? '', full_name: '', role: 'caissier', status: 'pending', location_id: null, tenant_id: null, created_at: '' }}
        onRefresh={refreshProfile}
        onSignOut={async () => { await signOut(); }}
      />
    );
  }

  if (profile.status === 'suspended') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center max-w-sm">
          <p className="text-red-600 font-bold mb-2">Compte suspendu</p>
          <p className="text-slate-500 text-sm mb-6">Votre accès a été suspendu. Contactez un administrateur.</p>
          <button onClick={() => signOut()} className="px-4 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm hover:bg-slate-200 transition-colors">
            Se déconnecter
          </button>
        </div>
      </div>
    );
  }

  return <AppShell profile={profile} signOut={signOut} tenantName={tenantInfo?.name ?? null} />;
}
