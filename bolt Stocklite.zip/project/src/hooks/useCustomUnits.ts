import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export function useCustomUnits(tenantId?: string | null) {
  const [units, setUnits] = useState<string[]>([]);

  const fetch = useCallback(async () => {
    const { data } = await supabase.from('custom_units').select('name');
    setUnits((data ?? []).map(u => u.name).sort((a, b) => a.localeCompare(b)));
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch, tenantId]);

  const addUnit = useCallback(async (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const existing = units;
    if (existing.some(u => u.toLowerCase() === trimmed.toLowerCase())) return;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    if (!navigator.onLine) {
      const queued: QueuedOp = {
        localId: id, op: 'customUnit',
        payload: { _id: id, name: trimmed, _isDelete: false },
        createdAt: now, status: 'pending', tenantId: tenantId ?? null,
      };
      await queueOp(queued);
      return;
    }
    const { error } = await supabase.from('custom_units').insert({ id, name: trimmed, tenant_id: null, created_at: now, updated_at: now });
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }, [units, fetch, tenantId]);

  const removeUnit = useCallback(async (name: string) => {
    if (!navigator.onLine) return;
    const { data } = await supabase.from('custom_units').select('id').eq('name', name).maybeSingle();
    if (!data) return;
    const queued: QueuedOp = {
      localId: crypto.randomUUID(), op: 'customUnit',
      payload: { _id: data.id, name, _isDelete: true },
      createdAt: new Date().toISOString(), status: 'pending', tenantId: tenantId ?? null,
    };
    await queueOp(queued);
    const { error } = await supabase.from('custom_units').delete().eq('id', data.id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }, [fetch, tenantId]);

  return { units, addUnit, removeUnit };
}
