import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { CompanySettings } from '../types';
import { translateError } from '../lib/translateError';
import { cacheSettings, getCachedSettings, queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

const defaults: Omit<CompanySettings, 'id'> = {
  name: 'Mon Entreprise',
  address: '',
  city: '',
  phone: '',
  email: '',
  tax_id: '',
  invoice_footer: 'Merci pour votre confiance.',
  delivery_notice: null,
  currency: 'FCFA',
  logo_url: null,
  fne_ncc: null,
  fne_api_key: null,
  fne_point_of_sale: null,
  fne_establishment: null,
  fne_api_url: null,
};

export function useSettings(tenantId?: string | null) {
  const [settings, setSettings] = useState<CompanySettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      let query = supabase.from('company_settings').select('*');
      if (tenantId) query = query.eq('tenant_id', tenantId);
      const { data, error } = await query.limit(1);
      if (error) {
        const cached = await getCachedSettings<CompanySettings>();
        setSettings(cached ?? ({ id: '', ...defaults } as CompanySettings));
        setLoading(false);
        return;
      }
      const rows = (data ?? []) as CompanySettings[];
      const s = rows.length ? rows[0] : ({ id: '', ...defaults } as CompanySettings);
      setSettings(s);
      await cacheSettings(s);
      setLoading(false);
    })();
  }, [tenantId]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [tenantId]);

  async function save(updates: Omit<CompanySettings, 'id'>) {
    const now = new Date().toISOString();
    const existing = settings?.id;
    if (!navigator.onLine) {
      const queued: QueuedOp = {
        localId: crypto.randomUUID(), op: 'settings',
        payload: { ...updates, tenant_id: tenantId ?? null },
        createdAt: now, status: 'pending', tenantId: tenantId ?? null,
      };
      await queueOp(queued);
      setSettings({ ...settings, ...updates } as CompanySettings);
      return;
    }
    if (!existing) {
      const { data, error } = await supabase.from('company_settings').insert({ ...updates, tenant_id: tenantId ?? null, created_at: now, updated_at: now }).select().single();
      if (error) throw new Error(translateError(error.message));
      setSettings(data as CompanySettings);
    } else {
      const { data, error } = await supabase.from('company_settings').update({ ...updates, updated_at: now }).eq('id', existing).select().single();
      if (error) throw new Error(translateError(error.message));
      setSettings(data as CompanySettings);
    }
  }

  return { settings: settings ?? null, loading, save };
}
