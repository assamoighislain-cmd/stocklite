import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { HeldCart, HeldCartItem, Commercial, Customer } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface SaveHeldCartInput {
  label: string;
  commercial_id: string | null;
  customer_id: string | null;
  items: HeldCartItem[];
  discount_pct: number;
  discount_amount?: number;
  tax_rate: number;
  notes: string;
  location_id: string | null;
}

export function useHeldCarts(locationId?: string | null) {
  const [heldCarts, setHeldCarts] = useState<HeldCart[]>([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    let query = supabase.from('held_carts').select('*').order('created_at', { ascending: false });
    if (locationId) query = query.eq('location_id', locationId);
    const { data } = await query;
    const rows = (data ?? []) as HeldCart[];

    const commercialIds = [...new Set(rows.map(c => c.commercial_id).filter(Boolean) as string[])];
    const customerIds = [...new Set(rows.map(c => c.customer_id).filter(Boolean) as string[])];
    const comMap = new Map<string, Commercial>();
    const custMap = new Map<string, Customer>();
    if (commercialIds.length) {
      const { data: coms } = await supabase.from('commerciaux').select('*').in('id', commercialIds);
      for (const c of (coms ?? []) as Commercial[]) comMap.set(c.id, c);
    }
    if (customerIds.length) {
      const { data: custs } = await supabase.from('customers').select('id, name').in('id', customerIds);
      for (const c of (custs ?? []) as Pick<Customer, 'id' | 'name'>[]) custMap.set(c.id, c);
    }

    setHeldCarts(rows.map(c => ({
      ...c,
      commercial: c.commercial_id ? comMap.get(c.commercial_id) : undefined,
      customer: c.customer_id ? { id: custMap.get(c.customer_id)!.id, name: custMap.get(c.customer_id)!.name } : undefined,
    })));
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch]);

  async function save(input: SaveHeldCartInput): Promise<HeldCart> {
    const now = new Date().toISOString();
    const id = crypto.randomUUID();

    if (!navigator.onLine) {
      await queueOp({ localId: id, op: 'heldCart', createdAt: now, status: 'pending', payload: { ...input, _id: id, _user_id: null } });
      return { id, ...input, created_by: null, created_at: now, updated_at: now } as HeldCart;
    }

    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from('held_carts').insert({
      id, label: input.label, commercial_id: input.commercial_id,
      customer_id: input.customer_id, items: input.items,
      discount_pct: input.discount_pct, discount_amount: input.discount_amount ?? 0, tax_rate: input.tax_rate,
      notes: input.notes, location_id: input.location_id,
      created_by: user?.id ?? null, created_at: now, updated_at: now,
    });
    if (error) throw new Error(translateError(error.message));
    await fetch();
    return { id, ...input, created_by: user?.id ?? null, created_at: now, updated_at: now } as HeldCart;
  }

  async function remove(id: string) {
    const { error } = await supabase.from('held_carts').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  return { heldCarts, loading, fetch, save, remove };
}
