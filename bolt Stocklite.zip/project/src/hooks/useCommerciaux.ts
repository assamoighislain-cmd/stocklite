import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Commercial } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export function useCommerciaux(locationId?: string | null, tenantId?: string | null) {
  const [commerciaux, setCommerciaux] = useState<Commercial[]>([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    let query = supabase.from('commerciaux').select('*').order('name');
    if (locationId) query = query.eq('location_id', locationId);
    const { data } = await query;
    setCommerciaux((data ?? []) as Commercial[]);
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch, tenantId]);

  async function save(payload: Omit<Commercial, 'id' | 'created_at'> & { id?: string }) {
    const { id, ...fields } = payload;
    const now = new Date().toISOString();
    if (!navigator.onLine) {
      const recordId = id ?? crypto.randomUUID();
      const queued: QueuedOp = {
        localId: recordId,
        op: 'commercial',
        payload: { ...fields, _id: recordId, _isUpdate: !!id },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: locationId ?? null,
      };
      await queueOp(queued);
      return;
    }
    if (id) {
      const { error } = await supabase.from('commerciaux').update({ ...fields, updated_at: now }).eq('id', id);
      if (error) throw new Error(translateError(error.message));
    } else {
      const recordId = crypto.randomUUID();
      const { error } = await supabase.from('commerciaux').insert({ ...fields, id: recordId, created_at: now, updated_at: now });
      if (error) throw new Error(translateError(error.message));
    }
    await fetch();
  }

  async function remove(id: string) {
    const { error } = await supabase.from('commerciaux').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  return { commerciaux, loading, fetch, save, remove };
}
