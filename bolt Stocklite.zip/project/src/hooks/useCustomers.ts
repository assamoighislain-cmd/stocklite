import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Customer, CustomerContact } from '../types';
import { translateError } from '../lib/translateError';
import { cacheCustomers, getCachedCustomers, cacheCustomerLocally, queueCustomer, getQueuedCustomersForTenant, type QueuedCustomer } from '../lib/offlineDb';
import { syncPendingCustomers } from '../lib/syncManager';

export function useCustomers(locationId?: string | null, tenantId?: string | null) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    const { data, error } = await supabase.from('customers').select('*').order('name');
    if (error) {
      const cached = await getCachedCustomers<Customer>();
      let filtered = cached;
      if (locationId) filtered = filtered.filter(c => c.location_id === locationId);
      setCustomers(filtered);
      setLoading(false);
      return;
    }
    let filtered = (data ?? []) as Customer[];
    if (locationId) filtered = filtered.filter(c => c.location_id === locationId);
    setCustomers(filtered);
    await cacheCustomers(data ?? []);
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => {
      syncPendingCustomers(tenantId ?? null).then(() => fetch());
    };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch, tenantId]);

  async function generateCustomerCode(): Promise<string> {
    const { data, error } = await supabase.rpc('next_customer_code');
    if (error || !data) throw new Error('Impossible de générer le code client');
    return data as string;
  }

  async function save(payload: Omit<Customer, 'id' | 'created_at'> & { location_id?: string | null }, id?: string): Promise<Customer> {
    const now = new Date().toISOString();
    const resolvedLocationId = locationId ?? payload.location_id ?? null;
    const dataPayload = { ...payload, location_id: resolvedLocationId || null } as Omit<Customer, 'id' | 'created_at'>;

    if (id) {
      const { data, error } = await supabase.from('customers').update({ ...dataPayload, updated_at: now }).eq('id', id).select().single();
      if (error) throw new Error(translateError(error.message));
      await fetch();
      return data as Customer;
    }

    if (!navigator.onLine) {
      const code = (dataPayload.code && dataPayload.code.trim()) || `CLI-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
      const localId = crypto.randomUUID();
      const localCustomer: Customer = {
        ...dataPayload,
        id: localId,
        code,
        created_at: now,
      };
      await cacheCustomerLocally(localCustomer);
      const queued: QueuedCustomer = {
        localId,
        payload: { ...dataPayload, code },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
      };
      await queueCustomer(queued);
      setCustomers(prev => [...prev, localCustomer]);
      return localCustomer;
    }

    const code = (dataPayload.code && dataPayload.code.trim()) || await generateCustomerCode();

    const { data, error } = await supabase.from('customers').insert({
      ...dataPayload, code, created_at: now, updated_at: now,
    }).select().single();
    if (error) throw new Error(translateError(error.message));
    await fetch();
    return data as Customer;
  }

  async function remove(id: string) {
    const { error } = await supabase.from('customers').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  async function fetchContacts(customerId: string): Promise<CustomerContact[]> {
    const { data, error } = await supabase
      .from('customer_contacts')
      .select('*')
      .eq('customer_id', customerId)
      .order('is_default', { ascending: false })
      .order('name', { ascending: true });
    if (error) throw new Error(translateError(error.message));
    return (data ?? []) as CustomerContact[];
  }

  async function saveContact(
    payload: Omit<CustomerContact, 'id' | 'created_at' | 'updated_at'>,
    id?: string
  ): Promise<CustomerContact> {
    const now = new Date().toISOString();
    if (payload.is_default) {
      await supabase
        .from('customer_contacts')
        .update({ is_default: false, updated_at: now })
        .eq('customer_id', payload.customer_id)
        .neq('id', id ?? '00000000-0000-0000-0000-000000000000');
    }
    if (id) {
      const { data, error } = await supabase
        .from('customer_contacts')
        .update({ ...payload, updated_at: now })
        .eq('id', id)
        .select()
        .single();
      if (error) throw new Error(translateError(error.message));
      return data as CustomerContact;
    }
    const { data, error } = await supabase
      .from('customer_contacts')
      .insert({ ...payload, created_at: now, updated_at: now })
      .select()
      .single();
    if (error) throw new Error(translateError(error.message));
    return data as CustomerContact;
  }

  async function removeContact(id: string): Promise<void> {
    const { error } = await supabase.from('customer_contacts').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
  }

  return { customers, loading, save, remove, refetch: fetch, fetchContacts, saveContact, removeContact };
}
