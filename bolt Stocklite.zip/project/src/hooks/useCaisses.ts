import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Caisse, CaisseStatus } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface CaisseWithUser extends Caisse {
  user?: { full_name: string; email: string } | null;
}

export function useCaisses(locationId?: string | null) {
  const [caisses, setCaisses] = useState<CaisseWithUser[]>([]);
  const [activeCaisse, setActiveCaisse] = useState<Caisse | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchCaisses = useCallback(async () => {
    let query = supabase.from('caisses').select('*').order('opened_at', { ascending: false });
    if (locationId) query = query.eq('location_id', locationId);
    const { data: rows, error } = await query;
    if (error) return;
    const caisseRows = (rows ?? []) as Caisse[];

    const userIds = [...new Set(caisseRows.map(c => c.user_id).filter(Boolean) as string[])];
    const userMap = new Map<string, { full_name: string; email: string }>();
    if (userIds.length) {
      const { data: profiles } = await supabase.from('user_profiles').select('id, full_name, email');
      for (const p of (profiles ?? []) as { id: string; full_name: string; email: string }[]) {
        if (userIds.includes(p.id)) userMap.set(p.id, { full_name: p.full_name, email: p.email });
      }
    }

    setCaisses(caisseRows.map(c => ({
      ...c,
      user: c.user_id ? userMap.get(c.user_id) ?? null : null,
    })));
  }, [locationId]);

  const fetchActive = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setActiveCaisse(null); return; }
    const { data } = await supabase.from('caisses').select('*').eq('user_id', user.id).eq('status', 'ouverte').order('opened_at', { ascending: false }).limit(1).maybeSingle();
    setActiveCaisse(data ? data as Caisse : null);
  }, []);

  useEffect(() => { fetchCaisses(); fetchActive(); }, [fetchCaisses, fetchActive]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(null).then(() => { fetchCaisses(); fetchActive(); }); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetchCaisses, fetchActive]);

  const openCaisse = useCallback(async (input: {
    opening_amount?: number;
    notes?: string;
  }): Promise<Caisse> => {
    setLoading(true);
    try {
      const now = new Date().toISOString();
      const id = crypto.randomUUID();

      if (!navigator.onLine) {
        await queueOp({ localId: id, op: 'caisse', createdAt: now, status: 'pending', payload: { opening_amount: input.opening_amount ?? 0, notes: input.notes ?? '', _id: id, _isClose: false, _user_id: null, _location_id: locationId ?? null } });
        return { id, user_id: null, ...(locationId ? { location_id: locationId } : {}), status: 'ouverte', opened_at: now, opening_amount: input.opening_amount ?? 0, notes: input.notes ?? '', created_at: now, updated_at: now, closed_at: null, closing_amount: null } as Caisse;
      }

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Session expirée — reconnectez-vous.');
      const payload = {
        id, user_id: user.id,
        ...(locationId ? { location_id: locationId } : {}),
        status: 'ouverte' as const, opened_at: now,
        opening_amount: input.opening_amount ?? 0, notes: input.notes ?? '',
        created_at: now, updated_at: now,
      };
      const { error } = await supabase.from('caisses').insert(payload);
      if (error) throw new Error(translateError(error.message));
      await fetchCaisses();
      await fetchActive();
      return { ...payload, closed_at: null, closing_amount: null } as Caisse;
    } finally { setLoading(false); }
  }, [locationId, fetchCaisses, fetchActive]);

  const closeCaisse = useCallback(async (id: string, input: {
    closing_amount?: number;
    notes?: string;
  }): Promise<void> => {
    setLoading(true);
    try {
      const now = new Date().toISOString();
      const patch = {
        status: 'cloturee' as CaisseStatus, closed_at: now,
        closing_amount: input.closing_amount ?? null, notes: input.notes ?? '',
        updated_at: now,
      };

      if (!navigator.onLine) {
        await queueOp({ localId: id, op: 'caisse', createdAt: now, status: 'pending', payload: { ...patch, _id: id, _isClose: true, _user_id: null, _location_id: locationId ?? null } });
        return;
      }

      const { error } = await supabase.from('caisses').update(patch).eq('id', id);
      if (error) throw new Error(translateError(error.message));
      await fetchCaisses();
      await fetchActive();
    } finally { setLoading(false); }
  }, [fetchCaisses, fetchActive]);

  const deleteCaisse = useCallback(async (id: string): Promise<void> => {
    if (!navigator.onLine) throw new Error('Suppression impossible hors ligne.');
    await supabase.from('pos_sales').update({ caisse_id: null }).eq('caisse_id', id);
    await supabase.from('caisse_closings').update({ caisse_id: null }).eq('caisse_id', id);
    await supabase.from('accounting_entries').update({ caisse_id: null }).eq('caisse_id', id);
    const { error } = await supabase.from('caisses').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetchCaisses();
    await fetchActive();
  }, [fetchCaisses, fetchActive]);

  return { caisses, activeCaisse, loading, openCaisse, closeCaisse, deleteCaisse };
}
