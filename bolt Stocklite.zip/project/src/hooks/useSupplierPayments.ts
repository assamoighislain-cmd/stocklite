import { useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { SupplierPayment, PaymentMethod } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';

export function useSupplierPayments(tenantId?: string | null) {
  const fetchForSupplier = useCallback(async (supplierId: string): Promise<SupplierPayment[]> => {
    const { data } = await supabase.from('supplier_payments').select('*, delivery_note:delivery_notes(id, note_number)').eq('supplier_id', supplierId).order('payment_date', { ascending: false });
    return (data ?? []) as SupplierPayment[];
  }, []);

  const fetchForSupplierByPeriod = useCallback(async (
    supplierId: string,
    startDate: string,
    endDate: string,
  ): Promise<SupplierPayment[]> => {
    const { data } = await supabase.from('supplier_payments').select('*, delivery_note:delivery_notes(id, note_number)')
      .eq('supplier_id', supplierId).gte('payment_date', startDate).lte('payment_date', endDate)
      .order('payment_date', { ascending: false });
    return (data ?? []) as SupplierPayment[];
  }, []);

  async function record(payload: {
    supplier_id: string;
    delivery_note_id: string | null;
    amount: number;
    method: PaymentMethod;
    payment_date: string;
    notes: string;
    location_id: string | null;
  }): Promise<SupplierPayment> {
    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    const { data: { user } } = await supabase.auth.getUser();

    if (!navigator.onLine) {
      const queued: QueuedOp = {
        localId: id,
        op: 'supplierPayment',
        payload: {
          _id: id,
          supplier_id: payload.supplier_id,
          delivery_note_id: payload.delivery_note_id,
          amount: payload.amount,
          method: payload.method,
          payment_date: payload.payment_date,
          notes: payload.notes,
          location_id: payload.location_id,
          created_by: user?.id ?? null,
        },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: payload.location_id ?? null,
      };
      await queueOp(queued);
      return { id, ...payload, created_by: user?.id ?? null, created_at: now, updated_at: now } as SupplierPayment;
    }

    const { data, error } = await supabase.from('supplier_payments').insert({
      id, supplier_id: payload.supplier_id, delivery_note_id: payload.delivery_note_id,
      amount: payload.amount, method: payload.method, payment_date: payload.payment_date,
      notes: payload.notes, location_id: payload.location_id,
      created_by: user?.id ?? null, created_at: now, updated_at: now,
    }).select('*, delivery_note:delivery_notes(id, note_number)').single();
    if (error) throw new Error(translateError(error.message));
    return data as SupplierPayment;
  }

  async function remove(id: string) {
    const { error } = await supabase.from('supplier_payments').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
  }

  return { fetchForSupplier, fetchForSupplierByPeriod, record, remove };
}
