import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Product, ProductSupplier } from '../types';
import { translateError } from '../lib/translateError';
import { cacheProducts, getCachedProducts, queueOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

const FAMILY_COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#14b8a6',
  '#3b82f6', '#8b5cf6', '#ec4899', '#6b7280', '#0ea5e9',
];

export function useProducts(locationId?: string | null) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    try {
      if (locationId) {
        // When a location is selected, load the full tenant catalog from products,
        // then merge in location_stock data for the selected depot. Products without
        // a location_stock row for this depot still appear, with 0 stock.
        const PAGE = 1000;
        let allProducts: Product[] = [];
        let from = 0;
        while (true) {
          const res = await supabase
            .from('products')
            .select('*')
            .order('name')
            .range(from, from + PAGE - 1);
          if (res.error) throw res.error;
          allProducts.push(...(res.data as Product[]));
          if (res.data.length < PAGE) break;
          from += PAGE;
        }

        // Fetch location_stock for the selected depot
        const lsMap = new Map<string, { stock_quantity: number; stock_min: number; price: number | null }>();
        {
          let lsFrom = 0;
          const lsPage = 1000;
          while (true) {
            const lsRes = await supabase
              .from('location_stock')
              .select('product_id, stock_quantity, stock_min, price')
              .eq('location_id', locationId)
              .range(lsFrom, lsFrom + lsPage - 1);
            if (lsRes.error) throw lsRes.error;
            for (const row of (lsRes.data ?? []) as Record<string, unknown>[]) {
              lsMap.set(row.product_id as string, {
                stock_quantity: row.stock_quantity as number,
                stock_min: row.stock_min as number,
                price: row.price as number | null,
              });
            }
            if ((lsRes.data ?? []).length < lsPage) break;
            lsFrom += lsPage;
          }
        }

        // Filter to only products that have a location_stock row for this depot.
        // Products not assigned to the selected point de vente are excluded.
        allProducts = allProducts
          .filter(p => lsMap.has(p.id))
          .map(p => {
            const ls = lsMap.get(p.id)!;
            return {
              ...p,
              stock_quantity: ls.stock_quantity,
              stock_min: ls.stock_min,
              price: ls.price != null && Number(ls.price) > 0 ? ls.price : p.price,
            };
          });

        // Fetch product-supplier links, per-location price types, and global price types.
        // Use pagination instead of .in('product_id', [...]) — with large catalogs (5000+ products)
        // the URL would exceed PostgREST's limit and the query would fail.
        const psMap = new Map<string, ProductSupplier[]>();
        {
          let psFrom = 0;
          const psPageSize = 1000;
          while (true) {
            const { data: psPage } = await supabase.from('product_suppliers')
              .select('product_id, supplier_id, is_default, supply_price, supply_unit, supplier:id(name, phone, email)')
              .order('is_default', { ascending: false })
              .range(psFrom, psFrom + psPageSize - 1);
            if (!psPage || psPage.length === 0) break;
            for (const ps of psPage as Record<string, unknown>[]) {
              const pid = ps.product_id as string;
              if (!psMap.has(pid)) psMap.set(pid, []);
              const supplier = ps.supplier as { id: string; name: string; phone: string; email: string } | null;
              psMap.get(pid)!.push({
                product_id: pid,
                supplier_id: ps.supplier_id as string,
                is_default: ps.is_default as boolean,
                supply_price: ps.supply_price != null ? Number(ps.supply_price) : null,
                supply_unit: (ps.supply_unit as string | null) ?? null,
                supplier: supplier ? { id: supplier.id, name: supplier.name, phone: supplier.phone, email: supplier.email } : undefined,
              });
            }
            if (psPage.length < psPageSize) break;
            psFrom += psPageSize;
          }
        }

        // Per-location price type overrides (scoped by location_id, no .in() needed)
        const locPriceMap = new Map<string, Map<string, number>>();
        {
          const { data: lpptData } = await supabase.from('location_product_price_types')
            .select('*')
            .eq('location_id', locationId);
          for (const lp of (lpptData ?? []) as Record<string, unknown>[]) {
            let inner = locPriceMap.get(lp.product_id as string);
            if (!inner) { inner = new Map(); locPriceMap.set(lp.product_id as string, inner); }
            inner.set(lp.price_type_id as string, lp.price as number);
          }
        }

        // Global price type prices (paginated, no .in() filter)
        const globalPriceMap = new Map<string, Map<string, number>>();
        {
          let pptFrom = 0;
          const pptPageSize = 1000;
          while (true) {
            const { data: pptPage } = await supabase.from('product_price_types')
              .select('*')
              .range(pptFrom, pptFrom + pptPageSize - 1);
            if (!pptPage || pptPage.length === 0) break;
            for (const pt of pptPage as Record<string, unknown>[]) {
              let inner = globalPriceMap.get(pt.product_id as string);
              if (!inner) { inner = new Map(); globalPriceMap.set(pt.product_id as string, inner); }
              inner.set(pt.price_type_id as string, pt.price as number);
            }
            if (pptPage.length < pptPageSize) break;
            pptFrom += pptPageSize;
          }
        }

        allProducts = allProducts.map(p => {
          const lpMap = locPriceMap.get(p.id);
          const gptMap = globalPriceMap.get(p.id);
          const prices = (p.prices ?? []).map(pr => {
            const lpPrice = lpMap?.get(pr.price_type_id);
            const gptPrice = gptMap?.get(pr.price_type_id);
            return {
              ...pr,
              price: lpPrice != null ? lpPrice : (gptPrice != null ? gptPrice : pr.price),
            };
          });
          // Also add price types that exist in DB but not in the product's prices array
          if (gptMap) {
            for (const [ptId, ptPrice] of gptMap) {
              if (!prices.some(pr => pr.price_type_id === ptId)) {
                const lpPrice = lpMap?.get(ptId);
                prices.push({
                  id: `${p.id}_${ptId}`,
                  product_id: p.id,
                  price_type_id: ptId,
                  price: lpPrice != null ? lpPrice : ptPrice,
                  created_at: '',
                } as import('../types').ProductPriceType);
              }
            }
          }
          return {
            ...p,
            suppliers: psMap.get(p.id) ?? [],
            prices,
          };
        });

        allProducts.sort((a, b) => a.name.localeCompare(b.name));
        setProducts(allProducts);
        await cacheProducts(allProducts);
        setLoading(false);
        return;
      }

      // No location selected — load full tenant catalog
      let allProducts: Product[] = [];
      const pageSize = 1000;
      let from = 0;
      while (true) {
        const res = await supabase.from('products').select('*').order('name').range(from, from + pageSize - 1);
        if (res.error) {
          const cached = await getCachedProducts<Product>();
          setProducts(cached);
          setLoading(false);
          return;
        }
        allProducts.push(...(res.data as Product[]));
        if (res.data.length < pageSize) break;
        from += pageSize;
      }

      // Fetch product-supplier links (paginated for large catalogs)
      const psMap = new Map<string, ProductSupplier[]>();
      {
        let psFrom = 0;
        const psPageSize = 1000;
        while (true) {
          const { data: psPage } = await supabase.from('product_suppliers')
            .select('product_id, supplier_id, is_default, supply_price, supply_unit, supplier:id(name, phone, email)')
            .order('is_default', { ascending: false })
            .range(psFrom, psFrom + psPageSize - 1);
          if (!psPage || psPage.length === 0) break;
          for (const ps of psPage as Record<string, unknown>[]) {
            const pid = ps.product_id as string;
            if (!psMap.has(pid)) psMap.set(pid, []);
            const supplier = ps.supplier as { id: string; name: string; phone: string; email: string } | null;
            psMap.get(pid)!.push({
              product_id: pid,
              supplier_id: ps.supplier_id as string,
              is_default: ps.is_default as boolean,
              supply_price: ps.supply_price != null ? Number(ps.supply_price) : null,
              supply_unit: (ps.supply_unit as string | null) ?? null,
              supplier: supplier ? { id: supplier.id, name: supplier.name, phone: supplier.phone, email: supplier.email } : undefined,
            });
          }
          if (psPage.length < psPageSize) break;
          psFrom += psPageSize;
        }
      }
      allProducts = allProducts.map(p => ({
        ...p,
        suppliers: psMap.get(p.id) ?? [],
      }));

      setProducts(allProducts);
      await cacheProducts(allProducts);
    } catch {
      const cached = await getCachedProducts<Product>();
      setProducts(cached);
    }
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch]);

  async function save(payload: Omit<Product, 'id' | 'created_at' | 'family' | 'prices' | 'suppliers'>, id?: string): Promise<string> {
    const { stock_quantity, stock_min, price, ...globalPayload } = payload;
    const now = new Date().toISOString();
    const recordId = id ?? crypto.randomUUID();

    if (!globalPayload.reference) {
      const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const rand = crypto.randomUUID().slice(0, 8).toUpperCase();
      globalPayload.reference = `REF-${dateStr}-${rand}`;
    }

    if (!navigator.onLine) {
      await queueOp({ localId: recordId, op: 'product', createdAt: now, status: 'pending', payload: { ...globalPayload, _id: recordId, _isUpdate: !!id, _location_id: locationId ?? null, _stock_quantity: stock_quantity, _stock_min: stock_min, _price: price } });
      return recordId;
    }

    if (globalPayload.reference) {
      let refQ = supabase.from('products').select('id, name').eq('reference', globalPayload.reference);
      if (id) refQ = refQ.neq('id', id);
      const { data: refMatch } = await refQ;
      if (refMatch && refMatch.length > 0) {
        let conflicting: typeof refMatch = [];
        if (locationId) {
          const { data: lsData } = await supabase.from('location_stock')
            .select('product_id').eq('location_id', locationId)
            .in('product_id', refMatch.map(p => p.id));
          const locProductIds = new Set((lsData ?? []).map(r => r.product_id));
          conflicting = refMatch.filter(p => locProductIds.has(p.id));
        } else {
          conflicting = refMatch;
        }
        if (conflicting.length > 0) {
          throw new Error(`La référence « ${globalPayload.reference} » est déjà utilisée par « ${conflicting[0].name} »`);
        }
      }
    }

    if (id) {
      const { error } = await supabase.from('products').update({ ...globalPayload, price, stock_quantity, stock_min, updated_at: now }).eq('id', id);
      if (error) throw new Error(translateError(error.message));

      if (locationId) {
        const lsId = `${id}_${locationId}`;
        const { error: lsErr } = await supabase.from('location_stock').upsert({
          id: lsId, product_id: id, location_id: locationId,
          stock_quantity, stock_min, price, updated_at: now,
        });
        if (lsErr) throw new Error(lsErr.message);
      }
    } else {
      const { error } = await supabase.from('products').insert({
        ...globalPayload, id: recordId, price, stock_quantity, stock_min,
        created_at: now, updated_at: now,
      });
      if (error) throw new Error(translateError(error.message));

      if (locationId) {
        const lsId = `${recordId}_${locationId}`;
        const { error: lsErr } = await supabase.from('location_stock').insert({
          id: lsId, product_id: recordId, location_id: locationId,
          stock_quantity, stock_min, price, updated_at: now,
        });
        if (lsErr) throw new Error(lsErr.message);
      }
    }
    await fetch();
    return recordId;
  }

  async function remove(id: string) {
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  async function bulkImport(
    rows: { family: string; name: string; reference?: string; stock: number; price: number; purchase_price: number; priceTypePrices?: Record<string, number> }[],
    targetLocationId?: string | null,
    onProgress?: (current: number, total: number) => void,
  ): Promise<{ created: number; updated: number; familiesCreated: number }> {
    if (!navigator.onLine) throw new Error('Import en masse impossible hors ligne — reconnectez-vous.');
    const now = new Date().toISOString();
    const { data: existingFams } = await supabase.from('product_families').select('*');
    const famByName = new Map((existingFams ?? []).map(f => [f.name.toLowerCase().trim(), f]));

    // 1. Pre-create all missing families in a single batch
    const newFamilies: Record<string, unknown>[] = [];
    for (const row of rows) {
      const famName = row.family.trim();
      if (!famName) continue;
      const key = famName.toLowerCase();
      if (!famByName.has(key)) {
        const id = crypto.randomUUID();
        const color = FAMILY_COLORS[famByName.size % FAMILY_COLORS.length];
        newFamilies.push({ id, name: famName, color, sort_order: famByName.size, created_at: now, updated_at: now });
        famByName.set(key, { id, name: famName, color, sort_order: famByName.size });
      }
    }
    if (newFamilies.length > 0) {
      const { error } = await supabase.from('product_families').insert(newFamilies);
      if (error) throw new Error(translateError(error.message));
    }

    // 2. Build all product + location_stock rows
    const productRows: Record<string, unknown>[] = [];
    const stockRows: Record<string, unknown>[] = [];
    const priceTypeRows: Record<string, unknown>[] = [];
    const locPriceTypeRows: Record<string, unknown>[] = [];
    const productMeta: { productId: string; ptPrices: Record<string, number> }[] = [];

    for (const row of rows) {
      const name = row.name.trim();
      if (!name) continue;

      const famName = row.family.trim();
      const familyId = famName ? famByName.get(famName.toLowerCase())?.id ?? null : null;
      const price = row.price || 0;
      const purchasePrice = row.purchase_price || 0;
      const stock = row.stock || 0;
      const reference = row.reference?.trim() || '';
      const ptPrices = row.priceTypePrices ?? {};
      const productId = crypto.randomUUID();
      const trackStock = stock > 0;

      productRows.push({
        id: productId, name, reference: reference || null, description: '', unit: 'pcs',
        price, purchase_price: purchasePrice, stock_quantity: stock, stock_min: 0,
        track_stock: trackStock, active: true, family_id: familyId,
        created_at: now, updated_at: now,
      });

      if (targetLocationId) {
        stockRows.push({
          id: `${productId}_${targetLocationId}`, product_id: productId, location_id: targetLocationId,
          stock_quantity: stock, stock_min: 0, price, updated_at: now,
        });
      }

      for (const [ptId, ptPrice] of Object.entries(ptPrices)) {
        if (ptPrice <= 0) continue;
        priceTypeRows.push({
          product_id: productId, price_type_id: ptId, price: ptPrice, updated_at: now,
        });
        if (targetLocationId) {
          locPriceTypeRows.push({
            id: `${productId}_${targetLocationId}_${ptId}`, product_id: productId, location_id: targetLocationId,
            price_type_id: ptId, price: ptPrice, updated_at: now,
          });
        }
      }

      productMeta.push({ productId, ptPrices });
    }

    const totalItems = productRows.length;

    // 3. Batch insert products (chunks of 200)
    const BATCH = 200;
    for (let i = 0; i < productRows.length; i += BATCH) {
      const chunk = productRows.slice(i, i + BATCH);
      const { error } = await supabase.from('products').insert(chunk);
      if (error) throw new Error(translateError(error.message));
      if (onProgress) onProgress(Math.min(i + BATCH, totalItems), totalItems);
    }

    // 4. Batch insert location_stock (chunks of 200)
    for (let i = 0; i < stockRows.length; i += BATCH) {
      const chunk = stockRows.slice(i, i + BATCH);
      const { error } = await supabase.from('location_stock').insert(chunk);
      if (error) throw new Error(translateError(error.message));
    }

    // 5. Batch upsert price type prices
    if (priceTypeRows.length > 0) {
      for (let i = 0; i < priceTypeRows.length; i += BATCH) {
        const chunk = priceTypeRows.slice(i, i + BATCH);
        const { error } = await supabase.from('product_price_types').upsert(chunk, { onConflict: 'product_id,price_type_id' });
        if (error) throw new Error(translateError(error.message));
      }
    }

    // 6. Batch upsert location price type prices
    if (locPriceTypeRows.length > 0) {
      for (let i = 0; i < locPriceTypeRows.length; i += BATCH) {
        const chunk = locPriceTypeRows.slice(i, i + BATCH);
        const { error } = await supabase.from('location_product_price_types').upsert(chunk, { onConflict: 'id' });
        if (error) throw new Error(translateError(error.message));
      }
    }

    if (onProgress) onProgress(totalItems, totalItems);
    await fetch();
    return { created: productRows.length, updated: 0, familiesCreated: newFamilies.length };
  }

  async function fetchProductLocations(productId: string): Promise<{
    location_id: string; price: number | null; stock_quantity: number; stock_min: number;
  }[]> {
    const { data } = await supabase.from('location_stock').select('*').eq('product_id', productId);
    return (data ?? []).map(r => ({
      location_id: r.location_id, price: r.price,
      stock_quantity: r.stock_quantity, stock_min: r.stock_min,
    }));
  }

  async function saveProductLocations(
    productId: string,
    entries: { location_id: string; price: number; stock_quantity: number; stock_min: number }[],
    removedLocationIds: string[]
  ): Promise<void> {
    if (!navigator.onLine) throw new Error('Modification du stock par boutique impossible hors ligne — reconnectez-vous.');
    const now = new Date().toISOString();
    for (const e of entries) {
      const lsId = `${productId}_${e.location_id}`;
      await supabase.from('location_stock').upsert({
        id: lsId, product_id: productId, location_id: e.location_id,
        stock_quantity: e.stock_quantity, stock_min: e.stock_min,
        price: e.price, updated_at: now,
      });
    }
    for (const locId of removedLocationIds) {
      const lsId = `${productId}_${locId}`;
      await supabase.from('location_stock').delete().eq('id', lsId);
    }
    await fetch();
  }

  async function fetchProductSuppliers(productId: string): Promise<ProductSupplier[]> {
    const { data } = await supabase.from('product_suppliers')
      .select('product_id, supplier_id, is_default, supply_price, supply_unit, supplier:id(name, phone, email)')
      .eq('product_id', productId)
      .order('is_default', { ascending: false });
    return ((data ?? []) as Record<string, unknown>[]).map(ps => {
      const supplier = ps.supplier as { id: string; name: string; phone: string; email: string } | null;
      return {
        product_id: ps.product_id as string,
        supplier_id: ps.supplier_id as string,
        is_default: ps.is_default as boolean,
        supply_price: ps.supply_price != null ? Number(ps.supply_price) : null,
        supply_unit: (ps.supply_unit as string | null) ?? null,
        supplier: supplier ? { id: supplier.id, name: supplier.name, phone: supplier.phone, email: supplier.email } : undefined,
      };
    });
  }

  async function saveProductSuppliers(
    productId: string,
    entries: { supplier_id: string; is_default: boolean; supply_price: number | null; supply_unit: string | null }[],
  ): Promise<void> {
    if (!navigator.onLine) throw new Error('Modification des fournisseurs impossible hors ligne — reconnectez-vous.');
    await supabase.from('product_suppliers').delete().eq('product_id', productId);
    if (entries.length === 0) { await fetch(); return; }
    const rows = entries.map(e => ({
      product_id: productId,
      supplier_id: e.supplier_id,
      is_default: e.is_default,
      supply_price: e.supply_price,
      supply_unit: e.supply_unit,
    }));
    const { error } = await supabase.from('product_suppliers').upsert(rows, { onConflict: 'product_id,supplier_id' });
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  return { products, loading, save, remove, bulkImport, refetch: fetch, fetchProductLocations, saveProductLocations, fetchProductSuppliers, saveProductSuppliers };
}
