import { useState, useEffect, useCallback } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import type { UserProfile, UserRole } from '../types';
import { translateError } from '../lib/translateError';
import { setMeta, getMeta } from '../lib/offlineDb';

export function useAuth() {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (userId: string) => {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*, location:sales_locations(*), commercial:commerciaux(*)')
      .eq('id', userId)
      .maybeSingle();
    if (error) {
      const cached = await getMeta<UserProfile>('user_profile');
      setProfile(cached ?? null);
      return;
    }
    const p = data as UserProfile | null;
    setProfile(p);
    if (p) await setMeta('user_profile', p);
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      if (s?.user) {
        (async () => {
          await fetchProfile(s.user.id);
          setLoading(false);
        })();
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s);
      if (s?.user) {
        (async () => { await fetchProfile(s.user.id); })();
      } else {
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchProfile]);

  async function signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(translateError(error.message));
  }

  async function signUp(email: string, password: string, fullName: string, role: UserRole, companyName?: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName, role, company_name: companyName?.trim() || null } },
    });
    if (error) throw new Error(translateError(error.message));

    if (data.session) {
      supabase.functions.invoke('whatsapp-notify', {
        body: { full_name: fullName, email, company_name: companyName?.trim() || null },
      }).catch(() => {});

      supabase.functions.invoke('send-push', {
        body: {
          title: 'Nouvelle demande de compte',
          body: `${fullName} (${email}) demande l'accès${companyName?.trim() ? ` pour "${companyName.trim()}"` : ''}`,
          company_name: companyName?.trim() || null,
          url: '/',
        },
      }).catch(() => {});
    }
  }

  async function signOut(): Promise<{ hadPendingData: boolean }> {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      console.warn('signOut error', e);
    }
    setSession(null);
    setProfile(null);
    await supabase.auth.signOut({ scope: 'local' });
    return { hadPendingData: false };
  }

  async function refreshProfile() {
    if (session?.user) await fetchProfile(session.user.id);
  }

  return { session, profile, loading, signIn, signUp, signOut, refreshProfile };
}
