import { useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Payment, PaymentMethod } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export function usePayments() {
  const fetchForCustomer = useCallback(async (customerId: string): Promise<Payment[]> => {
    const { data } = await supabase.from('payments').select('*').eq('customer_id', customerId).order('payment_date', { ascending: false });
    const rows = (data ?? []) as Payment[];
    const result: Payment[] = [];
    for (const p of rows) {
      let invoice: Payment['invoice'] = undefined;
      if (p.invoice_id) {
        const { data: inv } = await supabase.from('invoices').select('id, invoice_number, total').eq('id', p.invoice_id).maybeSingle();
        if (inv) invoice = inv as Payment['invoice'];
      }
      result.push({ ...p, invoice });
    }
    return result;
  }, []);

  async function record(payload: {
    customer_id: string;
    invoice_id: string | null;
    amount: number;
    method: PaymentMethod;
    payment_date: string;
    notes: string;
  }): Promise<Payment> {
    const now = new Date().toISOString();

    if (!navigator.onLine) {
      const localId = crypto.randomUUID();
      await queueOp({ localId, op: 'payment', createdAt: now, status: 'pending', payload: { ...payload, _id: localId } });
      return { ...payload, id: localId, created_at: now, updated_at: now } as Payment;
    }

    const { data, error } = await supabase.from('payments').insert({
      customer_id: payload.customer_id,
      invoice_id: payload.invoice_id,
      amount: payload.amount,
      method: payload.method,
      payment_date: payload.payment_date,
      notes: payload.notes,
      created_at: now,
      updated_at: now,
    }).select().single();
    if (error) throw new Error(translateError(error.message));
    const record = data as Payment;

    if (payload.invoice_id) {
      const { data: inv } = await supabase.from('invoices').select('total, amount_paid').eq('id', payload.invoice_id).maybeSingle() as { data: { total: number; amount_paid: number } | null };
      if (inv) {
        const newPaid = Math.min(Number(inv.total), Number(inv.amount_paid) + payload.amount);
        const status = newPaid >= Number(inv.total) ? 'payee' : 'partielle';
        await supabase.from('invoices').update({
          amount_paid: newPaid, status, updated_at: now,
        }).eq('id', payload.invoice_id);
      }
    }

    return record;
  }

  async function remove(id: string) {
    const { error } = await supabase.from('payments').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
  }

  return { fetchForCustomer, record, remove };
}
