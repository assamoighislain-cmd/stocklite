import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Deconditioning, Product, SalesLocation } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface CreateDeconditioningInput {
  pack_product_id: string;
  detail_product_id: string;
  pack_quantity: number;
  units_per_pack: number;
  location_id: string | null;
  notes: string;
}

export function useDeconditioning(locationId?: string | null) {
  const [deconditionings, setDeconditionings] = useState<Deconditioning[]>([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    let query = supabase.from('deconditionings').select('*').order('created_at', { ascending: false }).limit(200);
    if (locationId) query = query.eq('location_id', locationId);
    const { data: rows, error } = await query;
    if (error) { setLoading(false); return; }
    const dcRows = (rows ?? []) as Deconditioning[];

    const productIds = [...new Set([
      ...dcRows.map(d => d.pack_product_id).filter(Boolean) as string[],
      ...dcRows.map(d => d.detail_product_id).filter(Boolean) as string[],
    ])];
    const locationIds = [...new Set(dcRows.map(d => d.location_id).filter(Boolean) as string[])];

    const [prodsRes, locsRes] = await Promise.all([
      productIds.length ? supabase.from('products').select('id, name, unit').in('id', productIds) : Promise.resolve({ data: [] }),
      locationIds.length ? supabase.from('sales_locations').select('id, name').in('id', locationIds) : Promise.resolve({ data: [] }),
    ]);

    const prodMap = new Map((prodsRes.data ?? []).map(p => [p.id, p] as [string, Product]));
    const locMap = new Map((locsRes.data ?? []).map(l => [l.id, l] as [string, SalesLocation]));

    setDeconditionings(dcRows.map(d => ({
      ...d,
      pack_product: prodMap.get(d.pack_product_id) ? { id: d.pack_product_id, name: prodMap.get(d.pack_product_id)!.name, unit: prodMap.get(d.pack_product_id)!.unit } : undefined,
      detail_product: prodMap.get(d.detail_product_id) ? { id: d.detail_product_id, name: prodMap.get(d.detail_product_id)!.name, unit: prodMap.get(d.detail_product_id)!.unit } : undefined,
      location: d.location_id ? (locMap.get(d.location_id) ? { id: d.location_id, name: locMap.get(d.location_id)!.name } : undefined) : undefined,
    })));
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch]);

  async function execute(input: CreateDeconditioningInput): Promise<void> {
    const { pack_product_id, detail_product_id, pack_quantity, units_per_pack, location_id, notes } = input;
    const now = new Date().toISOString();
    const detailQty = pack_quantity * units_per_pack;
    const localId = crypto.randomUUID();

    if (!navigator.onLine) {
      await queueOp({ localId, op: 'deconditioning', createdAt: now, status: 'pending', payload: { pack_product_id, detail_product_id, pack_quantity, units_per_pack, location_id: location_id ?? null, notes, _id: localId, _user_id: null } });
      return;
    }

    // Decrease pack stock
    if (location_id) {
      const packLsId = `${pack_product_id}_${location_id}`;
      const { data: packLs } = await supabase.from('location_stock').select('*').eq('id', packLsId).maybeSingle();
      const packQty = Number(packLs?.stock_quantity ?? 0);
      const newPackQty = Math.max(0, packQty - pack_quantity);
      await supabase.from('location_stock').upsert({
        id: packLsId, product_id: pack_product_id, location_id: location_id,
        stock_quantity: newPackQty, stock_min: packLs?.stock_min ?? 0,
        price: packLs?.price ?? null, updated_at: now,
      });

      // Increase detail stock
      const detailLsId = `${detail_product_id}_${location_id}`;
      const { data: detailLs } = await supabase.from('location_stock').select('*').eq('id', detailLsId).maybeSingle();
      const detailCurrent = Number(detailLs?.stock_quantity ?? 0);
      await supabase.from('location_stock').upsert({
        id: detailLsId, product_id: detail_product_id, location_id: location_id,
        stock_quantity: detailCurrent + detailQty, stock_min: detailLs?.stock_min ?? 0,
        price: detailLs?.price ?? null, updated_at: now,
      });
    } else {
      const { data: packProd } = await supabase.from('products').select('stock_quantity').eq('id', pack_product_id).maybeSingle();
      const packQty = Number(packProd?.stock_quantity ?? 0);
      await supabase.from('products').update({ stock_quantity: Math.max(0, packQty - pack_quantity), updated_at: now }).eq('id', pack_product_id);

      const { data: detailProd } = await supabase.from('products').select('stock_quantity').eq('id', detail_product_id).maybeSingle();
      const detailCurrent = Number(detailProd?.stock_quantity ?? 0);
      await supabase.from('products').update({ stock_quantity: detailCurrent + detailQty, updated_at: now }).eq('id', detail_product_id);
    }

    // Record stock movements
    const { data: { user } } = await supabase.auth.getUser();

    await supabase.from('stock_movements').insert({
      id: crypto.randomUUID(), product_id: pack_product_id, type: 'sortie',
      quantity: pack_quantity, unit_cost: 0,
      reference: 'Déconditionnement', notes: notes || `Déconditionné en ${detailQty} unités`,
      ...(location_id ? { location_id } : {}),
      created_at: now, updated_at: now,
    });

    await supabase.from('stock_movements').insert({
      id: crypto.randomUUID(), product_id: detail_product_id, type: 'entree',
      quantity: detailQty, unit_cost: 0,
      reference: 'Déconditionnement', notes: notes || `Issu de ${pack_quantity} pack(s)`,
      ...(location_id ? { location_id } : {}),
      created_at: now, updated_at: now,
    });

    const { error } = await supabase.from('deconditionings').insert({
      id: crypto.randomUUID(), pack_product_id, detail_product_id,
      pack_quantity, units_per_pack,
      location_id: location_id ?? null,
      notes, created_by: user?.id ?? null,
      created_at: now, updated_at: now,
    });
    if (error) throw new Error(translateError(error.message));

    await fetch();
  }

  return { deconditionings, loading, fetch, execute };
}
