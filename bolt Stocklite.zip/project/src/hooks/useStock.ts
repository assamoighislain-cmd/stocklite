import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { StockMovement, StockMovementType, Product } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export function useStock(locationId?: string | null) {
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchMovements = useCallback(async () => {
    let query = supabase.from('stock_movements').select('*').order('created_at', { ascending: false }).limit(200);
    if (locationId) query = query.eq('location_id', locationId);
    const { data: rows, error } = await query;
    if (error) { setLoading(false); return; }
    const mvRows = (rows ?? []) as StockMovement[];

    const productIds = [...new Set(mvRows.map(m => m.product_id).filter(Boolean) as string[])];
    const prodMap = new Map<string, Product>();
    if (productIds.length) {
      const { data: prods } = await supabase.from('products').select('*');
      for (const p of (prods ?? []) as Product[]) if (productIds.includes(p.id)) prodMap.set(p.id, p);
    }

    const stockAfterMap = new Map<string, number>();
    if (locationId && productIds.length) {
      const { data: lsRows } = await supabase.from('location_stock').select('product_id, stock_quantity').eq('location_id', locationId);
      for (const ls of (lsRows ?? []) as { product_id: string; stock_quantity: number }[]) {
        stockAfterMap.set(ls.product_id, Number(ls.stock_quantity));
      }
    } else if (!locationId && productIds.length) {
      for (const pid of productIds) {
        const p = prodMap.get(pid);
        if (p) stockAfterMap.set(pid, Number(p.stock_quantity));
      }
    }

    const withStockAfter: StockMovement[] = mvRows.map(m => {
      let current = stockAfterMap.get(m.product_id) ?? null;
      if (current !== null) {
        const qty = Number(m.quantity);
        if (m.type === 'entree' || m.type === 'retour') current -= qty;
        else if (m.type === 'sortie' || m.type === 'vente') current += qty;
        stockAfterMap.set(m.product_id, current);
      }
      return {
        ...m,
        product: prodMap.get(m.product_id) ? { id: m.product_id, name: prodMap.get(m.product_id)!.name, unit: prodMap.get(m.product_id)!.unit } : undefined,
        stock_after: current,
      };
    });
    setMovements(withStockAfter);
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetchMovements(); }, [fetchMovements]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(null).then(() => fetchMovements()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetchMovements]);

  async function addMovement(payload: {
    product_id: string;
    type: StockMovementType;
    quantity: number;
    unit_cost?: number;
    reference?: string;
    notes?: string;
  }): Promise<void> {
    const now = new Date().toISOString();
    const mvId = crypto.randomUUID();

    if (!navigator.onLine) {
      await queueOp({ localId: mvId, op: 'stockMovement', createdAt: now, status: 'pending', payload: { ...payload, _id: mvId, _location_id: locationId ?? null } });
      return;
    }

    const { error } = await supabase.from('stock_movements').insert({
      id: mvId, product_id: payload.product_id, type: payload.type,
      quantity: payload.quantity, unit_cost: payload.unit_cost ?? 0,
      reference: payload.reference ?? '', notes: payload.notes ?? '',
      created_at: now, updated_at: now,
      ...(locationId ? { location_id: locationId } : {}),
    });
    if (error) throw new Error(translateError(error.message));

    if (locationId) {
      const lsId = `${payload.product_id}_${locationId}`;
      const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
      const current = Number(ls?.stock_quantity ?? 0);
      let newQty: number;
      if (payload.type === 'entree') newQty = current + payload.quantity;
      else if (payload.type === 'sortie' || payload.type === 'vente') newQty = Math.max(0, current - payload.quantity);
      else newQty = payload.quantity;
      await supabase.from('location_stock').upsert({
        id: lsId, product_id: payload.product_id, location_id: locationId,
        stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
        price: ls?.price ?? null, updated_at: now,
      });
    } else {
      const { data: prod } = await supabase.from('products').select('stock_quantity').eq('id', payload.product_id).maybeSingle();
      const current = Number(prod?.stock_quantity ?? 0);
      let newQty: number;
      if (payload.type === 'entree') newQty = current + payload.quantity;
      else if (payload.type === 'sortie' || payload.type === 'vente') newQty = Math.max(0, current - payload.quantity);
      else newQty = payload.quantity;
      await supabase.from('products').update({ stock_quantity: Math.max(0, newQty), updated_at: now }).eq('id', payload.product_id);
    }
    await fetchMovements();
  }

  async function fetchLowStock(): Promise<Product[]> {
    if (locationId) {
      const { data: stocks } = await supabase.from('location_stock').select('product_id, stock_quantity, stock_min').eq('location_id', locationId);
      const productIds = (stocks ?? []).map(s => s.product_id);
      const { data: products } = await supabase.from('products').select('*').in('id', productIds);
      const prodMap = new Map((products ?? []).map(p => [p.id, p as Product]));
      return (stocks ?? [])
        .map(s => prodMap.get(s.product_id))
        .filter((p): p is Product => !!p && p.track_stock && p.active && (p.stock_quantity <= p.stock_min));
    }
    const { data: all } = await supabase.from('products').select('*');
    return (all ?? []).filter(p => p.track_stock && p.active && p.stock_quantity <= p.stock_min) as Product[];
  }

  async function validateInventory(entries: { product_id: string; real_quantity: number; notes?: string }[]): Promise<void> {
    const now = new Date().toISOString();
    for (const entry of entries) {
      const current = await getCurrentStock(entry.product_id);
      const ecart = Math.round((entry.real_quantity - current) * 100) / 100;
      if (ecart === 0) continue;

      const mvId = crypto.randomUUID();
      const mvType: StockMovementType = ecart > 0 ? 'ajustement' : 'ajustement';
      const absQty = Math.abs(ecart);

      const { error: mvErr } = await supabase.from('stock_movements').insert({
        id: mvId, product_id: entry.product_id, type: mvType,
        quantity: absQty, unit_cost: 0,
        reference: 'INVENTAIRE',
        notes: entry.notes || (ecart > 0 ? `Inventaire: +${absQty}` : `Inventaire: -${absQty}`),
        created_at: now, updated_at: now,
        ...(locationId ? { location_id: locationId } : {}),
      });
      if (mvErr) throw new Error(translateError(mvErr.message));

      if (locationId) {
        const lsId = `${entry.product_id}_${locationId}`;
        const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
        const lsCurrent = Number(ls?.stock_quantity ?? 0);
        await supabase.from('location_stock').upsert({
          id: lsId, product_id: entry.product_id, location_id: locationId,
          stock_quantity: Math.max(0, entry.real_quantity), stock_min: ls?.stock_min ?? 0,
          price: ls?.price ?? null, updated_at: now,
        });
      } else {
        await supabase.from('products').update({ stock_quantity: Math.max(0, entry.real_quantity), updated_at: now }).eq('id', entry.product_id);
      }
    }
    await fetchMovements();
  }

  async function getCurrentStock(productId: string): Promise<number> {
    if (locationId) {
      const lsId = `${productId}_${locationId}`;
      const { data: ls } = await supabase.from('location_stock').select('stock_quantity').eq('id', lsId).maybeSingle();
      return Number(ls?.stock_quantity ?? 0);
    }
    const { data: prod } = await supabase.from('products').select('stock_quantity').eq('id', productId).maybeSingle();
    return Number(prod?.stock_quantity ?? 0);
  }

  return { movements, loading, fetchMovements, addMovement, fetchLowStock, validateInventory };
}
