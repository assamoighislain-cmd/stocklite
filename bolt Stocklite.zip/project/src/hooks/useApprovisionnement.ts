import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Supplier, DeliveryNote, DeliveryNoteItem, Product } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface SupplierInput {
  name: string;
  phone: string;
  email: string;
  address: string;
  active: boolean;
}

export interface DeliveryNoteItemInput {
  product_id: string;
  location_id: string | null;
  quantity: number;
  unit_cost: number;
}

export interface DeliveryNoteInput {
  note_number: string;
  supplier_id: string;
  location_id: string | null;
  note_date: string;
  notes: string;
  items: DeliveryNoteItemInput[];
}

export function useApprovisionnement(locationId?: string | null, tenantId?: string | null) {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [deliveryNotes, setDeliveryNotes] = useState<DeliveryNote[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchAll = useCallback(async () => {
    let supQuery = supabase.from('suppliers').select('*');
    if (locationId) supQuery = supQuery.or(`location_id.eq.${locationId},location_id.is.null`);
    const { data: supData } = await supQuery;
    setSuppliers(((supData ?? []) as Supplier[]).sort((a, b) => (a.name ?? '').localeCompare(b.name ?? '')));

    let noteQuery = supabase.from('delivery_notes').select('*').order('created_at', { ascending: false }).limit(100);
    if (locationId) noteQuery = noteQuery.or(`location_id.eq.${locationId},location_id.is.null`);
    const { data: noteData } = await noteQuery;
    const rows = (noteData ?? []) as DeliveryNote[];

    const supplierIds = [...new Set(rows.map(n => n.supplier_id).filter(Boolean) as string[])];
    const noteIds = rows.map(n => n.id);
    const supMap = new Map<string, Supplier>();
    const itemsMap = new Map<string, DeliveryNoteItem[]>();

    const [supRes, itemsRes] = await Promise.all([
      supplierIds.length ? supabase.from('suppliers').select('id, name').in('id', supplierIds) : Promise.resolve({ data: [] }),
      noteIds.length ? supabase.from('delivery_note_items').select('*, product:products(id, name, unit)').in('delivery_note_id', noteIds) : Promise.resolve({ data: [] }),
    ]);
    for (const s of (supRes.data ?? []) as Pick<Supplier, 'id' | 'name'>[]) supMap.set(s.id, s as Supplier);
    for (const it of (itemsRes.data ?? []) as (DeliveryNoteItem & { product?: Product })[]) {
      const arr = itemsMap.get(it.delivery_note_id) ?? [];
      arr.push({ ...it, product: it.product ? { id: it.product.id, name: it.product.name, unit: it.product.unit } : undefined });
      itemsMap.set(it.delivery_note_id, arr);
    }

    setDeliveryNotes(rows.map(n => ({
      ...n,
      supplier: supMap.get(n.supplier_id) ? { id: n.supplier_id, name: supMap.get(n.supplier_id)!.name } : undefined,
      items: itemsMap.get(n.id) ?? [],
    })));
  }, [locationId]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetchAll()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetchAll, tenantId]);

  const saveSupplier = useCallback(async (input: SupplierInput, id?: string): Promise<Supplier> => {
    const now = new Date().toISOString();
    const recordId = id ?? crypto.randomUUID();
    if (!navigator.onLine) {
      const queued: QueuedOp = {
        localId: crypto.randomUUID(),
        op: 'supplier',
        payload: { ...input, _id: recordId, _location_id: locationId ?? null, _isUpdate: !!id },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: locationId ?? null,
      };
      await queueOp(queued);
      return { ...input, id: recordId, location_id: locationId ?? null, created_at: now, updated_at: now } as Supplier;
    }
    const payload = {
      id: recordId, name: input.name, phone: input.phone, email: input.email,
      address: input.address, active: input.active,
      ...(locationId ? { location_id: locationId } : {}),
      created_at: now, updated_at: now,
    };
    if (id) {
      const { error } = await supabase.from('suppliers').update({ ...payload, id: undefined }).eq('id', id);
      if (error) throw new Error(translateError(error.message));
    } else {
      const { error } = await supabase.from('suppliers').insert(payload);
      if (error) throw new Error(translateError(error.message));
    }
    await fetchAll();
    return { ...payload, location_id: locationId ?? null } as Supplier;
  }, [locationId, fetchAll]);

  const removeSupplier = useCallback(async (id: string): Promise<void> => {
    const { error } = await supabase.from('suppliers').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetchAll();
  }, [fetchAll]);

  const createDeliveryNote = useCallback(async (input: DeliveryNoteInput): Promise<DeliveryNote> => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const now = new Date().toISOString();
      const id = crypto.randomUUID();
      const total = input.items.reduce((s, i) => s + i.quantity * i.unit_cost, 0);
      const locId = input.location_id ?? locationId ?? null;

      if (!navigator.onLine) {
        const queued: QueuedOp = {
          localId: crypto.randomUUID(),
          op: 'deliveryNote',
          payload: { ...input, _id: id, _user_id: user?.id ?? null },
          createdAt: now,
          status: 'pending',
          tenantId: tenantId ?? null,
          locationId: locId,
        };
        await queueOp(queued);
        return { id, note_number: input.note_number, supplier_id: input.supplier_id,
          location_id: locId, note_date: input.note_date, status: 'brouillon',
          total_amount: total, notes: input.notes, created_by: user?.id ?? null,
          created_at: now, updated_at: now, items: [] } as DeliveryNote;
      }

      const { error } = await supabase.from('delivery_notes').insert({
        id, note_number: input.note_number, supplier_id: input.supplier_id,
        ...(locId ? { location_id: locId } : {}),
        note_date: input.note_date, status: 'brouillon', total_amount: total,
        notes: input.notes, created_by: user?.id ?? null, created_at: now, updated_at: now,
      });
      if (error) throw new Error(translateError(error.message));

      const itemRows = input.items.map(i => ({
        id: crypto.randomUUID(), delivery_note_id: id, product_id: i.product_id,
        location_id: i.location_id ?? null, quantity: i.quantity, unit_cost: i.unit_cost,
        total: i.quantity * i.unit_cost, created_at: now,
      }));
      if (itemRows.length) {
        const { error: itemErr } = await supabase.from('delivery_note_items').insert(itemRows);
        if (itemErr) throw new Error(translateError(itemErr.message));
      }

      await fetchAll();
      return { id, note_number: input.note_number, supplier_id: input.supplier_id,
        location_id: locId, note_date: input.note_date, status: 'brouillon',
        total_amount: total, notes: input.notes, created_by: user?.id ?? null,
        created_at: now, updated_at: now, items: itemRows } as DeliveryNote;
    } finally { setLoading(false); }
  }, [locationId, fetchAll]);

  const validateDeliveryNote = useCallback(async (noteId: string): Promise<void> => {
    setLoading(true);
    try {
      if (!navigator.onLine) {
        const now = new Date().toISOString();
        const queued: QueuedOp = {
          localId: crypto.randomUUID(),
          op: 'validateDeliveryNote',
          payload: { noteId, location_id: locationId ?? null },
          createdAt: now,
          status: 'pending',
          tenantId: tenantId ?? null,
          locationId: locationId ?? null,
        };
        await queueOp(queued);
        return;
      }
      const { data: note } = await supabase.from('delivery_notes').select('*').eq('id', noteId).maybeSingle();
      if (!note || (note as DeliveryNote).status === 'valide') return;
      const { data: items } = await supabase.from('delivery_note_items').select('*').eq('delivery_note_id', noteId);
      const now = new Date().toISOString();
      const locId = (note as DeliveryNote).location_id ?? locationId ?? null;

      await supabase.from('delivery_notes').update({ status: 'valide', updated_at: now }).eq('id', noteId);

      for (const item of (items ?? []) as DeliveryNoteItem[]) {
        const { data: prod } = await supabase.from('products').select('track_stock').eq('id', item.product_id).maybeSingle();
        if (!prod?.track_stock) continue;

        const itemLocId = item.location_id ?? locId;
        if (itemLocId) {
          const lsId = `${item.product_id}_${itemLocId}`;
          const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
          const current = Number(ls?.stock_quantity ?? 0);
          const newQty = current + Number(item.quantity);
          await supabase.from('location_stock').upsert({
            id: lsId, product_id: item.product_id, location_id: itemLocId,
            stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
            price: ls?.price ?? null, updated_at: now,
          });
        } else {
          const { data: p } = await supabase.from('products').select('stock_quantity').eq('id', item.product_id).maybeSingle();
          const current = Number(p?.stock_quantity ?? 0);
          await supabase.from('products').update({ stock_quantity: current + Number(item.quantity), updated_at: now }).eq('id', item.product_id);
        }

        const mvId = crypto.randomUUID();
        await supabase.from('stock_movements').insert({
          id: mvId, product_id: item.product_id, type: 'entree',
          quantity: Number(item.quantity), unit_cost: Number(item.unit_cost),
          reference: (note as DeliveryNote).note_number, notes: `BL ${(note as DeliveryNote).note_number}`,
          created_at: now, updated_at: now,
          ...(itemLocId ? { location_id: itemLocId } : {}),
        });
      }
      await fetchAll();
    } finally { setLoading(false); }
  }, [locationId, fetchAll]);

  const deleteDeliveryNote = useCallback(async (noteId: string): Promise<void> => {
    if (!navigator.onLine) {
      const now = new Date().toISOString();
      const queued: QueuedOp = {
        localId: crypto.randomUUID(),
        op: 'deleteDeliveryNote',
        payload: { noteId },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: locationId ?? null,
      };
      await queueOp(queued);
      return;
    }
    await supabase.from('delivery_note_items').delete().eq('delivery_note_id', noteId);
    const { error } = await supabase.from('delivery_notes').delete().eq('id', noteId);
    if (error) throw new Error(translateError(error.message));
    await fetchAll();
  }, [fetchAll]);

  return {
    suppliers, deliveryNotes, loading,
    saveSupplier, removeSupplier,
    createDeliveryNote, validateDeliveryNote, deleteDeliveryNote,
  };
}
