import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { SalesContract } from '../types';
import { translateError } from '../lib/translateError';

export function useSalesContracts(tenantId?: string | null) {
  const [contracts, setContracts] = useState<SalesContract[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    if (!tenantId) { setLoading(false); return; }
    const { data, error } = await supabase
      .from('sales_contracts')
      .select('*')
      .eq('tenant_id', tenantId)
      .order('created_at', { ascending: false });
    if (error) {
      setContracts([]);
      setLoading(false);
      return;
    }
    setContracts((data ?? []) as SalesContract[]);
    setLoading(false);
  }, [tenantId]);

  useEffect(() => { fetch(); }, [fetch]);

  async function save(id: string | null, input: Omit<SalesContract, 'id' | 'tenant_id' | 'created_at' | 'updated_at'>) {
    const now = new Date().toISOString();
    if (id) {
      const { data, error } = await supabase
        .from('sales_contracts')
        .update({ ...input, updated_at: now })
        .eq('id', id)
        .select()
        .single();
      if (error) throw new Error(translateError(error.message));
      setContracts(prev => prev.map(c => (c.id === id ? (data as SalesContract) : c)));
      return data as SalesContract;
    }
    const { data, error } = await supabase
      .from('sales_contracts')
      .insert({ ...input, tenant_id: tenantId ?? null, created_at: now, updated_at: now })
      .select()
      .single();
    if (error) throw new Error(translateError(error.message));
    setContracts(prev => [data as SalesContract, ...prev]);
    return data as SalesContract;
  }

  async function remove(id: string) {
    const { error } = await supabase.from('sales_contracts').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    setContracts(prev => prev.filter(c => c.id !== id));
  }

  async function setActive(id: string) {
    const now = new Date().toISOString();
    if (tenantId) {
      await supabase.from('sales_contracts').update({ is_active: false, updated_at: now }).eq('tenant_id', tenantId).neq('id', id);
    }
    const { data, error } = await supabase.from('sales_contracts').update({ is_active: true, updated_at: now }).eq('id', id).select().single();
    if (error) throw new Error(translateError(error.message));
    setContracts(prev => prev.map(c => ({ ...c, is_active: c.id === id })));
    return data as SalesContract;
  }

  return { contracts, loading, fetch, save, remove, setActive };
}
