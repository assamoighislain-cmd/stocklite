import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Service, Dotation, DotationItem, SalesLocation, Product } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface CreateDotationInput {
  location_id: string;
  service_id: string;
  notes: string;
  effectif: number;
  items: { product_id: string; quantity: number; unit_cost: number }[];
}

export function useDotations(locationId?: string | null, tenantId?: string | null) {
  const [services, setServices] = useState<Service[]>([]);
  const [dotations, setDotations] = useState<Dotation[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    let svcQuery = supabase.from('services').select('*').order('sort_order');
    if (locationId) svcQuery = svcQuery.eq('location_id', locationId);
    const { data: svcData } = await svcQuery;
    setServices((svcData ?? []) as Service[]);

    let dotQuery = supabase.from('dotations').select('*').order('created_at', { ascending: false }).limit(200);
    if (locationId) dotQuery = dotQuery.eq('location_id', locationId);
    const { data: dotData } = await dotQuery;
    const rows = (dotData ?? []) as Dotation[];

    const serviceIds = [...new Set(rows.map(d => d.service_id).filter(Boolean) as string[])];
    const locationIds = [...new Set(rows.map(d => d.location_id).filter(Boolean) as string[])];
    const dotationIds = rows.map(d => d.id);

    const svcMap = new Map<string, Service>();
    const locMap = new Map<string, SalesLocation>();
    const itemsMap = new Map<string, DotationItem[]>();

    const [svcRes, locRes, itemsRes] = await Promise.all([
      serviceIds.length ? supabase.from('services').select('*').in('id', serviceIds) : Promise.resolve({ data: [] }),
      locationIds.length ? supabase.from('sales_locations').select('*').in('id', locationIds) : Promise.resolve({ data: [] }),
      dotationIds.length ? supabase.from('dotation_items').select('*, product:products(id, name, unit)') : Promise.resolve({ data: [] }),
    ]);
    for (const s of (svcRes.data ?? []) as Service[]) svcMap.set(s.id, s);
    for (const l of (locRes.data ?? []) as SalesLocation[]) locMap.set(l.id, l);
    for (const it of (itemsRes.data ?? []) as (DotationItem & { product?: Product })[]) {
      const arr = itemsMap.get(it.dotation_id) ?? [];
      arr.push({ ...it, product: it.product ? { id: it.product.id, name: it.product.name, unit: it.product.unit } : undefined });
      itemsMap.set(it.dotation_id, arr);
    }

    setDotations(rows.map(d => ({
      ...d,
      service: svcMap.get(d.service_id) ? { id: d.service_id, name: svcMap.get(d.service_id)!.name } : undefined,
      location: locMap.get(d.location_id) ? { id: d.location_id, name: locMap.get(d.location_id)!.name } : undefined,
      items: itemsMap.get(d.id) ?? [],
    })));
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch, tenantId]);

  async function saveService(payload: { name: string; location_id: string; sort_order?: number }, id?: string) {
    const now = new Date().toISOString();
    if (id) {
      const { error } = await supabase.from('services').update({ ...payload, updated_at: now }).eq('id', id);
      if (error) throw new Error(translateError(error.message));
    } else {
      const recordId = crypto.randomUUID();
      const { error } = await supabase.from('services').insert({
        id: recordId, name: payload.name, location_id: payload.location_id,
        active: true, sort_order: payload.sort_order ?? 0, created_at: now, updated_at: now,
      });
      if (error) throw new Error(translateError(error.message));
    }
    await fetch();
  }

  async function removeService(id: string) {
    const { error } = await supabase.from('services').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  async function createDotation(input: CreateDotationInput): Promise<Dotation> {
    const now = new Date().toISOString();
    const { data: { user } } = await supabase.auth.getUser();
    const date = new Date();
    const ymd = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`;
    const rand = crypto.randomUUID().slice(0, 8).toUpperCase();
    const dotationNumber = `DOT-${ymd}-${rand}`;
    const dotationId = crypto.randomUUID();

    if (!navigator.onLine) {
      const queued: QueuedOp = {
        localId: dotationId,
        op: 'dotation',
        payload: { ...input, _id: dotationId, _number: dotationNumber, _user_id: user?.id ?? null },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: input.location_id ?? null,
      };
      await queueOp(queued);
      return { id: dotationId, dotation_number: dotationNumber, location_id: input.location_id,
        service_id: input.service_id, notes: input.notes || '', effectif: input.effectif || 0,
        created_by: user?.id ?? null, created_at: now, updated_at: now } as Dotation;
    }

    const { error } = await supabase.from('dotations').insert({
      id: dotationId, dotation_number: dotationNumber, location_id: input.location_id,
      service_id: input.service_id, notes: input.notes || '', effectif: input.effectif || 0,
      created_by: user?.id ?? null, created_at: now, updated_at: now,
    });
    if (error) throw new Error(translateError(error.message));

    for (const item of input.items) {
      if (item.quantity <= 0) continue;
      const itemId = crypto.randomUUID();
      await supabase.from('dotation_items').insert({
        id: itemId, dotation_id: dotationId, product_id: item.product_id,
        quantity: item.quantity, unit_cost: item.unit_cost, created_at: now,
      });

      const lsId = `${item.product_id}_${input.location_id}`;
      const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
      const currentQty = Number(ls?.stock_quantity ?? 0);
      const newQty = Math.max(0, currentQty - item.quantity);
      await supabase.from('location_stock').upsert({
        id: lsId, product_id: item.product_id, location_id: input.location_id,
        stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
        price: ls?.price ?? null, updated_at: now,
      });

      const mvId = crypto.randomUUID();
      await supabase.from('stock_movements').insert({
        id: mvId, product_id: item.product_id, type: 'sortie', quantity: item.quantity,
        unit_cost: item.unit_cost, reference: `Dotation ${dotationNumber}`,
        notes: input.notes || 'Dotation vers service', location_id: input.location_id,
        created_at: now, updated_at: now,
      });
    }

    await fetch();
    return { id: dotationId, dotation_number: dotationNumber, location_id: input.location_id,
      service_id: input.service_id, notes: input.notes || '', effectif: input.effectif || 0,
      created_by: user?.id ?? null, created_at: now, updated_at: now } as Dotation;
  }

  return { services, dotations, loading, fetch, saveService, removeService, createDotation };
}
