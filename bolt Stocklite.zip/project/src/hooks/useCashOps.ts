import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { AccountingEntry } from './useAccounting';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface CashOpInput {
  date: string;
  category: string;
  description: string;
  amount: number;
  payment_method: string;
  reference: string;
  notes: string;
  caisse_id?: string | null;
}

export function useCashOps(locationId?: string | null, tenantId?: string | null) {
  const [ops, setOps] = useState<AccountingEntry[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchOps = useCallback(async () => {
    let query = supabase.from('accounting_entries').select('*').eq('source', 'caisse').order('date', { ascending: false }).order('created_at', { ascending: false });
    if (locationId) query = query.eq('location_id', locationId);
    const { data } = await query;
    setOps((data ?? []) as AccountingEntry[]);
  }, [locationId]);

  useEffect(() => { fetchOps(); }, [fetchOps]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetchOps()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetchOps, tenantId]);

  const totalExpenses = ops.reduce((s, e) => s + Number(e.amount), 0);

  const createOp = useCallback(async (input: CashOpInput) => {
    setLoading(true);
    try {
      const now = new Date().toISOString();
      const id = crypto.randomUUID();
      if (!navigator.onLine) {
        const queued: QueuedOp = {
          localId: id, op: 'cashOp',
          payload: { ...input, _id: id, _location_id: locationId ?? null },
          createdAt: now, status: 'pending',
          tenantId: tenantId ?? null, locationId: locationId ?? null,
        };
        await queueOp(queued);
        return;
      }
      const base = {
        id, date: input.date, type: 'charge' as const, category: input.category,
        description: input.description, amount: input.amount,
        payment_method: input.payment_method, reference: input.reference,
        notes: input.notes, source: 'caisse' as const,
        caisse_id: input.caisse_id ?? null, created_at: now, updated_at: now,
      };
      const { error } = await supabase.from('accounting_entries').insert({
        ...base, ...(locationId ? { location_id: locationId } : {}),
      });
      if (error) throw new Error(translateError(error.message));
      await fetchOps();
    } finally { setLoading(false); }
  }, [locationId, fetchOps, tenantId]);

  const deleteOp = useCallback(async (id: string) => {
    const { error } = await supabase.from('accounting_entries').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetchOps();
  }, [fetchOps]);

  return { ops, totalExpenses, loading, createOp, deleteOp };
}
