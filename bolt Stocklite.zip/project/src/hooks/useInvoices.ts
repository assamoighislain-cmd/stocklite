import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Invoice, InvoiceItem, InvoiceStatus, Customer } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface LineItemInput {
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
  unit_cost: number;
  discount: number;
  sort_order: number;
}

export interface CreateInvoiceInput {
  customer_id: string;
  date: string;
  due_date: string | null;
  tax_rate: number;
  remise?: number;
  notes: string;
  items: LineItemInput[];
  location_id?: string | null;
  order_number?: string | null;
  order_advance?: number;
  delivery_delay?: string | null;
  payment_mode?: string | null;
  contact_name?: string | null;
  contact_email?: string | null;
  contact_phone?: string | null;
  airsi?: number;
}

function calcTotals(items: LineItemInput[], taxRate: number, remise = 0, airsiRate = 0) {
  const ttc = items.reduce((s, i) => s + i.quantity * i.unit_price - (i.discount ?? 0), 0);
  const divisor = 1 + (taxRate + airsiRate) / 100;
  const subtotal = Math.round((ttc / divisor) * 100) / 100;
  const total_ttc = Math.round((ttc - remise) * 100) / 100;
  const tax_amount = Math.round((total_ttc * (taxRate / (taxRate + airsiRate + 100))) * 100) / 100;
  const airsi_amount = Math.round((total_ttc * (airsiRate / (taxRate + airsiRate + 100))) * 100) / 100;
  const total_ht = Math.round((total_ttc - tax_amount - airsi_amount) * 100) / 100;
  return { subtotal: total_ht, tax_amount, airsi_amount, total: Math.max(total_ttc, 0) };
}

export function useInvoices(locationId?: string | null, tenantId?: string | null) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    let query = supabase.from('invoices').select('*').order('created_at', { ascending: false }).limit(200);
    if (locationId) query = query.eq('location_id', locationId);
    const { data: invRows, error } = await query;
    if (error) { setLoading(false); return; }
    const rows = (invRows ?? []) as Invoice[];

    const customerIds = [...new Set(rows.map(i => i.customer_id).filter(Boolean) as string[])];
    const custMap = new Map<string, Customer>();
    if (customerIds.length) {
      const { data: custs } = await supabase.from('customers').select('*');
      for (const c of (custs ?? []) as Customer[]) if (customerIds.includes(c.id)) custMap.set(c.id, c);
    }

    const invoiceIds = rows.map(i => i.id);
    const itemsMap = new Map<string, InvoiceItem[]>();
    if (invoiceIds.length) {
      const { data: allItems } = await supabase.from('invoice_items').select('*');
      for (const it of (allItems ?? []) as InvoiceItem[]) {
        if (!invoiceIds.includes(it.invoice_id)) continue;
        const arr = itemsMap.get(it.invoice_id) ?? [];
        arr.push(it);
        itemsMap.set(it.invoice_id, arr);
      }
    }

    const creatorIds = [...new Set(rows.map(i => i.created_by).filter(Boolean) as string[])] as string[];
    const creatorMap = new Map<string, { full_name: string; email: string }>();
    if (creatorIds.length) {
      const { data: profiles } = await supabase.from('user_profiles').select('id, full_name, email').in('id', creatorIds);
      for (const p of (profiles ?? []) as { id: string; full_name: string; email: string }[]) {
        creatorMap.set(p.id, { full_name: p.full_name, email: p.email });
      }
    }

    setInvoices(rows.map(i => ({
      ...i,
      customer: i.customer_id ? custMap.get(i.customer_id) : undefined,
      items: (itemsMap.get(i.id) ?? []).sort((a, b) => a.sort_order - b.sort_order),
      creator: i.created_by ? creatorMap.get(i.created_by) ?? null : null,
    })));
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetchAll()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetchAll, tenantId]);

  async function fetchOne(id: string): Promise<Invoice | null> {
    const { data: inv } = await supabase.from('invoices').select('*').eq('id', id).maybeSingle();
    if (!inv) return null;
    const invoice = inv as Invoice;
    const { data: items } = await supabase.from('invoice_items').select('*').eq('invoice_id', id).order('sort_order');
    let customer: Customer | undefined;
    if (invoice.customer_id) {
      const { data: c } = await supabase.from('customers').select('*').eq('id', invoice.customer_id).maybeSingle();
      if (c) customer = c as Customer;
    }
    let creator: { full_name: string; email: string } | null = null;
    if (invoice.created_by) {
      const { data: p } = await supabase.from('user_profiles').select('full_name, email').eq('id', invoice.created_by).maybeSingle();
      if (p) creator = { full_name: (p as { full_name: string }).full_name, email: (p as { email: string }).email };
    }
    return { ...invoice, customer, items: (items ?? []) as InvoiceItem[], creator };
  }

  async function create(input: CreateInvoiceInput): Promise<Invoice> {
    const remise = input.remise ?? 0;
    const airsiRate = input.airsi ?? 0;
    const { subtotal, tax_amount, airsi_amount, total } = calcTotals(input.items, input.tax_rate, remise, airsiRate);
    const now = new Date().toISOString();
    const invId = crypto.randomUUID();
    const invNumber = `INV-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;

    const invLocationId = input.location_id ?? locationId;

    async function queueOffline() {
      let userId: string | null = null;
      try {
        const { data: authUser } = await supabase.auth.getUser();
        userId = authUser?.user?.id ?? null;
      } catch { /* offline — auth cache may not be available */ }
      const queued: QueuedOp = {
        localId: invId,
        op: 'invoice',
        payload: { ...input, _id: invId, _number: invNumber, _location_id: invLocationId, _created_by: userId },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: invLocationId ?? null,
      };
      await queueOp(queued);
      return { id: invId, invoice_number: invNumber, customer_id: input.customer_id,
        date: input.date, due_date: input.due_date || null, status: 'brouillon',
        tax_rate: input.tax_rate, remise, subtotal, tax_amount, total, amount_paid: 0,
        balance_due: total,
        notes: input.notes, created_at: now, updated_at: now, created_by: userId,
        order_number: input.order_number ?? null, order_advance: input.order_advance ?? 0,
        delivery_delay: input.delivery_delay ?? null, payment_mode: input.payment_mode ?? null,
        contact_name: input.contact_name ?? null, contact_email: input.contact_email ?? null, contact_phone: input.contact_phone ?? null,
        airsi: airsiRate, airsi_amount,
        ...(invLocationId ? { location_id: invLocationId } : {}),
      } as Invoice;
    }

    if (!navigator.onLine) {
      return queueOffline();
    }

    const { data: authUser } = await supabase.auth.getUser();
    const userId = authUser?.user?.id ?? null;

    let insertError: { message: string } | null = null;
    try {
      const { error } = await supabase.from('invoices').insert({
        id: invId, invoice_number: invNumber, customer_id: input.customer_id,
        date: input.date, due_date: input.due_date || null, status: 'brouillon',
        tax_rate: input.tax_rate, remise, subtotal, tax_amount, total, amount_paid: 0,
        notes: input.notes, created_at: now, updated_at: now,
        order_number: input.order_number ?? null,
        order_advance: input.order_advance ?? 0,
        delivery_delay: input.delivery_delay ?? null,
        payment_mode: input.payment_mode ?? null,
        contact_name: input.contact_name ?? null,
        contact_email: input.contact_email ?? null,
        contact_phone: input.contact_phone ?? null,
        airsi: airsiRate, airsi_amount,
        created_by: userId,
        ...(invLocationId ? { location_id: invLocationId } : {}),
      });
      insertError = error;
    } catch (netErr) {
      return queueOffline();
    }
    if (insertError) {
      if (/network|fetch|Failed to fetch|ERR_/i.test(insertError.message)) return queueOffline();
      throw new Error(translateError(insertError.message));
    }

    const itemRows = input.items.map(i => ({
      id: crypto.randomUUID(),
      invoice_id: invId,
      product_id: i.product_id || null,
      description: i.description,
      quantity: i.quantity,
      unit_price: i.unit_price,
      unit_cost: i.unit_cost ?? 0,
      discount: i.discount ?? 0,
      sort_order: i.sort_order,
    }));
    if (itemRows.length) {
      const { error: itemErr } = await supabase.from('invoice_items').insert(itemRows);
      if (itemErr) throw new Error(itemErr.message);
    }

    // Decrement stock for tracked products (same pattern as POS sales)
    for (const item of input.items) {
      if (!item.product_id) continue;
      const { data: prod } = await supabase.from('products').select('track_stock').eq('id', item.product_id).maybeSingle();
      if (!prod?.track_stock) continue;

      if (invLocationId) {
        const lsId = `${item.product_id}_${invLocationId}`;
        const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
        const current = Number(ls?.stock_quantity ?? 0);
        const newQty = Math.max(0, current - item.quantity);
        await supabase.from('location_stock').upsert({
          id: lsId, product_id: item.product_id, location_id: invLocationId,
          stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
          price: ls?.price ?? null, updated_at: now,
        });
      } else {
        const { data: p } = await supabase.from('products').select('stock_quantity').eq('id', item.product_id).maybeSingle();
        const current = Number(p?.stock_quantity ?? 0);
        const newQty = Math.max(0, current - item.quantity);
        await supabase.from('products').update({ stock_quantity: newQty, updated_at: now }).eq('id', item.product_id);
      }

      await supabase.from('stock_movements').insert({
        id: crypto.randomUUID(), product_id: item.product_id, type: 'vente',
        quantity: item.quantity, unit_cost: item.unit_price,
        reference: invNumber, notes: '', created_at: now, updated_at: now,
        ...(invLocationId ? { location_id: invLocationId } : {}),
      });
    }

    await fetchAll();
    return { id: invId, invoice_number: invNumber, customer_id: input.customer_id,
      date: input.date, due_date: input.due_date || null, status: 'brouillon',
      tax_rate: input.tax_rate, remise, subtotal, tax_amount, total, amount_paid: 0,
      balance_due: total,
      notes: input.notes, created_at: now, updated_at: now,
      airsi: airsiRate, airsi_amount,
      ...(invLocationId ? { location_id: invLocationId } : {}),
    } as Invoice;
  }

  async function restoreStock(items: { product_id: string | null; quantity: number }[], reference: string) {
    const now = new Date().toISOString();
    for (const item of items) {
      if (!item.product_id || item.quantity <= 0) continue;
      const { data: prod } = await supabase.from('products').select('track_stock').eq('id', item.product_id).maybeSingle();
      if (!prod?.track_stock) continue;

      if (locationId) {
        const lsId = `${item.product_id}_${locationId}`;
        const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
        const current = Number(ls?.stock_quantity ?? 0);
        const newQty = current + item.quantity;
        await supabase.from('location_stock').upsert({
          id: lsId, product_id: item.product_id, location_id: locationId,
          stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
          price: ls?.price ?? null, updated_at: now,
        });
      } else {
        const { data: p } = await supabase.from('products').select('stock_quantity').eq('id', item.product_id).maybeSingle();
        const current = Number(p?.stock_quantity ?? 0);
        await supabase.from('products').update({ stock_quantity: current + item.quantity, updated_at: now }).eq('id', item.product_id);
      }

      await supabase.from('stock_movements').insert({
        id: crypto.randomUUID(), product_id: item.product_id, type: 'entree',
        quantity: item.quantity, unit_cost: 0,
        reference, notes: 'Retour stock facture', created_at: now, updated_at: now,
        ...(locationId ? { location_id: locationId } : {}),
      });
    }
  }

  async function update(id: string, input: Partial<CreateInvoiceInput> & { status?: InvoiceStatus }) {
    const now = new Date().toISOString();
    const patch: Record<string, unknown> = { updated_at: now };
    if (input.customer_id !== undefined) patch.customer_id = input.customer_id;
    if (input.date !== undefined) patch.date = input.date;
    if (input.due_date !== undefined) patch.due_date = input.due_date || null;
    if (input.notes !== undefined) patch.notes = input.notes;
    if (input.order_number !== undefined) patch.order_number = input.order_number || null;
    if (input.order_advance !== undefined) patch.order_advance = input.order_advance ?? 0;
    if (input.delivery_delay !== undefined) patch.delivery_delay = input.delivery_delay || null;
    if (input.payment_mode !== undefined) patch.payment_mode = input.payment_mode || null;
    if (input.contact_name !== undefined) patch.contact_name = input.contact_name || null;
    if (input.contact_email !== undefined) patch.contact_email = input.contact_email || null;
    if (input.contact_phone !== undefined) patch.contact_phone = input.contact_phone || null;
    if (input.airsi !== undefined) patch.airsi = input.airsi ?? 0;
    if (input.status !== undefined) patch.status = input.status;

    if (input.status === 'payee') {
      const { data: current } = await supabase.from('invoices').select('total').eq('id', id).maybeSingle();
      if (current) { patch.amount_paid = (current as { total: number }).total; }
    }

    if (input.items !== undefined) {
      const taxRate = input.tax_rate ?? 0;
      const remise = input.remise ?? 0;
      const airsiRate = input.airsi ?? 0;
      const { subtotal, tax_amount, airsi_amount, total } = calcTotals(input.items, taxRate, remise, airsiRate);
      patch.tax_rate = taxRate; patch.remise = remise; patch.subtotal = subtotal; patch.tax_amount = tax_amount; patch.airsi = airsiRate; patch.airsi_amount = airsi_amount; patch.total = total;
      const { data: current } = await supabase.from('invoices').select('amount_paid, total').eq('id', id).maybeSingle();
      const paid = input.status === 'payee' ? total : Number((current as { amount_paid?: number })?.amount_paid ?? 0);
      patch.amount_paid = Math.min(paid, total);

      // Restore stock from old items before replacing
      const { data: oldItems } = await supabase.from('invoice_items').select('*').eq('invoice_id', id);
      const invRef = (await supabase.from('invoices').select('invoice_number').eq('id', id).maybeSingle()).data as { invoice_number?: string } | null;
      await restoreStock((oldItems ?? []).map((i: Record<string, unknown>) => ({
        product_id: i.product_id as string | null, quantity: i.quantity as number,
      })), invRef?.invoice_number ?? id);

      await supabase.from('invoice_items').delete().eq('invoice_id', id);
      const itemRows = input.items.map(i => ({
        id: crypto.randomUUID(), invoice_id: id, product_id: i.product_id || null,
        description: i.description, quantity: i.quantity, unit_price: i.unit_price,
        unit_cost: i.unit_cost ?? 0,
        discount: i.discount ?? 0,
        sort_order: i.sort_order,
        created_at: now, updated_at: now,
      }));
      if (itemRows.length) await supabase.from('invoice_items').insert(itemRows);

      // Decrement stock for new items
      for (const item of input.items) {
        if (!item.product_id) continue;
        const { data: prod } = await supabase.from('products').select('track_stock').eq('id', item.product_id).maybeSingle();
        if (!prod?.track_stock) continue;

        if (locationId) {
          const lsId = `${item.product_id}_${locationId}`;
          const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
          const currentQty = Number(ls?.stock_quantity ?? 0);
          const newQty = Math.max(0, currentQty - item.quantity);
          await supabase.from('location_stock').upsert({
            id: lsId, product_id: item.product_id, location_id: locationId,
            stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
            price: ls?.price ?? null, updated_at: now,
          });
        } else {
          const { data: p } = await supabase.from('products').select('stock_quantity').eq('id', item.product_id).maybeSingle();
          const currentQty = Number(p?.stock_quantity ?? 0);
          const newQty = Math.max(0, currentQty - item.quantity);
          await supabase.from('products').update({ stock_quantity: newQty, updated_at: now }).eq('id', item.product_id);
        }

        await supabase.from('stock_movements').insert({
          id: crypto.randomUUID(), product_id: item.product_id, type: 'vente',
          quantity: item.quantity, unit_cost: item.unit_price,
          reference: invRef?.invoice_number ?? id, notes: '', created_at: now, updated_at: now,
          ...(locationId ? { location_id: locationId } : {}),
        });
      }
    }

    await supabase.from('invoices').update(patch).eq('id', id);
    await fetchAll();
  }

  async function applyPayment(invoiceId: string, input: { status: InvoiceStatus }) {
    const now = new Date().toISOString();
    const patch: Record<string, unknown> = { status: input.status, updated_at: now };
    if (input.status === 'payee') {
      const { data: inv } = await supabase.from('invoices').select('total').eq('id', invoiceId).maybeSingle();
      if (inv) { patch.amount_paid = (inv as { total: number }).total; }
    }
    await supabase.from('invoices').update(patch).eq('id', invoiceId);
    await fetchAll();
  }

  async function returnInvoiceItems(invoiceId: string, returns: { item_id: string; product_id: string | null; quantity: number }[], reason: string): Promise<void> {
    if (!navigator.onLine) throw new Error('Retour impossible hors ligne.');
    const { data: inv } = await supabase.from('invoices').select('*').eq('id', invoiceId).maybeSingle();
    if (!inv) throw new Error('Facture introuvable.');
    const invLocationId = (inv as { location_id?: string | null }).location_id ?? locationId;
    const invRef = (inv as { invoice_number: string }).invoice_number;
    const now = new Date().toISOString();

    for (const r of returns) {
      if (!r.product_id || r.quantity <= 0) continue;
      const { data: prod } = await supabase.from('products').select('track_stock').eq('id', r.product_id).maybeSingle();
      if (!prod?.track_stock) continue;

      if (invLocationId) {
        const lsId = `${r.product_id}_${invLocationId}`;
        const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
        const current = Number(ls?.stock_quantity ?? 0);
        const newQty = current + r.quantity;
        await supabase.from('location_stock').upsert({
          id: lsId, product_id: r.product_id, location_id: invLocationId,
          stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
          price: ls?.price ?? null, updated_at: now,
        });
      } else {
        const { data: p } = await supabase.from('products').select('stock_quantity').eq('id', r.product_id).maybeSingle();
        const current = Number(p?.stock_quantity ?? 0);
        await supabase.from('products').update({ stock_quantity: current + r.quantity, updated_at: now }).eq('id', r.product_id);
      }

      await supabase.from('stock_movements').insert({
        id: crypto.randomUUID(), product_id: r.product_id, type: 'retour',
        quantity: r.quantity, unit_cost: 0,
        reference: invRef, notes: reason || 'Retour facture',
        created_at: now, updated_at: now,
        ...(invLocationId ? { location_id: invLocationId } : {}),
      });
    }

    await fetchAll();
  }

  async function remove(id: string) {
    const { data: items } = await supabase.from('invoice_items').select('*').eq('invoice_id', id);
    const invRef = (await supabase.from('invoices').select('invoice_number').eq('id', id).maybeSingle()).data as { invoice_number?: string } | null;
    await restoreStock((items ?? []).map((i: Record<string, unknown>) => ({
      product_id: i.product_id as string | null, quantity: i.quantity as number,
    })), invRef?.invoice_number ?? id);

    await supabase.from('invoice_items').delete().eq('invoice_id', id);
    const { error } = await supabase.from('invoices').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetchAll();
  }

  async function createCreditNote(originalId: string): Promise<Invoice | null> {
    const { data: orig } = await supabase.from('invoices').select('*').eq('id', originalId).maybeSingle();
    if (!orig) return null;
    const origInvoice = orig as Invoice;
    const { data: origItems } = await supabase.from('invoice_items').select('*').eq('invoice_id', originalId);

    const now = new Date().toISOString();
    const avoirId = crypto.randomUUID();
    const avoirNumber = `AV-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;

    const avoirRecord = {
      id: avoirId, invoice_number: avoirNumber, customer_id: origInvoice.customer_id,
      date: now.slice(0, 10), due_date: null, status: 'payee',
      tax_rate: origInvoice.tax_rate, remise: origInvoice.remise ?? 0,
      subtotal: -(origInvoice.subtotal), tax_amount: -(origInvoice.tax_amount),
      total: -(origInvoice.total), amount_paid: -(origInvoice.total),
      notes: `Avoir annulant la facture ${origInvoice.invoice_number}`,
      created_at: now, updated_at: now, is_credit_note: true, credit_note_of: originalId,
    };

    const { error } = await supabase.from('invoices').insert(avoirRecord);
    if (error) throw new Error(translateError(error.message));

    // Restore stock from original invoice items
    await restoreStock((origItems ?? []).map((i: Record<string, unknown>) => ({
      product_id: i.product_id as string | null, quantity: i.quantity as number,
    })), origInvoice.invoice_number);

    const avoirItems = (origItems ?? []).map((i: Record<string, unknown>) => ({
      id: crypto.randomUUID(), invoice_id: avoirId,
      product_id: (i.product_id as string) || null,
      description: i.description as string,
      quantity: -(i.quantity as number),
      unit_price: i.unit_price as number,
      unit_cost: Number(i.unit_cost ?? 0),
      discount: -(Number(i.discount ?? 0)),
      sort_order: i.sort_order as number,
      created_at: now, updated_at: now,
    }));
    if (avoirItems.length) await supabase.from('invoice_items').insert(avoirItems);

    await supabase.from('invoices').update({ status: 'annulee', updated_at: now }).eq('id', originalId);
    await fetchAll();

    // If the original invoice was FNE-certified, auto-certify the credit note (refund) with the DGI
    if (origInvoice.fne_status === 'certified') {
      try {
        const { data: settingsRow } = await supabase.from('company_settings').select('*').limit(1).maybeSingle();
        const settings = settingsRow as Record<string, unknown> | null;
        const pointOfSale = (settings?.fne_point_of_sale as string | undefined)?.trim();
        const establishment = (settings?.fne_establishment as string | undefined)?.trim();
        const apiKey = (settings?.fne_api_key as string | undefined)?.trim();

        if (pointOfSale && establishment && apiKey) {
          // Fetch original invoice's DGI invoice ID and FNE reference
          const { data: origFne } = await supabase.from('invoices')
            .select('fne_dgi_invoice_id, fne_reference')
            .eq('id', originalId)
            .maybeSingle();
          const origFneData = origFne as { fne_dgi_invoice_id?: string; fne_reference?: string } | null;
          const dgiInvoiceId = origFneData?.fne_dgi_invoice_id ?? null;
          const origFneReference = origFneData?.fne_reference ?? null;

          if (!dgiInvoiceId && !origFneReference) {
            throw new Error('La facture originale n\'a ni ID DGI ni référence FNE. Re-certifiez la facture originale.');
          }

          // Fetch original invoice items with their DGI item IDs
          const { data: origItemsWithDgi } = await supabase.from('invoice_items')
            .select('product_id, fne_dgi_item_id')
            .eq('invoice_id', originalId);
          const origItemsDgi = (origItemsWithDgi ?? []) as { product_id: string | null; fne_dgi_item_id: string | null }[];

          // Build refund items: match by product_id
          const refundItems: { id: string; quantity: number }[] = [];
          for (const origItem of (origItems ?? []) as Record<string, unknown>[]) {
            const pid = origItem.product_id as string | null;
            const dgiItem = origItemsDgi.find(oi => oi.product_id === pid);
            if (!dgiItem?.fne_dgi_item_id) {
              // Fallback: send product_id, edge function will try to resolve via GET
              refundItems.push({
                id: pid ?? (origItem.id as string),
                quantity: Math.abs(origItem.quantity as number),
              });
            } else {
              refundItems.push({
                id: dgiItem.fne_dgi_item_id,
                quantity: Math.abs(origItem.quantity as number),
              });
            }
          }

          const fnePayload: Record<string, unknown> = {
            settingsId: settings?.id as string | undefined,
            mode: 'refund' as const,
            ...(dgiInvoiceId ? { originalDgiInvoiceId: dgiInvoiceId } : {}),
            ...(origFneReference ? { originalFneReference: origFneReference } : {}),
            refundItems,
          };

          const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/fne-certify`;
          const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(fnePayload),
          });

          const certData = await response.json().catch(() => ({}));
          if (response.ok && certData.reference && certData.token) {
            const certNow = new Date().toISOString();
            const avoirPatch: Record<string, unknown> = {
              fne_reference: certData.reference,
              fne_token: certData.token,
              fne_ncc: certData.ncc,
              fne_status: 'certified',
              fne_error: null,
              fne_certified_at: certNow,
              fne_warning: Boolean(certData.warning),
              fne_balance_sticker: typeof certData.balance_sticker === 'number' ? certData.balance_sticker : null,
              updated_at: certNow,
            };
            if (certData.dgiInvoiceId) {
              avoirPatch.fne_dgi_invoice_id = certData.dgiInvoiceId;
            }
            await supabase.from('invoices').update(avoirPatch).eq('id', avoirId);

            // If the edge function resolved the DGI invoice ID via GET fallback, store it on the original invoice too
            if (certData.dgiInvoiceId && !dgiInvoiceId) {
              await supabase.from('invoices').update({ fne_dgi_invoice_id: certData.dgiInvoiceId }).eq('id', originalId);
            }
            // Also store DGI item IDs on original invoice items if resolved
            if (certData.dgiItemIds && !dgiInvoiceId) {
              for (const oi of origItemsDgi) {
                const dgiItemId = certData.dgiItemIds[oi.product_id ?? ''];
                if (dgiItemId) {
                  await supabase.from('invoice_items').update({ fne_dgi_item_id: dgiItemId }).eq('product_id', oi.product_id).eq('invoice_id', originalId);
                }
              }
            }
          } else {
            const errMsg = (certData && typeof certData === 'object' && 'error' in certData && typeof certData.error === 'string')
              ? certData.error
              : `Erreur FNE (${response.status})`;
            await supabase.from('invoices').update({
              fne_status: 'error',
              fne_error: errMsg,
              updated_at: new Date().toISOString(),
            }).eq('id', avoirId);
          }
        }
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : 'Erreur certification avoir FNE';
        await supabase.from('invoices').update({
          fne_status: 'error',
          fne_error: errMsg,
          updated_at: new Date().toISOString(),
        }).eq('id', avoirId);
      }
      await fetchAll();
    }

    return avoirRecord as unknown as Invoice;
  }

  return { invoices, loading, fetchOne, create, update, applyPayment, remove, createCreditNote, refetch: fetchAll, returnInvoiceItems };
}
