import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Tenant, Subscription, LicensePlan, UserStatus } from '../types';
import { translateError } from '../lib/translateError';

export interface RevenueStats {
  amount: number;
  currency: string;
  status: string;
  starts_at: string;
  created_at: string;
  tenant_id: string;
  payment_method: string;
  plan_id: string | null;
}

export function useTenants() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [plans, setPlans] = useState<LicensePlan[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTenants = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('tenants')
      .select('*')
      .order('created_at', { ascending: false });
    setTenants((data ?? []) as Tenant[]);
    setLoading(false);
  }, []);

  const fetchSubscriptions = useCallback(async (tenantId?: string) => {
    let q = supabase.from('subscriptions').select('*').order('created_at', { ascending: false });
    if (tenantId) q = q.eq('tenant_id', tenantId);
    const { data } = await q;
    setSubscriptions((data ?? []) as Subscription[]);
  }, []);

  useEffect(() => { fetchTenants(); }, [fetchTenants]);

  async function createTenant(input: { name: string; slug: string; license_expires_at: string | null; max_users?: number }) {
    const expiresAt = input.license_expires_at ?? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    const { data, error } = await supabase.from('tenants').insert({
      name: input.name,
      slug: input.slug,
      active: true,
      license_expires_at: expiresAt,
      max_users: input.max_users ?? 5,
    }).select().maybeSingle();
    if (error) throw new Error(translateError(error.message));
    if (data) setTenants(prev => [data as Tenant, ...prev]);
    return data as Tenant;
  }

  async function updateTenant(id: string, patch: Partial<Pick<Tenant, 'name' | 'slug' | 'active' | 'license_expires_at' | 'max_users'>>) {
    const { error } = await supabase.from('tenants').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) throw new Error(translateError(error.message));
    setTenants(prev => prev.map(t => t.id === id ? { ...t, ...patch } : t));
  }

  async function createSubscription(input: {
    tenant_id: string;
    amount: number;
    starts_at: string;
    ends_at: string;
    payment_method: string;
    payment_reference?: string;
    plan_id?: string | null;
  }) {
    const { data, error } = await supabase.from('subscriptions').insert({
      ...input,
      status: 'active',
      currency: 'XOF',
      plan_id: input.plan_id ?? null,
    }).select().maybeSingle();
    if (error) throw new Error(translateError(error.message));
    await supabase.from('tenants').update({
      license_expires_at: input.ends_at,
      active: true,
      updated_at: new Date().toISOString(),
    }).eq('id', input.tenant_id);
    setTenants(prev => prev.map(t => t.id === input.tenant_id ? { ...t, license_expires_at: input.ends_at, active: true } : t));
    if (data) setSubscriptions(prev => [data as Subscription, ...prev]);
    return data as Subscription;
  }

  async function assignUserToTenant(userId: string, tenantId: string) {
    const { error } = await supabase.from('user_profiles').update({ tenant_id: tenantId, updated_at: new Date().toISOString() }).eq('id', userId);
    if (error) throw new Error(translateError(error.message));
  }

  async function createTenantUser(input: { email: string; password: string; full_name: string; role: string; tenant_id: string }) {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) throw new Error('Non connecte');

    const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-tenant-user`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`,
        'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
      },
      body: JSON.stringify(input),
    });

    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Erreur inconnue');
    return json.user;
  }

  async function fetchTenantActivity(tenantId: string) {
    const { data, error } = await supabase.rpc('get_tenant_activity', { p_tenant_id: tenantId });
    if (error) throw new Error(translateError(error.message));
    return data;
  }

  async function updateTenantUserRole(userId: string, role: string) {
    const { error } = await supabase.from('user_profiles').update({ role, updated_at: new Date().toISOString() }).eq('id', userId);
    if (error) throw new Error(translateError(error.message));
  }

  async function updateTenantUserStatus(userId: string, status: UserStatus) {
    const { error } = await supabase.from('user_profiles').update({ status, updated_at: new Date().toISOString() }).eq('id', userId);
    if (error) throw new Error(translateError(error.message));
  }

  async function deleteUser(userId: string) {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) throw new Error('Non connecté');

    const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-user`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`,
        'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ userId }),
    });

    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Erreur inconnue');
    return json;
  }

  async function deleteTenant(id: string) {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) throw new Error('Non connecté');

    const { data: rpcResult, error: rpcErr } = await supabase.rpc('cascade_delete_tenant', { p_tenant_id: id });
    if (rpcErr) throw new Error(translateError(rpcErr.message));
    if (!rpcResult?.success) throw new Error('Échec de la suppression');

    const userIds: string[] = rpcResult.user_ids_to_delete_from_auth ?? [];
    for (const userId of userIds) {
      try {
        const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-user`;
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({ userId }),
        });
        // Best-effort: tenant data is already deleted, auth user cleanup is secondary
        if (!res.ok) { /* ignore — user may already be gone */ }
      } catch { /* best-effort: DB data is already deleted */ }
    }

    setTenants(prev => prev.filter(t => t.id !== id));
  }

  async function deleteSubscription(id: string) {
    const { error } = await supabase.from('subscriptions').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    setSubscriptions(prev => prev.filter(s => s.id !== id));
  }

  async function fetchRevenueStats(): Promise<RevenueStats[]> {
    const { data, error } = await supabase
      .from('subscriptions')
      .select('amount, currency, status, starts_at, created_at, tenant_id, payment_method, plan_id')
      .order('created_at', { ascending: false });
    if (error) throw new Error(translateError(error.message));
    return (data ?? []) as unknown as RevenueStats[];
  }

  const fetchPlans = useCallback(async () => {
    const { data, error } = await supabase
      .from('license_plans')
      .select('*')
      .eq('active', true)
      .order('sort_order', { ascending: true });
    if (error) throw new Error(translateError(error.message));
    setPlans((data ?? []) as LicensePlan[]);
    return (data ?? []) as LicensePlan[];
  }, []);

  async function createPlan(input: Omit<LicensePlan, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase.from('license_plans').insert(input).select().maybeSingle();
    if (error) throw new Error(translateError(error.message));
    if (data) setPlans(prev => [...prev, data as LicensePlan].sort((a, b) => a.sort_order - b.sort_order));
    return data as LicensePlan;
  }

  async function deletePlan(id: string) {
    const { error } = await supabase.from('license_plans').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    setPlans(prev => prev.filter(p => p.id !== id));
  }

  return {
    tenants, subscriptions, plans, loading,
    fetchTenants, fetchSubscriptions, fetchPlans,
    createTenant, updateTenant, deleteTenant, createSubscription, deleteSubscription,
    createPlan, deletePlan,
    assignUserToTenant, createTenantUser,
    fetchTenantActivity, deleteUser, updateTenantUserRole, updateTenantUserStatus,
    fetchRevenueStats,
  };
}
