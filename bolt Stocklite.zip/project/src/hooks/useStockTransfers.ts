import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { StockTransfer, StockTransferItem, Product, SalesLocation } from '../types';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface TransferItemInput {
  product_id: string;
  quantity: number;
}

export interface CreateTransferInput {
  items: TransferItemInput[];
  from_location_id: string;
  to_location_id: string;
  notes: string;
}

export function useStockTransfers(locationId?: string | null, tenantId?: string | null) {
  const [transfers, setTransfers] = useState<StockTransfer[]>([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    const { data } = await supabase
      .from('stock_transfers')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);
    const rows = (data ?? []) as StockTransfer[];

    const productIds = [...new Set(
      rows.flatMap(t => [
        ...(t.product_id ? [t.product_id] : []),
        ...((t.items ?? []).map(i => i.product_id).filter(Boolean) as string[]),
      ])
    )];
    const locationIds = [...new Set([
      ...rows.map(t => t.from_location_id).filter(Boolean) as string[],
      ...rows.map(t => t.to_location_id).filter(Boolean) as string[],
    ])];

    const [prodsRes, locsRes, itemsRes] = await Promise.all([
      productIds.length
        ? supabase.from('products').select('id, name, unit').in('id', productIds)
        : Promise.resolve({ data: [] }),
      locationIds.length
        ? supabase.from('sales_locations').select('id, name').in('id', locationIds)
        : Promise.resolve({ data: [] }),
      rows.length
        ? supabase.from('stock_transfer_items').select('*').in('transfer_id', rows.map(r => r.id))
        : Promise.resolve({ data: [] as StockTransferItem[] | null }),
    ]);

    const prodMap = new Map((prodsRes.data ?? []).map(p => [p.id, p] as [string, Product]));
    const locMap = new Map((locsRes.data ?? []).map(l => [l.id, l] as [string, SalesLocation]));

    const itemsByTransfer = new Map<string, StockTransferItem[]>();
    for (const it of (itemsRes.data ?? []) as StockTransferItem[]) {
      const arr = itemsByTransfer.get(it.transfer_id) ?? [];
      arr.push({
        ...it,
        product: prodMap.get(it.product_id)
          ? { id: it.product_id, name: prodMap.get(it.product_id)!.name, unit: prodMap.get(it.product_id)!.unit }
          : undefined,
      });
      itemsByTransfer.set(it.transfer_id, arr);
    }

    setTransfers(rows.map(t => ({
      ...t,
      product: t.product_id && prodMap.get(t.product_id)
        ? { id: t.product_id, name: prodMap.get(t.product_id)!.name, unit: prodMap.get(t.product_id)!.unit }
        : null,
      from_location: locMap.get(t.from_location_id)
        ? { id: t.from_location_id, name: locMap.get(t.from_location_id)!.name }
        : undefined,
      to_location: locMap.get(t.to_location_id)
        ? { id: t.to_location_id, name: locMap.get(t.to_location_id)!.name }
        : undefined,
      items: itemsByTransfer.get(t.id) ?? [],
    })));
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch, tenantId]);

  async function create(input: CreateTransferInput): Promise<void> {
    const { items, from_location_id, to_location_id, notes } = input;
    const now = new Date().toISOString();

    if (!navigator.onLine) {
      const { data: { user } } = await supabase.auth.getUser();
      const queued: QueuedOp = {
        localId: crypto.randomUUID(),
        op: 'stockTransfer',
        payload: { ...input, _user_id: user?.id ?? null },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: locationId ?? null,
      };
      await queueOp(queued);
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();
    const transferId = crypto.randomUUID();

    const { error: transferErr } = await supabase.from('stock_transfers').insert({
      id: transferId,
      product_id: null,
      quantity: null,
      from_location_id,
      to_location_id,
      notes,
      status: 'en_attente',
      created_by: user?.id ?? null,
      created_at: now,
      updated_at: now,
    });
    if (transferErr) throw transferErr;

    if (items.length > 0) {
      const itemRows = items.map(it => ({
        id: crypto.randomUUID(),
        transfer_id: transferId,
        product_id: it.product_id,
        quantity: it.quantity,
        created_at: now,
      }));
      const { error: itemsErr } = await supabase.from('stock_transfer_items').insert(itemRows);
      if (itemsErr) throw itemsErr;
    }

    await fetch();
  }

  async function validate(transferId: string): Promise<void> {
    const now = new Date().toISOString();
    const { data: { user } } = await supabase.auth.getUser();

    // Fetch transfer + items
    const { data: transfer } = await supabase
      .from('stock_transfers')
      .select('*')
      .eq('id', transferId)
      .maybeSingle();
    if (!transfer) throw new Error('Transfert introuvable');
    if (transfer.status !== 'en_attente') throw new Error('Ce transfert a déjà été traité');

    const { data: items } = await supabase
      .from('stock_transfer_items')
      .select('*')
      .eq('transfer_id', transferId);
    if (!items || items.length === 0) throw new Error('Aucun article dans ce transfert');

    const fromLoc = transfer.from_location_id;
    const toLoc = transfer.to_location_id;

    for (const item of items) {
      const productId = item.product_id;
      const quantity = Number(item.quantity);

      const { data: prod } = await supabase.from('products').select('track_stock').eq('id', productId).maybeSingle();

      const srcId = `${productId}_${fromLoc}`;
      const { data: src } = await supabase.from('location_stock').select('*').eq('id', srcId).maybeSingle();
      const srcQty = Number(src?.stock_quantity ?? 0);
      const newSrcQty = Math.max(0, srcQty - quantity);
      await supabase.from('location_stock').upsert({
        id: srcId, product_id: productId, location_id: fromLoc,
        stock_quantity: newSrcQty, stock_min: src?.stock_min ?? 0,
        price: src?.price ?? null, updated_at: now,
      });

      const dstId = `${productId}_${toLoc}`;
      const { data: dst } = await supabase.from('location_stock').select('*').eq('id', dstId).maybeSingle();
      const dstQty = Number(dst?.stock_quantity ?? 0);
      await supabase.from('location_stock').upsert({
        id: dstId, product_id: productId, location_id: toLoc,
        stock_quantity: dstQty + quantity, stock_min: dst?.stock_min ?? 0,
        price: dst?.price ?? null, updated_at: now,
      });

      if (prod?.track_stock) {
        await supabase.from('stock_movements').insert({
          id: crypto.randomUUID(), product_id: productId, type: 'sortie', quantity, unit_cost: 0,
          reference: `Transfert → ${toLoc}`, notes: transfer.notes || 'Transfert inter-boutiques',
          location_id: fromLoc, created_at: now, updated_at: now,
        });
        await supabase.from('stock_movements').insert({
          id: crypto.randomUUID(), product_id: productId, type: 'entree', quantity, unit_cost: 0,
          reference: `Transfert ← ${fromLoc}`, notes: transfer.notes || 'Transfert inter-boutiques',
          location_id: toLoc, created_at: now, updated_at: now,
        });
      }
    }

    await supabase.from('stock_transfers').update({
      status: 'valide',
      validated_by: user?.id ?? null,
      validated_at: now,
      updated_at: now,
    }).eq('id', transferId);

    await fetch();
  }

  async function cancel(transferId: string): Promise<void> {
    const now = new Date().toISOString();
    const { error } = await supabase.from('stock_transfers').update({
      status: 'annule',
      updated_at: now,
    }).eq('id', transferId).eq('status', 'en_attente');
    if (error) throw error;
    await fetch();
  }

  return { transfers, loading, fetch, create, validate, cancel };
}
