import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Order, OrderItem, OrderStatus, Customer, Commercial } from '../types';
import type { CreateInvoiceInput } from './useInvoices';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface LineItemInput {
  id?: string;
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
  sort_order: number;
}

export interface CreateOrderInput {
  customer_id: string;
  commercial_id: string | null;
  date: string;
  tax_rate: number;
  notes: string;
  items: LineItemInput[];
  contact_name?: string | null;
  contact_email?: string | null;
  contact_phone?: string | null;
}

function calcTotals(items: LineItemInput[], taxRate: number) {
  const subtotal = items.reduce((s, i) => s + i.quantity * i.unit_price, 0);
  const tax_amount = Math.round(subtotal * (taxRate / 100) * 100) / 100;
  const total = Math.round((subtotal + tax_amount) * 100) / 100;
  return { subtotal: Math.round(subtotal * 100) / 100, tax_amount, total };
}

export function useOrders(locationId?: string | null, tenantId?: string | null) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    let query = supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(200);
    if (locationId) query = query.eq('location_id', locationId);
    const { data: rows, error } = await query;
    if (error) { setLoading(false); return; }
    const orderRows = (rows ?? []) as Order[];

    const customerIds = [...new Set(orderRows.map(o => o.customer_id).filter(Boolean) as string[])];
    const commercialIds = [...new Set(orderRows.map(o => o.commercial_id).filter(Boolean) as string[])];
    const custMap = new Map<string, Customer>();
    const commMap = new Map<string, Commercial>();
    if (customerIds.length) {
      const { data: custs } = await supabase.from('customers').select('*');
      for (const c of (custs ?? []) as Customer[]) if (customerIds.includes(c.id)) custMap.set(c.id, c);
    }
    if (commercialIds.length) {
      const { data: comms } = await supabase.from('commerciaux').select('*');
      for (const c of (comms ?? []) as Commercial[]) if (commercialIds.includes(c.id)) commMap.set(c.id, c);
    }

    const orderIds = orderRows.map(o => o.id);
    const itemsMap = new Map<string, OrderItem[]>();
    if (orderIds.length) {
      const { data: allItems } = await supabase.from('order_items').select('*');
      for (const it of (allItems ?? []) as OrderItem[]) {
        if (!orderIds.includes(it.order_id)) continue;
        const arr = itemsMap.get(it.order_id) ?? [];
        arr.push(it); itemsMap.set(it.order_id, arr);
      }
    }

    setOrders(orderRows.map(o => ({
      ...o,
      customer: o.customer_id ? custMap.get(o.customer_id) : undefined,
      commercial: o.commercial_id ? commMap.get(o.commercial_id) : undefined,
      items: (itemsMap.get(o.id) ?? []).sort((a, b) => a.sort_order - b.sort_order),
    })));
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetchAll()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetchAll, tenantId]);

  async function fetchOne(id: string): Promise<Order | null> {
    const { data: ord } = await supabase.from('orders').select('*').eq('id', id).maybeSingle();
    if (!ord) return null;
    const order = ord as Order;
    const { data: items } = await supabase.from('order_items').select('*').eq('order_id', id).order('sort_order');
    let customer: Customer | undefined;
    if (order.customer_id) {
      const { data: c } = await supabase.from('customers').select('*').eq('id', order.customer_id).maybeSingle();
      if (c) customer = c as Customer;
    }
    let commercial: Commercial | undefined;
    if (order.commercial_id) {
      const { data: c } = await supabase.from('commerciaux').select('*').eq('id', order.commercial_id).maybeSingle();
      if (c) commercial = c as Commercial;
    }
    return { ...order, customer, commercial, items: (items ?? []) as OrderItem[] };
  }

  async function create(input: CreateOrderInput): Promise<Order> {
    const { subtotal, tax_amount, total } = calcTotals(input.items, input.tax_rate);
    const now = new Date().toISOString();
    const ordId = crypto.randomUUID();
    const ordNumber = `CMD-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;

    if (!navigator.onLine) {
      const queued: QueuedOp = {
        localId: ordId,
        op: 'order',
        payload: { ...input, _id: ordId, _number: ordNumber, _location_id: locationId ?? null },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: locationId ?? null,
      };
      await queueOp(queued);
      return { id: ordId, order_number: ordNumber, customer_id: input.customer_id,
        commercial_id: input.commercial_id, location_id: locationId ?? null,
        date: input.date, status: 'brouillon', tax_rate: input.tax_rate,
        subtotal, tax_amount, total, notes: input.notes, created_by: null,
        contact_name: input.contact_name ?? null, contact_email: input.contact_email ?? null, contact_phone: input.contact_phone ?? null,
        created_at: now, updated_at: now } as Order;
    }

    const { error } = await supabase.from('orders').insert({
      id: ordId, order_number: ordNumber, customer_id: input.customer_id,
      commercial_id: input.commercial_id, location_id: locationId ?? null,
      date: input.date, status: 'brouillon', tax_rate: input.tax_rate,
      subtotal, tax_amount, total, notes: input.notes,
      contact_name: input.contact_name ?? null, contact_email: input.contact_email ?? null, contact_phone: input.contact_phone ?? null,
      created_by: null, created_at: now, updated_at: now,
    });
    if (error) throw new Error(translateError(error.message));

    const itemRows = input.items.map(i => ({
      id: crypto.randomUUID(), order_id: ordId, product_id: i.product_id || null,
      description: i.description, quantity: i.quantity, unit_price: i.unit_price,
      sort_order: i.sort_order,
      created_at: now, updated_at: now,
    }));
    if (itemRows.length) await supabase.from('order_items').insert(itemRows);

    await fetchAll();
    return { id: ordId, order_number: ordNumber, customer_id: input.customer_id,
      commercial_id: input.commercial_id, location_id: locationId ?? null,
      date: input.date, status: 'brouillon', tax_rate: input.tax_rate,
      subtotal, tax_amount, total, notes: input.notes, created_by: null,
      contact_name: input.contact_name ?? null, contact_email: input.contact_email ?? null, contact_phone: input.contact_phone ?? null,
      created_at: now, updated_at: now } as Order;
  }

  async function update(id: string, input: Partial<CreateOrderInput> & { status?: OrderStatus }) {
    const now = new Date().toISOString();
    const patch: Record<string, unknown> = { updated_at: now };
    if (input.customer_id !== undefined) patch.customer_id = input.customer_id;
    if (input.commercial_id !== undefined) patch.commercial_id = input.commercial_id;
    if (input.date !== undefined) patch.date = input.date;
    if (input.notes !== undefined) patch.notes = input.notes;
    if (input.status !== undefined) patch.status = input.status;
    if (input.contact_name !== undefined) patch.contact_name = input.contact_name;
    if (input.contact_email !== undefined) patch.contact_email = input.contact_email;
    if (input.contact_phone !== undefined) patch.contact_phone = input.contact_phone;

    if (input.items !== undefined) {
      const taxRate = input.tax_rate ?? 0;
      const { subtotal, tax_amount, total } = calcTotals(input.items, taxRate);
      patch.tax_rate = taxRate; patch.subtotal = subtotal; patch.tax_amount = tax_amount; patch.total = total;

      const { data: existing } = await supabase.from('order_items').select('*').eq('order_id', id);
      const existingMap = new Map((existing ?? []).map(e => [e.id, e]));
      const inputIds = new Set(input.items.map(i => i.id).filter(Boolean) as string[]);

      for (const it of existing ?? []) {
        if (!inputIds.has(it.id)) await supabase.from('order_items').delete().eq('id', it.id);
      }

      for (const i of input.items) {
        if (i.id && existingMap.has(i.id)) {
          await supabase.from('order_items').update({
            product_id: i.product_id || null, description: i.description,
            quantity: i.quantity, unit_price: i.unit_price,
            sort_order: i.sort_order, updated_at: now,
          }).eq('id', i.id);
        } else {
          const newId = i.id ?? crypto.randomUUID();
          await supabase.from('order_items').insert({
            id: newId, order_id: id, product_id: i.product_id || null,
            description: i.description, quantity: i.quantity, unit_price: i.unit_price,
            sort_order: i.sort_order, printed_at: null,
            created_at: now, updated_at: now,
          });
        }
      }
    }

    await supabase.from('orders').update(patch).eq('id', id);
    await fetchAll();
  }

  async function markItemsPrinted(itemIds: string[]) {
    const now = new Date().toISOString();
    for (const itemId of itemIds) {
      await supabase.from('order_items').update({ printed_at: now }).eq('id', itemId);
    }
    await fetchAll();
  }

  async function remove(id: string) {
    await supabase.from('order_items').delete().eq('order_id', id);
    const { error } = await supabase.from('orders').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetchAll();
  }

  async function convertToInvoice(
    orderId: string,
    createInvoice: (input: CreateInvoiceInput) => Promise<{ id: string }>,
  ): Promise<{ id: string } | null> {
    const ord = await fetchOne(orderId);
    if (!ord) return null;
    const invoiceInput: CreateInvoiceInput = {
      customer_id: ord.customer_id, date: ord.date, due_date: null,
      tax_rate: ord.tax_rate, notes: ord.notes,
      items: (ord.items ?? []).map(i => ({
        product_id: i.product_id, description: i.description,
        quantity: i.quantity, unit_price: i.unit_price, discount: i.discount ?? 0, sort_order: i.sort_order,
      })),
    };
    const invoice = await createInvoice(invoiceInput);
    await update(orderId, { status: 'convertie' });
    return invoice;
  }

  return { orders, loading, fetchOne, create, update, remove, convertToInvoice, markItemsPrinted, refetch: fetchAll };
}
