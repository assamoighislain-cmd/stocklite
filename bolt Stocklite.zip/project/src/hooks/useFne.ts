import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Invoice, InvoiceItem, CompanySettings, Customer, PaymentMethod } from '../types';

export interface FneCertifyResult {
  ncc: string;
  reference: string;
  token: string;
  warning: boolean;
  warningMessage?: string;
  balance_sticker: number;
  dgiInvoiceId?: string;
  dgiItemIds?: Record<string, string>;
}

export interface FneCertifyError {
  error: string;
  statusCode?: number;
}

function mapTaxRate(taxRate: number): string[] {
  if (taxRate >= 18) return ['TVA'];
  if (taxRate > 0) return ['TVAB'];
  return ['TVAC'];
}

type FnePaymentMethod = 'cash' | 'card' | 'check' | 'mobile-money' | 'transfer' | 'deferred';

function mapPaymentMethod(method: PaymentMethod | undefined): FnePaymentMethod {
  switch (method) {
    case 'especes': return 'cash';
    case 'carte': return 'card';
    case 'virement': return 'transfer';
    case 'cheque': return 'check';
    case 'orange_money':
    case 'wave':
    case 'mtn_money':
    case 'moov_money': return 'mobile-money';
    case 'avoir': return 'deferred';
    default: return 'cash';
  }
}

async function resolvePaymentMethod(invoice: Invoice): Promise<FnePaymentMethod> {
  const { data } = await supabase.from('payments').select('method, amount').eq('invoice_id', invoice.id);
  const active = (data ?? []) as { method: PaymentMethod; amount: number }[];
  if (active.length === 0) return 'deferred';
  if (active.length === 1) return mapPaymentMethod(active[0].method);
  const totals = new Map<FnePaymentMethod, number>();
  for (const p of active) {
    const m = mapPaymentMethod(p.method);
    totals.set(m, (totals.get(m) ?? 0) + Number(p.amount));
  }
  let best: FnePaymentMethod = 'cash';
  let bestAmt = -1;
  for (const [m, amt] of totals) { if (amt > bestAmt) { best = m; bestAmt = amt; } }
  return best;
}

function inferTemplate(customer: Customer | undefined): 'B2B' | 'B2C' {
  if (!customer) return 'B2C';
  if (customer.type === 'entreprise') return 'B2B';
  return 'B2C';
}

const VALID_UNITS = new Set([
  'pcs', 'kg', 'g', 'l', 'm', 'm2', 'm3', 'h', 'j', 'box', 'set', 'btl', 'bag', 'roll',
]);

function normalizeUnit(unit: string | undefined): string {
  if (!unit) return 'pcs';
  const u = unit.trim().toLowerCase();
  return VALID_UNITS.has(u) ? u : 'pcs';
}

export function useFne() {
  const [certifying, setCertifying] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<FneCertifyResult | null>(null);

  const certify = useCallback(async (
    invoice: Invoice,
    items: InvoiceItem[],
    settings: CompanySettings | null,
    customer: Customer | undefined,
    invoiceType: 'sale' | 'credit-note' = 'sale',
  ): Promise<FneCertifyResult | null> => {
    const paymentMethod = await resolvePaymentMethod(invoice);
    setCertifying(true);
    setError(null);
    setResult(null);

    try {
      const pointOfSale = settings?.fne_point_of_sale?.trim();
      const establishment = settings?.fne_establishment?.trim();
      if (!pointOfSale || !establishment) {
        throw new Error('Point de vente et établissement FNE requis (Paramètres).');
      }

      const productIds = items.map(it => it.product_id).filter(Boolean) as string[];
      const unitByProductId = new Map<string, string>();
      if (productIds.length) {
        const { data: products } = await supabase.from('products').select('id, unit').in('id', productIds);
        for (const p of (products ?? []) as { id: string; unit: string }[]) unitByProductId.set(p.id, p.unit);
      }

      let payload: Record<string, unknown>;
      let isRefund = false;

      if (invoiceType === 'credit-note' && invoice.credit_note_of) {
        // Refund flow: use DGI refund endpoint with original invoice's DGI IDs
        const { data: origInvoice } = await supabase.from('invoices')
          .select('fne_dgi_invoice_id, fne_reference')
          .eq('id', invoice.credit_note_of)
          .maybeSingle();

        const origData = origInvoice as { fne_dgi_invoice_id?: string; fne_reference?: string } | null;
        const dgiInvoiceId = origData?.fne_dgi_invoice_id ?? null;
        const origFneReference = origData?.fne_reference ?? null;

        if (!dgiInvoiceId && !origFneReference) {
          throw new Error('La facture originale n\'a ni ID DGI ni référence FNE. Re-certifiez la facture originale d\'abord.');
        }

        // Fetch original invoice items with their DGI item IDs
        const { data: origItems } = await supabase.from('invoice_items')
          .select('product_id, quantity, fne_dgi_item_id')
          .eq('invoice_id', invoice.credit_note_of);
        const origItemsList = (origItems ?? []) as { product_id: string | null; quantity: number; fne_dgi_item_id: string | null }[];

        // Map credit note items to DGI refund items
        const refundItems: { id: string; quantity: number }[] = [];
        for (const it of items) {
          const origItem = origItemsList.find(oi => oi.product_id === it.product_id);
          if (!origItem?.fne_dgi_item_id) {
            // If no DGI item ID stored, send product_id as fallback - edge function will try to resolve via GET
            refundItems.push({
              id: it.product_id ?? it.id,
              quantity: Math.abs(it.quantity),
            });
          } else {
            refundItems.push({
              id: origItem.fne_dgi_item_id,
              quantity: Math.abs(it.quantity),
            });
          }
        }

        isRefund = true;
        payload = {
          settingsId: settings?.id ?? undefined,
          mode: 'refund',
          ...(dgiInvoiceId ? { originalDgiInvoiceId: dgiInvoiceId } : {}),
          ...(origFneReference ? { originalFneReference: origFneReference } : {}),
          refundItems,
        };
      } else {
        // Standard sign flow
        payload = {
          settingsId: settings?.id ?? undefined,
          invoiceType: invoiceType === 'credit-note' ? 'sale' : invoiceType,
          paymentMethod,
          template: inferTemplate(customer),
          isRne: Boolean(settings?.fne_rne?.trim()),
          rne: settings?.fne_rne?.trim() || null,
          clientNcc: customer?.ncc ?? '',
          clientCompanyName: customer?.name ?? 'Client',
          clientPhone: customer?.phone ?? '',
          clientEmail: customer?.email ?? '',
          clientSellerName: settings?.name ?? '',
          pointOfSale,
          establishment,
          commercialMessage: settings?.invoice_footer ?? '',
          footer: null,
          foreignCurrency: '',
          foreignCurrencyRate: 0,
          items: items.map(it => {
            const pid = it.product_id;
            return {
              reference: pid ?? '',
              description: it.description,
              quantity: it.quantity,
              amount: it.unit_price,
              discount: 0,
              measurementUnit: normalizeUnit(unitByProductId.get(pid ?? '')),
              taxes: mapTaxRate(invoice.tax_rate),
            };
          }),
          customTaxes: [],
          discount: 0,
        };
      }

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/fne-certify`;
      const headers = {
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };
      const response = await fetch(apiUrl, { method: 'POST', headers, body: JSON.stringify(payload) });

      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const rawError = (data && typeof data === 'object' && 'error' in data && typeof (data as { error: unknown }).error === 'string')
          ? (data as { error: string }).error
          : `Erreur FNE (${response.status})`;
        const details = (data && typeof data === 'object' && 'details' in data) ? (data as { details: unknown }).details : null;
        throw new Error(details ? `${rawError} (Réponse DGI: ${JSON.stringify(details).slice(0, 200)})` : rawError);
      }

      const cert = data as FneCertifyResult;
      if (!cert.reference || !cert.token) {
        throw new Error('Réponse DGI invalide : référence ou token manquant.');
      }

      const now = new Date().toISOString();
      const patch: Record<string, unknown> = {
        fne_reference: cert.reference, fne_token: cert.token, fne_ncc: cert.ncc,
        fne_status: 'certified', fne_error: null, fne_certified_at: now,
        fne_warning: Boolean(cert.warning),
        fne_warning_message: cert.warningMessage ?? null,
        fne_balance_sticker: typeof cert.balance_sticker === 'number' ? cert.balance_sticker : null,
        updated_at: now,
      };
      if (invoiceType === 'sale') {
        patch.status = 'envoyee';
        if (cert.dgiInvoiceId) {
          patch.fne_dgi_invoice_id = cert.dgiInvoiceId;
        }
      }
      await supabase.from('invoices').update(patch).eq('id', invoice.id);

      // Store DGI item IDs on invoice_items for future refunds
      if (cert.dgiItemIds && invoiceType === 'sale') {
        for (const it of items) {
          const dgiItemId = cert.dgiItemIds[it.product_id ?? ''];
          if (dgiItemId && it.id) {
            await supabase.from('invoice_items').update({ fne_dgi_item_id: dgiItemId }).eq('id', it.id);
          }
        }
      }

      setResult(cert);
      return cert;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur certification FNE';
      setError(message);
      const now = new Date().toISOString();
      try {
        await supabase.from('invoices').update({ fne_status: 'error', fne_error: message, updated_at: now }).eq('id', invoice.id);
      } catch { /* best effort */ }
      return null;
    } finally {
      setCertifying(false);
    }
  }, []);

  return { certify, certifying, error, result };
}
