import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { UserProfile, UserRole, UserStatus } from '../types';
import { translateError } from '../lib/translateError';

export function useAdminUsers() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*, location:sales_locations(*), commercial:commerciaux(*)')
        .order('created_at', { ascending: true });
      if (error) throw new Error(translateError(error.message));
      setUsers((data ?? []) as UserProfile[]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  async function updateStatus(userId: string, status: UserStatus) {
    const now = new Date().toISOString();
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, status } : u));
    const { error } = await supabase.from('user_profiles').update({ status, updated_at: now }).eq('id', userId);
    if (error) throw new Error(translateError(error.message));
  }

  async function updateRole(userId: string, role: UserRole) {
    const now = new Date().toISOString();
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, role } : u));
    const { error } = await supabase.from('user_profiles').update({ role, updated_at: now }).eq('id', userId);
    if (error) throw new Error(translateError(error.message));
  }

  async function updateLocation(userId: string, locationId: string | null) {
    const now = new Date().toISOString();
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, location_id: locationId } : u));
    const { error } = await supabase.from('user_profiles').update({ location_id: locationId, updated_at: now }).eq('id', userId);
    if (error) throw new Error(translateError(error.message));
  }

  async function updateCommercial(userId: string, commercialId: string | null) {
    const now = new Date().toISOString();
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, commercial_id: commercialId } : u));
    const { error } = await supabase.from('user_profiles').update({ commercial_id: commercialId, updated_at: now }).eq('id', userId);
    if (error) throw new Error(translateError(error.message));
  }

  async function removeUser(userId: string) {
    const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-user`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token ?? ''}`,
        apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ userId }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error ?? `Échec (${res.status})`);
    }
    setUsers(prev => prev.filter(u => u.id !== userId));
  }

  async function createUser(input: { email: string; password: string; full_name: string; role: UserRole }) {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) throw new Error('Non connecté');
    const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-tenant-user`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
        apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
      },
      body: JSON.stringify(input),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error ?? 'Erreur inconnue');
    await fetchUsers();
    return json.user;
  }

  return { users, loading, error, fetchUsers, updateStatus, updateRole, updateLocation, updateCommercial, removeUser, createUser };
}
