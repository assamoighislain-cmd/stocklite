import { useCallback } from 'react';
import * as XLSX from 'xlsx';
import { supabase } from '../lib/supabase';
import type { Customer, Invoice, InvoiceItem, Payment, PaymentMethod, InvoiceStatus } from '../types';

export interface ImportResult {
  customers: number;
  invoices: number;
  invoiceItems: number;
  payments: number;
  errors: string[];
}

async function parseExcel(file: File): Promise<Record<string, string>[]> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array' });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  if (!sheet) return [];
  const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });
  const rows: Record<string, string>[] = json.map(obj => {
    const row: Record<string, string> = {};
    for (const [k, v] of Object.entries(obj)) {
      row[k] = v == null ? '' : String(v).trim();
    }
    return row;
  });
  return rows;
}

function findKey(obj: Record<string, string>, candidates: string[]): string | null {
  const keys = Object.keys(obj);
  for (const c of candidates) {
    const found = keys.find(k => k.toLowerCase().trim() === c.toLowerCase());
    if (found) return found;
  }
  return null;
}

function toNum(v: string): number {
  if (!v) return 0;
  const cleaned = v.replace(/\s/g, '').replace(',', '.').replace(/[^\d.-]/g, '');
  const n = parseFloat(cleaned);
  return isNaN(n) ? 0 : n;
}

function toDate(v: string): string {
  if (!v) return new Date().toISOString();
  const d = new Date(v);
  if (isNaN(d.getTime())) return new Date().toISOString();
  return d.toISOString();
}

const PAYMENT_METHODS: Record<string, PaymentMethod> = {
  'especes': 'especes', 'espèces': 'especes', 'cash': 'especes',
  'carte': 'carte', 'card': 'carte',
  'virement': 'virement', 'transfer': 'virement',
  'cheque': 'cheque', 'chèque': 'cheque', 'check': 'cheque',
  'orange_money': 'orange_money', 'orange': 'orange_money',
  'wave': 'wave',
  'mtn money': 'mtn_money', 'mtn': 'mtn_money',
  'moov money': 'moov_money', 'moov': 'moov_money',
  'avoir': 'avoir', 'credit': 'avoir',
  'autre': 'autre', 'other': 'autre',
};

function parseMethod(v: string): PaymentMethod {
  return PAYMENT_METHODS[v.toLowerCase().trim()] ?? 'especes';
}

function parseStatus(v: string): InvoiceStatus {
  const s = v.toLowerCase().trim();
  if (s === 'payee' || s === 'payée' || s === 'paye') return 'payee';
  if (s === 'partielle' || s === 'partial') return 'partielle';
  if (s === 'annulee' || s === 'annulée' || s === 'cancelled') return 'annulee';
  if (s === 'envoyee' || s === 'envoyée' || s === 'sent') return 'envoyee';
  return 'brouillon';
}

export function useImportData(locationId?: string | null) {
  const doImport = useCallback(async (
    files: { customers?: File; invoices?: File; invoiceItems?: File; payments?: File; },
    onProgress?: (current: number, total: number, label: string) => void
  ): Promise<ImportResult> => {
    const result: ImportResult = { customers: 0, invoices: 0, invoiceItems: 0, payments: 0, errors: [] };
    const now = new Date().toISOString();
    const customerCodeMap = new Map<string, string>();
    const invoiceNumberMap = new Map<string, string>();

    // Pre-parse all files to compute total row count for progress
    let total = 0;
    const parsed: { customers?: Record<string, string>[]; invoices?: Record<string, string>[]; invoiceItems?: Record<string, string>[]; payments?: Record<string, string>[] } = {};
    if (files.customers) { parsed.customers = await parseExcel(files.customers); total += parsed.customers.length; }
    if (files.invoices) { parsed.invoices = await parseExcel(files.invoices); total += parsed.invoices.length; }
    if (files.invoiceItems) { parsed.invoiceItems = await parseExcel(files.invoiceItems); total += parsed.invoiceItems.length; }
    if (files.payments) { parsed.payments = await parseExcel(files.payments); total += parsed.payments.length; }
    let current = 0;

    if (files.customers) {
      try {
        const rows = parsed.customers ?? [];
        for (const row of rows) {
          const codeKey = findKey(row, ['code', 'code_client', 'Code']);
          const nameKey = findKey(row, ['nom', 'name', 'raison_sociale', 'Raison sociale']);
          const phoneKey = findKey(row, ['telephone', 'phone', 'tel', 'Téléphone']);
          const emailKey = findKey(row, ['email', 'mail', 'Email']);
          const addressKey = findKey(row, ['adresse', 'address', 'Adresse']);
          const cityKey = findKey(row, ['ville', 'city', 'Ville']);
          const typeKey = findKey(row, ['type', 'Type']);
          const nccKey = findKey(row, ['ncc', 'NCC', 'numero_compte', 'Numéro Compte Contribuable']);

          const name = nameKey ? row[nameKey] : '';
          if (!name) { result.errors.push(`Client sans nom ignoré (ligne ${rows.indexOf(row) + 2})`); continue; }
          const code = codeKey ? row[codeKey] : '';
          const type = (typeKey && row[typeKey]?.toLowerCase().includes('entreprise')) ? 'entreprise' : 'particulier';

          const id = crypto.randomUUID();
          const customer = {
            id, code: code || null, name,
            email: emailKey ? row[emailKey] : '',
            phone: phoneKey ? row[phoneKey] : '',
            address: addressKey ? row[addressKey] : '',
            city: cityKey ? row[cityKey] : '',
            notes: '', location_id: locationId ?? null,
            type: type as 'particulier' | 'entreprise',
            ncc: type === 'entreprise' ? (nccKey ? row[nccKey] : null) : null,
            created_at: now, updated_at: now,
          };
          const { error } = await supabase.from('customers').insert(customer);
          if (error) { result.errors.push(`Client ${name}: ${error.message}`); continue; }
          if (code) customerCodeMap.set(code, id);
          result.customers++;
          current++; onProgress?.(current, total, 'Clients');
        }
      } catch (e) { result.errors.push(`Clients: ${e instanceof Error ? e.message : 'erreur'}`); }
    }

    if (files.invoices) {
      try {
        const rows = parsed.invoices ?? [];
        for (const row of rows) {
          const numKey = findKey(row, ['numero', 'invoice_number', 'Numero', 'N° Facture', 'N°']);
          const codeKey = findKey(row, ['code_client', 'client_code', 'Code Client', 'code']);
          const nameKey = findKey(row, ['client', 'nom_client', 'Client', 'Nom Client', 'nom']);
          const dateKey = findKey(row, ['date', 'Date', 'date_facture']);
          const dueKey = findKey(row, ['echeance', 'due_date', 'Échéance', 'Date échéance']);
          const statusKey = findKey(row, ['statut', 'status', 'Statut']);
          const subtotalKey = findKey(row, ['sous_total', 'subtotal', 'Sous-total', 'Sous total']);
          const taxKey = findKey(row, ['tva', 'tax_rate', 'TVA', 'Taux TVA']);
          const taxAmountKey = findKey(row, ['montant_tva', 'tax_amount', 'Montant TVA']);
          const totalKey = findKey(row, ['total', 'montant', 'Total', 'Montant']);
          const paidKey = findKey(row, ['montant_paye', 'amount_paid', 'Payé', 'Versé']);
          const notesKey = findKey(row, ['notes', 'observation', 'Notes']);

          const invoiceNumber = numKey ? row[numKey] : `IMP-${Date.now()}`;
          const code = codeKey ? row[codeKey] : '';
          const name = nameKey ? row[nameKey] : '';

          let customerId: string | null = null;
          if (code && customerCodeMap.has(code)) {
            customerId = customerCodeMap.get(code)!;
          } else {
            const { data: custs } = await supabase.from('customers').select('id, code, name');
            const match = (custs ?? []).find((c: Record<string, string>) =>
              (code && c.code === code) || (name && c.name?.toLowerCase() === name.toLowerCase()));
            if (match) customerId = match.id;
          }

          if (!customerId) {
            result.errors.push(`Facture ${invoiceNumber}: client non trouvé (${code || name})`);
            continue;
          }

          const subtotal = subtotalKey ? toNum(row[subtotalKey]) : 0;
          const taxRate = taxKey ? toNum(row[taxKey]) : 0;
          const taxAmount = taxAmountKey ? toNum(row[taxAmountKey]) : Math.round(subtotal * taxRate / 100 * 100) / 100;
          const total = totalKey ? toNum(row[totalKey]) : Math.round((subtotal + taxAmount) * 100) / 100;
          const paid = paidKey ? toNum(row[paidKey]) : 0;
          const status = statusKey ? parseStatus(row[statusKey]) : (paid >= total ? 'payee' : 'brouillon');

          const id = crypto.randomUUID();
          const invoice = {
            id, invoice_number: invoiceNumber, customer_id: customerId,
            date: dateKey ? toDate(row[dateKey]) : now,
            due_date: dueKey ? (row[dueKey] ? toDate(row[dueKey]) : null) : null,
            status, subtotal, tax_rate: taxRate, tax_amount: taxAmount,
            total, amount_paid: paid,
            notes: notesKey ? row[notesKey] : '', created_at: now, updated_at: now,
            ...(locationId ? { location_id: locationId } : {}),
          };
          const { error } = await supabase.from('invoices').insert(invoice);
          if (error) { result.errors.push(`Facture ${invoiceNumber}: ${error.message}`); continue; }
          invoiceNumberMap.set(invoiceNumber, id);
          result.invoices++;
          current++; onProgress?.(current, total, 'Factures');
        }
      } catch (e) { result.errors.push(`Factures: ${e instanceof Error ? e.message : 'erreur'}`); }
    }

    if (files.invoiceItems) {
      try {
        const rows = parsed.invoiceItems ?? [];
        const { data: allProducts } = await supabase.from('products').select('id, reference, name, purchase_price');
        const productByRef = new Map<string, string>();
        const productByName = new Map<string, string>();
        const productCostMap = new Map<string, number>();
        for (const p of (allProducts ?? []) as { id: string; reference: string | null; name: string; purchase_price: number }[]) {
          if (p.reference) productByRef.set(p.reference.toLowerCase().trim(), p.id);
          if (p.name) productByName.set(p.name.toLowerCase().trim(), p.id);
          productCostMap.set(p.id, Number(p.purchase_price) || 0);
        }

        for (const row of rows) {
          const numKey = findKey(row, ['numero_facture', 'invoice_number', 'Numero Facture', 'N° Facture', 'numero']);
          const refKey = findKey(row, ['reference_article', 'reference', 'Reference', 'Ref', 'ref_article']);
          const articleKey = findKey(row, ['nom_article', 'article', 'Article', 'produit', 'Produit', 'nom_produit']);
          const descKey = findKey(row, ['description', 'designation', 'Désignation']);
          const qtyKey = findKey(row, ['quantite', 'quantity', 'Quantité', 'Qte']);
          const priceKey = findKey(row, ['prix_unitaire', 'unit_price', 'Prix unitaire', 'PU', 'prix']);
          const totalKey = findKey(row, ['total', 'montant', 'Total', 'Montant']);

          const invoiceNumber = numKey ? row[numKey] : '';
          let invoiceId = invoiceNumberMap.get(invoiceNumber);
          if (!invoiceId) {
            const { data: inv } = await supabase.from('invoices').select('id').eq('invoice_number', invoiceNumber).maybeSingle();
            if (inv) invoiceId = (inv as { id: string }).id;
          }
          if (!invoiceId) { result.errors.push(`Ligne ignorée: facture ${invoiceNumber} non trouvée`); continue; }

          const articleRef = refKey ? row[refKey].trim() : '';
          const articleName = articleKey ? row[articleKey].trim() : '';
          const description = descKey ? row[descKey] : articleName;
          const quantity = qtyKey ? toNum(row[qtyKey]) : 1;
          const unitPrice = priceKey ? toNum(row[priceKey]) : 0;
          const itemTotal = totalKey ? toNum(row[totalKey]) : quantity * unitPrice;

          let productId: string | null = null;
          if (articleRef) productId = productByRef.get(articleRef.toLowerCase()) ?? null;
          if (!productId && articleName) productId = productByName.get(articleName.toLowerCase()) ?? null;

          const id = crypto.randomUUID();
          const { error } = await supabase.from('invoice_items').insert({
            id, invoice_id: invoiceId, product_id: productId,
            description: description || articleName, quantity,
            unit_price: unitPrice, unit_cost: productId ? (productCostMap.get(productId) ?? 0) : 0,
            sort_order: result.invoiceItems,
            created_at: now, updated_at: now,
          });
          if (error) { result.errors.push(`Ligne: ${error.message}`); continue; }
          result.invoiceItems++;
          current++; onProgress?.(current, total, 'Lignes facture');
        }
      } catch (e) { result.errors.push(`Lignes: ${e instanceof Error ? e.message : 'erreur'}`); }
    }

    if (files.payments) {
      try {
        const rows = parsed.payments ?? [];
        for (const row of rows) {
          const numKey = findKey(row, ['numero_facture', 'invoice_number', 'Numero Facture', 'N° Facture', 'facture']);
          const codeKey = findKey(row, ['code_client', 'client_code', 'Code Client', 'code']);
          const amountKey = findKey(row, ['montant', 'amount', 'Montant']);
          const methodKey = findKey(row, ['methode', 'method', 'Méthode', 'mode', 'Mode']);
          const dateKey = findKey(row, ['date', 'payment_date', 'Date', 'Date paiement']);
          const notesKey = findKey(row, ['notes', 'reference', 'Notes', 'Référence']);

          const invoiceNumber = numKey ? row[numKey] : '';
          let invoiceId: string | null = null;
          if (invoiceNumber) {
            invoiceId = invoiceNumberMap.get(invoiceNumber) ?? null;
            if (!invoiceId) {
              const { data: inv } = await supabase.from('invoices').select('id').eq('invoice_number', invoiceNumber).maybeSingle();
              if (inv) invoiceId = (inv as { id: string }).id;
            }
          }

          let customerId: string | null = null;
          if (invoiceId) {
            const { data: inv } = await supabase.from('invoices').select('customer_id').eq('id', invoiceId).maybeSingle();
            customerId = (inv as { customer_id: string } | null)?.customer_id ?? null;
          }
          if (!customerId && codeKey) {
            const code = row[codeKey];
            customerId = customerCodeMap.get(code) ?? null;
            if (!customerId) {
              const { data: cust } = await supabase.from('customers').select('id').eq('code', code).maybeSingle();
              if (cust) customerId = (cust as { id: string }).id;
            }
          }

          if (!customerId) { result.errors.push(`Règlement ignoré: client non trouvé`); continue; }

          const amount = amountKey ? toNum(row[amountKey]) : 0;
          if (amount <= 0) { result.errors.push(`Règlement ignoré: montant nul`); continue; }

          const id = crypto.randomUUID();
          const { error } = await supabase.from('payments').insert({
            id, customer_id: customerId, invoice_id: invoiceId, amount,
            method: methodKey ? parseMethod(row[methodKey]) : 'especes',
            payment_date: dateKey ? toDate(row[dateKey]) : now,
            notes: notesKey ? row[notesKey] : '', created_at: now, updated_at: now,
          });
          if (error) { result.errors.push(`Règlement: ${error.message}`); continue; }

          if (invoiceId) {
            const { data: inv } = await supabase.from('invoices').select('total, amount_paid').eq('id', invoiceId).maybeSingle() as { data: { total: number; amount_paid: number } | null };
            if (inv) {
              const newPaid = Math.min(Number(inv.total), Number(inv.amount_paid) + amount);
              const status = newPaid >= Number(inv.total) ? 'payee' : 'partielle';
              await supabase.from('invoices').update({
                amount_paid: newPaid,
                status, updated_at: now,
              }).eq('id', invoiceId);
            }
          }
          result.payments++;
          current++; onProgress?.(current, total, 'Règlements');
        }
      } catch (e) { result.errors.push(`Règlements: ${e instanceof Error ? e.message : 'erreur'}`); }
    }

    return result;
  }, [locationId]);

  return { doImport };
}

export { parseExcel };
