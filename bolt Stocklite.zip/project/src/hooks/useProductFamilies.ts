import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { ProductFamily } from '../types';
import { translateError } from '../lib/translateError';
import { cacheFamilies, getCachedFamilies, queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export function useProductFamilies(tenantId?: string | null) {
  const [families, setFamilies] = useState<ProductFamily[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    const { data, error } = await supabase.from('product_families').select('*').order('sort_order');
    if (error) {
      const cached = await getCachedFamilies<ProductFamily>();
      setFamilies(cached);
      setLoading(false);
      return;
    }
    const rows = (data ?? []) as ProductFamily[];
    setFamilies(rows);
    await cacheFamilies(rows);
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch, tenantId]);

  async function saveFamily(payload: { name: string; color: string; sort_order: number; printer_name: string | null }, id?: string) {
    const now = new Date().toISOString();
    if (!navigator.onLine) {
      const queued: QueuedOp = {
        localId: id ?? crypto.randomUUID(),
        op: 'productFamily',
        payload: { ...payload, _id: id, _isUpdate: !!id },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
      };
      await queueOp(queued);
      return;
    }
    if (id) {
      const { error } = await supabase.from('product_families').update({ ...payload, updated_at: now }).eq('id', id);
      if (error) throw new Error(translateError(error.message));
    } else {
      const { error } = await supabase.from('product_families').insert({ ...payload, created_at: now, updated_at: now });
      if (error) throw new Error(translateError(error.message));
    }
    await fetch();
  }

  async function removeFamily(id: string) {
    const { error } = await supabase.from('product_families').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  return { families, loading, refetch: fetch, saveFamily, removeFamily };
}
