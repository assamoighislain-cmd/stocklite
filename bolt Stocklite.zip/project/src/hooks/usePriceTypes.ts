import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { PriceType, ProductPriceType } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export function usePriceTypes(tenantId?: string | null) {
  const [priceTypes, setPriceTypes] = useState<PriceType[]>([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    const { data } = await supabase.from('price_types').select('*').order('sort_order');
    setPriceTypes((data ?? []) as PriceType[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch, tenantId]);

  async function save(payload: Omit<PriceType, 'id' | 'created_at'> & { id?: string }) {
    const { id, ...fields } = payload;
    const now = new Date().toISOString();
    if (!navigator.onLine) {
      const recordId = id ?? crypto.randomUUID();
      const queued: QueuedOp = {
        localId: recordId,
        op: 'priceType',
        payload: { ...fields, _id: recordId, _isUpdate: !!id },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
      };
      await queueOp(queued);
      return;
    }
    if (id) {
      const { error } = await supabase.from('price_types').update({ ...fields, updated_at: now }).eq('id', id);
      if (error) throw new Error(translateError(error.message));
    } else {
      const recordId = crypto.randomUUID();
      const { error } = await supabase.from('price_types').insert({ ...fields, id: recordId, created_at: now, updated_at: now });
      if (error) throw new Error(translateError(error.message));
    }
    await fetch();
  }

  async function remove(id: string) {
    const { error } = await supabase.from('price_types').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  async function fetchProductPrices(productId: string): Promise<ProductPriceType[]> {
    const { data } = await supabase.from('product_price_types').select('*, price_type:price_types(*)').eq('product_id', productId);
    return (data ?? []) as ProductPriceType[];
  }

  async function saveProductPrices(productId: string, prices: { price_type_id: string; price: number }[]) {
    const now = new Date().toISOString();
    for (const p of prices) {
      if (p.price < 0) continue;
      await supabase.from('product_price_types').upsert({
        product_id: productId, price_type_id: p.price_type_id,
        price: p.price, updated_at: now,
      }, { onConflict: 'product_id,price_type_id' });
    }
  }

  async function deleteProductPrice(productId: string, priceTypeId: string) {
    const { error } = await supabase.from('product_price_types')
      .delete()
      .eq('product_id', productId)
      .eq('price_type_id', priceTypeId);
    if (error) throw new Error(translateError(error.message));
  }

  async function fetchLocationProductPrices(productId: string): Promise<{
    location_id: string; price_type_id: string; price: number;
  }[]> {
    const { data } = await supabase.from('location_product_price_types').select('location_id, price_type_id, price').eq('product_id', productId);
    return (data ?? []) as { location_id: string; price_type_id: string; price: number }[];
  }

  async function saveLocationProductPrices(
    productId: string,
    entries: { location_id: string; price_type_id: string; price: number }[],
    removedIds: string[]
  ): Promise<void> {
    const now = new Date().toISOString();
    for (const e of entries) {
      if (e.price < 0) continue;
      const id = `${productId}_${e.location_id}_${e.price_type_id}`;
      await supabase.from('location_product_price_types').upsert({
        id, product_id: productId, location_id: e.location_id,
        price_type_id: e.price_type_id, price: e.price, updated_at: now,
      });
    }
    for (const id of removedIds) {
      await supabase.from('location_product_price_types').delete().eq('id', id);
    }
  }

  return { priceTypes, loading, fetch, save, remove, fetchProductPrices, saveProductPrices, deleteProductPrice, fetchLocationProductPrices, saveLocationProductPrices };
}
