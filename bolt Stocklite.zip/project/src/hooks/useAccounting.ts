import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { translateError } from '../lib/translateError';
import { queueOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface AccountingEntry {
  id: string;
  date: string;
  type: 'recette' | 'charge';
  category: string;
  description: string;
  amount: number;
  payment_method: string;
  reference: string;
  notes: string;
  created_at: string;
  location_id?: string | null;
  source?: 'manual' | 'caisse';
  caisse_id?: string | null;
  updated_at?: string;
}

export interface PnLData {
  pos_revenue: number;
  invoice_revenue: number;
  manual_revenue: number;
  total_charges: number;
  supply_cost: number;
  total_creances: number;
  creances_count: number;
  pos_by_method: { method: string; amount: number }[];
  invoice_by_method: { method: string; amount: number }[];
  charges_by_category: { category: string; amount: number }[];
  recettes_by_category: { category: string; amount: number }[];
}

export interface HistoryItem {
  id: string;
  date: string;
  type: 'pos' | 'invoice' | 'supply';
  number: string;
  label: string;
  amount: number;
  status?: string;
}

export interface SalesHistoryRow {
  saleId: string;
  saleType: 'pos' | 'invoice';
  date: string;
  ref: string;
  designation: string;
  quantity: number;
  amount: number;
  unitCost: number;
  cost: number;
  margin: number;
  customer: string;
}

export interface MonthlyBar {
  month: string;
  label: string;
  revenue: number;
  charges: number;
}

export const CHARGE_CATEGORIES: { value: string; label: string }[] = [
  { value: 'salaires',            label: 'Salaires & charges sociales' },
  { value: 'loyer',               label: 'Loyer & charges locatives' },
  { value: 'electricite_eau',     label: 'Électricité & eau' },
  { value: 'transport',           label: 'Transport & déplacement' },
  { value: 'communication',       label: 'Téléphone & internet' },
  { value: 'fournitures',         label: 'Fournitures de bureau' },
  { value: 'charges_fiscales',    label: 'Impôts & taxes' },
  { value: 'maintenance',         label: 'Entretien & réparations' },
  { value: 'prestataires',        label: 'Honoraires & sous-traitance' },
  { value: 'autres_charges',      label: 'Autres charges' },
];

export const RECETTE_CATEGORIES: { value: string; label: string }[] = [
  { value: 'autre_vente',         label: 'Autres ventes' },
  { value: 'prestation_service',  label: 'Prestations de services' },
  { value: 'remboursement',       label: 'Remboursements reçus' },
  { value: 'subvention',          label: 'Subventions & aides' },
  { value: 'autres_recettes',     label: 'Autres recettes' },
];

export function categoryLabel(cat: string, type: 'recette' | 'charge'): string {
  const list = type === 'charge' ? CHARGE_CATEGORIES : RECETTE_CATEGORIES;
  return list.find(c => c.value === cat)?.label ?? cat;
}

export function useAccounting(locationId?: string | null) {
  const [entries, setEntries] = useState<AccountingEntry[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchEntries = useCallback(async () => {
    setLoading(true);
    let query = supabase.from('accounting_entries').select('*').order('date', { ascending: false }).order('created_at', { ascending: false });
    if (locationId) query = query.eq('location_id', locationId);
    const { data, error } = await query;
    if (error) console.error('[accounting] fetchEntries:', error.message);
    setEntries((data ?? []) as AccountingEntry[]);
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetchEntries(); }, [fetchEntries]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(null).then(() => fetchEntries()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetchEntries]);

  async function createEntry(input: Omit<AccountingEntry, 'id' | 'created_at' | 'updated_at'>) {
    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    const payload = locationId ? { ...input, location_id: locationId } : input;

    if (!navigator.onLine) {
      await queueOp({ localId: id, op: 'accountingEntry', createdAt: now, status: 'pending', payload: { ...payload, _id: id, _location_id: locationId ?? null } });
      return;
    }

    const { error } = await supabase.from('accounting_entries').insert({ ...payload, id, created_at: now, updated_at: now });
    if (error) throw new Error(translateError(error.message));
    await fetchEntries();
  }

  async function deleteEntry(id: string) {
    const { error } = await supabase.from('accounting_entries').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetchEntries();
  }

  const computePnL = useCallback(async (periodStart: string, periodEnd: string): Promise<PnLData> => {
    let posQuery = supabase.from('pos_sales').select('id, total, created_at, location_id');
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    const { data: posSales } = await posQuery;
    let posRows = (posSales ?? []) as { id: string; total: number; created_at: string; location_id?: string }[];

    let entryQuery = supabase.from('accounting_entries').select('*');
    if (locationId) entryQuery = entryQuery.eq('location_id', locationId);
    const { data: entryRows } = await entryQuery;
    const allEntries = (entryRows ?? []) as AccountingEntry[];

    const { data: payments } = await supabase.from('payments').select('*');
    const allPayments = (payments ?? []) as { payment_date: string; method: string; amount: number; invoice_id: string | null }[];

    const { data: invoices } = await supabase.from('invoices').select('*');
    const allInvoices = (invoices ?? []) as { id: string; total: number; amount_paid: number; balance_due: number; status: string; date: string; customer_id: string | null }[];

    let dnQuery = supabase.from('delivery_notes').select('id, note_number, note_date, total_amount, status, supplier:suppliers(name)').eq('status', 'valide');
    if (locationId) dnQuery = dnQuery.eq('location_id', locationId);
    const { data: dnRows } = await dnQuery;
    const allDeliveryNotes = (dnRows ?? []) as { id: string; note_number: string; note_date: string; total_amount: number; status: string; supplier: { name: string } | null }[];

    const startMs = new Date(periodStart + 'T00:00:00').getTime();
    const endMs = new Date(periodEnd + 'T23:59:59').getTime();
    const inPeriod = (ts?: string) => { if (!ts) return false; const t = new Date(ts).getTime(); return t >= startMs && t <= endMs; };

    const posInPeriod = posRows.filter(s => inPeriod(s.created_at));
    const posIds = new Set(posInPeriod.map(s => s.id));
    let posPayments: { method: string; amount: number; sale_id: string }[] = [];
    if (posIds.size > 0) {
      const { data: posPays } = await supabase.from('pos_payments').select('*').in('sale_id', [...posIds]);
      posPayments = (posPays ?? []) as { method: string; amount: number; sale_id: string }[];
    }

    const invPayments = allPayments.filter(p => p.payment_date && p.payment_date.slice(0, 10) >= periodStart && p.payment_date.slice(0, 10) <= periodEnd);
    const ents = allEntries.filter(e => e.date >= periodStart && e.date <= periodEnd);

    const posRevenue = posInPeriod.reduce((s, sale) => s + Number(sale.total), 0);
    const invoicesInPeriod = allInvoices.filter(i => inPeriod(i.date) && i.status !== 'brouillon' && i.status !== 'annulee');
    const invoiceRevenue = invoicesInPeriod.reduce((s, i) => s + Number(i.total), 0);
    const manualRevenue = ents.filter(e => e.type === 'recette').reduce((s, e) => s + Number(e.amount), 0);
    const totalCharges = ents.filter(e => e.type === 'charge' && e.category !== 'achats_marchandises').reduce((s, e) => s + Number(e.amount), 0);

    const posMethodMap: Record<string, number> = {};
    const invMethodMap: Record<string, number> = {};
    const catChargeMap: Record<string, number> = {};
    const catRecetteMap: Record<string, number> = {};

    for (const p of posPayments) posMethodMap[p.method] = (posMethodMap[p.method] ?? 0) + Number(p.amount);
    for (const p of invPayments) invMethodMap[p.method] = (invMethodMap[p.method] ?? 0) + Number(p.amount);
    for (const e of ents) {
      if (e.type === 'charge' && e.category !== 'achats_marchandises') catChargeMap[e.category] = (catChargeMap[e.category] ?? 0) + Number(e.amount);
      else if (e.type === 'recette') catRecetteMap[e.category] = (catRecetteMap[e.category] ?? 0) + Number(e.amount);
    }

    const outstandingInvoices = allInvoices.filter(i => (i.status === 'envoyee' || i.status === 'partielle') && Number(i.balance_due) > 0);
    const totalCreances = outstandingInvoices.reduce((s, i) => s + Number(i.balance_due), 0);

    const supplyInPeriod = allDeliveryNotes.filter(dn => dn.note_date >= periodStart && dn.note_date <= periodEnd);
    const supplyCost = supplyInPeriod.reduce((s, dn) => s + Number(dn.total_amount), 0);

    const byAmt = (a: { amount: number }, b: { amount: number }) => b.amount - a.amount;
    return {
      pos_revenue: posRevenue, invoice_revenue: invoiceRevenue, manual_revenue: manualRevenue,
      total_charges: totalCharges, supply_cost: supplyCost,
      total_creances: totalCreances, creances_count: outstandingInvoices.length,
      pos_by_method: Object.entries(posMethodMap).map(([method, amount]) => ({ method, amount })).sort(byAmt),
      invoice_by_method: Object.entries(invMethodMap).map(([method, amount]) => ({ method, amount })).sort(byAmt),
      charges_by_category: Object.entries(catChargeMap).map(([category, amount]) => ({ category, amount })).sort(byAmt),
      recettes_by_category: Object.entries(catRecetteMap).map(([category, amount]) => ({ category, amount })).sort(byAmt),
    };
  }, [locationId]);

  const computeMonthlyTrend = useCallback(async (months = 6): Promise<MonthlyBar[]> => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() - months + 1, 1).toISOString().slice(0, 10);
    const end = now.toISOString().slice(0, 10);

    let posQuery = supabase.from('pos_sales').select('id, total, created_at').gte('created_at', start).lte('created_at', end);
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    const { data: posSales } = await posQuery;
    const posRows = (posSales ?? []) as { id: string; total: number; created_at: string }[];

    let entryQuery = supabase.from('accounting_entries').select('*').gte('date', start).lte('date', end);
    if (locationId) entryQuery = entryQuery.eq('location_id', locationId);
    const { data: entryRows } = await entryQuery;
    const entries = (entryRows ?? []) as AccountingEntry[];

    const { data: invRows } = await supabase.from('invoices').select('total, date, status').gte('date', start).lte('date', end);
    const allInvoices = (invRows ?? []) as { total: number; date: string; status: string }[];

    const revMap: Record<string, number> = {};
    const chgMap: Record<string, number> = {};

    for (const s of posRows) { const m = s.created_at.slice(0, 7); revMap[m] = (revMap[m] ?? 0) + Number(s.total); }
    for (const i of allInvoices) {
      if (i.status === 'brouillon' || i.status === 'annulee') continue;
      const m = i.date.slice(0, 7); revMap[m] = (revMap[m] ?? 0) + Number(i.total);
    }
    for (const e of entries) {
      const m = e.date.slice(0, 7);
      if (e.type === 'recette') revMap[m] = (revMap[m] ?? 0) + Number(e.amount);
      else if (e.type === 'charge' && e.category !== 'achats_marchandises') chgMap[m] = (chgMap[m] ?? 0) + Number(e.amount);
    }

    return Array.from({ length: months }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (months - 1 - i), 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const lbl = d.toLocaleDateString('fr-FR', { month: 'short', year: 'numeric' });
      return { month: key, label: lbl.charAt(0).toUpperCase() + lbl.slice(1), revenue: revMap[key] ?? 0, charges: chgMap[key] ?? 0 };
    });
  }, [locationId]);

  const computeHistory = useCallback(async (periodStart: string, periodEnd: string): Promise<HistoryItem[]> => {
    const items: HistoryItem[] = [];

    let posQuery = supabase.from('pos_sales').select('id, sale_number, total, created_at, customer:customers(name)').gte('created_at', periodStart + 'T00:00:00').lte('created_at', periodEnd + 'T23:59:59');
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    const { data: posRows } = await posQuery;
    for (const s of (posRows ?? []) as { id: string; sale_number: string; total: number; created_at: string; customer: { name: string } | null }[]) {
      items.push({ id: s.id, date: s.created_at, type: 'pos', number: s.sale_number, label: s.customer?.name ?? 'Vente comptoir', amount: Number(s.total) });
    }

    const { data: invRows } = await supabase.from('invoices').select('id, invoice_number, total, date, status, customer:customers(name)').gte('date', periodStart).lte('date', periodEnd);
    for (const i of (invRows ?? []) as { id: string; invoice_number: string; total: number; date: string; status: string; customer: { name: string } | null }[]) {
      if (i.status === 'brouillon' || i.status === 'annulee') continue;
      items.push({ id: i.id, date: i.date, type: 'invoice', number: i.invoice_number, label: i.customer?.name ?? 'Facture', amount: Number(i.total), status: i.status });
    }

    let dnQuery = supabase.from('delivery_notes').select('id, note_number, note_date, total_amount, status, supplier:suppliers(name)').eq('status', 'valide').gte('note_date', periodStart).lte('note_date', periodEnd);
    if (locationId) dnQuery = dnQuery.eq('location_id', locationId);
    const { data: dnRows } = await dnQuery;
    for (const d of (dnRows ?? []) as { id: string; note_number: string; note_date: string; total_amount: number; status: string; supplier: { name: string } | null }[]) {
      items.push({ id: d.id, date: d.note_date, type: 'supply', number: d.note_number, label: d.supplier?.name ?? 'Fournisseur', amount: -Number(d.total_amount), status: d.status });
    }

    items.sort((a, b) => b.date.localeCompare(a.date));
    return items;
  }, [locationId]);

  const computeSalesHistory = useCallback(async (periodStart: string, periodEnd: string): Promise<SalesHistoryRow[]> => {
    const rows: SalesHistoryRow[] = [];

    let posQuery = supabase.from('pos_sales')
      .select('id, sale_number, created_at, customer:customers(name), items:pos_sale_items(product_id, description, quantity, unit_price, total, unit_cost)')
      .gte('created_at', periodStart + 'T00:00:00').lte('created_at', periodEnd + 'T23:59:59');
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    const { data: posRows } = await posQuery;
    for (const s of (posRows ?? []) as { id: string; sale_number: string; created_at: string; customer: { name: string } | null; items: { product_id: string | null; description: string; quantity: number; unit_price: number; total: number; unit_cost: number }[] }[]) {
      for (const item of s.items ?? []) {
        const unitCost = Number(item.unit_cost) || 0;
        const cost = unitCost * Number(item.quantity);
        const amount = Number(item.total);
        rows.push({
          saleId: s.id, saleType: 'pos', date: s.created_at, ref: s.sale_number,
          designation: item.description, quantity: Number(item.quantity),
          amount, unitCost, cost, margin: amount - cost,
          customer: s.customer?.name ?? 'Comptoir',
        });
      }
    }

    const { data: invRows } = await supabase.from('invoices')
      .select('id, invoice_number, date, status, customer:customers(name), items:invoice_items(product_id, description, quantity, unit_price, discount, total, unit_cost)')
      .gte('date', periodStart).lte('date', periodEnd);
    for (const inv of (invRows ?? []) as { id: string; invoice_number: string; date: string; status: string; customer: { name: string } | null; items: { product_id: string | null; description: string; quantity: number; unit_price: number; discount: number; total: number; unit_cost: number }[] }[]) {
      if (inv.status === 'brouillon' || inv.status === 'annulee') continue;
      for (const item of inv.items ?? []) {
        const unitCost = Number(item.unit_cost) || 0;
        const cost = unitCost * Number(item.quantity);
        const amount = Number(item.total);
        rows.push({
          saleId: inv.id, saleType: 'invoice', date: inv.date, ref: inv.invoice_number,
          designation: item.description, quantity: Number(item.quantity),
          amount, unitCost, cost, margin: amount - cost,
          customer: inv.customer?.name ?? 'Client',
        });
      }
    }

    rows.sort((a, b) => b.date.localeCompare(a.date));
    return rows;
  }, [locationId]);

  return { entries, loading, fetchEntries, createEntry, deleteEntry, computePnL, computeMonthlyTrend, computeHistory, computeSalesHistory };
}
