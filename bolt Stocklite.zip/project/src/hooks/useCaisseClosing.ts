import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { PaymentMethod } from '../types';
import { ALL_PAYMENT_METHODS } from '../types';
import { translateError } from '../lib/translateError';
import { queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export interface ClosingLine {
  method: PaymentMethod;
  expected_amount: number;
  counted_amount: number;
  difference: number;
}

export interface CaisseClosing {
  id: string;
  user_id: string | null;
  location_id: string | null;
  caisse_id: string | null;
  date: string;
  period_start: string;
  period_end: string;
  status: 'brouillon' | 'cloturee';
  notes: string;
  created_at: string;
  lines?: ClosingLine[];
  user?: { full_name: string; email: string } | null;
}

export interface ExpectedByMethod { method: PaymentMethod; expected_amount: number; }
export interface ProductSaleSummary { description: string; total_quantity: number; total_amount: number; }

export interface PosJournalEntry {
  id: string;
  sale_number: string;
  created_at: string;
  customer_name: string | null;
  total: number;
  payment_methods: string;
}

export interface InvoiceJournalEntry {
  id: string;
  invoice_number: string;
  date: string;
  customer_name: string | null;
  total: number;
  amount_paid: number;
  status: string;
}

export interface PaymentSummaryEntry {
  method: PaymentMethod;
  pos_amount: number;
  invoice_amount: number;
  total: number;
  count: number;
}

export function useCaisseClosing(locationId?: string | null, tenantId?: string | null) {
  const [loading, setLoading] = useState(false);
  const [caisseId, setCaisseId] = useState<string | null>(null);
  const [closings, setClosings] = useState<CaisseClosing[]>([]);

  const fetchClosings = useCallback(async () => {
    let query = supabase.from('caisse_closings').select('*').order('created_at', { ascending: false }).limit(50);
    if (locationId) query = query.eq('location_id', locationId);
    if (caisseId) query = query.eq('caisse_id', caisseId);
    const { data } = await query;
    const rows = (data ?? []) as CaisseClosing[];

    const closingIds = rows.map(c => c.id);
    const linesMap = new Map<string, ClosingLine[]>();
    if (closingIds.length) {
      const { data: lines } = await supabase.from('caisse_closing_lines').select('*').in('closing_id', closingIds);
      for (const l of (lines ?? []) as (ClosingLine & { closing_id: string })[]) {
        const arr = linesMap.get(l.closing_id) ?? [];
        arr.push(l); linesMap.set(l.closing_id, arr);
      }
    }
    setClosings(rows.map(c => ({ ...c, lines: linesMap.get(c.id) ?? [] })));
    setLoading(false);
  }, [locationId, caisseId]);

  useEffect(() => { fetchClosings(); }, [fetchClosings]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetchClosings()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetchClosings, tenantId]);

  const computeExpected = useCallback(async (periodStart: string, periodEnd: string, caisse?: string | null): Promise<ExpectedByMethod[]> => {
    const cId = caisse ?? caisseId;
    let posQuery = supabase.from('pos_sales').select('id, created_at').gte('created_at', periodStart).lte('created_at', periodEnd);
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    if (cId) posQuery = posQuery.eq('caisse_id', cId);
    const { data: posSales } = await posQuery;
    const inPeriod = (posSales ?? []) as { id: string }[];
    const map: Record<string, number> = {};

    if (inPeriod.length) {
      const saleIds = inPeriod.map(s => s.id);
      const { data: pays } = await supabase.from('pos_payments').select('method, amount').in('sale_id', saleIds);
      for (const p of (pays ?? []) as { method: string; amount: number }[]) map[p.method] = (map[p.method] ?? 0) + Number(p.amount);
    }

    let opsQuery = supabase.from('accounting_entries').select('amount, payment_method, date, caisse_id').eq('source', 'caisse');
    if (cId) opsQuery = opsQuery.eq('caisse_id', cId);
    else opsQuery = opsQuery.gte('date', periodStart).lte('date', periodEnd);
    const { data: ops } = await opsQuery;
    for (const op of (ops ?? []) as { amount: number; payment_method: string }[]) {
      const method = op.payment_method ?? 'espèces';
      map[method] = (map[method] ?? 0) - Number(op.amount);
    }

    const result: ExpectedByMethod[] = ALL_PAYMENT_METHODS.map(m => ({
      method: m.value as PaymentMethod,
      expected_amount: map[m.value] ?? 0,
    }));
    return result;
  }, [locationId, caisseId]);

  const computeProductSales = useCallback(async (periodStart: string, periodEnd: string, caisse?: string | null): Promise<ProductSaleSummary[]> => {
    const cId = caisse ?? caisseId;
    let posQuery = supabase.from('pos_sales').select('id').gte('created_at', periodStart).lte('created_at', periodEnd);
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    if (cId) posQuery = posQuery.eq('caisse_id', cId);
    const { data: posSales } = await posQuery;
    const saleIds = (posSales ?? []).map(s => s.id);
    if (!saleIds.length) return [];

    const { data: items } = await supabase.from('pos_sale_items').select('description, quantity, total').in('sale_id', saleIds);
    const map: Record<string, { total_quantity: number; total_amount: number }> = {};
    for (const item of (items ?? []) as { description: string; quantity: number; total: number }[]) {
      if (!map[item.description]) map[item.description] = { total_quantity: 0, total_amount: 0 };
      map[item.description].total_quantity += Number(item.quantity);
      map[item.description].total_amount += Number(item.total);
    }
    return Object.entries(map).map(([description, v]) => ({ description, ...v })).sort((a, b) => b.total_amount - a.total_amount);
  }, [locationId, caisseId]);

  const computePosJournal = useCallback(async (periodStart: string, periodEnd: string, caisse?: string | null): Promise<PosJournalEntry[]> => {
    const cId = caisse ?? caisseId;
    let posQuery = supabase.from('pos_sales').select('id, sale_number, created_at, customer_id, total').gte('created_at', periodStart).lte('created_at', periodEnd).order('created_at', { ascending: false });
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    if (cId) posQuery = posQuery.eq('caisse_id', cId);
    const { data: posSales } = await posQuery;
    const rows = (posSales ?? []) as { id: string; sale_number: string; created_at: string; customer_id: string | null; total: number }[];
    if (!rows.length) return [];

    const customerIds = [...new Set(rows.map(s => s.customer_id).filter(Boolean) as string[])];
    const custMap = new Map<string, string>();
    if (customerIds.length) {
      const { data: custs } = await supabase.from('customers').select('id, name').in('id', customerIds);
      for (const c of (custs ?? []) as { id: string; name: string }[]) custMap.set(c.id, c.name);
    }

    const saleIds = rows.map(s => s.id);
    const { data: pays } = await supabase.from('pos_payments').select('sale_id, method').in('sale_id', saleIds);
    const payMap = new Map<string, string[]>();
    for (const p of (pays ?? []) as { sale_id: string; method: string }[]) {
      const arr = payMap.get(p.sale_id) ?? [];
      arr.push(p.method); payMap.set(p.sale_id, arr);
    }

    const methodLabel = (m: string) => ALL_PAYMENT_METHODS.find(mm => mm.value === m)?.label ?? m;

    return rows.map(s => ({
      id: s.id,
      sale_number: s.sale_number,
      created_at: s.created_at,
      customer_name: s.customer_id ? custMap.get(s.customer_id) ?? null : null,
      total: Number(s.total),
      payment_methods: (payMap.get(s.id) ?? []).map(methodLabel).join(', ') || '—',
    }));
  }, [locationId, caisseId]);

  const computeInvoiceJournal = useCallback(async (periodStart: string, periodEnd: string): Promise<InvoiceJournalEntry[]> => {
    let invQuery = supabase.from('invoices').select('id, invoice_number, date, customer_id, total, amount_paid, status').gte('date', periodStart.slice(0, 10)).lte('date', periodEnd.slice(0, 10)).order('date', { ascending: false });
    if (locationId) invQuery = invQuery.eq('location_id', locationId);
    const { data: invRows } = await invQuery;
    const rows = (invRows ?? []) as { id: string; invoice_number: string; date: string; customer_id: string; total: number; amount_paid: number; status: string }[];
    if (!rows.length) return [];

    const customerIds = [...new Set(rows.map(i => i.customer_id).filter(Boolean))];
    const custMap = new Map<string, string>();
    if (customerIds.length) {
      const { data: custs } = await supabase.from('customers').select('id, name').in('id', customerIds);
      for (const c of (custs ?? []) as { id: string; name: string }[]) custMap.set(c.id, c.name);
    }

    return rows.map(i => ({
      id: i.id,
      invoice_number: i.invoice_number,
      date: i.date,
      customer_name: custMap.get(i.customer_id) ?? null,
      total: Number(i.total),
      amount_paid: Number(i.amount_paid),
      status: i.status,
    }));
  }, [locationId]);

  const computePaymentSummary = useCallback(async (periodStart: string, periodEnd: string, caisse?: string | null): Promise<PaymentSummaryEntry[]> => {
    const cId = caisse ?? caisseId;

    // POS payments
    let posQuery = supabase.from('pos_sales').select('id').gte('created_at', periodStart).lte('created_at', periodEnd);
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    if (cId) posQuery = posQuery.eq('caisse_id', cId);
    const { data: posSales } = await posQuery;
    const posSaleIds = (posSales ?? []).map(s => s.id);
    const posMap: Record<string, { amount: number; count: number }> = {};
    if (posSaleIds.length) {
      const { data: pays } = await supabase.from('pos_payments').select('method, amount').in('sale_id', posSaleIds);
      for (const p of (pays ?? []) as { method: string; amount: number }[]) {
        if (!posMap[p.method]) posMap[p.method] = { amount: 0, count: 0 };
        posMap[p.method].amount += Number(p.amount);
        posMap[p.method].count += 1;
      }
    }

    // Invoice payments (customer payments table)
    let payQuery = supabase.from('payments').select('method, amount, payment_date').gte('payment_date', periodStart.slice(0, 10)).lte('payment_date', periodEnd.slice(0, 10));
    if (locationId) payQuery = payQuery.eq('location_id', locationId);
    const { data: invPays } = await payQuery;
    const invMap: Record<string, { amount: number; count: number }> = {};
    for (const p of (invPays ?? []) as { method: string; amount: number }[]) {
      if (!invMap[p.method]) invMap[p.method] = { amount: 0, count: 0 };
      invMap[p.method].amount += Number(p.amount);
      invMap[p.method].count += 1;
    }

    const allMethods = new Set([...Object.keys(posMap), ...Object.keys(invMap)]);
    return Array.from(allMethods).map(m => ({
      method: m as PaymentMethod,
      pos_amount: posMap[m]?.amount ?? 0,
      invoice_amount: invMap[m]?.amount ?? 0,
      total: (posMap[m]?.amount ?? 0) + (invMap[m]?.amount ?? 0),
      count: (posMap[m]?.count ?? 0) + (invMap[m]?.count ?? 0),
    })).sort((a, b) => b.total - a.total);
  }, [locationId, caisseId]);

  async function saveClosing(input: {
    period_start: string;
    period_end: string;
    caisse_id?: string | null;
    lines: { method: PaymentMethod; expected_amount: number; counted_amount: number }[];
    notes: string;
    status: 'brouillon' | 'cloturee';
  }): Promise<CaisseClosing> {
    const { data: { user } } = await supabase.auth.getUser();
    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    const cId = input.caisse_id ?? caisseId;

    if (!navigator.onLine) {
      const queued: QueuedOp = {
        localId: id, op: 'caisseClosing',
        payload: {
          _id: id, _user_id: user?.id ?? null, _location_id: locationId ?? null,
          date: input.period_start.slice(0, 10),
          period_start: input.period_start, period_end: input.period_end,
          status: input.status, notes: input.notes,
          lines: input.lines.map(l => ({ method: l.method, expected_amount: l.expected_amount, counted_amount: l.counted_amount })),
          ...(cId ? { caisse_id: cId } : {}),
        },
        createdAt: now, status: 'pending',
        tenantId: tenantId ?? null, locationId: locationId ?? null,
      };
      await queueOp(queued);
      return {
        id, user_id: user?.id ?? null, location_id: locationId ?? null,
        caisse_id: cId ?? null, date: input.period_start.slice(0, 10),
        period_start: input.period_start, period_end: input.period_end,
        status: input.status, notes: input.notes, created_at: now,
        lines: input.lines.map(l => ({ ...l, difference: l.counted_amount - l.expected_amount })),
      };
    }

    const { error } = await supabase.from('caisse_closings').insert({
      id, user_id: user?.id ?? null,
      ...(locationId ? { location_id: locationId } : {}),
      ...(cId ? { caisse_id: cId } : {}),
      date: input.period_start.slice(0, 10),
      period_start: input.period_start, period_end: input.period_end,
      status: input.status, notes: input.notes, created_at: now, updated_at: now,
    });
    if (error) throw new Error(translateError(error.message));

    const lineRows = input.lines.map(l => ({
      id: crypto.randomUUID(), closing_id: id, method: l.method,
      expected_amount: l.expected_amount, counted_amount: l.counted_amount,
      difference: l.counted_amount - l.expected_amount,
      created_at: now, updated_at: now,
    }));
    if (lineRows.length) await supabase.from('caisse_closing_lines').insert(lineRows);

    await fetchClosings();
    return {
      id, user_id: user?.id ?? null, location_id: locationId ?? null, caisse_id: cId ?? null,
      date: input.period_start.slice(0, 10), period_start: input.period_start, period_end: input.period_end,
      status: input.status, notes: input.notes, created_at: now,
      lines: input.lines.map(l => ({ ...l, difference: l.counted_amount - l.expected_amount })),
    };
  }

  async function updateStatus(id: string, status: 'brouillon' | 'cloturee') {
    const now = new Date().toISOString();
    await supabase.from('caisse_closings').update({ status, updated_at: now }).eq('id', id);
    await fetchClosings();
  }

  const computeCashSummary = useCallback(async (periodStart: string, periodEnd: string, caisse?: string | null): Promise<{
    opening_amount: number;
    total_sales: number;
    total_expenses: number;
    expense_count: number;
    theoretical_balance: number;
  }> => {
    const cId = caisse ?? caisseId;

    // Fond de caisse from the selected caisse
    let opening_amount = 0;
    if (cId) {
      const { data: caisseRow } = await supabase.from('caisses').select('opening_amount').eq('id', cId).maybeSingle();
      opening_amount = Number((caisseRow as { opening_amount?: number } | null)?.opening_amount ?? 0);
    }

    // Total POS sales for the period
    let posQuery = supabase.from('pos_sales').select('id, total').gte('created_at', periodStart).lte('created_at', periodEnd);
    if (locationId) posQuery = posQuery.eq('location_id', locationId);
    if (cId) posQuery = posQuery.eq('caisse_id', cId);
    const { data: posSales } = await posQuery;
    const total_sales = (posSales ?? []).reduce((s, r) => s + Number((r as { total: number }).total), 0);

    // Cash expenses (accounting_entries source='caisse')
    let opsQuery = supabase.from('accounting_entries').select('amount, payment_method, date, caisse_id').eq('source', 'caisse');
    if (cId) opsQuery = opsQuery.eq('caisse_id', cId);
    else opsQuery = opsQuery.gte('date', periodStart).lte('date', periodEnd);
    const { data: ops } = await opsQuery;
    const opsRows = (ops ?? []) as { amount: number }[];
    const total_expenses = opsRows.reduce((s, o) => s + Number(o.amount), 0);
    const expense_count = opsRows.length;

    return {
      opening_amount,
      total_sales,
      total_expenses,
      expense_count,
      theoretical_balance: opening_amount + total_sales - total_expenses,
    };
  }, [locationId, caisseId]);

  return { closings, loading, fetchClosings, computeExpected, computeProductSales, computePosJournal, computeInvoiceJournal, computePaymentSummary, computeCashSummary, saveClosing, updateStatus, caisseId, setCaisseId };
}
