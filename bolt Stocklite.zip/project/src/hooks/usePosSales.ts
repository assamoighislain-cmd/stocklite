import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { PosSale, PosSaleItem, PosPayment, PaymentMethod, Customer } from '../types';
import { translateError } from '../lib/translateError';
import { queueSale, getQueuedSales, getQueuedSalesForTenant, removeQueuedSale, decrementCachedStock, restoreCachedStock, cacheSales, getCachedSales, type QueuedSale } from '../lib/offlineDb';
import { syncPendingSales } from '../lib/syncManager';

export interface CartItemInput {
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
  unit_cost: number;
}

export interface TenderInput {
  method: PaymentMethod;
  amount: number;
  reference: string;
}

export interface CreateSaleInput {
  customer_id: string | null;
  commercial_id: string | null;
  caisse_id: string | null;
  items: CartItemInput[];
  tenders: TenderInput[];
  discount_pct: number;
  discount_amount?: number;
  tax_rate: number;
  notes: string;
}

export function usePosSales(locationId?: string | null, tenantId?: string | null) {
  const [sales, setSales] = useState<PosSale[]>([]);
  const [loading, setLoading] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const [queuedSales, setQueuedSales] = useState<QueuedSale[]>([]);

  const refreshPendingCount = useCallback(async () => {
    const queue = await getQueuedSalesForTenant(tenantId ?? null);
    setPendingCount(queue.length);
    setQueuedSales(queue);
  }, [tenantId]);

  const runSync = useCallback(async () => {
    if (!locationId) return;
    await syncPendingSales(locationId, tenantId ?? null);
    await refreshPendingCount();
    await fetchSales();
  }, [locationId, tenantId, refreshPendingCount]);

  useEffect(() => {
    refreshPendingCount();
    const goOnline = () => { runSync(); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [runSync, refreshPendingCount]);

  const fetchSales = useCallback(async () => {
    let query = supabase.from('pos_sales').select('*').order('created_at', { ascending: false }).limit(100);
    if (locationId) query = query.eq('location_id', locationId);
    const { data: rows, error } = await query;
    if (error) {
      const cached = await getCachedSales<PosSale>();
      setSales(cached);
      setLoading(false);
      return;
    }
    const saleRows = (rows ?? []) as PosSale[];

    const customerIds = [...new Set(saleRows.map(s => s.customer_id).filter(Boolean) as string[])];
    const custMap = new Map<string, Customer>();
    if (customerIds.length) {
      const { data: custs } = await supabase.from('customers').select('*');
      for (const c of (custs ?? []) as Customer[]) if (customerIds.includes(c.id)) custMap.set(c.id, c);
    }

    const saleIds = saleRows.map(s => s.id);
    const itemsMap = new Map<string, PosSaleItem[]>();
    const payMap = new Map<string, PosPayment[]>();
    if (saleIds.length) {
      const { data: allItems } = await supabase.from('pos_sale_items').select('*');
      const { data: allPays } = await supabase.from('pos_payments').select('*');
      for (const it of (allItems ?? []) as PosSaleItem[]) {
        if (!saleIds.includes(it.sale_id)) continue;
        const arr = itemsMap.get(it.sale_id) ?? [];
        arr.push(it); itemsMap.set(it.sale_id, arr);
      }
      for (const p of (allPays ?? []) as PosPayment[]) {
        if (!saleIds.includes(p.sale_id)) continue;
        const arr = payMap.get(p.sale_id) ?? [];
        arr.push(p); payMap.set(p.sale_id, arr);
      }
    }

    const enriched = saleRows.map(s => ({
      ...s,
      customer: s.customer_id ? custMap.get(s.customer_id) : undefined,
      items: itemsMap.get(s.id) ?? [],
      payments: payMap.get(s.id) ?? [],
    }));
    setSales(enriched);
    await cacheSales(enriched);
    setLoading(false);
  }, [locationId]);

  useEffect(() => { fetchSales(); }, [fetchSales]);

  async function createSale(input: CreateSaleInput): Promise<PosSale> {
    if (!locationId) throw new Error('Aucune boutique rattachée. Une vente doit obligatoirement être effectuée dans une boutique.');
    const subtotal = input.items.reduce((s, i) => s + i.quantity * i.unit_price, 0);
    const discount_amount = Math.min(Math.round((input.discount_amount ?? 0) * 100) / 100, subtotal);
    const discount_pct = subtotal > 0 ? Math.round((discount_amount / subtotal) * 10000) / 100 : 0;
    const afterDiscount = subtotal - discount_amount;
    const tax_amount = Math.round(afterDiscount * (input.tax_rate / 100) * 100) / 100;
    const total = Math.round((afterDiscount + tax_amount) * 100) / 100;

    const now = new Date().toISOString();
    const saleId = crypto.randomUUID();
    const saleNumber = `POS-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;

    if (!navigator.onLine) {
      const queued: QueuedSale = {
        localId: saleId,
        payload: input,
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
        locationId: locationId ?? null,
      };
      await queueSale(queued);
      await decrementCachedStock(input.items.map(i => ({ product_id: i.product_id, quantity: i.quantity })));
      await refreshPendingCount();

      const itemRows = input.items.map((i, idx) => ({
        id: crypto.randomUUID(), sale_id: saleId, product_id: i.product_id,
        description: i.description, quantity: i.quantity, unit_price: i.unit_price,
        unit_cost: i.unit_cost ?? 0,
        total: Math.round(i.quantity * i.unit_price * 100) / 100,
        created_at: now, updated_at: now,
      }));
      const payRows = input.tenders.map(t => ({
        id: crypto.randomUUID(), sale_id: saleId, method: t.method,
        amount: t.amount, reference: t.reference, created_at: now, updated_at: now,
      }));

      return {
        id: saleId, sale_number: saleNumber, customer_id: input.customer_id,
        user_id: null, caisse_id: input.caisse_id ?? null,
        subtotal, discount_pct: input.discount_pct, discount_amount,
        tax_rate: input.tax_rate, tax_amount, total, notes: input.notes,
        created_at: now,
        items: itemRows,
        payments: payRows,
      } as PosSale;
    }

    const { data: { user } } = await supabase.auth.getUser();

    const { error } = await supabase.from('pos_sales').insert({
      id: saleId, sale_number: saleNumber, customer_id: input.customer_id,
      commercial_id: input.commercial_id, user_id: user?.id ?? null,
      caisse_id: input.caisse_id ?? null, location_id: locationId,
      subtotal, discount_pct: input.discount_pct, discount_amount,
      tax_rate: input.tax_rate, tax_amount, total, notes: input.notes,
      created_at: now, updated_at: now,
    });
    if (error) throw new Error(translateError(error.message));

    const itemRows = input.items.map((i, idx) => ({
      id: crypto.randomUUID(), sale_id: saleId, product_id: i.product_id,
      description: i.description, quantity: i.quantity, unit_price: i.unit_price,
      unit_cost: i.unit_cost ?? 0,
      created_at: now, updated_at: now,
    }));
    if (itemRows.length) {
      const { error: itemErr } = await supabase.from('pos_sale_items').insert(itemRows);
      if (itemErr) throw new Error(itemErr.message);
    }

    const payRows = input.tenders.map(t => ({
      id: crypto.randomUUID(), sale_id: saleId, method: t.method,
      amount: t.amount, reference: t.reference, created_at: now, updated_at: now,
    }));
    if (payRows.length) {
      const { error: payErr } = await supabase.from('pos_payments').insert(payRows);
      if (payErr) throw new Error(payErr.message);
    }

    for (const item of input.items) {
      if (!item.product_id) continue;
      const { data: prod } = await supabase.from('products').select('track_stock').eq('id', item.product_id).maybeSingle();
      if (!prod?.track_stock) continue;

      const lsId = `${item.product_id}_${locationId}`;
      const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
      const current = Number(ls?.stock_quantity ?? 0);
      const newQty = Math.max(0, current - item.quantity);
      await supabase.from('location_stock').upsert({
        id: lsId, product_id: item.product_id, location_id: locationId,
        stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
        price: ls?.price ?? null, updated_at: now,
      });

      const mvId = crypto.randomUUID();
      await supabase.from('stock_movements').insert({
        id: mvId, product_id: item.product_id, type: 'vente',
        quantity: item.quantity, unit_cost: item.unit_price,
        reference: saleNumber, notes: '', location_id: locationId,
        created_at: now, updated_at: now,
      });
    }

    await fetchSales();
    return {
      id: saleId, sale_number: saleNumber, customer_id: input.customer_id,
      user_id: user?.id ?? null, caisse_id: input.caisse_id ?? null,
      subtotal, discount_pct: input.discount_pct, discount_amount,
      tax_rate: input.tax_rate, tax_amount, total, notes: input.notes,
      created_at: now,
      items: itemRows.map(r => ({ ...r, total: r.quantity * r.unit_price })),
      payments: payRows,
    } as PosSale;
  }

  async function cancelQueuedSale(localId: string): Promise<void> {
    const queued = queuedSales.find(q => q.localId === localId);
    if (queued) {
      const payload = queued.payload as CreateSaleInput;
      await restoreCachedStock(payload.items.map(i => ({ product_id: i.product_id, quantity: i.quantity })));
    }
    await removeQueuedSale(localId);
    await refreshPendingCount();
  }

  async function manualSync(): Promise<void> {
    await runSync();
  }

  async function returnSaleItems(saleId: string, returns: { item_id: string; product_id: string | null; quantity: number }[], reason: string): Promise<void> {
    if (!navigator.onLine) throw new Error('Retour impossible hors ligne.');
    const { data: sale } = await supabase.from('pos_sales').select('*').eq('id', saleId).maybeSingle();
    if (!sale) throw new Error('Vente introuvable.');
    const saleLocationId = (sale as { location_id: string }).location_id ?? locationId;
    if (!saleLocationId) throw new Error('Aucune boutique rattachée à cette vente.');

    const saleRef = (sale as { sale_number: string }).sale_number;
    const now = new Date().toISOString();

    for (const r of returns) {
      if (!r.product_id || r.quantity <= 0) continue;
      const lsId = `${r.product_id}_${saleLocationId}`;
      const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
      const current = Number(ls?.stock_quantity ?? 0);
      const newQty = current + r.quantity;
      await supabase.from('location_stock').upsert({
        id: lsId, product_id: r.product_id, location_id: saleLocationId,
        stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
        price: ls?.price ?? null, updated_at: now,
      });

      await supabase.from('stock_movements').insert({
        id: crypto.randomUUID(), product_id: r.product_id, type: 'retour',
        quantity: r.quantity, unit_cost: 0,
        reference: saleRef, notes: reason || 'Retour vente caisse',
        location_id: saleLocationId, created_at: now, updated_at: now,
      });
    }

    await fetchSales();
  }

  async function deleteSale(saleId: string): Promise<void> {
    if (!navigator.onLine) throw new Error('Suppression impossible hors ligne.');

    const { data: sale } = await supabase.from('pos_sales').select('*').eq('id', saleId).maybeSingle();
    if (!sale) throw new Error('Vente introuvable.');

    const { data: items } = await supabase.from('pos_sale_items').select('*').eq('sale_id', saleId);

    for (const item of (items ?? []) as PosSaleItem[]) {
      if (!item.product_id) continue;
      const lsId = `${item.product_id}_${sale.location_id}`;
      const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
      if (ls) {
        const current = Number(ls.stock_quantity ?? 0);
        const newQty = current + item.quantity;
        await supabase.from('location_stock').upsert({
          id: lsId, product_id: item.product_id, location_id: sale.location_id,
          stock_quantity: newQty, stock_min: ls.stock_min ?? 0,
          price: ls.price ?? null, updated_at: new Date().toISOString(),
        });
      }
      await supabase.from('stock_movements').delete()
        .eq('reference', sale.sale_number).eq('product_id', item.product_id);
    }

    await supabase.from('pos_sale_items').delete().eq('sale_id', saleId);
    await supabase.from('pos_payments').delete().eq('sale_id', saleId);
    const { error } = await supabase.from('pos_sales').delete().eq('id', saleId);
    if (error) throw new Error(translateError(error.message));

    await fetchSales();
  }

  return { sales, loading, fetchSales, createSale, pendingCount, queuedSales, manualSync, cancelQueuedSale, deleteSale, returnSaleItems };
}
