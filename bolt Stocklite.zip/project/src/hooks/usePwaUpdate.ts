import { registerSW } from 'virtual:pwa-register';

export function usePwaUpdate() {
  registerSW({ immediate: true });
}
