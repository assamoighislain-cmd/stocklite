import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { SalesLocation } from '../types';
import { translateError } from '../lib/translateError';
import { cacheLocations, getCachedLocations, queueOp, type QueuedOp } from '../lib/offlineDb';
import { syncPendingOps } from '../lib/syncManager';

export function useSalesLocations(tenantId?: string | null) {
  const [locations, setLocations] = useState<SalesLocation[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    const { data, error } = await supabase.from('sales_locations').select('*').order('sort_order');
    if (error) {
      const cached = await getCachedLocations<SalesLocation>();
      setLocations(cached);
      setLoading(false);
      return;
    }
    const rows = (data ?? []) as SalesLocation[];
    setLocations(rows);
    await cacheLocations(rows);
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    const goOnline = () => { syncPendingOps(tenantId ?? null).then(() => fetch()); };
    window.addEventListener('online', goOnline);
    return () => window.removeEventListener('online', goOnline);
  }, [fetch, tenantId]);

  async function save(payload: Omit<SalesLocation, 'id' | 'created_at'>, id?: string) {
    const now = new Date().toISOString();
    if (!navigator.onLine) {
      const recordId = id ?? crypto.randomUUID();
      const queued: QueuedOp = {
        localId: recordId,
        op: 'salesLocation',
        payload: { ...payload, _id: recordId, _isUpdate: !!id },
        createdAt: now,
        status: 'pending',
        tenantId: tenantId ?? null,
      };
      await queueOp(queued);
      return;
    }
    if (id) {
      const { error } = await supabase.from('sales_locations').update({ ...payload, updated_at: now }).eq('id', id);
      if (error) throw new Error(translateError(error.message));
    } else {
      const recordId = crypto.randomUUID();
      const { error } = await supabase.from('sales_locations').insert({ ...payload, id: recordId, created_at: now, updated_at: now });
      if (error) throw new Error(translateError(error.message));
    }
    await fetch();
  }

  async function remove(id: string) {
    const { error } = await supabase.from('sales_locations').delete().eq('id', id);
    if (error) throw new Error(translateError(error.message));
    await fetch();
  }

  return { locations, loading, refetch: fetch, save, remove };
}
