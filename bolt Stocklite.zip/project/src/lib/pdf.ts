import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { wrapDocument, getPrintCss, type PrintFormat } from './printEngine';

export type { PrintFormat } from './printEngine';

/**
 * Exports a DOM element to a multi-page PDF.
 * For A4: slices the canvas at page boundaries, avoiding mid-row cuts by
 * checking break-point positions embedded in the document.
 * For receipt: renders as a single continuous page.
 */
export async function exportElementToPdf(element: HTMLElement, filename: string, format: PrintFormat = 'a4') {
  const canvas = await html2canvas(element, {
    scale: 2,
    backgroundColor: '#ffffff',
    useCORS: true,
    logging: false,
  });

  const imgData = canvas.toDataURL('image/png');

  if (format === 'a4') {
    const pdf = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const margin = 10;
    const usableHeight = pdfHeight - margin * 2;
    const imgWidth = pdfWidth - margin * 2;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    // Collect break-point Y positions (elements with .doc-row or .doc-section)
    // to avoid slicing through a row.
    const breakPoints: number[] = [];
    const breakEls = element.querySelectorAll('.doc-row, .doc-section, tr, .doc-break-before');
    const scale = imgHeight / element.scrollHeight;
    for (const el of breakEls) {
      const rect = (el as HTMLElement).getBoundingClientRect();
      const elTop = (rect.top - element.getBoundingClientRect().top) * scale;
      breakPoints.push(elTop);
    }
    breakPoints.sort((a, b) => a - b);

    let heightLeft = imgHeight;
    let position = margin;
    let firstPage = true;

    while (heightLeft > 0) {
      if (!firstPage) {
        pdf.addPage();
        position = margin;
      }

      // Find the best break point — the largest break Y <= (position + usableHeight - position + imgHeight - heightLeft)
      const pageBottom = (imgHeight - heightLeft) + usableHeight;
      let sliceEnd = pageBottom;
      for (const bp of breakPoints) {
        if (bp > (imgHeight - heightLeft) && bp <= pageBottom + 5) {
          sliceEnd = bp;
        }
      }

      const sliceHeight = Math.min(sliceEnd - (imgHeight - heightLeft), usableHeight);
      const srcY = imgHeight - heightLeft;

      if (sliceHeight <= 0) {
        // No break point found in range — just cut at page boundary
        pdf.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight, undefined, 'FAST');
        pdf.setPage(pdf.getCurrentPageInfo().pageNumber);
        // Use clipping to show only the current page slice
        pdf.rect(0, 0, pdfWidth, pdfHeight, 'F', '#ffffff');
        pdf.addImage(imgData, 'PNG', margin, position - srcY, imgWidth, imgHeight);
        heightLeft -= usableHeight;
      } else {
        // Create a sub-canvas for this page slice
        const srcScale = canvas.width / imgWidth;
        const sliceCanvas = document.createElement('canvas');
        sliceCanvas.width = canvas.width;
        sliceCanvas.height = Math.ceil(sliceHeight * srcScale);
        const ctx = sliceCanvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(
            canvas,
            0, Math.floor(srcY * srcScale),
            canvas.width, Math.ceil(sliceHeight * srcScale),
            0, 0,
            canvas.width, sliceCanvas.height,
          );
          const sliceData = sliceCanvas.toDataURL('image/png');
          pdf.addImage(sliceData, 'PNG', margin, position, imgWidth, sliceHeight);
        } else {
          pdf.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight);
        }
        heightLeft -= sliceHeight;
      }

      firstPage = false;
      // Guard against infinite loop
      if (heightLeft > -1 && heightLeft < 1) break;
    }

    pdf.save(filename);
  } else {
    // Receipt — single continuous page
    const imgWidth = 80;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    const pdf = new jsPDF({ unit: 'mm', format: [80, imgHeight] });
    pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
    pdf.save(filename);
  }
}

/**
 * Exports an HTML string to a PDF. Renders the HTML in a hidden iframe, then
 * captures the body with html2canvas and paginates it via exportElementToPdf.
 * The shared pagination CSS from printEngine is injected automatically.
 */
export async function exportHtmlToPdf(html: string, filename: string, format: PrintFormat = 'a4') {
  const fullHtml = wrapDocument(html, { format, printOnly: true, title: filename.replace(/\.pdf$/, '') });

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.left = '-9999px';
  iframe.style.top = '0';
  iframe.style.width = format === 'a4' ? '210mm' : '80mm';
  iframe.style.height = '297mm';
  iframe.style.border = 'none';
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument;
  if (!doc) { iframe.remove(); return; }
  doc.open();
  doc.write(fullHtml);
  doc.close();

  await new Promise(r => setTimeout(r, 400));

  const target = doc.body;
  if (target) {
    await exportElementToPdf(target, filename, format);
  }

  iframe.remove();
}
