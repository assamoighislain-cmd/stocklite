export function fmtQty(n: number): string {
  return new Intl.NumberFormat('fr-FR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(n);
}

const UNITS = ['zéro', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf', 'dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];
const TENS = ['', '', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante', 'quatre-vingt', 'quatre-vingt'];

function below100(n: number): string {
  if (n < 20) return UNITS[n];
  const t = Math.floor(n / 10);
  const u = n % 10;
  if (t === 7 || t === 9) {
    const base = t === 7 ? 'soixante' : 'quatre-vingt';
    const rest = below100(10 + u);
    return t === 9 && u === 0 ? 'quatre-vingt-dix' : `${base}-${rest}`;
  }
  let result = TENS[t];
  if (u === 1 && t !== 8) result += '-et-un';
  else if (u > 0) result += `-${UNITS[u]}`;
  else if (t === 8) result += 's';
  return result;
}

function below1000(n: number): string {
  if (n < 100) return below100(n);
  const h = Math.floor(n / 100);
  const r = n % 100;
  let result = h === 1 ? 'cent' : `${UNITS[h]} cent${r === 0 ? 's' : ''}`;
  if (r > 0) result += ` ${below100(r)}`;
  return result;
}

function intToFrenchWords(n: number): string {
  if (n === 0) return 'zéro';
  const groups: string[] = [];
  const scales = ['', 'mille', 'million', 'milliard'];
  let scaleIdx = 0;
  while (n > 0) {
    const group = n % 1000;
    if (group > 0) {
      let groupWords = below1000(group);
      if (scaleIdx === 1 && group === 1) groupWords = 'mille';
      else if (scaleIdx > 0) groupWords += ` ${scales[scaleIdx]}`;
      if (scaleIdx === 2 && group > 1) groupWords += 's';
      groups.unshift(groupWords);
    }
    n = Math.floor(n / 1000);
    scaleIdx++;
  }
  return groups.join(' ');
}

export function amountToFrenchWords(amount: number, currency = 'FCFA'): string {
  const rounded = Math.round(amount);
  const words = intToFrenchWords(rounded);
  const unitName = currency === 'FCFA' ? 'franc CFA' : currency;
  const plural = rounded > 1 ? 's' : '';
  return `${words} ${unitName}${plural}`;
}
