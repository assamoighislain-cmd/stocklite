// Unified print layout & pagination engine.
// Provides shared CSS for print-page sizing, headers/footers, and break-aware
// table row pagination. Used by all printable documents across the app.

export type PrintFormat = 'a4' | 'receipt';

export interface PrintOptions {
  format?: PrintFormat;
  /** Title shown in the browser tab and PDF metadata. */
  title?: string;
  /** Extra <style> content appended after the base pagination CSS. */
  extraStyle?: string;
  /** If true, suppresses the screen preview wrapper (pure print doc). */
  printOnly?: boolean;
}

const A4_PAGE_CSS = `
  @page {
    size: A4;
    margin: 14mm 12mm 16mm 12mm;
  }
  @media print {
    html, body {
      background: #fff !important;
      width: auto;
      margin: 0;
      padding: 0;
    }
    .doc-screen-only { display: none !important; }
    .doc-page {
      box-shadow: none !important;
      margin: 0 !important;
      width: auto !important;
      min-height: auto !important;
      border: none !important;
      border-radius: 0 !important;
      page-break-after: always;
      break-after: page;
    }
    .doc-page:last-child {
      page-break-after: auto;
      break-after: auto;
    }
    /* Keep table headers and totals together — avoid breaking inside */
    tr, .doc-row {
      page-break-inside: avoid;
      break-inside: avoid;
    }
    thead { display: table-header-group; }
    tfoot { display: table-footer-group; }
    .doc-section {
      page-break-inside: avoid;
      break-inside: avoid;
    }
    .doc-break-before {
      page-break-before: always;
      break-before: page;
    }
    .doc-break-after {
      page-break-after: always;
      break-after: page;
    }
  }
`;

const RECEIPT_PAGE_CSS = `
  @page {
    size: 80mm auto;
    margin: 0;
  }
  @media print {
    html, body {
      background: #fff !important;
      width: 80mm;
      margin: 0;
      padding: 0;
    }
    .doc-screen-only { display: none !important; }
    tr, .doc-row {
      page-break-inside: avoid;
      break-inside: avoid;
    }
  }
`;

const SCREEN_WRAPPER_CSS = `
  @media screen {
    html { background: #e8e8e8; min-height: 100vh; }
    body {
      background: #e8e8e8;
      margin: 0;
      padding: 20px 0;
      font-family: -apple-system, 'Segoe UI', Roboto, sans-serif;
    }
    .doc-page {
      background: #fff;
      box-shadow: 0 4px 24px rgba(0,0,0,.15);
      border-radius: 4px;
      margin: 0 auto 24px;
      max-width: 100%;
    }
    .doc-page.a4 {
      width: 210mm;
      min-height: 297mm;
      padding: 14mm 12mm 16mm 12mm;
    }
    .doc-page.receipt {
      width: 80mm;
      padding: 6mm 5mm 12mm;
    }
    .doc-screen-only {
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 100;
      display: flex;
      gap: 8px;
    }
    .doc-screen-only button {
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: opacity .15s;
    }
    .doc-screen-only button:hover { opacity: .85; }
    .doc-screen-only .doc-btn-print {
      background: #2563eb;
      color: #fff;
    }
    .doc-screen-only .doc-btn-close {
      background: #e5e7eb;
      color: #374151;
    }
  }
`;

/**
 * Returns the base pagination CSS for the given format, plus the screen
 * preview wrapper styles. This is the single source of truth for print CSS.
 */
export function getPrintCss(format: PrintFormat): string {
  const pageCss = format === 'receipt' ? RECEIPT_PAGE_CSS : A4_PAGE_CSS;
  return pageCss + SCREEN_WRAPPER_CSS;
}

/**
 * Wraps a body HTML fragment into a full `<!DOCTYPE html>` document with the
 * shared pagination CSS injected. If the caller passes an already-complete
 * document (starts with `<!DOCTYPE` or `<html`), the CSS is injected into the
 * existing `<head>` instead.
 */
export function wrapDocument(bodyHtml: string, opts: PrintOptions = {}): string {
  const format = opts.format ?? 'a4';
  const baseCss = getPrintCss(format);
  const extra = opts.extraStyle ?? '';
  const title = opts.title ?? 'Document';
  const fullCss = baseCss + '\n' + extra;

  const trimmed = bodyHtml.trimStart();
  if (trimmed.startsWith('<!DOCTYPE') || trimmed.startsWith('<html')) {
    // Already a full document — inject CSS before </head> or after <head>
    if (/<\/head>/i.test(bodyHtml)) {
      return bodyHtml.replace(/<\/head>/i, `<style>\n${fullCss}\n</style>\n</head>`);
    }
    if (/<head[^>]*>/i.test(bodyHtml)) {
      return bodyHtml.replace(/<head([^>]*)>/i, `<head$1>\n<style>\n${fullCss}\n</style>`);
    }
    // No <head> — inject after <html>
    return bodyHtml.replace(/<html([^>]*)>/i, `<html$1>\n<head>\n<meta charset="UTF-8">\n<title>${title}</title>\n<style>\n${fullCss}\n</style>\n</head>`);
  }

  // Fragment — wrap it
  const screenBtns = opts.printOnly ? '' : `
  <div class="doc-screen-only">
    <button class="doc-btn-print" onclick="window.print()">Imprimer / PDF</button>
    <button class="doc-btn-close" onclick="window.close()">Fermer</button>
  </div>`;

  return `<!DOCTYPE html>
<html lang="fr"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title}</title>
<style>
${fullCss}
</style>
</head>
<body>
${screenBtns}
<div class="doc-page ${format}">
${bodyHtml}
</div>
</body></html>`;
}

/**
 * Opens a print popup with the given HTML and triggers the browser print dialog.
 * Uses the shared pagination CSS for proper page breaks.
 */
export function printDocument(bodyHtml: string, opts: PrintOptions = {}): void {
  const fullHtml = wrapDocument(bodyHtml, opts);
  const win = window.open('', '_blank', 'width=900,height=700');
  if (!win) {
    // Popup blocked — fallback to iframe print
    printInIframe(fullHtml);
    return;
  }
  win.document.open();
  win.document.write(fullHtml);
  win.document.close();
  win.onload = () => {
    setTimeout(() => {
      try { win.focus(); win.print(); } catch { /* ignore */ }
    }, 250);
  };
}

/**
 * Prints an HTML document inside a hidden iframe (used when popups are blocked
 * or for the POS thermal printer flow).
 */
export function printInIframe(html: string): void {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.left = '-9999px';
  iframe.style.top = '0';
  iframe.style.width = '210mm';
  iframe.style.height = '297mm';
  iframe.style.border = 'none';
  document.body.appendChild(iframe);
  const doc = iframe.contentDocument;
  if (!doc) { iframe.remove(); return; }
  doc.open();
  doc.write(html);
  doc.close();
  iframe.onload = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch { /* ignore */ }
    setTimeout(() => iframe.remove(), 1000);
  };
}

/**
 * CSS class constants for use in document HTML.
 */
export const BREAK = {
  row: 'doc-row',
  section: 'doc-section',
  breakBefore: 'doc-break-before',
  breakAfter: 'doc-break-after',
  screenOnly: 'doc-screen-only',
  page: 'doc-page',
} as const;
