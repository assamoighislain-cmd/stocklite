const TRANSLATIONS: { pattern: RegExp; fr: string }[] = [
  { pattern: /row-level security policy/i, fr: "Action non autorisée. Vérifiez vos permissions." },
  { pattern: /violates row-level security/i, fr: "Action non autorisée. Vérifiez vos permissions." },
  { pattern: /new row violates row-level security/i, fr: "Action non autorisée. Vérifiez vos permissions." },
  { pattern: /JWT expired/i, fr: "Votre session a expiré. Reconnectez-vous." },
  { pattern: /Invalid login credentials/i, fr: "Email ou mot de passe incorrect." },
  { pattern: /User already registered/i, fr: "Un compte existe déjà avec cet email." },
  { pattern: /already been registered/i, fr: "Un compte existe déjà avec cet email." },
  { pattern: /Email not confirmed/i, fr: "Email non confirmé. Vérifiez votre boîte de réception." },
  { pattern: /duplicate key value/i, fr: "Cette valeur existe déjà. Vérifiez les doublons." },
  { pattern: /unique constraint/i, fr: "Cette valeur existe déjà. Vérifiez les doublons." },
  { pattern: /foreign key constraint/i, fr: "Référence invalide. L'élément lié n'existe pas." },
  { pattern: /violates foreign key/i, fr: "Référence invalide. L'élément lié n'existe pas." },
  { pattern: /not-null constraint/i, fr: "Un champ obligatoire est manquant." },
  { pattern: /null value in column/i, fr: "Un champ obligatoire est manquant." },
  { pattern: /check constraint/i, fr: "Une valeur fournie n'est pas valide." },
  { pattern: /permission denied/i, fr: "Vous n'avez pas la permission d'effectuer cette action." },
  { pattern: /network request failed/i, fr: "Problème de connexion. Vérifiez votre internet." },
  { pattern: /Failed to fetch/i, fr: "Problème de connexion. Vérifiez votre internet." },
  { pattern: /Request timed out/i, fr: "La requête a expiré. Réessayez." },
  { pattern: /rate limit/i, fr: "Trop de requêtes. Patientez un instant." },
  { pattern: /over request rate limit/i, fr: "Trop de requêtes. Patientez un instant." },
  { pattern: /User not found/i, fr: "Utilisateur introuvable." },
  { pattern: /User not allowed/i, fr: "Action non autorisée." },
  { pattern: /Email rate limit exceeded/i, fr: "Trop d'emails envoyés. Patientez un instant." },
  { pattern: /Password should be at least/i, fr: "Le mot de passe doit contenir au moins 6 caractères." },
  { pattern: /Unable to validate email address/i, fr: "Adresse email invalide." },
  { pattern: /Signup not allowed/i, fr: "Inscription non autorisée." },
  { pattern: /fetch failed/i, fr: "Problème de connexion. Vérifiez votre internet." },
];

export function translateError(message: string): string {
  if (!message) return "Une erreur est survenue.";
  for (const { pattern, fr } of TRANSLATIONS) {
    if (pattern.test(message)) return fr;
  }
  return message;
}
