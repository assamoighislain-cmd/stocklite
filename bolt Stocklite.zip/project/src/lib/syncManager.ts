import { supabase } from './supabase';
import {
  getQueuedSalesForTenant, updateQueuedSale, removeQueuedSale, type QueuedSale,
  getQueuedCustomersForTenant, updateQueuedCustomer, removeQueuedCustomer, type QueuedCustomer,
  getQueuedOpsForTenant, updateQueuedOp, removeQueuedOp, type QueuedOp, type OpType,
} from './offlineDb';
import type { CreateSaleInput, CartItemInput } from '../hooks/usePosSales';
import type { CreateInvoiceInput, LineItemInput } from '../hooks/useInvoices';
import type { CreateOrderInput } from '../hooks/useOrders';
import type { DeliveryNoteInput, SupplierInput } from '../hooks/useApprovisionnement';
import type { CreateTransferInput } from '../hooks/useStockTransfers';
import type { CreateDotationInput } from '../hooks/useDotations';
import type { CashOpInput } from '../hooks/useCashOps';

export type SyncResult = { localId: string; success: boolean; error?: string };

let syncing = false;

export async function syncPendingSales(
  locationId: string,
  tenantId?: string | null,
  onProgress?: (result: SyncResult) => void,
): Promise<void> {
  if (syncing) return;
  syncing = true;
  try {
    const queue = await getQueuedSalesForTenant(tenantId ?? null);
    const pending = queue.filter(q => q.status === 'pending' || q.status === 'error');
    for (const item of pending) {
      try {
        await updateQueuedSale(item.localId, { status: 'syncing' });
        await pushSaleToSupabase(item.payload as CreateSaleInput, locationId);
        await removeQueuedSale(item.localId);
        onProgress?.({ localId: item.localId, success: true });
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Erreur de synchro';
        await updateQueuedSale(item.localId, { status: 'error', error: msg });
        onProgress?.({ localId: item.localId, success: false, error: msg });
      }
    }
  } finally {
    syncing = false;
  }
}

async function pushSaleToSupabase(input: CreateSaleInput, locationId: string): Promise<void> {
  const subtotal = input.items.reduce((s: number, i: CartItemInput) => s + i.quantity * i.unit_price, 0);
  const discount_amount = Math.min(Math.round((input.discount_amount ?? 0) * 100) / 100, subtotal);
  const afterDiscount = subtotal - discount_amount;
  const tax_amount = Math.round(afterDiscount * (input.tax_rate / 100) * 100) / 100;
  const total = Math.round((afterDiscount + tax_amount) * 100) / 100;

  const now = new Date().toISOString();
  const saleId = crypto.randomUUID();
  const saleNumber = `POS-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const { data: { user } } = await supabase.auth.getUser();

  const { error } = await supabase.from('pos_sales').insert({
    id: saleId, sale_number: saleNumber, customer_id: input.customer_id,
    commercial_id: input.commercial_id, user_id: user?.id ?? null,
    caisse_id: input.caisse_id ?? null, location_id: locationId,
    subtotal, discount_pct: input.discount_pct, discount_amount,
    tax_rate: input.tax_rate, tax_amount, total, notes: input.notes,
    created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);

  const itemRows = input.items.map((i, idx) => ({
    id: crypto.randomUUID(), sale_id: saleId, product_id: i.product_id,
    description: i.description, quantity: i.quantity, unit_price: i.unit_price,
    unit_cost: i.unit_cost ?? 0,
    created_at: now, updated_at: now,
  }));
  if (itemRows.length) {
    const { error: itemErr } = await supabase.from('pos_sale_items').insert(itemRows);
    if (itemErr) throw new Error(itemErr.message);
  }

  const payRows = input.tenders.map(t => ({
    id: crypto.randomUUID(), sale_id: saleId, method: t.method,
    amount: t.amount, reference: t.reference, created_at: now, updated_at: now,
  }));
  if (payRows.length) {
    const { error: payErr } = await supabase.from('pos_payments').insert(payRows);
    if (payErr) throw new Error(payErr.message);
  }

  for (const item of input.items) {
    if (!item.product_id) continue;
    const { data: prod } = await supabase.from('products').select('track_stock').eq('id', item.product_id).maybeSingle();
    if (!prod?.track_stock) continue;

    const lsId = `${item.product_id}_${locationId}`;
    const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
    const current = Number(ls?.stock_quantity ?? 0);
    const newQty = Math.max(0, current - item.quantity);
    await supabase.from('location_stock').upsert({
      id: lsId, product_id: item.product_id, location_id: locationId,
      stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
      price: ls?.price ?? null, updated_at: now,
    });

    const mvId = crypto.randomUUID();
    await supabase.from('stock_movements').insert({
      id: mvId, product_id: item.product_id, type: 'vente',
      quantity: item.quantity, unit_cost: item.unit_price,
      reference: saleNumber, notes: '', location_id: locationId,
      created_at: now, updated_at: now,
    });
  }
}

export async function getQueueCount(tenantId?: string | null): Promise<number> {
  const queue = await getQueuedSalesForTenant(tenantId ?? null);
  return queue.filter(q => q.status !== 'syncing').length;
}

export type { QueuedSale };

// ── Generic ops sync ──

let opsSyncing = false;

export async function syncPendingOps(tenantId?: string | null): Promise<void> {
  if (opsSyncing) return;
  opsSyncing = true;
  try {
    const queue = await getQueuedOpsForTenant(tenantId ?? null);
    const pending = queue.filter(q => q.status === 'pending' || q.status === 'error');
    for (const item of pending) {
      try {
        await updateQueuedOp(item.localId, { status: 'syncing' });
        await replayOp(item);
        await removeQueuedOp(item.localId);
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Erreur de synchro';
        await updateQueuedOp(item.localId, { status: 'error', error: msg });
      }
    }
  } finally {
    opsSyncing = false;
  }
}

async function replayOp(item: QueuedOp): Promise<void> {
  const now = new Date().toISOString();
  switch (item.op) {
    case 'invoice': { await replayInvoice(item.payload as CreateInvoiceInput & { _id: string; _number: string; _location_id?: string | null; _created_by?: string | null }, now); break; }
    case 'order': { await replayOrder(item.payload as CreateOrderInput & { _id: string; _number: string; _location_id?: string | null }, now); break; }
    case 'deliveryNote': { await replayDeliveryNote(item.payload as DeliveryNoteInput & { _id: string; _user_id: string | null }, now); break; }
    case 'validateDeliveryNote': { await replayValidateDeliveryNote(item.payload as { noteId: string; location_id?: string | null }, now); break; }
    case 'deleteDeliveryNote': { await replayDeleteDeliveryNote(item.payload as { noteId: string }); break; }
    case 'stockTransfer': { await replayStockTransfer(item.payload as CreateTransferInput & { _user_id: string | null }, now); break; }
    case 'dotation': { await replayDotation(item.payload as CreateDotationInput & { _id: string; _number: string; _user_id: string | null }, now); break; }
    case 'supplier': { await replaySupplier(item.payload as SupplierInput & { _id: string; _location_id?: string | null; _isUpdate: boolean }, now); break; }
    case 'supplierPayment': { await replaySupplierPayment(item.payload as Record<string, unknown> & { _id: string }, now); break; }
    case 'commercial': { await replayCommercial(item.payload as Record<string, unknown> & { _id: string; _isUpdate: boolean }, now); break; }
    case 'productFamily': { await replayProductFamily(item.payload as Record<string, unknown> & { _id?: string; _isUpdate: boolean }, now); break; }
    case 'priceType': { await replayPriceType(item.payload as Record<string, unknown> & { _id: string; _isUpdate: boolean }, now); break; }
    case 'salesLocation': { await replaySalesLocation(item.payload as Record<string, unknown> & { _id: string; _isUpdate: boolean }, now); break; }
    case 'customUnit': { await replayCustomUnit(item.payload as { _id: string; name: string; _isDelete: boolean }); break; }
    case 'caisseClosing': { await replayCaisseClosing(item.payload as Record<string, unknown> & { _id: string; _user_id: string | null; _location_id?: string | null }, now); break; }
    case 'cashOp': { await replayCashOp(item.payload as CashOpInput & { _id: string; _location_id?: string | null }, now); break; }
    case 'settings': { await replaySettings(item.payload as Record<string, unknown>); break; }
    case 'product': { await replayProduct(item.payload as Record<string, unknown> & { _id: string; _isUpdate: boolean; _location_id?: string | null; _stock_quantity?: number; _stock_min?: number; _price?: number }, now); break; }
    case 'stockMovement': { await replayStockMovement(item.payload as Record<string, unknown> & { _id: string; _location_id?: string | null }, now); break; }
    case 'payment': { await replayPayment(item.payload as Record<string, unknown> & { _id: string }, now); break; }
    case 'deconditioning': { await replayDeconditioning(item.payload as Record<string, unknown> & { _id: string; _user_id: string | null }, now); break; }
    case 'accountingEntry': { await replayAccountingEntry(item.payload as Record<string, unknown> & { _id: string; _location_id?: string | null }, now); break; }
    case 'heldCart': { await replayHeldCart(item.payload as Record<string, unknown> & { _id: string; _user_id: string | null }, now); break; }
    case 'caisse': { await replayCaisse(item.payload as Record<string, unknown> & { _id: string; _isClose: boolean; _user_id?: string | null; _location_id?: string | null }, now); break; }
  }
}

async function replayInvoice(p: CreateInvoiceInput & { _id: string; _number: string; _location_id?: string | null; _created_by?: string | null }, now: string) {
  const remise = p.remise ?? 0;
  const subtotal = Math.round(p.items.reduce((s, i) => s + i.quantity * i.unit_price - (i.discount ?? 0), 0) * 100) / 100;
  const tax_amount = Math.round(subtotal * (p.tax_rate / 100) * 100) / 100;
  const total = Math.max(Math.round((subtotal + tax_amount - remise) * 100) / 100, 0);
  const locId = p._location_id ?? p.location_id ?? null;
  const { error } = await supabase.from('invoices').insert({
    id: p._id, invoice_number: p._number, customer_id: p.customer_id,
    date: p.date, due_date: p.due_date || null, status: 'brouillon',
    tax_rate: p.tax_rate, remise, subtotal, tax_amount, total, amount_paid: 0,
    notes: p.notes, created_at: now, updated_at: now,
    order_number: p.order_number ?? null,
    order_advance: p.order_advance ?? 0,
    delivery_delay: p.delivery_delay ?? null,
    payment_mode: p.payment_mode ?? null,
    created_by: p._created_by ?? null,
    ...(locId ? { location_id: locId } : {}),
  });
  if (error) throw new Error(error.message);
  const itemRows = p.items.map(i => ({ id: crypto.randomUUID(), invoice_id: p._id, product_id: i.product_id || null, description: i.description, quantity: i.quantity, unit_price: i.unit_price, unit_cost: i.unit_cost ?? 0, discount: i.discount ?? 0, sort_order: i.sort_order }));
  if (itemRows.length) { const { error: e } = await supabase.from('invoice_items').insert(itemRows); if (e) throw new Error(e.message); }
  for (const item of p.items) {
    if (!item.product_id) continue;
    const { data: prod } = await supabase.from('products').select('track_stock').eq('id', item.product_id).maybeSingle();
    if (!prod?.track_stock) continue;
    if (locId) {
      const lsId = `${item.product_id}_${locId}`;
      const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
      const newQty = Math.max(0, Number(ls?.stock_quantity ?? 0) - item.quantity);
      await supabase.from('location_stock').upsert({ id: lsId, product_id: item.product_id, location_id: locId, stock_quantity: newQty, stock_min: ls?.stock_min ?? 0, price: ls?.price ?? null, updated_at: now });
    } else {
      const { data: prod2 } = await supabase.from('products').select('stock_quantity').eq('id', item.product_id).maybeSingle();
      const newQty = Math.max(0, Number(prod2?.stock_quantity ?? 0) - item.quantity);
      await supabase.from('products').update({ stock_quantity: newQty, updated_at: now }).eq('id', item.product_id);
    }
    await supabase.from('stock_movements').insert({ id: crypto.randomUUID(), product_id: item.product_id, type: 'vente', quantity: item.quantity, unit_cost: item.unit_price, reference: p._number, notes: '', created_at: now, updated_at: now, ...(locId ? { location_id: locId } : {}) });
  }
}

async function replayOrder(p: CreateOrderInput & { _id: string; _number: string; _location_id?: string | null }, now: string) {
  const subtotal = Math.round(p.items.reduce((s, i) => s + i.quantity * i.unit_price, 0) * 100) / 100;
  const tax_amount = Math.round(subtotal * (p.tax_rate / 100) * 100) / 100;
  const total = Math.round((subtotal + tax_amount) * 100) / 100;
  const locId = p._location_id ?? null;
  const { error } = await supabase.from('orders').insert({
    id: p._id, order_number: p._number, customer_id: p.customer_id, commercial_id: p.commercial_id,
    location_id: locId, date: p.date, status: 'brouillon', tax_rate: p.tax_rate,
    subtotal, tax_amount, total, notes: p.notes, created_by: null, created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);
  const itemRows = p.items.map(i => ({ id: crypto.randomUUID(), order_id: p._id, product_id: i.product_id || null, description: i.description, quantity: i.quantity, unit_price: i.unit_price, sort_order: i.sort_order, created_at: now, updated_at: now }));
  if (itemRows.length) await supabase.from('order_items').insert(itemRows);
}

async function replayDeliveryNote(p: DeliveryNoteInput & { _id: string; _user_id: string | null }, now: string) {
  const total = p.items.reduce((s, i) => s + i.quantity * i.unit_cost, 0);
  const locId = p.location_id ?? null;
  const { error } = await supabase.from('delivery_notes').insert({
    id: p._id, note_number: p.note_number, supplier_id: p.supplier_id,
    ...(locId ? { location_id: locId } : {}), note_date: p.note_date, status: 'brouillon',
    total_amount: total, notes: p.notes, created_by: p._user_id, created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);
  const itemRows = p.items.map(i => ({ id: crypto.randomUUID(), delivery_note_id: p._id, product_id: i.product_id, location_id: i.location_id ?? null, quantity: i.quantity, unit_cost: i.unit_cost, total: i.quantity * i.unit_cost, created_at: now }));
  if (itemRows.length) await supabase.from('delivery_note_items').insert(itemRows);
}

async function replayValidateDeliveryNote(p: { noteId: string; location_id?: string | null }, now: string) {
  const { data: note } = await supabase.from('delivery_notes').select('*').eq('id', p.noteId).maybeSingle();
  if (!note || (note as { status: string }).status === 'valide') return;
  const { data: items } = await supabase.from('delivery_note_items').select('*').eq('delivery_note_id', p.noteId);
  const locId = (note as { location_id?: string | null }).location_id ?? p.location_id ?? null;
  await supabase.from('delivery_notes').update({ status: 'valide', updated_at: now }).eq('id', p.noteId);
  for (const item of (items ?? []) as { product_id: string; location_id?: string | null; quantity: number | string; unit_cost: number | string }[]) {
    const { data: prod } = await supabase.from('products').select('track_stock').eq('id', item.product_id).maybeSingle();
    if (!prod?.track_stock) continue;
    const itemLocId = item.location_id ?? locId;
    if (itemLocId) {
      const lsId = `${item.product_id}_${itemLocId}`;
      const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
      const newQty = Number(ls?.stock_quantity ?? 0) + Number(item.quantity);
      await supabase.from('location_stock').upsert({ id: lsId, product_id: item.product_id, location_id: itemLocId, stock_quantity: newQty, stock_min: ls?.stock_min ?? 0, price: ls?.price ?? null, updated_at: now });
    } else {
      const { data: prod2 } = await supabase.from('products').select('stock_quantity').eq('id', item.product_id).maybeSingle();
      await supabase.from('products').update({ stock_quantity: Number(prod2?.stock_quantity ?? 0) + Number(item.quantity), updated_at: now }).eq('id', item.product_id);
    }
    await supabase.from('stock_movements').insert({ id: crypto.randomUUID(), product_id: item.product_id, type: 'entree', quantity: Number(item.quantity), unit_cost: Number(item.unit_cost), reference: (note as { note_number: string }).note_number, notes: '', created_at: now, updated_at: now, ...(itemLocId ? { location_id: itemLocId } : {}) });
  }
}

async function replayDeleteDeliveryNote(p: { noteId: string }) {
  await supabase.from('delivery_note_items').delete().eq('delivery_note_id', p.noteId);
  const { error } = await supabase.from('delivery_notes').delete().eq('id', p.noteId);
  if (error) throw new Error(error.message);
}

async function replayStockTransfer(p: CreateTransferInput & { _user_id: string | null }, now: string) {
  const { items, from_location_id, to_location_id, notes } = p;
  const transferId = crypto.randomUUID();
  const { error: transferErr } = await supabase.from('stock_transfers').insert({
    id: transferId, product_id: null, quantity: null,
    from_location_id, to_location_id, notes,
    status: 'en_attente', created_by: p._user_id,
    created_at: now, updated_at: now,
  });
  if (transferErr) throw new Error(transferErr.message);
  if (items.length > 0) {
    const itemRows = items.map(it => ({
      id: crypto.randomUUID(), transfer_id: transferId,
      product_id: it.product_id, quantity: it.quantity, created_at: now,
    }));
    const { error: itemsErr } = await supabase.from('stock_transfer_items').insert(itemRows);
    if (itemsErr) throw new Error(itemsErr.message);
  }
}

async function replayDotation(p: CreateDotationInput & { _id: string; _number: string; _user_id: string | null }, now: string) {
  const { error } = await supabase.from('dotations').insert({
    id: p._id, dotation_number: p._number, location_id: p.location_id, service_id: p.service_id,
    notes: p.notes || '', effectif: p.effectif || 0, created_by: p._user_id, created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);
  for (const item of p.items) {
    if (item.quantity <= 0) continue;
    await supabase.from('dotation_items').insert({ id: crypto.randomUUID(), dotation_id: p._id, product_id: item.product_id, quantity: item.quantity, unit_cost: item.unit_cost, created_at: now });
    const lsId = `${item.product_id}_${p.location_id}`;
    const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
    const newQty = Math.max(0, Number(ls?.stock_quantity ?? 0) - item.quantity);
    await supabase.from('location_stock').upsert({ id: lsId, product_id: item.product_id, location_id: p.location_id, stock_quantity: newQty, stock_min: ls?.stock_min ?? 0, price: ls?.price ?? null, updated_at: now });
    await supabase.from('stock_movements').insert({ id: crypto.randomUUID(), product_id: item.product_id, type: 'sortie', quantity: item.quantity, unit_cost: item.unit_cost, reference: `Dotation ${p._number}`, notes: p.notes || 'Dotation vers service', location_id: p.location_id, created_at: now, updated_at: now });
  }
}

async function replaySupplier(p: SupplierInput & { _id: string; _location_id?: string | null; _isUpdate: boolean }, now: string) {
  const payload = { name: p.name, phone: p.phone, email: p.email, address: p.address, active: p.active, ...(p._location_id ? { location_id: p._location_id } : {}), updated_at: now };
  if (p._isUpdate) {
    const { error } = await supabase.from('suppliers').update(payload).eq('id', p._id);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabase.from('suppliers').insert({ ...payload, id: p._id, created_at: now });
    if (error) throw new Error(error.message);
  }
}

async function replaySupplierPayment(p: Record<string, unknown> & { _id: string }, now: string) {
  const { _id, ...rest } = p;
  const { error } = await supabase.from('supplier_payments').insert({ ...rest, id: _id, created_at: now, updated_at: now });
  if (error) throw new Error(error.message);
}

async function replayCommercial(p: Record<string, unknown> & { _id: string; _isUpdate: boolean }, now: string) {
  const { _id, _isUpdate, ...rest } = p;
  if (_isUpdate) {
    const { error } = await supabase.from('commerciaux').update({ ...rest, updated_at: now }).eq('id', _id as string);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabase.from('commerciaux').insert({ ...rest, id: _id, created_at: now, updated_at: now });
    if (error) throw new Error(error.message);
  }
}

async function replayProductFamily(p: Record<string, unknown> & { _id?: string; _isUpdate: boolean }, now: string) {
  const { _id, _isUpdate, ...rest } = p;
  if (_isUpdate && _id) {
    const { error } = await supabase.from('product_families').update({ ...rest, updated_at: now }).eq('id', _id);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabase.from('product_families').insert({ ...rest, created_at: now, updated_at: now });
    if (error) throw new Error(error.message);
  }
}

async function replayPriceType(p: Record<string, unknown> & { _id: string; _isUpdate: boolean }, now: string) {
  const { _id, _isUpdate, ...rest } = p;
  if (_isUpdate) {
    const { error } = await supabase.from('price_types').update({ ...rest, updated_at: now }).eq('id', _id);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabase.from('price_types').insert({ ...rest, id: _id, created_at: now, updated_at: now });
    if (error) throw new Error(error.message);
  }
}

async function replaySalesLocation(p: Record<string, unknown> & { _id: string; _isUpdate: boolean }, now: string) {
  const { _id, _isUpdate, ...rest } = p;
  if (_isUpdate) {
    const { error } = await supabase.from('sales_locations').update({ ...rest, updated_at: now }).eq('id', _id);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabase.from('sales_locations').insert({ ...rest, id: _id, created_at: now, updated_at: now });
    if (error) throw new Error(error.message);
  }
}

async function replayCustomUnit(p: { _id: string; name: string; _isDelete: boolean }) {
  if (p._isDelete) {
    await supabase.from('custom_units').delete().eq('id', p._id);
  } else {
    const { error } = await supabase.from('custom_units').insert({ id: p._id, name: p.name });
    if (error) throw new Error(error.message);
  }
}

async function replayCaisseClosing(p: Record<string, unknown> & { _id: string; _user_id: string | null; _location_id?: string | null }, now: string) {
  const { _id, _user_id, _location_id, lines, ...rest } = p;
  const { error } = await supabase.from('caisse_closings').insert({
    ...rest, id: _id, user_id: _user_id,
    ...(_location_id ? { location_id: _location_id } : {}),
    created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);
  const lineRows = (lines as { method: string; expected_amount: number; counted_amount: number }[] | undefined)?.map(l => ({
    id: crypto.randomUUID(), closing_id: _id, method: l.method,
    expected_amount: l.expected_amount, counted_amount: l.counted_amount,
    difference: l.counted_amount - l.expected_amount, created_at: now, updated_at: now,
  }));
  if (lineRows?.length) await supabase.from('caisse_closing_lines').insert(lineRows);
}

async function replayCashOp(p: CashOpInput & { _id: string; _location_id?: string | null }, now: string) {
  const { _id, _location_id, ...rest } = p;
  const { error } = await supabase.from('accounting_entries').insert({
    ...rest, id: _id, type: 'charge', source: 'caisse',
    ...(_location_id ? { location_id: _location_id } : {}),
    created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);
}

async function replaySettings(p: Record<string, unknown>) {
  const { data: existing } = await supabase.from('company_settings').select('id').limit(1).maybeSingle();
  if (existing) {
    const { id, ...updates } = p;
    const { error } = await supabase.from('company_settings').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', (existing as { id: string }).id);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabase.from('company_settings').insert(p);
    if (error) throw new Error(error.message);
  }
}

async function replayProduct(p: Record<string, unknown> & { _id: string; _isUpdate: boolean; _location_id?: string | null; _stock_quantity?: number; _stock_min?: number; _price?: number }, now: string) {
  const { _id, _isUpdate, _location_id, _stock_quantity, _stock_min, _price, ...rest } = p;
  if (_isUpdate) {
    const { error } = await supabase.from('products').update({ ...rest, updated_at: now }).eq('id', _id);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabase.from('products').insert({ ...rest, id: _id, created_at: now, updated_at: now });
    if (error) throw new Error(error.message);
  }
  if (_location_id) {
    const lsId = `${_id}_${_location_id}`;
    if (_isUpdate) {
      const { error } = await supabase.from('location_stock').upsert({
        id: lsId, product_id: _id, location_id: _location_id,
        stock_quantity: _stock_quantity ?? 0, stock_min: _stock_min ?? 0,
        price: _price ?? null, updated_at: now,
      });
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabase.from('location_stock').insert({
        id: lsId, product_id: _id, location_id: _location_id,
        stock_quantity: _stock_quantity ?? 0, stock_min: _stock_min ?? 0,
        price: _price ?? null, updated_at: now,
      });
      if (error) throw new Error(error.message);
    }
  }
}

async function replayStockMovement(p: Record<string, unknown> & { _id: string; _location_id?: string | null }, now: string) {
  const { _id, _location_id, ...rest } = p;
  const { error } = await supabase.from('stock_movements').insert({
    ...rest, id: _id,
    ...(_location_id ? { location_id: _location_id } : {}),
    created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);

  const productId = p.product_id as string;
  const type = p.type as string;
  const quantity = Number(p.quantity ?? 0);

  if (_location_id) {
    const lsId = `${productId}_${_location_id}`;
    const { data: ls } = await supabase.from('location_stock').select('*').eq('id', lsId).maybeSingle();
    const current = Number(ls?.stock_quantity ?? 0);
    let newQty: number;
    if (type === 'entree') newQty = current + quantity;
    else if (type === 'sortie' || type === 'vente') newQty = Math.max(0, current - quantity);
    else newQty = quantity;
    await supabase.from('location_stock').upsert({
      id: lsId, product_id: productId, location_id: _location_id,
      stock_quantity: newQty, stock_min: ls?.stock_min ?? 0,
      price: ls?.price ?? null, updated_at: now,
    });
  } else {
    const { data: prod } = await supabase.from('products').select('stock_quantity').eq('id', productId).maybeSingle();
    const current = Number(prod?.stock_quantity ?? 0);
    let newQty: number;
    if (type === 'entree') newQty = current + quantity;
    else if (type === 'sortie' || type === 'vente') newQty = Math.max(0, current - quantity);
    else newQty = quantity;
    await supabase.from('products').update({ stock_quantity: Math.max(0, newQty), updated_at: now }).eq('id', productId);
  }
}

async function replayPayment(p: Record<string, unknown> & { _id: string }, now: string) {
  const { _id, ...rest } = p;
  const { error } = await supabase.from('payments').insert({ ...rest, id: _id, created_at: now, updated_at: now });
  if (error) throw new Error(error.message);

  const invoiceId = p.invoice_id as string | null;
  if (invoiceId) {
    const { data: inv } = await supabase.from('invoices').select('total, amount_paid').eq('id', invoiceId).maybeSingle() as { data: { total: number; amount_paid: number } | null };
    if (inv) {
      const newPaid = Math.min(Number(inv.total), Number(inv.amount_paid) + Number(p.amount));
      const status = newPaid >= Number(inv.total) ? 'payee' : 'partielle';
      await supabase.from('invoices').update({ amount_paid: newPaid, status, updated_at: now }).eq('id', invoiceId);
    }
  }
}

async function replayDeconditioning(p: Record<string, unknown> & { _id: string; _user_id: string | null }, now: string) {
  const packProductId = p.pack_product_id as string;
  const detailProductId = p.detail_product_id as string;
  const packQuantity = Number(p.pack_quantity ?? 0);
  const unitsPerPack = Number(p.units_per_pack ?? 1);
  const locationId = (p.location_id as string | null) ?? null;
  const detailQty = packQuantity * unitsPerPack;

  if (locationId) {
    const packLsId = `${packProductId}_${locationId}`;
    const { data: packLs } = await supabase.from('location_stock').select('*').eq('id', packLsId).maybeSingle();
    const newPackQty = Math.max(0, Number(packLs?.stock_quantity ?? 0) - packQuantity);
    await supabase.from('location_stock').upsert({ id: packLsId, product_id: packProductId, location_id: locationId, stock_quantity: newPackQty, stock_min: packLs?.stock_min ?? 0, price: packLs?.price ?? null, updated_at: now });

    const detailLsId = `${detailProductId}_${locationId}`;
    const { data: detailLs } = await supabase.from('location_stock').select('*').eq('id', detailLsId).maybeSingle();
    await supabase.from('location_stock').upsert({ id: detailLsId, product_id: detailProductId, location_id: locationId, stock_quantity: Number(detailLs?.stock_quantity ?? 0) + detailQty, stock_min: detailLs?.stock_min ?? 0, price: detailLs?.price ?? null, updated_at: now });
  } else {
    const { data: packProd } = await supabase.from('products').select('stock_quantity').eq('id', packProductId).maybeSingle();
    await supabase.from('products').update({ stock_quantity: Math.max(0, Number(packProd?.stock_quantity ?? 0) - packQuantity), updated_at: now }).eq('id', packProductId);
    const { data: detailProd } = await supabase.from('products').select('stock_quantity').eq('id', detailProductId).maybeSingle();
    await supabase.from('products').update({ stock_quantity: Number(detailProd?.stock_quantity ?? 0) + detailQty, updated_at: now }).eq('id', detailProductId);
  }

  await supabase.from('stock_movements').insert({ id: crypto.randomUUID(), product_id: packProductId, type: 'sortie', quantity: packQuantity, unit_cost: 0, reference: 'Déconditionnement', notes: (p.notes as string) || '', ...(locationId ? { location_id: locationId } : {}), created_at: now, updated_at: now });
  await supabase.from('stock_movements').insert({ id: crypto.randomUUID(), product_id: detailProductId, type: 'entree', quantity: detailQty, unit_cost: 0, reference: 'Déconditionnement', notes: (p.notes as string) || '', ...(locationId ? { location_id: locationId } : {}), created_at: now, updated_at: now });

  const { error } = await supabase.from('deconditionings').insert({ id: p._id, pack_product_id: packProductId, detail_product_id: detailProductId, pack_quantity: packQuantity, units_per_pack: unitsPerPack, location_id: locationId, notes: p.notes as string, created_by: p._user_id, created_at: now, updated_at: now });
  if (error) throw new Error(error.message);
}

async function replayAccountingEntry(p: Record<string, unknown> & { _id: string; _location_id?: string | null }, now: string) {
  const { _id, _location_id, ...rest } = p;
  const { error } = await supabase.from('accounting_entries').insert({
    ...rest, id: _id,
    ...(_location_id ? { location_id: _location_id } : {}),
    created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);
}

async function replayHeldCart(p: Record<string, unknown> & { _id: string; _user_id: string | null }, now: string) {
  const { _id, _user_id, ...rest } = p;
  const { error } = await supabase.from('held_carts').insert({
    ...rest, id: _id, created_by: _user_id,
    created_at: now, updated_at: now,
  });
  if (error) throw new Error(error.message);
}

async function replayCaisse(p: Record<string, unknown> & { _id: string; _isClose: boolean; _user_id?: string | null; _location_id?: string | null }, now: string) {
  const { _id, _isClose, _user_id, _location_id, ...rest } = p;
  if (_isClose) {
    const { error } = await supabase.from('caisses').update({ ...rest, status: 'cloturee', updated_at: now }).eq('id', _id);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabase.from('caisses').insert({
      ...rest, id: _id, user_id: _user_id,
      status: 'ouverte',
      ...(_location_id ? { location_id: _location_id } : {}),
      created_at: now, updated_at: now,
    });
    if (error) throw new Error(error.message);
  }
}

export async function syncPendingCustomers(tenantId?: string | null): Promise<void> {
  const queue = await getQueuedCustomersForTenant(tenantId ?? null);
  const pending = queue.filter(q => q.status === 'pending' || q.status === 'error');
  for (const item of pending) {
    try {
      await updateQueuedCustomer(item.localId, { status: 'syncing' });
      const { data: rpcData, error: rpcErr } = await supabase.rpc('next_customer_code');
      const code = rpcErr || !rpcData ? `CLI-${crypto.randomUUID().slice(0, 8).toUpperCase()}` : rpcData as string;
      const now = new Date().toISOString();
      const { data, error } = await supabase.from('customers').insert({
        ...item.payload,
        code,
        created_at: now,
        updated_at: now,
      }).select().single();
      if (error) throw new Error(error.message);
      await removeQueuedCustomer(item.localId);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erreur de synchro client';
      await updateQueuedCustomer(item.localId, { status: 'error', error: msg });
    }
  }
}
