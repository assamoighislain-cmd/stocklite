const DB_NAME = 'stocklite-offline';
const DB_VERSION = 4;

const STORES = {
  products: 'products',
  customers: 'customers',
  pendingSales: 'pending_sales',
  pendingCustomers: 'pending_customers',
  pendingOps: 'pending_ops',
  locations: 'locations',
  settings: 'settings',
  families: 'families',
  sales: 'sales',
  meta: 'meta',
} as const;

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORES.products)) db.createObjectStore(STORES.products, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(STORES.customers)) db.createObjectStore(STORES.customers, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(STORES.pendingSales)) db.createObjectStore(STORES.pendingSales, { keyPath: 'localId' });
      if (!db.objectStoreNames.contains(STORES.pendingCustomers)) db.createObjectStore(STORES.pendingCustomers, { keyPath: 'localId' });
      if (!db.objectStoreNames.contains(STORES.pendingOps)) db.createObjectStore(STORES.pendingOps, { keyPath: 'localId' });
      if (!db.objectStoreNames.contains(STORES.locations)) db.createObjectStore(STORES.locations, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(STORES.settings)) db.createObjectStore(STORES.settings, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(STORES.families)) db.createObjectStore(STORES.families, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(STORES.sales)) db.createObjectStore(STORES.sales, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(STORES.meta)) db.createObjectStore(STORES.meta);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(db => new Promise<T>((resolve, reject) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  }));
}

async function bulkCache(store: string, items: unknown[]): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, 'readwrite');
    const s = t.objectStore(store);
    s.clear();
    for (const item of items) s.put(item);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

async function getAll<T>(store: string): Promise<T[]> {
  return tx<T[]>(store, 'readonly', s => s.getAll());
}

async function getItem<T>(store: string, key: string): Promise<T | undefined> {
  return tx<T | undefined>(store, 'readonly', s => s.get(key));
}

// ── Products ──
export async function cacheProducts(products: unknown[]): Promise<void> {
  await bulkCache(STORES.products, products);
}

export async function getCachedProducts<T>(): Promise<T[]> {
  return getAll<T>(STORES.products);
}

export async function decrementCachedStock(items: { product_id: string | null; quantity: number }[]): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES.products, 'readwrite');
    const store = t.objectStore(STORES.products);
    const productIds = items.map(i => i.product_id).filter(Boolean) as string[];
    const gets = productIds.map(id => {
      const req = store.get(id);
      return new Promise<{ id: string; data: any }>((res, rej) => {
        req.onsuccess = () => res({ id, data: req.result });
        req.onerror = () => rej(req.error);
      });
    });
    Promise.all(gets).then(results => {
      for (const { id, data } of results) {
        if (!data) continue;
        const item = items.find(i => i.product_id === id);
        if (!item) continue;
        const newQty = Math.max(0, Number(data.stock_quantity ?? 0) - item.quantity);
        store.put({ ...data, stock_quantity: newQty });
      }
    }).catch(reject);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

export async function restoreCachedStock(items: { product_id: string | null; quantity: number }[]): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES.products, 'readwrite');
    const store = t.objectStore(STORES.products);
    const productIds = items.map(i => i.product_id).filter(Boolean) as string[];
    const gets = productIds.map(id => {
      const req = store.get(id);
      return new Promise<{ id: string; data: any }>((res, rej) => {
        req.onsuccess = () => res({ id, data: req.result });
        req.onerror = () => rej(req.error);
      });
    });
    Promise.all(gets).then(results => {
      for (const { id, data } of results) {
        if (!data) continue;
        const item = items.find(i => i.product_id === id);
        if (!item) continue;
        const newQty = Number(data.stock_quantity ?? 0) + item.quantity;
        store.put({ ...data, stock_quantity: newQty });
      }
    }).catch(reject);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

// ── Customers ──
export async function cacheCustomers(customers: unknown[]): Promise<void> {
  await bulkCache(STORES.customers, customers);
}

export async function getCachedCustomers<T>(): Promise<T[]> {
  return getAll<T>(STORES.customers);
}

// ── Pending Customers Queue ──
export interface QueuedCustomer {
  localId: string;
  payload: Omit<import('../types').Customer, 'id' | 'created_at'>;
  createdAt: string;
  status: 'pending' | 'syncing' | 'error';
  error?: string;
  tenantId?: string | null;
}

export async function queueCustomer(c: QueuedCustomer): Promise<void> {
  await tx(STORES.pendingCustomers, 'readwrite', s => s.put(c));
}

export async function getQueuedCustomers(): Promise<QueuedCustomer[]> {
  return tx<QueuedCustomer[]>(STORES.pendingCustomers, 'readonly', s => s.getAll());
}

export async function getQueuedCustomersForTenant(tenantId: string | null): Promise<QueuedCustomer[]> {
  const all = await getQueuedCustomers();
  return all.filter(q => (q.tenantId ?? null) === (tenantId ?? null));
}

export async function updateQueuedCustomer(localId: string, patch: Partial<QueuedCustomer>): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES.pendingCustomers, 'readwrite');
    const store = t.objectStore(STORES.pendingCustomers);
    const getReq = store.get(localId);
    getReq.onsuccess = () => {
      const existing = getReq.result as QueuedCustomer | undefined;
      if (existing) store.put({ ...existing, ...patch });
    };
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

export async function removeQueuedCustomer(localId: string): Promise<void> {
  await tx(STORES.pendingCustomers, 'readwrite', s => s.delete(localId));
}

export async function cacheCustomerLocally(customer: import('../types').Customer): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES.customers, 'readwrite');
    t.objectStore(STORES.customers).put(customer);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

// ── Generic Pending Ops Queue ──
export type OpType =
  | 'invoice' | 'order' | 'deliveryNote' | 'validateDeliveryNote' | 'deleteDeliveryNote'
  | 'stockTransfer' | 'dotation' | 'supplier' | 'supplierPayment'
  | 'commercial' | 'productFamily' | 'priceType' | 'salesLocation'
  | 'customUnit' | 'caisseClosing' | 'cashOp' | 'settings'
  | 'product' | 'stockMovement' | 'payment' | 'deconditioning'
  | 'accountingEntry' | 'heldCart' | 'caisse';

export interface QueuedOp {
  localId: string;
  op: OpType;
  payload: unknown;
  createdAt: string;
  status: 'pending' | 'syncing' | 'error';
  error?: string;
  tenantId?: string | null;
  locationId?: string | null;
}

export async function queueOp(op: QueuedOp): Promise<void> {
  await tx(STORES.pendingOps, 'readwrite', s => s.put(op));
}

export async function getQueuedOps(): Promise<QueuedOp[]> {
  return tx<QueuedOp[]>(STORES.pendingOps, 'readonly', s => s.getAll());
}

export async function getQueuedOpsForTenant(tenantId: string | null): Promise<QueuedOp[]> {
  const all = await getQueuedOps();
  return all.filter(q => (q.tenantId ?? null) === (tenantId ?? null));
}

export async function updateQueuedOp(localId: string, patch: Partial<QueuedOp>): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES.pendingOps, 'readwrite');
    const store = t.objectStore(STORES.pendingOps);
    const getReq = store.get(localId);
    getReq.onsuccess = () => {
      const existing = getReq.result as QueuedOp | undefined;
      if (existing) store.put({ ...existing, ...patch });
    };
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

export async function removeQueuedOp(localId: string): Promise<void> {
  await tx(STORES.pendingOps, 'readwrite', s => s.delete(localId));
}

export async function getPendingOpsCount(): Promise<number> {
  return tx<number>(STORES.pendingOps, 'readonly', s => s.count());
}

// ── Sales Locations ──
export async function cacheLocations(locations: unknown[]): Promise<void> {
  await bulkCache(STORES.locations, locations);
}

export async function getCachedLocations<T>(): Promise<T[]> {
  return getAll<T>(STORES.locations);
}

// ── Company Settings ──
export async function cacheSettings(settings: unknown): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES.settings, 'readwrite');
    const s = t.objectStore(STORES.settings);
    s.clear();
    s.put(settings);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

export async function getCachedSettings<T>(): Promise<T | undefined> {
  const all = await getAll<T>(STORES.settings);
  return all.length > 0 ? all[0] : undefined;
}

// ── Product Families ──
export async function cacheFamilies(families: unknown[]): Promise<void> {
  await bulkCache(STORES.families, families);
}

export async function getCachedFamilies<T>(): Promise<T[]> {
  return getAll<T>(STORES.families);
}

// ── Past Sales ──
export async function cacheSales(sales: unknown[]): Promise<void> {
  await bulkCache(STORES.sales, sales);
}

export async function getCachedSales<T>(): Promise<T[]> {
  return getAll<T>(STORES.sales);
}

// ── Pending Sales Queue ──
export interface QueuedSale {
  localId: string;
  payload: unknown;
  createdAt: string;
  status: 'pending' | 'syncing' | 'error';
  error?: string;
  tenantId?: string | null;
  locationId?: string | null;
}

export async function queueSale(sale: QueuedSale): Promise<void> {
  await tx(STORES.pendingSales, 'readwrite', s => s.put(sale));
}

export async function getQueuedSales(): Promise<QueuedSale[]> {
  return tx<QueuedSale[]>(STORES.pendingSales, 'readonly', s => s.getAll());
}

export async function getQueuedSalesForTenant(tenantId: string | null): Promise<QueuedSale[]> {
  const all = await getQueuedSales();
  return all.filter(q => (q.tenantId ?? null) === (tenantId ?? null));
}

export async function updateQueuedSale(localId: string, patch: Partial<QueuedSale>): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES.pendingSales, 'readwrite');
    const store = t.objectStore(STORES.pendingSales);
    const getReq = store.get(localId);
    getReq.onsuccess = () => {
      const existing = getReq.result as QueuedSale | undefined;
      if (existing) store.put({ ...existing, ...patch });
    };
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

export async function removeQueuedSale(localId: string): Promise<void> {
  await tx(STORES.pendingSales, 'readwrite', s => s.delete(localId));
}

export async function getPendingCount(): Promise<number> {
  return tx<number>(STORES.pendingSales, 'readonly', s => s.count());
}

// ── Meta ──
export async function setMeta(key: string, value: unknown): Promise<void> {
  await tx(STORES.meta, 'readwrite', s => s.put(value, key));
}

export async function getMeta<T>(key: string): Promise<T | undefined> {
  return tx<T | undefined>(STORES.meta, 'readonly', s => s.get(key));
}
