import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, UserCheck, Phone, MapPin, Link2, Unlink } from 'lucide-react';
import type { Commercial, SalesLocation, UserProfile } from '../types';
import type { useCommerciaux } from '../hooks/useCommerciaux';
import { useAdminUsers } from '../hooks/useAdminUsers';
import { supabase } from '../lib/supabase';

interface Props {
  commerciaux: Commercial[];
  loading: boolean;
  onSave: ReturnType<typeof useCommerciaux>['save'];
  onRemove: ReturnType<typeof useCommerciaux>['remove'];
  locations: SalesLocation[];
  activeLocationId: string | null;
}

const EMPTY: Omit<Commercial, 'id' | 'created_at'> = {
  name: '',
  phone: '',
  active: true,
  location_id: null,
};

export default function CommerciauxPage({ commerciaux, loading, onSave, onRemove, locations, activeLocationId }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Commercial | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [commercialUsers, setCommercialUsers] = useState<UserProfile[]>([]);
  const [linkingId, setLinkingId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('user_profiles')
        .select('*, location:sales_locations(*)')
        .eq('role', 'commercial')
        .order('created_at', { ascending: true });
      if (data) setCommercialUsers(data as UserProfile[]);
    })();
  }, []);

  function openNew() {
    setEditing(null);
    setForm({ ...EMPTY, location_id: activeLocationId });
    setShowForm(true);
  }

  function openEdit(c: Commercial) {
    setEditing(c);
    setForm({ name: c.name, phone: c.phone, active: c.active, location_id: c.location_id });
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditing(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      await onSave({ ...form, ...(editing ? { id: editing.id } : {}) });
      closeForm();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    await onRemove(id);
    setConfirmDelete(null);
  }

  const locationName = (id: string | null) => locations.find(l => l.id === id)?.name ?? '—';

  const filtered = activeLocationId
    ? commerciaux.filter(c => c.location_id === activeLocationId)
    : commerciaux;

  const linkedUserFor = (commercialId: string) =>
    commercialUsers.find(u => u.commercial_id === commercialId) ?? null;

  async function handleLink(commercialId: string, userId: string | null) {
    setLinkingId(commercialId);
    try {
      const now = new Date().toISOString();
      // Unlink any user currently linked to this commercial
      const prev = linkedUserFor(commercialId);
      if (prev && prev.id !== userId) {
        await supabase.from('user_profiles').update({ commercial_id: null, updated_at: now }).eq('id', prev.id);
      }
      // Unlink the selected user from any other commercial
      if (userId) {
        const otherCommercial = commerciaux.find(c => linkedUserFor(c.id)?.id === userId && c.id !== commercialId);
        if (otherCommercial) {
          // The user was linked to another commercial; we'll just reassign
        }
        await supabase.from('user_profiles').update({ commercial_id: commercialId, updated_at: now }).eq('id', userId);
      }
      // Refresh local state
      setCommercialUsers(prev => prev.map(u => {
        if (u.id === userId) return { ...u, commercial_id: commercialId };
        if (u.commercial_id === commercialId && u.id !== userId) return { ...u, commercial_id: null };
        return u;
      }));
    } finally {
      setLinkingId(null);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Commerciaux</h1>
          <p className="text-sm text-gray-500 mt-0.5">{filtered.length} commercial{filtered.length !== 1 ? 'x' : ''}</p>
        </div>
        <button
          onClick={openNew}
          className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95"
        >
          <Plus className="h-4 w-4" />
          Nouveau commercial
        </button>
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-16 rounded-xl bg-gray-100 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-300 py-16 text-center">
          <UserCheck className="h-10 w-10 text-gray-300 mb-3" />
          <p className="text-sm font-medium text-gray-400">Aucun commercial</p>
          <p className="text-xs text-gray-400 mt-1">Créez votre premier commercial pour l'assigner aux ventes.</p>
          <button onClick={openNew} className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition">
            Ajouter un commercial
          </button>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white divide-y divide-gray-100">
          {filtered.map(c => (
            <div key={c.id} className="flex items-center gap-4 px-5 py-4">
              <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-sm font-bold text-blue-700 shrink-0">
                {c.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900">{c.name}</p>
                <div className="flex items-center gap-3 mt-0.5">
                  {c.phone && (
                    <span className="flex items-center gap-1 text-xs text-gray-400">
                      <Phone className="h-3 w-3" />{c.phone}
                    </span>
                  )}
                  {c.location_id && (
                    <span className="flex items-center gap-1 text-xs text-gray-400">
                      <MapPin className="h-3 w-3" />{locationName(c.location_id)}
                    </span>
                  )}
                </div>
                {/* Linked account dropdown */}
                <div className="flex items-center gap-1.5 mt-1.5">
                  <Link2 className="h-3 w-3 text-gray-300 shrink-0" />
                  <select
                    value={linkedUserFor(c.id)?.id ?? ''}
                    disabled={linkingId === c.id}
                    onChange={e => handleLink(c.id, e.target.value || null)}
                    className="rounded-md border border-gray-200 bg-gray-50 px-2 py-1 text-xs text-gray-600 outline-none focus:border-blue-500 disabled:opacity-50 max-w-[200px]"
                  >
                    <option value="">Aucun compte lié</option>
                    {commercialUsers.map(u => (
                      <option key={u.id} value={u.id}>{u.full_name || u.email}</option>
                    ))}
                  </select>
                </div>
              </div>
              <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.active ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-400'}`}>
                {c.active ? 'Actif' : 'Inactif'}
              </span>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => openEdit(c)} className="rounded-lg p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-700 transition">
                  <Pencil className="h-4 w-4" />
                </button>
                <button onClick={() => setConfirmDelete(c.id)} className="rounded-lg p-2 text-gray-400 hover:bg-red-50 hover:text-red-500 transition">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white shadow-2xl overflow-hidden">
            <div className="border-b border-gray-100 px-6 py-4">
              <h2 className="text-base font-semibold text-gray-900">
                {editing ? 'Modifier le commercial' : 'Nouveau commercial'}
              </h2>
            </div>
            <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Nom complet *</label>
                <input
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  required
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                  placeholder="Ex : Mamadou Diallo"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Téléphone</label>
                <input
                  value={form.phone}
                  onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                  placeholder="+225 07 00 00 00 00"
                />
              </div>
              {locations.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Boutique</label>
                  <select
                    value={form.location_id ?? ''}
                    onChange={e => setForm(f => ({ ...f, location_id: e.target.value || null }))}
                    className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
                  >
                    <option value="">Toutes les boutiques</option>
                    {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
                  </select>
                </div>
              )}
              <label className="flex items-center gap-3 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={form.active}
                  onChange={e => setForm(f => ({ ...f, active: e.target.checked }))}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 accent-blue-600"
                />
                <span className="text-sm text-gray-700">Actif</span>
              </label>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={closeForm} className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition">
                  Annuler
                </button>
                <button type="submit" disabled={saving} className="flex-1 rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50">
                  {saving ? 'Enregistrement…' : editing ? 'Mettre à jour' : 'Créer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete confirm */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white shadow-2xl p-6 space-y-4">
            <p className="text-sm font-medium text-gray-800">Supprimer ce commercial ?</p>
            <p className="text-xs text-gray-500">Cette action est irréversible. Les ventes existantes ne sont pas affectées.</p>
            <div className="flex gap-3">
              <button onClick={() => setConfirmDelete(null)} className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition">
                Annuler
              </button>
              <button onClick={() => handleDelete(confirmDelete)} className="flex-1 rounded-xl bg-red-600 py-2.5 text-sm font-semibold text-white hover:bg-red-500 transition">
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
