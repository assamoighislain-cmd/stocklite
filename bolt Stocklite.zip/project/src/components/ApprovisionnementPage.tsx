import { useState, useMemo, useRef, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import {
  Truck, Plus, Search, CheckCircle, Trash2, Package, X,
  ChevronDown, ChevronUp, FileText, Building2, Phone, Mail, MapPin, Wallet,
} from 'lucide-react';
import type { Supplier, DeliveryNote, Product, CompanySettings, SalesLocation, PaymentMethod, SupplierPayment } from '../types';
import { ALL_PAYMENT_METHODS } from '../types';
import { fmtQty } from '../lib/format';
import type { useApprovisionnement } from '../hooks/useApprovisionnement';
import { translateError } from '../lib/translateError';

interface ApprovisionnementPageProps {
  settings: CompanySettings | null;
  products: Product[];
  locationId: string | null;
  locations: SalesLocation[];
  suppliers: Supplier[];
  deliveryNotes: DeliveryNote[];
  loading: boolean;
  onSaveSupplier: (input: { name: string; phone: string; email: string; address: string; active: boolean }) => Promise<Supplier>;
  onRemoveSupplier: (id: string) => Promise<void>;
  onCreateNote: (input: {
    note_number: string; supplier_id: string; location_id: string | null;
    note_date: string; notes: string;
    items: { product_id: string; location_id: string | null; quantity: number; unit_cost: number }[];
  }) => Promise<DeliveryNote>;
  onValidateNote: (noteId: string) => Promise<void>;
  onDeleteNote: (noteId: string) => Promise<void>;
  onRecordSupplierPayment: (input: {
    supplier_id: string; delivery_note_id: string | null; amount: number;
    method: PaymentMethod; payment_date: string; notes: string; location_id: string | null;
  }) => Promise<SupplierPayment>;
  onRemoveSupplierPayment: (id: string) => Promise<void>;
}

type Tab = 'notes' | 'suppliers' | 'payments';

export function ApprovisionnementPage({
  settings, products, locationId, locations, suppliers, deliveryNotes, loading,
  onSaveSupplier, onRemoveSupplier, onCreateNote, onValidateNote, onDeleteNote,
  onRecordSupplierPayment, onRemoveSupplierPayment,
}: ApprovisionnementPageProps) {
  const currency = settings?.currency ?? 'FCFA';
  const [tab, setTab] = useState<Tab>('notes');
  const [showSupplierForm, setShowSupplierForm] = useState(false);
  const [showNoteForm, setShowNoteForm] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [validateTarget, setValidateTarget] = useState<DeliveryNote | null>(null);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Approvisionnement</h1>
          <p className="text-sm text-gray-500">Bons de livraison fournisseurs et mouvements de stock</p>
        </div>
        <div className="flex gap-2">
          {tab === 'notes' ? (
            <button
              onClick={() => setShowNoteForm(true)}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95"
            >
              <Plus className="h-4 w-4" />
              Nouveau bon
            </button>
          ) : tab === 'suppliers' ? (
            <button
              onClick={() => setShowSupplierForm(true)}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95"
            >
              <Plus className="h-4 w-4" />
              Nouveau fournisseur
            </button>
          ) : (
            <button
              onClick={() => setShowPaymentForm(true)}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95"
            >
              <Plus className="h-4 w-4" />
              Nouveau règlement
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 rounded-xl border border-gray-200 bg-white p-1 shadow-sm">
        <button
          onClick={() => setTab('notes')}
          className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-sm font-semibold transition ${
            tab === 'notes' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <FileText className="h-4 w-4" />
          Bons de livraison
          {deliveryNotes.length > 0 && (
            <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${tab === 'notes' ? 'bg-blue-500' : 'bg-gray-200 text-gray-600'}`}>
              {deliveryNotes.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setTab('suppliers')}
          className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-sm font-semibold transition ${
            tab === 'suppliers' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <Building2 className="h-4 w-4" />
          Fournisseurs
          {suppliers.length > 0 && (
            <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${tab === 'suppliers' ? 'bg-blue-500' : 'bg-gray-200 text-gray-600'}`}>
              {suppliers.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setTab('payments')}
          className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-sm font-semibold transition ${
            tab === 'payments' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <Wallet className="h-4 w-4" />
          Règlements
        </button>
      </div>

      {/* Content */}
      {tab === 'notes' ? (
        <NotesList
          notes={deliveryNotes}
          locations={locations}
          loading={loading}
          currency={currency}
          expandedId={expandedId}
          onToggle={(id) => setExpandedId(prev => prev === id ? null : id)}
          onValidate={(n) => setValidateTarget(n)}
          onDelete={onDeleteNote}
        />
      ) : tab === 'suppliers' ? (
        <SuppliersList
          suppliers={suppliers}
          onRemove={onRemoveSupplier}
        />
      ) : (
        <SupplierPaymentsList
          suppliers={suppliers}
          deliveryNotes={deliveryNotes}
          currency={currency}
          locationId={locationId}
          onRemove={onRemoveSupplierPayment}
        />
      )}

      {showSupplierForm && (
        <SupplierForm
          onClose={() => setShowSupplierForm(false)}
          onSave={async (input) => { await onSaveSupplier(input); setShowSupplierForm(false); }}
        />
      )}

      {showNoteForm && (
        <NoteForm
          suppliers={suppliers}
          locations={locations}
          defaultLocationId={locationId}
          currency={currency}
          existingCount={deliveryNotes.length}
          onClose={() => setShowNoteForm(false)}
          onSave={async (input) => { await onCreateNote(input); setShowNoteForm(false); }}
        />
      )}

      {showPaymentForm && (
        <SupplierPaymentForm
          suppliers={suppliers}
          deliveryNotes={deliveryNotes}
          defaultLocationId={locationId}
          currency={currency}
          onClose={() => setShowPaymentForm(false)}
          onSave={async (input) => { await onRecordSupplierPayment(input); setShowPaymentForm(false); }}
        />
      )}

      {validateTarget && (
        <ValidateConfirmModal
          note={validateTarget}
          locations={locations}
          currency={currency}
          onClose={() => setValidateTarget(null)}
          onConfirm={async () => {
            await onValidateNote(validateTarget.id);
            setValidateTarget(null);
          }}
        />
      )}
    </div>
  );
}

// ── Notes list ─────────────────────────────────────────────────
function NotesList({
  notes, locations, loading, currency, expandedId, onToggle, onValidate, onDelete,
}: {
  notes: DeliveryNote[];
  locations: SalesLocation[];
  loading: boolean;
  currency: string;
  expandedId: string | null;
  onToggle: (id: string) => void;
  onValidate: (note: DeliveryNote) => void;
  onDelete: (id: string) => Promise<void>;
}) {
  if (loading && notes.length === 0) {
    return <div className="rounded-xl border border-gray-200 bg-white p-8 text-center text-sm text-gray-400">Chargement…</div>;
  }
  if (notes.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-gray-300 bg-white p-10 text-center">
        <Truck className="mx-auto h-10 w-10 text-gray-300" />
        <p className="mt-3 text-sm font-medium text-gray-500">Aucun bon de livraison</p>
        <p className="text-xs text-gray-400">Créez un bon pour enregistrer une réception fournisseur.</p>
      </div>
    );
  }
  return (
    <div className="space-y-2">
      {notes.map(n => {
        const expanded = expandedId === n.id;
        const isValidated = n.status === 'valide';
        return (
          <div key={n.id} className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
            <button
              onClick={() => onToggle(n.id)}
              className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 transition"
            >
              <div className={`flex h-9 w-9 items-center justify-center rounded-lg shrink-0 ${isValidated ? 'bg-emerald-100' : 'bg-amber-100'}`}>
                {isValidated ? <CheckCircle className="h-5 w-5 text-emerald-600" /> : <FileText className="h-5 w-5 text-amber-600" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-bold text-gray-900">{n.note_number}</p>
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${isValidated ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                    {isValidated ? 'Validé' : 'Brouillon'}
                  </span>
                </div>
                <p className="text-xs text-gray-500 truncate">
                  {n.supplier?.name ?? 'Fournisseur inconnu'} · {new Date(n.note_date).toLocaleDateString('fr-FR')} · {(n.items ?? []).length} article(s)
                  {n.location_id ? ` · ${locations.find(l => l.id === n.location_id)?.name ?? 'Boutique'}` : ''}
                </p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-sm font-bold tabular-nums text-gray-900">{new Intl.NumberFormat('fr-FR').format(n.total_amount)} {currency}</p>
              </div>
              {expanded ? <ChevronUp className="h-4 w-4 text-gray-400 shrink-0" /> : <ChevronDown className="h-4 w-4 text-gray-400 shrink-0" />}
            </button>

            {expanded && (
              <div className="border-t border-gray-100 bg-gray-50/50 px-4 py-3">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-[11px] uppercase tracking-wider text-gray-400">
                        <th className="pb-2 font-semibold">Article</th>
                        <th className="pb-2 text-right font-semibold">Qté</th>
                        <th className="pb-2 text-right font-semibold">Coût unit.</th>
                        <th className="pb-2 text-right font-semibold">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {(n.items ?? []).map((it, i) => (
                        <tr key={i}>
                          <td className="py-2 text-gray-700">{it.product?.name ?? it.product_id}</td>
                          <td className="py-2 text-right tabular-nums text-gray-700">{fmtQty(it.quantity)}</td>
                          <td className="py-2 text-right tabular-nums text-gray-700">{new Intl.NumberFormat('fr-FR').format(it.unit_cost)}</td>
                          <td className="py-2 text-right tabular-nums font-medium text-gray-900">{new Intl.NumberFormat('fr-FR').format(it.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {n.notes && <p className="mt-2 text-xs text-gray-500">Remarques : {n.notes}</p>}
                <div className="mt-3 flex justify-end gap-2">
                  {!isValidated && (
                    <button
                      onClick={() => onValidate(n)}
                      className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 transition active:scale-95"
                    >
                      <CheckCircle className="h-3.5 w-3.5" />
                      Valider et mouvementer le stock
                    </button>
                  )}
                  {!isValidated && (
                    <button
                      onClick={() => { if (confirm('Supprimer ce bon ?')) onDelete(n.id); }}
                      className="flex items-center gap-1.5 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 hover:bg-gray-100 transition active:scale-95"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      Supprimer
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Validate confirmation modal ────────────────────────────────
function ValidateConfirmModal({ note, locations, currency, onClose, onConfirm }: {
  note: DeliveryNote;
  locations: SalesLocation[];
  currency: string;
  onClose: () => void;
  onConfirm: () => Promise<void>;
}) {
  const [confirming, setConfirming] = useState(false);
  const locName = locations.find(l => l.id === note.location_id)?.name ?? 'Boutique';
  const items = note.items ?? [];

  async function handleConfirm() {
    setConfirming(true);
    try { await onConfirm(); }
    catch (e) { alert(e instanceof Error ? translateError(e.message) : 'Erreur'); }
    finally { setConfirming(false); }
  }

  return (
    <Modal onClose={onClose} title="Valider le bon de livraison" wide>
      <div className="space-y-4">
        <div className="rounded-lg bg-amber-50 border border-amber-200 px-4 py-3">
          <div className="flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-amber-900">Confirmer la validation</p>
              <p className="text-xs text-amber-700 mt-0.5">
                La validation mettra &agrave; jour le stock des articles ci-dessous pour le point de vente
                &laquo;&nbsp;{locName}&nbsp;&raquo;. Cette action est irr&eacute;versible.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div><span className="text-gray-500">N&deg; du bon :</span> <b className="text-gray-900">{note.note_number}</b></div>
          <div><span className="text-gray-500">Date :</span> <b className="text-gray-900">{new Date(note.note_date).toLocaleDateString('fr-FR')}</b></div>
          <div><span className="text-gray-500">Fournisseur :</span> <b className="text-gray-900">{note.supplier?.name ?? '—'}</b></div>
          <div><span className="text-gray-500">Point de vente :</span> <b className="text-gray-900">{locName}</b></div>
        </div>

        <div className="overflow-x-auto rounded-lg border border-gray-200">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-left text-[11px] uppercase tracking-wider text-gray-400">
              <tr>
                <th className="px-3 py-2 font-semibold">Article</th>
                <th className="px-3 py-2 text-right font-semibold">Qt&eacute;</th>
                <th className="px-3 py-2 text-right font-semibold">Co&ucirc;t unit.</th>
                <th className="px-3 py-2 text-right font-semibold">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((it, i) => (
                <tr key={i}>
                  <td className="px-3 py-2 text-gray-700">{it.product?.name ?? it.product_id}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-gray-700">{fmtQty(it.quantity)}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-gray-700">{new Intl.NumberFormat('fr-FR').format(it.unit_cost)}</td>
                  <td className="px-3 py-2 text-right tabular-nums font-medium text-gray-900">{new Intl.NumberFormat('fr-FR').format(it.total)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t border-gray-200 bg-gray-50">
                <td colSpan={3} className="px-3 py-2 text-right text-xs font-semibold uppercase text-gray-500">Total</td>
                <td className="px-3 py-2 text-right tabular-nums font-bold text-gray-900">{new Intl.NumberFormat('fr-FR').format(note.total_amount)} {currency}</td>
              </tr>
            </tfoot>
          </table>
        </div>

        {note.notes && <p className="text-xs text-gray-500">Remarques : {note.notes}</p>}

        <div className="flex justify-end gap-2 pt-1">
          <button onClick={onClose} className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-600 hover:bg-gray-100">Annuler</button>
          <button onClick={handleConfirm} disabled={confirming} className="flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 disabled:opacity-50">
            <CheckCircle className="h-4 w-4" />
            {confirming ? 'Validation…' : 'Confirmer et mettre &agrave; jour le stock'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ── Suppliers list ─────────────────────────────────────────────
function SuppliersList({ suppliers, onRemove }: { suppliers: Supplier[]; onRemove: (id: string) => Promise<void> }) {
  if (suppliers.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-gray-300 bg-white p-10 text-center">
        <Building2 className="mx-auto h-10 w-10 text-gray-300" />
        <p className="mt-3 text-sm font-medium text-gray-500">Aucun fournisseur</p>
        <p className="text-xs text-gray-400">Ajoutez un fournisseur pour commencer.</p>
      </div>
    );
  }
  return (
    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
      {suppliers.map(s => (
        <div key={s.id} className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="text-sm font-bold text-gray-900 truncate">{s.name}</p>
              {!s.active && <span className="text-[10px] font-semibold text-gray-400">Inactif</span>}
            </div>
            <button
              onClick={() => { if (confirm('Supprimer ce fournisseur ?')) onRemove(s.id); }}
              className="text-gray-300 hover:text-red-500 transition shrink-0"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
          <div className="mt-2 space-y-1 text-xs text-gray-500">
            {s.phone && <p className="flex items-center gap-1.5"><Phone className="h-3 w-3" />{s.phone}</p>}
            {s.email && <p className="flex items-center gap-1.5"><Mail className="h-3 w-3" />{s.email}</p>}
            {s.address && <p className="flex items-center gap-1.5"><MapPin className="h-3 w-3" />{s.address}</p>}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Supplier form modal ────────────────────────────────────────
function SupplierForm({ onClose, onSave }: {
  onClose: () => void;
  onSave: (input: { name: string; phone: string; email: string; address: string; active: boolean }) => Promise<void>;
}) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!name.trim()) return;
    setSaving(true);
    try { await onSave({ name: name.trim(), phone, email, address, active: true }); }
    catch (e) { alert(e instanceof Error ? translateError(e.message) : 'Erreur'); }
    finally { setSaving(false); }
  }

  return (
    <Modal onClose={onClose} title="Nouveau fournisseur">
      <div className="space-y-3">
        <Field label="Nom *">
          <input value={name} onChange={e => setName(e.target.value)} className="input" placeholder="Nom du fournisseur" />
        </Field>
        <Field label="Téléphone">
          <input value={phone} onChange={e => setPhone(e.target.value)} className="input" placeholder="+225 ..." />
        </Field>
        <Field label="Email">
          <input value={email} onChange={e => setEmail(e.target.value)} className="input" placeholder="contact@fournisseur.com" />
        </Field>
        <Field label="Adresse">
          <textarea value={address} onChange={e => setAddress(e.target.value)} className="input" rows={2} placeholder="Adresse" />
        </Field>
        <div className="flex justify-end gap-2 pt-2">
          <button onClick={onClose} className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-600 hover:bg-gray-100">Annuler</button>
          <button onClick={submit} disabled={saving || !name.trim()} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ── Delivery note form modal ───────────────────────────────────
function NoteForm({ suppliers, locations, defaultLocationId, currency, existingCount, onClose, onSave }: {
  suppliers: Supplier[];
  locations: SalesLocation[];
  defaultLocationId: string | null;
  currency: string;
  existingCount: number;
  onClose: () => void;
  onSave: (input: {
    note_number: string; supplier_id: string; location_id: string | null;
    note_date: string; notes: string;
    items: { product_id: string; location_id: string | null; quantity: number; unit_cost: number }[];
  }) => Promise<void>;
}) {
  const today = new Date().toISOString().slice(0, 10);
  const defaultNumber = `BL-${new Date().getFullYear()}-${String(existingCount + 1).padStart(4, '0')}`;
  const [noteNumber, setNoteNumber] = useState(defaultNumber);
  const [supplierId, setSupplierId] = useState(suppliers[0]?.id ?? '');
  const [locId, setLocId] = useState<string>(defaultLocationId ?? locations[0]?.id ?? '');
  const [noteDate, setNoteDate] = useState(today);
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<{ product_id: string; quantity: string; unit_cost: string }[]>([]);
  const [comboOpen, setComboOpen] = useState(false);
  const [comboQuery, setComboQuery] = useState('');
  const [saving, setSaving] = useState(false);
  const comboRef = useRef<HTMLDivElement>(null);

  const [locationProducts, setLocationProducts] = useState<Product[]>([]);
  const [productsLoading, setProductsLoading] = useState(false);

  useEffect(() => {
    if (!locId) { setLocationProducts([]); return; }
    let cancelled = false;
    setProductsLoading(true);
    (async () => {
      const lsMap = new Map<string, { stock_quantity: number; stock_min: number; price: number | null }>();
      let from = 0;
      while (true) {
        const res = await supabase.from('location_stock')
          .select('product_id, stock_quantity, stock_min, price')
          .eq('location_id', locId)
          .range(from, from + 999);
        if (res.error) break;
        for (const r of (res.data ?? []) as Record<string, unknown>[]) {
          lsMap.set(r.product_id as string, {
            stock_quantity: Number(r.stock_quantity),
            stock_min: Number(r.stock_min),
            price: r.price != null ? Number(r.price) : null,
          });
        }
        if ((res.data ?? []).length < 1000) break;
        from += 1000;
      }
      const ids = [...lsMap.keys()];
      const loaded: Product[] = [];
      for (let i = 0; i < ids.length; i += 200) {
        const { data } = await supabase.from('products').select('*').in('id', ids.slice(i, i + 200));
        if (data) loaded.push(...(data as Product[]));
      }
      if (cancelled) return;
      const merged = loaded
        .filter(p => p.active !== false)
        .map(p => {
          const ls = lsMap.get(p.id);
          return ls ? { ...p, stock_quantity: ls.stock_quantity, stock_min: ls.stock_min, price: ls.price != null && ls.price > 0 ? ls.price : p.price } : p;
        })
        .sort((a, b) => a.name.localeCompare(b.name));
      setLocationProducts(merged);
      setProductsLoading(false);
    })();
    return () => { cancelled = true; };
  }, [locId]);

  const fullCatalog = locationProducts;

  const filteredProducts = useMemo(() => {
    const q = comboQuery.toLowerCase().trim();
    return q ? locationProducts.filter(p => p.name.toLowerCase().includes(q) || (p.reference ?? '').toLowerCase().includes(q)) : locationProducts;
  }, [locationProducts, comboQuery]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (comboRef.current && !comboRef.current.contains(e.target as Node)) setComboOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function addProduct(p: Product) {
    setItems(prev => [...prev, { product_id: p.id, quantity: '1', unit_cost: String(p.purchase_price ?? p.price ?? 0) }]);
    setComboQuery('');
    setComboOpen(false);
  }

  function updateItem(idx: number, patch: Partial<{ quantity: string; unit_cost: string }>) {
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, ...patch } : it));
  }
  function removeItem(idx: number) {
    setItems(prev => prev.filter((_, i) => i !== idx));
  }

  const total = items.reduce((s, it) => s + (parseFloat(it.quantity) || 0) * (parseFloat(it.unit_cost) || 0), 0);

  async function submit() {
    if (!supplierId) { alert('Sélectionnez un fournisseur'); return; }
    if (!locId) { alert('Sélectionnez un point de vente'); return; }
    if (items.length === 0) { alert('Ajoutez au moins un article'); return; }
    setSaving(true);
    try {
      await onSave({
        note_number: noteNumber.trim() || defaultNumber,
        supplier_id: supplierId,
        location_id: locId || null,
        note_date: noteDate,
        notes,
        items: items.map(it => ({
          product_id: it.product_id,
          location_id: locId || null,
          quantity: parseFloat(it.quantity) || 0,
          unit_cost: parseFloat(it.unit_cost) || 0,
        })),
      });
    } catch (e) {
      alert(e instanceof Error ? translateError(e.message) : 'Erreur');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal onClose={onClose} title="Nouveau bon de livraison" wide>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="N° du bon">
            <input value={noteNumber} onChange={e => setNoteNumber(e.target.value)} className="input" />
          </Field>
          <Field label="Fournisseur *">
            <select value={supplierId} onChange={e => setSupplierId(e.target.value)} className="input">
              <option value="">— Choisir —</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </Field>
          <Field label="Point de vente *">
            <select value={locId} onChange={e => setLocId(e.target.value)} className="input">
              <option value="">— Choisir —</option>
              {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
            </select>
          </Field>
          <Field label="Date">
            <input type="date" value={noteDate} onChange={e => setNoteDate(e.target.value)} className="input" />
          </Field>
        </div>

        {/* Product picker — searchable combobox filtered by point de vente */}
        <div>
          <div className="relative" ref={comboRef}>
            <button
              type="button"
              onClick={() => { setComboOpen(o => !o); setComboQuery(''); }}
              disabled={!locId}
              className="flex w-full items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 py-2.5 pl-3 pr-3 text-sm outline-none transition hover:border-gray-300 focus:border-blue-500 focus:bg-white disabled:opacity-50"
            >
              <Search className="h-4 w-4 shrink-0 text-gray-400" />
              <span className={`flex-1 text-left ${comboQuery ? 'text-gray-700' : 'text-gray-400'}`}>
                {locId ? 'Rechercher et ajouter un article…' : 'Sélectionnez d\'abord un point de vente'}
              </span>
              <ChevronDown className={`h-4 w-4 shrink-0 text-gray-400 transition ${comboOpen ? 'rotate-180' : ''}`} />
            </button>
            {comboOpen && locId && (
              <div className="absolute z-20 mt-1 w-full rounded-lg border border-gray-200 bg-white shadow-lg">
                <div className="border-b border-gray-100 p-2">
                  <input
                    autoFocus
                    value={comboQuery}
                    onChange={e => setComboQuery(e.target.value)}
                    placeholder="Tapez pour filtrer…"
                    className="w-full rounded-md border border-gray-200 bg-gray-50 px-3 py-1.5 text-sm outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
                <div className="max-h-56 overflow-y-auto">
                  {filteredProducts.length === 0 ? (
                    <p className="px-3 py-3 text-center text-xs text-gray-400">
                      {productsLoading ? 'Chargement des articles…' : locationProducts.length === 0 ? 'Aucun article actif trouvé' : 'Aucun résultat'}
                    </p>
                  ) : (
                    filteredProducts.map(p => (
                      <button
                        key={p.id}
                        onClick={() => addProduct(p)}
                        className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-blue-50 transition"
                      >
                        <Package className="h-4 w-4 shrink-0 text-gray-400" />
                        <span className="flex-1 text-gray-700">{p.name}</span>
                        <span className="text-xs text-gray-400">Stock {fmtQty(p.stock_quantity)} {p.unit}</span>
                      </button>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Items */}
        {items.length > 0 && (
          <div className="overflow-x-auto rounded-lg border border-gray-200">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-left text-[11px] uppercase tracking-wider text-gray-400">
                <tr>
                  <th className="px-3 py-2 font-semibold">Article</th>
                  <th className="px-3 py-2 text-right font-semibold">Qté</th>
                  <th className="px-3 py-2 text-right font-semibold">Coût unit.</th>
                  <th className="px-3 py-2 text-right font-semibold">Total</th>
                  <th className="px-3 py-2"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {items.map((it, idx) => {
                  const p = fullCatalog.find(pr => pr.id === it.product_id);
                  const lineTotal = (parseFloat(it.quantity) || 0) * (parseFloat(it.unit_cost) || 0);
                  return (
                    <tr key={idx}>
                      <td className="px-3 py-2 text-gray-700">{p?.name ?? it.product_id}</td>
                      <td className="px-3 py-2">
                        <input type="number" min="0" step="0.01" value={it.quantity} onChange={e => updateItem(idx, { quantity: e.target.value })} className="w-20 rounded border border-gray-200 px-2 py-1 text-right text-sm tabular-nums outline-none focus:border-blue-500" />
                      </td>
                      <td className="px-3 py-2">
                        <input type="number" min="0" step="0.01" value={it.unit_cost} onChange={e => updateItem(idx, { unit_cost: e.target.value })} className="w-24 rounded border border-gray-200 px-2 py-1 text-right text-sm tabular-nums outline-none focus:border-blue-500" />
                      </td>
                      <td className="px-3 py-2 text-right tabular-nums font-medium text-gray-900">{new Intl.NumberFormat('fr-FR').format(lineTotal)}</td>
                      <td className="px-3 py-2 text-right">
                        <button onClick={() => removeItem(idx)} className="text-gray-300 hover:text-red-500"><X className="h-4 w-4" /></button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t border-gray-200 bg-gray-50">
                  <td colSpan={3} className="px-3 py-2 text-right text-xs font-semibold uppercase text-gray-500">Total</td>
                  <td className="px-3 py-2 text-right tabular-nums font-bold text-gray-900">{new Intl.NumberFormat('fr-FR').format(total)} {currency}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}

        <Field label="Remarques">
          <textarea value={notes} onChange={e => setNotes(e.target.value)} className="input" rows={2} placeholder="Remarques (optionnel)" />
        </Field>

        <div className="flex justify-end gap-2 pt-1">
          <button onClick={onClose} className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-600 hover:bg-gray-100">Annuler</button>
          <button onClick={submit} disabled={saving || !supplierId || !locId || items.length === 0} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
            {saving ? 'Enregistrement…' : 'Enregistrer le bon'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ── Supplier payments list ─────────────────────────────────────
function SupplierPaymentsList({
  suppliers, deliveryNotes, currency, locationId, onRemove,
}: {
  suppliers: Supplier[];
  deliveryNotes: DeliveryNote[];
  currency: string;
  locationId: string | null;
  onRemove: (id: string) => Promise<void>;
}) {
  const [payments, setPayments] = useState<(SupplierPayment & { supplier_name: string })[]>([]);
  useEffect(() => {
    (async () => {
      let query = supabase.from('supplier_payments').select('*, supplier:suppliers(id, name)').order('payment_date', { ascending: false });
      if (locationId) query = query.or(`location_id.eq.${locationId},location_id.is.null`);
      const { data } = await query;
      setPayments((data ?? []).map((p: Record<string, unknown>) => ({
        ...p,
        supplier_name: (p.supplier as { name?: string } | null)?.name ?? '—',
      })) as (SupplierPayment & { supplier_name: string })[]);
    })();
  }, [locationId]);

  if (payments.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-gray-300 bg-white p-10 text-center">
        <Wallet className="mx-auto h-10 w-10 text-gray-300" />
        <p className="mt-3 text-sm font-medium text-gray-500">Aucun règlement fournisseur</p>
        <p className="text-xs text-gray-400">Enregistrez un règlement pour suivre vos paiements.</p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-100 bg-gray-50 text-left text-[11px] uppercase tracking-wider text-gray-400">
            <th className="px-4 py-3 font-semibold">Date</th>
            <th className="px-4 py-3 font-semibold">Fournisseur</th>
            <th className="px-4 py-3 font-semibold">Bon de livraison</th>
            <th className="px-4 py-3 font-semibold">Mode</th>
            <th className="px-4 py-3 text-right font-semibold">Montant</th>
            <th className="px-4 py-3"></th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {payments.map(p => (
            <tr key={p.id} className="hover:bg-gray-50 transition">
              <td className="px-4 py-3 text-gray-600">{new Date(p.payment_date).toLocaleDateString('fr-FR')}</td>
              <td className="px-4 py-3 font-medium text-gray-800">{p.supplier_name}</td>
              <td className="px-4 py-3 font-mono text-xs text-blue-600">
                {p.delivery_note_id
                  ? (deliveryNotes.find(n => n.id === p.delivery_note_id)?.note_number ?? '—')
                  : '—'}
              </td>
              <td className="px-4 py-3 text-gray-700">{p.method}</td>
              <td className="px-4 py-3 text-right tabular-nums font-semibold text-red-600">
                -{new Intl.NumberFormat('fr-FR').format(p.amount)} {currency}
              </td>
              <td className="px-4 py-2 text-right">
                <button
                  onClick={() => { if (confirm('Supprimer ce règlement ?')) onRemove(p.id); }}
                  className="text-gray-300 hover:text-red-500 transition"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Supplier payment form modal ────────────────────────────────
function SupplierPaymentForm({ suppliers, deliveryNotes, defaultLocationId, currency, onClose, onSave }: {
  suppliers: Supplier[];
  deliveryNotes: DeliveryNote[];
  defaultLocationId: string | null;
  currency: string;
  onClose: () => void;
  onSave: (input: {
    supplier_id: string; delivery_note_id: string | null; amount: number;
    method: PaymentMethod; payment_date: string; notes: string; location_id: string | null;
  }) => Promise<void>;
}) {
  const today = new Date().toISOString().slice(0, 10);
  const [supplierId, setSupplierId] = useState(suppliers[0]?.id ?? '');
  const [noteId, setNoteId] = useState('');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('especes');
  const [paymentDate, setPaymentDate] = useState(today);
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const supplierNotes = deliveryNotes.filter(n => n.supplier_id === supplierId && n.status === 'valide');

  async function submit() {
    if (!supplierId) { alert('Sélectionnez un fournisseur'); return; }
    if (!amount || parseFloat(amount) <= 0) { alert('Saisissez un montant'); return; }
    setSaving(true);
    try {
      await onSave({
        supplier_id: supplierId,
        delivery_note_id: noteId || null,
        amount: parseFloat(amount),
        method,
        payment_date: paymentDate,
        notes,
        location_id: defaultLocationId,
      });
    } catch (e) {
      alert(e instanceof Error ? translateError(e.message) : 'Erreur');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal onClose={onClose} title="Nouveau règlement fournisseur">
      <div className="space-y-3">
        <Field label="Fournisseur *">
          <select value={supplierId} onChange={e => { setSupplierId(e.target.value); setNoteId(''); }} className="input">
            <option value="">— Choisir —</option>
            {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
        <Field label="Bon de livraison (optionnel)">
          <select value={noteId} onChange={e => setNoteId(e.target.value)} className="input">
            <option value="">— Paiement libre —</option>
            {supplierNotes.map(n => (
              <option key={n.id} value={n.id}>{n.note_number} — {new Intl.NumberFormat('fr-FR').format(n.total_amount)} {currency}</option>
            ))}
          </select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Montant *">
            <input type="number" min="0" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} className="input" />
          </Field>
          <Field label="Mode de règlement">
            <select value={method} onChange={e => setMethod(e.target.value as PaymentMethod)} className="input">
              {ALL_PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </Field>
        </div>
        <Field label="Date">
          <input type="date" value={paymentDate} onChange={e => setPaymentDate(e.target.value)} className="input" />
        </Field>
        <Field label="Notes">
          <input value={notes} onChange={e => setNotes(e.target.value)} className="input" placeholder="Référence, remarque…" />
        </Field>
        <div className="flex justify-end gap-2 pt-2">
          <button onClick={onClose} className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-600 hover:bg-gray-100">Annuler</button>
          <button onClick={submit} disabled={saving || !supplierId || !amount} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ── Shared UI ──────────────────────────────────────────────────
function Modal({ children, onClose, title, wide }: { children: React.ReactNode; onClose: () => void; title: string; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className={`relative z-10 max-h-[90vh] overflow-y-auto rounded-2xl bg-white shadow-xl ${wide ? 'w-full max-w-2xl' : 'w-full max-w-md'}`}>
        <div className="sticky top-0 flex items-center justify-between border-b border-gray-100 bg-white px-5 py-3.5">
          <h2 className="text-base font-bold text-gray-900">{title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700"><X className="h-5 w-5" /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold text-gray-600">{label}</span>
      {children}
    </label>
  );
}
