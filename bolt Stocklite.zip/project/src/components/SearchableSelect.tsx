import { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Search, ChevronDown, Check } from 'lucide-react';

export interface SearchableOption {
  value: string;
  label: string;
  sublabel?: string;
}

interface SearchableSelectProps {
  options: SearchableOption[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  emptyOption?: string;
  className?: string;
  disabled?: boolean;
  size?: 'sm' | 'md';
}

export function SearchableSelect({
  options,
  value,
  onChange,
  placeholder = '— Sélectionner —',
  emptyOption,
  className = '',
  disabled = false,
  size = 'md',
}: SearchableSelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(-1);
  const [coords, setCoords] = useState({ top: 0, left: 0, width: 0 });
  const ref = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLButtonElement | null)[]>([]);

  const selected = options.find(o => o.value === value);

  const filtered = useMemo(() => {
    if (!query.trim()) return options;
    const q = query.toLowerCase();
    return options.filter(o =>
      o.label.toLowerCase().includes(q) ||
      o.sublabel?.toLowerCase().includes(q)
    );
  }, [options, query]);

  const updateCoords = useCallback(() => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    setCoords({
      top: rect.bottom + window.scrollY + 4,
      left: rect.left + window.scrollX,
      width: rect.width,
    });
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      const target = e.target as Node;
      if (
        ref.current && !ref.current.contains(target) &&
        dropdownRef.current && !dropdownRef.current.contains(target)
      ) {
        setOpen(false);
        setQuery('');
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (open && inputRef.current) {
      inputRef.current.focus();
      updateCoords();
    }
  }, [open, updateCoords]);

  useEffect(() => {
    if (!open) {
      setQuery('');
      setActiveIndex(-1);
    }
  }, [open]);

  useEffect(() => {
    setActiveIndex(-1);
  }, [query]);

  useEffect(() => {
    if (!open) return;
    const onScroll = () => updateCoords();
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('resize', onScroll);
    };
  }, [open, updateCoords]);

  const scrollActiveIntoView = useCallback(() => {
    requestAnimationFrame(() => {
      const el = itemRefs.current[activeIndex];
      if (el && listRef.current) {
        el.scrollIntoView({ block: 'nearest' });
      }
    });
  }, [activeIndex]);

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Escape') {
      setOpen(false);
      setQuery('');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!open) { setOpen(true); return; }
      setActiveIndex(i => Math.min(i + 1, filtered.length - 1));
      scrollActiveIntoView();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex(i => Math.max(i - 1, emptyOption ? -1 : 0));
      scrollActiveIntoView();
    } else if (e.key === 'Enter') {
      if (open && activeIndex >= 0 && activeIndex < filtered.length) {
        e.preventDefault();
        const opt = filtered[activeIndex];
        onChange(opt.value);
        setOpen(false);
        setQuery('');
      }
    }
  }

  function selectIndex(idx: number) {
    if (idx >= 0 && idx < filtered.length) {
      onChange(filtered[idx].value);
      setOpen(false);
      setQuery('');
    }
  }

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        type="button"
        disabled={disabled}
        onClick={() => { if (!open) updateCoords(); setOpen(o => !o); }}
        onKeyDown={handleKeyDown}
        className={`flex w-full items-center justify-between gap-2 rounded-lg border border-gray-300 bg-white px-3 outline-none transition focus:border-blue-500 disabled:opacity-50 ${size === 'sm' ? 'py-1.5 text-xs' : 'py-2.5 text-sm'}`}
      >
        <span className={selected ? 'truncate' : 'text-gray-400'}>
          {selected ? selected.label : placeholder}
        </span>
        <ChevronDown className={`h-4 w-4 flex-shrink-0 text-gray-400 transition ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && createPortal(
        <div
          ref={dropdownRef}
          className="fixed z-[9999] overflow-hidden rounded-lg border border-gray-200 bg-white shadow-xl"
          style={{ top: coords.top, left: coords.left, width: coords.width }}
        >
          <div className="flex items-center gap-2 border-b border-gray-100 px-3 py-2">
            <Search className="h-4 w-4 flex-shrink-0 text-gray-400" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Rechercher…"
              className={`w-full text-gray-800 outline-none placeholder-gray-400 ${size === 'sm' ? 'text-xs' : 'text-sm'}`}
            />
          </div>
          <div ref={listRef} className="max-h-72 overflow-y-auto overscroll-contain scroll-smooth">
            {emptyOption && (
              <button
                type="button"
                onMouseEnter={() => setActiveIndex(-1)}
                onClick={() => { onChange(''); setOpen(false); setQuery(''); }}
                className={`flex w-full items-center justify-between px-3 py-2.5 text-sm transition hover:bg-gray-50 ${!value ? 'font-medium text-blue-600' : 'text-gray-500'}`}
              >
                {emptyOption}
                {!value && <Check className="h-4 w-4" />}
              </button>
            )}
            {filtered.length === 0 && (emptyOption || !query.trim()) && (
              <div className="px-3 py-3 text-sm text-gray-400">Aucun résultat</div>
            )}
            {filtered.map((opt, idx) => (
              <button
                key={opt.value}
                ref={el => { itemRefs.current[idx] = el; }}
                type="button"
                onMouseEnter={() => setActiveIndex(idx)}
                onClick={() => selectIndex(idx)}
                className={`flex w-full items-center justify-between gap-2 px-3 py-2 text-sm transition ${opt.value === value ? 'font-medium text-blue-600 bg-blue-50/40' : 'text-gray-700'} ${activeIndex === idx ? 'bg-gray-100' : 'hover:bg-gray-50'}`}
              >
                <span className="truncate text-left">
                  {opt.label}
                  {opt.sublabel && (
                    <span className="ml-1.5 text-xs text-gray-400">{opt.sublabel}</span>
                  )}
                </span>
                {opt.value === value && <Check className="h-4 w-4 flex-shrink-0" />}
              </button>
            ))}
            {filtered.length === 0 && query.trim() && (
              <div className="px-3 py-3 text-sm text-gray-400">Aucun résultat pour « {query} »</div>
            )}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
