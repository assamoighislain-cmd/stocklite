import { useState, useRef, useEffect, useMemo } from 'react';
import { PackageOpen, Plus, MapPin, AlertTriangle, ArrowDown, Search, Check, X } from 'lucide-react';
import type { Product, SalesLocation, Deconditioning } from '../types';
import type { CreateDeconditioningInput } from '../hooks/useDeconditioning';
import { fmtQty } from '../lib/format';
import { translateError } from '../lib/translateError';

interface Props {
  products: Product[];
  locations: SalesLocation[];
  deconditionings: Deconditioning[];
  loading: boolean;
  onExecute: (input: CreateDeconditioningInput) => Promise<void>;
  activeLocationId?: string | null;
}

function fmtDate(d: string) {
  return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(d));
}

function SearchableProductSelect({ products, value, onChange, placeholder }: {
  products: Product[];
  value: string;
  onChange: (id: string) => void;
  placeholder: string;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = products.find(p => p.id === value);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products;
    return products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      (p.reference ?? '').toLowerCase().includes(q)
    );
  }, [products, query]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  useEffect(() => {
    if (open) { setQuery(''); setTimeout(() => inputRef.current?.focus(), 50); }
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="flex w-full items-center justify-between gap-2 rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
      >
        <span className={`truncate ${selected ? 'text-gray-800' : 'text-gray-400'}`}>
          {selected ? `${selected.name} (${selected.unit}) — Stock: ${fmtQty(selected.stock_quantity)}` : placeholder}
        </span>
        {selected ? (
          <span className="flex items-center gap-1 shrink-0">
            <Check className="h-3.5 w-3.5 text-blue-500" />
            <X
              className="h-3.5 w-3.5 text-gray-400 hover:text-red-500"
              onClick={(e) => { e.stopPropagation(); onChange(''); }}
            />
          </span>
        ) : (
          <Search className="h-3.5 w-3.5 text-gray-400 shrink-0" />
        )}
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-lg border border-gray-200 bg-white shadow-xl">
          <div className="flex items-center gap-2 border-b border-gray-100 px-3 py-2">
            <Search className="h-3.5 w-3.5 text-gray-400 shrink-0" />
            <input
              ref={inputRef}
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Tapez le nom de l'article…"
              className="flex-1 text-sm text-gray-800 outline-none placeholder:text-gray-400"
            />
            {query && (
              <button type="button" onClick={() => setQuery('')} className="text-gray-400 hover:text-gray-600">
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <div className="max-h-56 overflow-y-auto">
            {filtered.length === 0 ? (
              <p className="px-3 py-4 text-center text-xs text-gray-400">Aucun article trouvé</p>
            ) : (
              filtered.map(p => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => { onChange(p.id); setOpen(false); }}
                  className={`flex w-full items-center justify-between px-3 py-2 text-sm transition hover:bg-blue-50 ${
                    p.id === value ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                  }`}
                >
                  <span className="truncate">{p.name}</span>
                  <span className="flex items-center gap-2 shrink-0">
                    <span className="text-[11px] text-gray-400">{p.unit}</span>
                    {p.id === value && <Check className="h-3.5 w-3.5 text-blue-500" />}
                  </span>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function DeconditioningPage({ products, locations, deconditionings, loading, onExecute, activeLocationId }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    pack_product_id: '',
    detail_product_id: '',
    pack_quantity: '',
    units_per_pack: '',
    notes: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const trackedProducts = products.filter(p => p.active && p.track_stock);
  const activeLocations = locations.filter(l => l.active);

  const selectedPack = trackedProducts.find(p => p.id === form.pack_product_id);
  const selectedDetail = trackedProducts.find(p => p.id === form.detail_product_id);

  const packQtyNum = parseFloat(form.pack_quantity) || 0;
  const unitsPerPackNum = parseFloat(form.units_per_pack) || 0;
  const totalUnits = packQtyNum * unitsPerPackNum;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!form.pack_product_id || !form.detail_product_id) {
      setError('Veuillez sélectionner les deux articles.');
      return;
    }
    if (form.pack_product_id === form.detail_product_id) {
      setError('Le carton et le détail doivent être deux articles différents.');
      return;
    }
    if (!packQtyNum || packQtyNum <= 0) {
      setError('La quantité de cartons doit être supérieure à 0.');
      return;
    }
    if (!unitsPerPackNum || unitsPerPackNum <= 0) {
      setError('Le nombre d\'unités par carton doit être supérieur à 0.');
      return;
    }
    setSubmitting(true);
    try {
      await onExecute({
        pack_product_id: form.pack_product_id,
        detail_product_id: form.detail_product_id,
        pack_quantity: packQtyNum,
        units_per_pack: unitsPerPackNum,
        location_id: activeLocationId ?? null,
        notes: form.notes,
      });
      setShowForm(false);
      setForm({ pack_product_id: '', detail_product_id: '', pack_quantity: '', units_per_pack: '', notes: '' });
    } catch (err) {
      setError(err instanceof Error ? translateError(err.message) : 'Erreur lors du déconditionnement');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Déconditionnement</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Cassez vos cartons et packs pour vendre au détail — le stock du carton diminue, le stock du détail augmente.
          </p>
        </div>
        <button
          onClick={() => { setShowForm(true); setError(null); }}
          className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95"
        >
          <Plus className="h-4 w-4" />
          Nouveau déconditionnement
        </button>
      </div>

      {/* History */}
      {loading ? (
        <div className="space-y-2">
          {[...Array(4)].map((_, i) => <div key={i} className="h-16 rounded-xl bg-gray-100 animate-pulse" />)}
        </div>
      ) : deconditionings.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-300 py-16 text-center">
          <PackageOpen className="h-10 w-10 text-gray-300 mb-3" />
          <p className="text-sm font-medium text-gray-400">Aucun déconditionnement</p>
          <p className="text-xs text-gray-400 mt-1">Les opérations de casse de cartons apparaîtront ici.</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white divide-y divide-gray-100">
          {deconditionings.map(d => (
            <div key={d.id} className="px-5 py-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="h-9 w-9 rounded-lg bg-amber-50 flex items-center justify-center shrink-0">
                    <PackageOpen className="h-4 w-4 text-amber-600" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-gray-900">
                      {fmtQty(d.pack_quantity)} {d.pack_product?.unit ?? 'pack'} → {fmtQty(d.detail_quantity)} {d.detail_product?.unit ?? 'unité'}
                    </p>
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mt-0.5 flex-wrap">
                      <span className="font-medium text-gray-700">{d.pack_product?.name ?? '—'}</span>
                      <ArrowDown className="h-3 w-3 text-amber-500" />
                      <span className="font-medium text-gray-700">{d.detail_product?.name ?? '—'}</span>
                      {d.location && (
                        <>
                          <span className="text-gray-300">·</span>
                          <MapPin className="h-3 w-3" />
                          <span>{d.location.name}</span>
                        </>
                      )}
                    </div>
                    {d.notes && <p className="text-xs text-gray-400 mt-0.5">{d.notes}</p>}
                  </div>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-xs text-gray-400">{fmtDate(d.created_at)}</p>
                  <p className="text-[10px] text-gray-400 mt-0.5">{fmtQty(d.units_per_pack)} unités/pack</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white shadow-2xl overflow-hidden">
            <div className="border-b border-gray-100 px-6 py-4">
              <div className="flex items-center gap-2">
                <PackageOpen className="h-4 w-4 text-amber-600" />
                <h2 className="text-base font-semibold text-gray-900">Déconditionner un article</h2>
              </div>
            </div>
            <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
              {error && (
                <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3 py-2.5">
                  <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-red-700">{error}</p>
                </div>
              )}

              {/* Pack product */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Article carton / pack *</label>
                <SearchableProductSelect
                  products={trackedProducts}
                  value={form.pack_product_id}
                  onChange={id => setForm(f => ({ ...f, pack_product_id: id }))}
                  placeholder="Rechercher le carton…"
                />
                {selectedPack && (
                  <p className="mt-1 text-[11px] text-gray-400">Stock actuel: {fmtQty(selectedPack.stock_quantity)} {selectedPack.unit}</p>
                )}
              </div>

              {/* Detail product */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Article détail / unité *</label>
                <SearchableProductSelect
                  products={trackedProducts.filter(p => p.id !== form.pack_product_id)}
                  value={form.detail_product_id}
                  onChange={id => setForm(f => ({ ...f, detail_product_id: id }))}
                  placeholder="Rechercher le détail…"
                />
                {selectedDetail && (
                  <p className="mt-1 text-[11px] text-gray-400">Stock actuel: {fmtQty(selectedDetail.stock_quantity)} {selectedDetail.unit}</p>
                )}
              </div>

              {/* Visual flow */}
              {selectedPack && selectedDetail && (
                <div className="flex items-center justify-center gap-3 rounded-lg bg-amber-50 border border-amber-200 py-2.5 text-xs">
                  <span className="font-semibold text-gray-700">{selectedPack.name}</span>
                  <ArrowDown className="h-4 w-4 text-amber-500" />
                  <span className="font-semibold text-gray-700">{selectedDetail.name}</span>
                </div>
              )}

              {/* Quantity + units per pack */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">
                    Nombre de cartons *
                    {selectedPack && <span className="ml-1 text-gray-400">({selectedPack.unit})</span>}
                  </label>
                  <input
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={form.pack_quantity}
                    onChange={e => setForm(f => ({ ...f, pack_quantity: e.target.value }))}
                    required
                    className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Unités par carton *</label>
                  <input
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={form.units_per_pack}
                    onChange={e => setForm(f => ({ ...f, units_per_pack: e.target.value }))}
                    required
                    className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                    placeholder="ex: 12"
                  />
                </div>
              </div>

              {/* Result preview */}
              {totalUnits > 0 && (
                <div className="flex items-center justify-between rounded-lg bg-blue-50 border border-blue-200 px-3 py-2.5 text-xs">
                  <span className="text-blue-700">Résultat:</span>
                  <span className="font-semibold text-blue-800">
                    -{fmtQty(packQtyNum)} {selectedPack?.unit ?? ''} · +{fmtQty(totalUnits)} {selectedDetail?.unit ?? ''}
                  </span>
                </div>
              )}

              {/* Notes */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
                <input
                  value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                  placeholder="Commentaire (optionnel)…"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => { setShowForm(false); setError(null); }}
                  className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-amber-600 py-2.5 text-sm font-semibold text-white hover:bg-amber-500 transition disabled:opacity-50"
                >
                  <PackageOpen className="h-4 w-4" />
                  {submitting ? 'En cours…' : 'Déconditionner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
