import { useMemo } from 'react';
import { TrendingUp, AlertCircle, Users, Clock, ArrowRight, PlusCircle, ShoppingCart, AlertTriangle } from 'lucide-react';
import type { Invoice, Customer, Product, PosSale } from '../types';
import type { Route } from '../App';
import { StatusBadge } from './StatusBadge';
import { fmtQty } from '../lib/format';

interface DashboardProps {
  invoices: Invoice[];
  customers: Customer[];
  products: Product[];
  posSales: PosSale[];
  currency: string;
  onNavigate: (r: Route) => void;
}

function fmt(n: number, currency: string) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}

function KpiCard({ label, value, sub, icon: Icon, color }: {
  label: string; value: string; sub?: string; icon: React.ElementType; color: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-card transition hover:shadow-card-lg lg:p-6">
      <div className="mb-2 flex items-center justify-between lg:mb-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 lg:text-xs">{label}</p>
        <div className={`flex h-8 w-8 items-center justify-center rounded-xl lg:h-10 lg:w-10 ${color}`}>
          <Icon className="h-4 w-4 lg:h-5 lg:w-5" />
        </div>
      </div>
      <p className="text-xl font-extrabold tracking-tight text-slate-900 lg:text-3xl">{value}</p>
      {sub && <p className="mt-1 text-[10px] font-medium text-slate-400 lg:mt-1.5 lg:text-xs">{sub}</p>}
    </div>
  );
}

export function Dashboard({ invoices, customers, products, posSales, currency, onNavigate }: DashboardProps) {
  const stats = useMemo(() => {
    const caFacture = invoices
      .filter(i => i.status === 'payee' || i.status === 'partielle')
      .reduce((s, i) => s + i.amount_paid, 0);
    const encours = invoices
      .filter(i => i.status !== 'payee' && i.status !== 'annulee')
      .reduce((s, i) => s + i.balance_due, 0);
    const enRetard = invoices.filter(i => {
      if (i.status === 'payee' || i.status === 'annulee') return false;
      return i.due_date && new Date(i.due_date) < new Date();
    }).length;

    // Today's POS
    const today = new Date().toISOString().split('T')[0];
    const todaySales = posSales.filter(s => s.created_at?.startsWith(today));
    const todayRevenue = todaySales.reduce((s, p) => s + p.total, 0);

    // Low stock
    const lowStock = products.filter(p => p.track_stock && p.active && p.stock_quantity <= p.stock_min);

    return { caFacture, encours, enRetard, todayRevenue, todaySales: todaySales.length, lowStock };
  }, [invoices, products, posSales]);

  const recent = invoices.slice(0, 6);
  const recentPos = posSales.slice(0, 5);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-lg font-extrabold tracking-tight text-slate-900 lg:text-2xl">Tableau de bord</h1>
        <p className="text-xs font-semibold text-slate-400 lg:text-sm">Vue d'ensemble de votre activité</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
        <KpiCard label="CA facturé" value={fmt(stats.caFacture, currency)} sub="encaissements factures" icon={TrendingUp} color="bg-blue-500/15 text-blue-600" />
        <KpiCard label="Ventes caisse" value={fmt(stats.todayRevenue, currency)} sub={`${stats.todaySales} ticket(s) aujourd'hui`} icon={ShoppingCart} color="bg-emerald-500/15 text-emerald-600" />
        <KpiCard label="Encours" value={fmt(stats.encours, currency)} sub="à encaisser (factures)" icon={Clock} color="bg-amber-500/15 text-amber-600" />
        <KpiCard label="Clients" value={String(customers.length)} sub="enregistrés" icon={Users} color="bg-slate-200 text-slate-600" />
      </div>

      {/* Stock alerts */}
      {stats.lowStock.length > 0 && (
        <div className="rounded-2xl border border-amber-300 bg-amber-50 p-4 shadow-card lg:p-5">
          <div className="mb-2 flex items-center justify-between lg:mb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-600 lg:h-5 lg:w-5" />
              <span className="text-xs font-bold text-amber-900 lg:text-sm">
                {stats.lowStock.length} article{stats.lowStock.length > 1 ? 's' : ''} en stock bas / rupture
              </span>
            </div>
            <button onClick={() => onNavigate({ page: 'stock' })} className="text-[10px] text-amber-700 hover:text-amber-900 flex items-center gap-1 font-bold lg:text-xs">
              Gérer <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {stats.lowStock.slice(0, 6).map(p => (
              <span key={p.id} className={`rounded-full px-2.5 py-0.5 text-[10px] font-semibold lg:px-3 lg:py-1 lg:text-xs ${p.stock_quantity <= 0 ? 'bg-red-100 text-red-700 ring-1 ring-red-300' : 'bg-amber-100 text-amber-700 ring-1 ring-amber-300'}`}>
                {p.name} — {fmtQty(p.stock_quantity)} {p.unit}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Recent invoices */}
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-700 lg:text-base">Factures récentes</h2>
            <button onClick={() => onNavigate({ page: 'invoices' })} className="flex items-center gap-1 text-[10px] font-bold text-blue-600 hover:text-blue-700 lg:text-xs">
              Tout voir <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          {recent.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 py-12 text-center">
              <p className="mb-4 text-xs text-slate-400 lg:text-sm">Aucune facture.</p>
              <button onClick={() => onNavigate({ page: 'invoice-form' })} className="flex items-center gap-2 rounded-xl bg-blue-600 px-3 py-2 text-xs font-bold text-white hover:bg-blue-500 lg:px-4 lg:py-2.5 lg:text-sm">
                <PlusCircle className="h-4 w-4" /> Créer une facture
              </button>
            </div>
          ) : (
            <div className="overflow-hidden rounded-2xl border border-slate-200 shadow-card">
              <table className="w-full text-xs lg:text-sm">
                <tbody className="divide-y divide-slate-100">
                  {recent.map(inv => (
                    <tr key={inv.id} className="cursor-pointer bg-white hover:bg-slate-50" onClick={() => onNavigate({ page: 'invoice-detail', id: inv.id })}>
                      <td className="px-3 py-2.5 pl-4 font-mono text-[10px] font-bold text-blue-600 lg:px-4 lg:py-3.5 lg:pl-5 lg:text-xs">{inv.invoice_number}</td>
                      <td className="px-3 py-2.5 text-slate-700 truncate max-w-[80px] font-medium lg:px-4 lg:py-3.5 lg:max-w-[100px]">{inv.customer?.name ?? '—'}</td>
                      <td className="px-3 py-2.5 tabular-nums font-bold text-slate-900 lg:px-4 lg:py-3.5">{fmt(inv.total, currency)}</td>
                      <td className="px-3 py-2.5 pr-3 lg:px-4 lg:py-3.5 lg:pr-4"><StatusBadge status={inv.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Recent POS */}
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-700 lg:text-base">Dernières ventes (caisse)</h2>
            <button onClick={() => onNavigate({ page: 'pos' })} className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 hover:text-emerald-700 lg:text-xs">
              Ouvrir <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          {recentPos.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 py-12 text-center">
              <p className="mb-4 text-xs text-slate-400 lg:text-sm">Aucune vente en caisse.</p>
              <button onClick={() => onNavigate({ page: 'pos' })} className="flex items-center gap-2 rounded-xl bg-emerald-700 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-600 lg:px-4 lg:py-2.5 lg:text-sm">
                <ShoppingCart className="h-4 w-4" /> Ouvrir la caisse
              </button>
            </div>
          ) : (
            <div className="overflow-hidden rounded-2xl border border-slate-200 shadow-card">
              <table className="w-full text-xs lg:text-sm">
                <tbody className="divide-y divide-slate-100">
                  {recentPos.map(sale => (
                    <tr key={sale.id} className="bg-white hover:bg-slate-50">
                      <td className="px-3 py-2.5 pl-4 font-mono text-[10px] font-bold text-emerald-600 lg:px-4 lg:py-3.5 lg:pl-5 lg:text-xs">{sale.sale_number}</td>
                      <td className="px-3 py-2.5 text-slate-500 text-[10px] lg:px-4 lg:py-3.5 lg:text-xs">
                        {new Date(sale.created_at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}
                      </td>
                      <td className="px-3 py-2.5 text-slate-700 font-medium lg:px-4 lg:py-3.5">{sale.customer?.name ?? 'Comptant'}</td>
                      <td className="px-3 py-2.5 pr-3 tabular-nums font-bold text-slate-900 lg:px-4 lg:py-3.5 lg:pr-4">{fmt(sale.total, currency)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {stats.enRetard > 0 && (
        <div className="flex items-center gap-3 rounded-2xl border border-red-300 bg-red-50 px-4 py-3 shadow-card lg:px-5 lg:py-4">
          <AlertCircle className="h-4 w-4 text-red-500 shrink-0 lg:h-5 lg:w-5" />
          <p className="text-xs text-red-700 lg:text-sm">
            <span className="font-bold">{stats.enRetard} facture{stats.enRetard > 1 ? 's' : ''}</span> dépassent leur date d'échéance.
          </p>
          <button onClick={() => onNavigate({ page: 'invoices' })} className="ml-auto text-[10px] font-bold text-red-600 hover:text-red-800 flex items-center gap-1 shrink-0 lg:text-xs">
            Voir <ArrowRight className="h-3 w-3" />
          </button>
        </div>
      )}
    </div>
  );
}
