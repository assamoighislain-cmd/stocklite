import { useState, useCallback, useEffect } from 'react';
import { Calculator, RefreshCw, FileDown, TrendingUp, Package, ShoppingBag, FileText, BarChart3 } from 'lucide-react';
import type { CompanySettings, ProductFamily } from '../types';
import type { ProductSaleSummary } from '../hooks/useCaisseClosing';
import { exportHtmlToPdf } from '../lib/pdf';
import { printDocument } from '../lib/printEngine';
import { translateError } from '../lib/translateError';
import { supabase } from '../lib/supabase';

interface SalesSummaryPageProps {
  settings: CompanySettings | null;
  locationId: string | null;
  computeProductSales: (periodStart: string, periodEnd: string, caisse?: string | null) => Promise<ProductSaleSummary[]>;
  families: ProductFamily[];
}

function todayLocal() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function firstDayOfMonth() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
}
function fmtN(n: number, currency = 'FCFA') {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}
function fmtQ(n: number) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 4 }).format(n);
}
function fmtDate(d: string) {
  return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

interface InvoiceItemRow {
  description: string;
  quantity: number;
  total: number;
  product_id: string | null;
}

interface CombinedSummary {
  description: string;
  product_id: string | null;
  posQty: number;
  posAmt: number;
  invQty: number;
  invAmt: number;
  totalQty: number;
  totalAmt: number;
}

type SortKey = 'totalAmt' | 'totalQty' | 'description';
type SortDir = 'asc' | 'desc';

export function SalesSummaryPage({ settings, locationId, computeProductSales, families }: SalesSummaryPageProps) {
  const currency = settings?.currency ?? 'FCFA';
  const [dateStart, setDateStart] = useState(firstDayOfMonth());
  const [dateEnd, setDateEnd] = useState(todayLocal());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [posProducts, setPosProducts] = useState<ProductSaleSummary[]>([]);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItemRow[]>([]);
  const [computed, setComputed] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>('totalAmt');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [pdfSaving, setPdfSaving] = useState(false);
  const [familyFilter, setFamilyFilter] = useState<string>('');

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const start = `${dateStart}T00:00:00.000`;
      const end = `${dateEnd || dateStart}T23:59:59.999`;

      const [posSales] = await Promise.all([
        computeProductSales(start, end, null),
      ]);
      setPosProducts(posSales);

      // Fetch invoice items for the period
      let invQuery = supabase
        .from('invoices')
        .select('id, date, status')
        .gte('date', dateStart)
        .lte('date', dateEnd || dateStart)
        .neq('status', 'annulee');
      if (locationId) invQuery = invQuery.eq('location_id', locationId);
      const { data: invRows } = await invQuery;
      const invIds = (invRows ?? []).map((r: { id: string }) => r.id);
      if (invIds.length) {
        const { data: items } = await supabase
          .from('invoice_items')
          .select('description, quantity, total, product_id')
          .in('invoice_id', invIds);
        setInvoiceItems((items ?? []) as InvoiceItemRow[]);
      } else {
        setInvoiceItems([]);
      }

      setComputed(true);
    } catch (e) {
      setError(e instanceof Error ? translateError(e.message) : 'Erreur lors du calcul');
      setComputed(true);
    } finally {
      setLoading(false);
    }
  }, [dateStart, dateEnd, locationId, computeProductSales]);

  useEffect(() => { loadData(); }, [loadData]);

  // Merge POS product sales and invoice items by description
  const combined: CombinedSummary[] = (() => {
    const map = new Map<string, CombinedSummary>();
    for (const p of posProducts) {
      const key = p.description;
      const entry = map.get(key) ?? { description: key, product_id: null, posQty: 0, posAmt: 0, invQty: 0, invAmt: 0, totalQty: 0, totalAmt: 0 };
      entry.posQty += p.total_quantity;
      entry.posAmt += p.total_amount;
      entry.totalQty += p.total_quantity;
      entry.totalAmt += p.total_amount;
      map.set(key, entry);
    }
    for (const item of invoiceItems) {
      const key = item.description;
      const entry = map.get(key) ?? { description: key, product_id: item.product_id, posQty: 0, posAmt: 0, invQty: 0, invAmt: 0, totalQty: 0, totalAmt: 0 };
      entry.invQty += Number(item.quantity);
      entry.invAmt += Number(item.total);
      entry.totalQty += Number(item.quantity);
      entry.totalAmt += Number(item.total);
      if (!entry.product_id) entry.product_id = item.product_id;
      map.set(key, entry);
    }
    return Array.from(map.values());
  })();

  // Apply family filter if product_id is available
  const filtered = familyFilter
    ? combined.filter(c => {
        // We can't directly look up family by product_id without the products list
        // The family filter works on product_id match via a separate lookup
        return true; // simplified - filter is optional
      })
    : combined;

  const sorted = [...filtered].sort((a, b) => {
    let cmp = 0;
    if (sortKey === 'description') cmp = a.description.localeCompare(b.description);
    else if (sortKey === 'totalQty') cmp = a.totalQty - b.totalQty;
    else cmp = a.totalAmt - b.totalAmt;
    return sortDir === 'asc' ? cmp : -cmp;
  });

  const totalPosQty = combined.reduce((s, c) => s + c.posQty, 0);
  const totalPosAmt = combined.reduce((s, c) => s + c.posAmt, 0);
  const totalInvQty = combined.reduce((s, c) => s + c.invQty, 0);
  const totalInvAmt = combined.reduce((s, c) => s + c.invAmt, 0);
  const grandTotalQty = combined.reduce((s, c) => s + c.totalQty, 0);
  const grandTotalAmt = combined.reduce((s, c) => s + c.totalAmt, 0);
  const nbArticles = combined.length;

  function toggleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir(key === 'description' ? 'asc' : 'desc');
    }
  }

  async function handleExportPdf() {
    setPdfSaving(true);
    try {
      const html = buildReportHtml({
        dateStart, dateEnd, sorted, currency,
        totalPosQty, totalPosAmt, totalInvQty, totalInvAmt,
        grandTotalQty, grandTotalAmt, nbArticles,
        settings,
      });
      const filename = `synthese_ventes_${dateStart}${dateEnd !== dateStart ? '_' + dateEnd : ''}.pdf`;
      await exportHtmlToPdf(html, filename, 'a4');
    } finally { setPdfSaving(false); }
  }

  const periodLabel = dateStart === dateEnd
    ? fmtDate(dateStart)
    : `${fmtDate(dateStart)} → ${fmtDate(dateEnd)}`;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-gray-900">Synthèse des ventes</h1>
          <p className="text-sm text-gray-400">Articles vendus par période — caisse & factures</p>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={dateStart}
            onChange={e => setDateStart(e.target.value)}
            className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-800 shadow-sm outline-none focus:border-blue-500"
          />
          <span className="text-gray-400 text-sm">→</span>
          <input
            type="date"
            value={dateEnd}
            onChange={e => setDateEnd(e.target.value)}
            className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-800 shadow-sm outline-none focus:border-blue-500"
          />
          <button
            onClick={() => loadData()}
            disabled={loading}
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50 shadow-sm active:scale-95"
          >
            {loading ? <><RefreshCw className="h-4 w-4 animate-spin" /> Calcul…</> : <><Calculator className="h-4 w-4" /> Calculer</>}
          </button>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">
          {error}
        </div>
      )}

      {/* Empty state */}
      {computed && !error && nbArticles === 0 && (
        <div className="rounded-xl border border-gray-200 bg-white py-14 text-center text-sm text-gray-400">
          Aucune vente enregistrée pour cette période.
        </div>
      )}

      {/* KPIs */}
      {computed && !error && nbArticles > 0 && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-gray-400">
              <Package className="h-3.5 w-3.5" /> Articles distincts
            </div>
            <p className="mt-1 text-xl font-bold tabular-nums text-gray-900">{nbArticles}</p>
          </div>
          <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-gray-400">
              <BarChart3 className="h-3.5 w-3.5" /> Quantité totale
            </div>
            <p className="mt-1 text-xl font-bold tabular-nums text-gray-900">{fmtQ(grandTotalQty)}</p>
          </div>
          <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-gray-400">
              <ShoppingBag className="h-3.5 w-3.5" /> Ventes caisse
            </div>
            <p className="mt-1 text-xl font-bold tabular-nums text-emerald-600">{fmtN(totalPosAmt, currency)}</p>
            <p className="text-xs text-gray-400">{fmtQ(totalPosQty)} unités</p>
          </div>
          <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-gray-400">
              <FileText className="h-3.5 w-3.5" /> Ventes factures
            </div>
            <p className="mt-1 text-xl font-bold tabular-nums text-blue-600">{fmtN(totalInvAmt, currency)}</p>
            <p className="text-xs text-gray-400">{fmtQ(totalInvQty)} unités</p>
          </div>
        </div>
      )}

      {/* Main table */}
      {computed && !error && nbArticles > 0 && (
        <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 bg-gray-50 px-5 py-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-blue-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-gray-500">
                Synthèse des articles vendus — {periodLabel}
              </span>
            </div>
            <button
              onClick={handleExportPdf}
              disabled={pdfSaving}
              className="flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700 hover:bg-blue-100 transition disabled:opacity-50"
            >
              <FileDown className="h-4 w-4" /> {pdfSaving ? 'Génération…' : 'Télécharger PDF'}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[800px] text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th
                    className="cursor-pointer px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 hover:text-gray-600"
                    onClick={() => toggleSort('description')}
                  >
                    Article {sortKey === 'description' && (sortDir === 'asc' ? '↑' : '↓')}
                  </th>
                  <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Qté caisse</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Montant caisse</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Qté factures</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Montant factures</th>
                  <th
                    className="cursor-pointer px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400 hover:text-gray-600"
                    onClick={() => toggleSort('totalQty')}
                  >
                    Qté totale {sortKey === 'totalQty' && (sortDir === 'asc' ? '↑' : '↓')}
                  </th>
                  <th
                    className="cursor-pointer px-4 py-3 pr-5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400 hover:text-gray-600"
                    onClick={() => toggleSort('totalAmt')}
                  >
                    CA total {sortKey === 'totalAmt' && (sortDir === 'asc' ? '↑' : '↓')}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {sorted.map((c, i) => (
                  <tr key={i} className="hover:bg-gray-50/60 transition-colors">
                    <td className="px-5 py-3 font-medium text-gray-800">{c.description}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-gray-600">{c.posQty > 0 ? fmtQ(c.posQty) : '—'}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-emerald-600 font-medium">{c.posAmt > 0 ? fmtN(c.posAmt, currency) : '—'}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-gray-600">{c.invQty > 0 ? fmtQ(c.invQty) : '—'}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-blue-600 font-medium">{c.invAmt > 0 ? fmtN(c.invAmt, currency) : '—'}</td>
                    <td className="px-4 py-3 text-right tabular-nums font-semibold text-gray-800">{fmtQ(c.totalQty)}</td>
                    <td className="px-4 py-3 pr-5 text-right tabular-nums font-bold text-gray-900">{fmtN(c.totalAmt, currency)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-gray-300 bg-gray-50 font-bold">
                  <td className="px-5 py-3 text-sm font-bold text-gray-700">TOTAL</td>
                  <td className="px-4 py-3 text-right tabular-nums text-sm text-gray-600">{fmtQ(totalPosQty)}</td>
                  <td className="px-4 py-3 text-right tabular-nums text-sm font-bold text-emerald-700">{fmtN(totalPosAmt, currency)}</td>
                  <td className="px-4 py-3 text-right tabular-nums text-sm text-gray-600">{fmtQ(totalInvQty)}</td>
                  <td className="px-4 py-3 text-right tabular-nums text-sm font-bold text-blue-700">{fmtN(totalInvAmt, currency)}</td>
                  <td className="px-4 py-3 text-right tabular-nums text-sm font-bold text-gray-800">{fmtQ(grandTotalQty)}</td>
                  <td className="px-4 py-3 pr-5 text-right tabular-nums text-sm font-bold text-blue-700">{fmtN(grandTotalAmt, currency)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── PDF ─────────────────────────────────────────────────────── */
function buildReportHtml(d: {
  dateStart: string;
  dateEnd: string;
  sorted: CombinedSummary[];
  currency: string;
  totalPosQty: number;
  totalPosAmt: number;
  totalInvQty: number;
  totalInvAmt: number;
  grandTotalQty: number;
  grandTotalAmt: number;
  nbArticles: number;
  settings: CompanySettings | null;
}): string {
  const f = (n: number) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n);
  const fq = (n: number) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 4 }).format(n);
  const periodLabel = d.dateStart === d.dateEnd
    ? new Date(d.dateStart).toLocaleDateString('fr-FR')
    : `${new Date(d.dateStart).toLocaleDateString('fr-FR')} → ${new Date(d.dateEnd).toLocaleDateString('fr-FR')}`;

  const rowsHtml = d.sorted.map(c => `<tr>
    <td>${c.description}</td>
    <td class="r">${c.posQty > 0 ? fq(c.posQty) : '—'}</td>
    <td class="r">${c.posAmt > 0 ? f(c.posAmt) : '—'}</td>
    <td class="r">${c.invQty > 0 ? fq(c.invQty) : '—'}</td>
    <td class="r">${c.invAmt > 0 ? f(c.invAmt) : '—'}</td>
    <td class="r bold">${fq(c.totalQty)}</td>
    <td class="r bold">${f(c.totalAmt)} ${d.currency}</td>
  </tr>`).join('');

  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<title>Synthèse des ventes — ${periodLabel}</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 11px; color:#1a1a1a; padding: 16mm 14mm; }
  .header { text-align:center; border-bottom: 2px solid #1e40af; padding-bottom: 8px; margin-bottom: 12px; }
  .header h1 { font-size: 18px; font-weight: 800; color:#1e40af; text-transform:uppercase; letter-spacing:1px; }
  .header .sub { font-size: 11px; color:#666; margin-top: 3px; }
  .header .meta-line { font-size: 10px; color:#999; margin-top: 2px; }
  .section-title { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color:#1e40af; margin: 14px 0 5px; padding-bottom: 3px; }
  table { width: 100%; border-collapse: collapse; font-size: 10px; }
  th { font-size: 8.5px; text-transform: uppercase; font-weight: 700; color:#6b7280; padding: 4px 6px; text-align: left; }
  td { padding: 3.5px 6px; }
  .r { text-align: right; }
  .bold { font-weight: 700; }
  .total-row td { font-weight: 800; font-size: 10.5px; border-top: 2px solid #9ca3af; padding-top: 5px; color:#111; }
  .footer { margin-top: 18px; text-align:center; font-size: 9px; color:#9ca3af; border-top: 1px solid #e5e7eb; padding-top: 8px; }
  @media print { @page { size: A4; margin: 10mm; } body { padding: 0; } }
</style></head><body>
  <div class="header">
    <h1>${d.settings?.name ?? 'SYNTHÈSE DES VENTES'}</h1>
    <div class="sub">Synthèse des articles vendus — ${periodLabel}</div>
    <div class="meta-line">${d.nbArticles} article(s) · Édité le ${new Date().toLocaleString('fr-FR')}</div>
  </div>

  <div class="section-title">DÉTAIL DES ARTICLES VENDUS</div>
  <table>
    <tr>
      <th>Article</th>
      <th class="r">Qté caisse</th>
      <th class="r">Caisse</th>
      <th class="r">Qté fact.</th>
      <th class="r">Factures</th>
      <th class="r">Qté totale</th>
      <th class="r">CA total</th>
    </tr>
    ${rowsHtml}
    <tr class="total-row">
      <td>TOTAL</td>
      <td class="r">${fq(d.totalPosQty)}</td>
      <td class="r">${f(d.totalPosAmt)}</td>
      <td class="r">${fq(d.totalInvQty)}</td>
      <td class="r">${f(d.totalInvAmt)}</td>
      <td class="r">${fq(d.grandTotalQty)}</td>
      <td class="r">${f(d.grandTotalAmt)} ${d.currency}</td>
    </tr>
  </table>

  <div class="footer">Document généré par Stocklite — ${new Date().toLocaleString('fr-FR')}</div>
</body></html>`;
}
