import { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import {
  Search, PlusCircle, Pencil, Trash2, ToggleLeft, ToggleRight,
  Layers, Package, FolderOpen, Tag, Upload, MapPin, X, Plus, Truck, Image as ImageIcon, Loader2, AlertTriangle,
} from 'lucide-react';
import type { Product, ProductFamily, PriceType, SalesLocation, Supplier } from '../types';
import type { useProductFamilies } from '../hooks/useProductFamilies';
import type { usePriceTypes } from '../hooks/usePriceTypes';
import type { useProducts } from '../hooks/useProducts';
import { useCustomUnits } from '../hooks/useCustomUnits';
import { Modal } from './Modal';
import { ImportProductsModal } from './ImportProductsModal';
import { fmtQty } from '../lib/format';
import { translateError } from '../lib/translateError';
import { supabase } from '../lib/supabase';

interface ProductsPageProps {
  products: Product[];
  families: ProductFamily[];
  priceTypes: PriceType[];
  suppliers: Supplier[];
  onSave: (payload: Omit<Product, 'id' | 'created_at' | 'family' | 'prices' | 'suppliers'>, id?: string) => Promise<string>;
  onSavePrices: ReturnType<typeof usePriceTypes>['saveProductPrices'];
  onRemove: (id: string) => Promise<void>;
  onSaveFamily: ReturnType<typeof useProductFamilies>['saveFamily'];
  onRemoveFamily: ReturnType<typeof useProductFamilies>['removeFamily'];
  onBulkImport: (
    rows: { family: string; name: string; reference?: string; stock: number; price: number; purchase_price: number; priceTypePrices?: Record<string, number> }[],
    targetLocationId: string | null,
    onProgress?: (current: number, total: number) => void,
  ) => Promise<{ created: number; updated: number; familiesCreated: number }>;
  onFetchProductLocations: (productId: string) => Promise<{ location_id: string; price: number | null; stock_quantity: number; stock_min: number }[]>;
  onSaveProductLocations: (productId: string, entries: { location_id: string; price: number; stock_quantity: number; stock_min: number }[], removedLocationIds: string[]) => Promise<void>;
  onFetchLocationProductPrices: (productId: string) => Promise<{ location_id: string; price_type_id: string; price: number }[]>;
  onSaveLocationProductPrices: (productId: string, entries: { location_id: string; price_type_id: string; price: number }[], removedIds: string[]) => Promise<void>;
  onFetchProductSuppliers: ReturnType<typeof useProducts>['fetchProductSuppliers'];
  onSaveProductSuppliers: ReturnType<typeof useProducts>['saveProductSuppliers'];
  currency: string;
  locationId?: string | null;
  locations?: SalesLocation[];
  tenantId?: string | null;
}

const UNITS = ['pcs', 'h', 'kg', 'g', 'l', 'ml', 'm', 'cm', 'forfait', 'service'];

const FAMILY_COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#14b8a6',
  '#3b82f6', '#8b5cf6', '#ec4899', '#6b7280', '#0ea5e9',
];

function fmt(n: number, currency: string) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}

// ── Product Form ─────────────────────────────────────────────────
interface ProductFormProps {
  initial?: Product;
  currency: string;
  families: ProductFamily[];
  priceTypes: PriceType[];
  suppliers: Supplier[];
  locationId?: string | null;
  locations: SalesLocation[];
  onFetchProductLocations: (productId: string) => Promise<{ location_id: string; price: number | null; stock_quantity: number; stock_min: number }[]>;
  onSaveProductLocations: (productId: string, entries: { location_id: string; price: number; stock_quantity: number; stock_min: number }[], removedLocationIds: string[]) => Promise<void>;
  onFetchLocationProductPrices: (productId: string) => Promise<{ location_id: string; price_type_id: string; price: number }[]>;
  onSaveLocationProductPrices: (productId: string, entries: { location_id: string; price_type_id: string; price: number }[], removedIds: string[]) => Promise<void>;
  onFetchProductSuppliers: (productId: string) => Promise<{ product_id: string; supplier_id: string; is_default: boolean; supply_price: number | null; supply_unit: string | null }[]>;
  onSaveProductSuppliers: (productId: string, entries: { supplier_id: string; is_default: boolean; supply_price: number | null; supply_unit: string | null }[]) => Promise<void>;
  knownUnits: string[];
  customUnits: string[];
  onAddUnit: (name: string) => Promise<void>;
  onRemoveUnit: (name: string) => Promise<void>;
  onSubmit: (d: Omit<Product, 'id' | 'created_at' | 'family' | 'prices' | 'suppliers'>) => Promise<string>;
  onSavePrices: (productId: string, prices: { price_type_id: string; price: number }[]) => Promise<void>;
  onClose: () => void;
}

interface LocationEntry {
  location_id: string;
  enabled: boolean;
  price: string;
  stock_quantity: string;
  stock_min: string;
}

function ProductForm({ initial, currency, families, priceTypes, suppliers, locationId, locations, knownUnits, customUnits, onAddUnit, onRemoveUnit, onFetchProductLocations, onSaveProductLocations, onFetchLocationProductPrices, onSaveLocationProductPrices, onFetchProductSuppliers, onSaveProductSuppliers, onSubmit, onSavePrices, onClose }: ProductFormProps) {
  const [form, setForm] = useState({
    name: initial?.name ?? '',
    reference: initial?.reference ?? '',
    description: initial?.description ?? '',
    unit: initial?.unit ?? 'pcs',
    price: initial?.price ? String(initial.price) : '',
    purchase_price: initial?.purchase_price ? String(initial.purchase_price) : '',
    track_stock: initial?.track_stock ?? false,
    stock_quantity: initial?.stock_quantity ? String(initial.stock_quantity) : '0',
    stock_min: initial?.stock_min ? String(initial.stock_min) : '0',
    active: initial?.active ?? true,
    family_id: initial?.family_id ?? '',
  });
  const [photoUrl, setPhotoUrl] = useState<string | null>(initial?.photo_url ?? null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const [autoRef, setAutoRef] = useState(!initial?.reference);
  const tenantId = (initial as Record<string, unknown> & { tenant_id?: string } | undefined)?.tenant_id as string | undefined;
  const [dupRefWarning, setDupRefWarning] = useState<string | null>(null);
  const [dupChecking, setDupChecking] = useState(false);

  const checkDuplicates = useCallback(async (name: string, reference: string) => {
    if (!navigator.onLine) return;
    setDupChecking(true);
    try {
      const trimmedRef = reference.trim();
      if (!trimmedRef) { setDupRefWarning(null); setDupChecking(false); return; }
      let refQ = supabase.from('products').select('id, name').eq('reference', trimmedRef);
      if (initial?.id) refQ = refQ.neq('id', initial.id);
      const { data: refMatch } = await refQ;
      if (refMatch && refMatch.length > 0) {
        let conflicting = refMatch;
        if (locationId) {
          const { data: lsData } = await supabase.from('location_stock')
            .select('product_id').eq('location_id', locationId)
            .in('product_id', refMatch.map(p => p.id));
          const locProductIds = new Set((lsData ?? []).map(r => r.product_id));
          conflicting = refMatch.filter(p => locProductIds.has(p.id));
        }
        if (conflicting.length > 0) {
          setDupRefWarning(`Référence déjà utilisée par « ${conflicting[0].name} »`);
        } else {
          setDupRefWarning(null);
        }
      } else {
        setDupRefWarning(null);
      }
    } catch {
      setDupRefWarning(null);
    } finally {
      setDupChecking(false);
    }
  }, [initial?.id, locationId]);

  useEffect(() => {
    const timer = setTimeout(() => {
      checkDuplicates(form.name, form.reference);
    }, 400);
    return () => clearTimeout(timer);
  }, [form.name, form.reference, checkDuplicates]);
  const [typePrices, setTypePrices] = useState<Record<string, string>>(() => {
    const map: Record<string, string> = {};
    (initial?.prices ?? []).forEach(p => { map[p.price_type_id] = String(p.price); });
    return map;
  });
  const [locEntries, setLocEntries] = useState<Record<string, LocationEntry>>({});
  const [locTypePrices, setLocTypePrices] = useState<Record<string, Record<string, string>>>({});
  const [locLoaded, setLocLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [newUnit, setNewUnit] = useState('');
  const [productSuppliers, setProductSuppliers] = useState<Record<string, { enabled: boolean; is_default: boolean; supply_price: string; supply_unit: string }>>({});
  const [suppliersLoaded, setSuppliersLoaded] = useState(false);

  const activeLocations = locationId
    ? locations.filter(l => l.active && l.id === locationId)
    : locations.filter(l => l.active);
  const showMultiLocation = activeLocations.length >= 2;

  useEffect(() => {
    if (!showMultiLocation || !initial?.id) { setLocLoaded(true); return; }
    let mounted = true;
    (async () => {
      try {
        const [rows, priceRows] = await Promise.all([
          onFetchProductLocations(initial.id!),
          onFetchLocationProductPrices(initial.id!),
        ]);
        if (!mounted) return;
        const map: Record<string, LocationEntry> = {};
        for (const l of activeLocations) {
          const r = rows.find(x => x.location_id === l.id);
          map[l.id] = {
            location_id: l.id,
            enabled: !!r,
            price: r?.price != null ? String(r.price) : '',
            stock_quantity: r ? String(r.stock_quantity) : '0',
            stock_min: r ? String(r.stock_min) : '0',
          };
        }
        setLocEntries(map);
        const tpMap: Record<string, Record<string, string>> = {};
        for (const pr of priceRows) {
          if (!tpMap[pr.location_id]) tpMap[pr.location_id] = {};
          tpMap[pr.location_id][pr.price_type_id] = String(pr.price);
        }
        setLocTypePrices(tpMap);
      } catch { /* ignore */ }
      if (mounted) setLocLoaded(true);
    })();
    return () => { mounted = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initial?.id, showMultiLocation]);

  useEffect(() => {
    if (!initial?.id || suppliers.length === 0) { setSuppliersLoaded(true); return; }
    let mounted = true;
    (async () => {
      try {
        const rows = await onFetchProductSuppliers(initial.id!);
        if (!mounted) return;
        const map: Record<string, { enabled: boolean; is_default: boolean; supply_price: string; supply_unit: string }> = {};
        for (const r of rows) {
          map[r.supplier_id] = {
            enabled: true,
            is_default: r.is_default,
            supply_price: r.supply_price != null ? String(r.supply_price) : '',
            supply_unit: r.supply_unit ?? '',
          };
        }
        setProductSuppliers(map);
      } catch { /* ignore */ }
      if (mounted) setSuppliersLoaded(true);
    })();
    return () => { mounted = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initial?.id, suppliers.length]);

  function set(k: string, v: string | boolean) { setForm(f => ({ ...f, [k]: v })); }
  const activePriceTypes = priceTypes.filter(pt => pt.active);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setErr('Le nom est requis.'); return; }
    if (dupRefWarning) { setErr(`Un article avec cette référence existe déjà (${dupRefWarning})`); return; }
    if (!form.price || isNaN(parseFloat(form.price))) { setErr('Prix de vente invalide.'); return; }
    setSaving(true);
    try {
      const productId = await onSubmit({
        name: form.name.trim(),
        reference: form.reference.trim() || null,
        description: form.description.trim(),
        unit: form.unit.trim() || 'pcs',
        price: parseFloat(form.price) || 0,
        purchase_price: parseFloat(form.purchase_price) || 0,
        track_stock: form.track_stock,
        stock_quantity: parseFloat(form.stock_quantity) || 0,
        stock_min: parseFloat(form.stock_min) || 0,
        active: form.active,
        family_id: form.family_id || null,
        photo_url: photoUrl,
      });
      // Save price types
      const priceRows = Object.entries(typePrices)
        .filter(([, v]) => v !== '' && !isNaN(parseFloat(v)))
        .map(([price_type_id, price]) => ({ price_type_id, price: parseFloat(price) }));
      if (priceRows.length > 0) await onSavePrices(productId, priceRows);

      // Save per-location price/stock
      if (showMultiLocation) {
        const entries: { location_id: string; price: number; stock_quantity: number; stock_min: number }[] = [];
        const removed: string[] = [];
        for (const l of activeLocations) {
          const e = locEntries[l.id];
          if (e?.enabled) {
            entries.push({
              location_id: l.id,
              price: parseFloat(e.price) || 0,
              stock_quantity: parseFloat(e.stock_quantity) || 0,
              stock_min: parseFloat(e.stock_min) || 0,
            });
          } else if (e && !e.enabled) {
            removed.push(l.id);
          }
        }
        if (entries.length || removed.length) await onSaveProductLocations(productId, entries, removed);

        // Save per-location price type prices
        const lpEntries: { location_id: string; price_type_id: string; price: number }[] = [];
        const lpRemoved: string[] = [];
        for (const l of activeLocations) {
          const e = locEntries[l.id];
          if (!e?.enabled) continue;
          const tpMap = locTypePrices[l.id] ?? {};
          for (const pt of activePriceTypes) {
            const val = tpMap[pt.id];
            if (val != null && val !== '' && !isNaN(parseFloat(val))) {
              lpEntries.push({ location_id: l.id, price_type_id: pt.id, price: parseFloat(val) });
            } else {
              lpRemoved.push(`${productId}_${l.id}_${pt.id}`);
            }
          }
        }
        if (lpEntries.length || lpRemoved.length) await onSaveLocationProductPrices(productId, lpEntries, lpRemoved);
      }

      // Save suppliers
      const supplierEntries: { supplier_id: string; is_default: boolean; supply_price: number | null; supply_unit: string | null }[] = [];
      for (const s of suppliers) {
        const e = productSuppliers[s.id];
        if (e?.enabled) {
          supplierEntries.push({
            supplier_id: s.id,
            is_default: e.is_default,
            supply_price: e.supply_price !== '' && !isNaN(parseFloat(e.supply_price)) ? parseFloat(e.supply_price) : null,
            supply_unit: e.supply_unit.trim() || null,
          });
        }
      }
      if (supplierEntries.length > 0 || (initial?.id && Object.keys(productSuppliers).length > 0)) {
        await onSaveProductSuppliers(productId, supplierEntries);
      }

      onClose();
    } catch (e) { setErr(e instanceof Error ? translateError(e.message) : 'Erreur'); setSaving(false); }
  }

  return (
    <form onSubmit={submit} className="space-y-4 p-5">
      <div className="flex items-start gap-4">
        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl border-2 border-gray-200 bg-gray-50 flex items-center justify-center">
          {photoUrl ? (
            <>
              <img src={photoUrl} alt="Aperçu" className="h-full w-full object-cover" />
              <button
                type="button"
                onClick={() => setPhotoUrl(null)}
                className="absolute right-0 top-0 rounded-bl-lg bg-red-500/90 px-1.5 py-0.5 text-white hover:bg-red-600 transition"
              >
                <X className="h-3 w-3" />
              </button>
            </>
          ) : (
            <ImageIcon className="h-8 w-8 text-gray-300" />
          )}
        </div>
        <div className="flex-1">
          <label className="label">Photo de l'article</label>
          <p className="mb-2 text-xs text-gray-400">Format : PNG, JPG ou WebP. Max 2 Mo.</p>
          <input
            ref={photoInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={async e => {
              const file = e.target.files?.[0];
              if (!file) return;
              if (file.size > 2 * 1024 * 1024) { setErr('L\'image ne doit pas dépasser 2 Mo.'); return; }
              if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) { setErr('Format accepté : PNG, JPG ou WebP.'); return; }
              setUploadingPhoto(true); setErr('');
              try {
                const { data: { user } } = await supabase.auth.getUser();
                const tid = tenantId ?? (user?.id ?? 'unknown');
                const ext = file.name.split('.').pop() ?? 'png';
                const path = `${tid}/${crypto.randomUUID()}.${ext}`;
                const { error: upErr } = await supabase.storage.from('product-photos').upload(path, file, { contentType: file.type });
                if (upErr) throw new Error(upErr.message);
                const { data: urlData } = supabase.storage.from('product-photos').getPublicUrl(path);
                setPhotoUrl(`${urlData.publicUrl}?t=${Date.now()}`);
              } catch (e) {
                setErr(e instanceof Error ? translateError(e.message) : 'Erreur lors du téléversement');
              } finally {
                setUploadingPhoto(false);
                if (photoInputRef.current) photoInputRef.current.value = '';
              }
            }}
            disabled={uploadingPhoto}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => photoInputRef.current?.click()}
            disabled={uploadingPhoto}
            className="flex items-center gap-2 rounded-lg border border-gray-300 bg-gray-50 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 transition disabled:opacity-50"
          >
            {uploadingPhoto ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            {uploadingPhoto ? 'Téléversement…' : photoUrl ? 'Changer la photo' : 'Choisir une photo'}
          </button>
        </div>
      </div>
      <div>
        <label className="label">Désignation *</label>
        <input className="input" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Nom de l'article" />
      </div>
      <div>
        <label className="label">Référence</label>
        <div className="flex items-center gap-2">
          <input
            className="input flex-1"
            value={form.reference}
            disabled={autoRef}
            onChange={e => set('reference', e.target.value)}
            placeholder={autoRef ? 'Auto-générée' : 'Saisir une référence'}
          />
          <button
            type="button"
            onClick={() => {
              const next = !autoRef;
              setAutoRef(next);
              if (next) set('reference', '');
            }}
            className={`shrink-0 rounded-lg px-3 py-2 text-xs font-medium transition ${autoRef ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            {autoRef ? 'Auto' : 'Manuel'}
          </button>
        </div>
        {dupRefWarning && (
          <div className="mt-1.5 flex items-center gap-1.5 text-xs text-amber-600">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            <span>Doublon : {dupRefWarning}</span>
          </div>
        )}
      </div>
      <div>
        <label className="label">Description</label>
        <input className="input" value={form.description} onChange={e => set('description', e.target.value)} placeholder="Optionnel" />
      </div>
      <div>
        <label className="label">Famille</label>
        <select className="input" value={form.family_id} onChange={e => set('family_id', e.target.value)}>
          <option value="">— Sans famille —</option>
          {families.map(f => (
            <option key={f.id} value={f.id}>{f.name}</option>
          ))}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">
            {locationId ? 'Prix de vente boutique' : 'Prix de vente'} ({currency})
          </label>
          <input type="number" step="any" min="0" className="input" value={form.price} onChange={e => set('price', e.target.value)} placeholder="0" />
          {locationId && (
            <p className="mt-1 text-[10px] text-blue-500">Prix spécifique à cette boutique</p>
          )}
        </div>
        <div>
          <label className="label">Prix d'achat ({currency})</label>
          <input type="number" step="any" min="0" className="input" value={form.purchase_price} onChange={e => set('purchase_price', e.target.value)} placeholder="0" />
        </div>
      </div>
      <div>
        <label className="label">Unité</label>
        <div className="relative">
          <input
            className="input pr-9"
            value={form.unit}
            onChange={e => set('unit', e.target.value)}
            placeholder="pcs, kg, h…"
            list="unit-list"
          />
          <datalist id="unit-list">
            {knownUnits.map(u => <option key={u} value={u} />)}
          </datalist>
          {form.unit && (
            <button
              type="button"
              onClick={() => set('unit', '')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <div className="mt-1.5 flex flex-wrap gap-1">
          {knownUnits.map(u => (
            <span key={u} className="relative group">
              <button
                type="button"
                onClick={() => set('unit', u)}
                className={`rounded-full px-2.5 py-0.5 text-[11px] font-medium transition ${form.unit === u ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                {u}
              </button>
              {customUnits.includes(u) && (
                <button
                  type="button"
                  onClick={async () => { await onRemoveUnit(u); if (form.unit === u) set('unit', 'pcs'); }}
                  title={`Supprimer l'unité « ${u} »`}
                  className="absolute -right-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-red-500 text-white opacity-0 transition group-hover:opacity-100 hover:bg-red-600"
                >
                  <X className="h-2.5 w-2.5" />
                </button>
              )}
            </span>
          ))}
        </div>
        <div className="mt-2 flex items-center gap-1.5">
          <input
            type="text"
            className="input flex-1 py-1.5 text-xs"
            value={newUnit}
            onChange={e => setNewUnit(e.target.value)}
            placeholder="Ajouter une unité…"
            onKeyDown={e => {
              if (e.key === 'Enter') {
                e.preventDefault();
                if (newUnit.trim()) { onAddUnit(newUnit); setNewUnit(''); }
              }
            }}
          />
          <button
            type="button"
            onClick={() => { if (newUnit.trim()) { onAddUnit(newUnit); setNewUnit(''); } }}
            disabled={!newUnit.trim()}
            className="flex shrink-0 items-center gap-1 rounded-lg bg-gray-100 px-2.5 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-200 disabled:opacity-50"
          >
            <Plus className="h-3.5 w-3.5" /> Ajouter
          </button>
        </div>
      </div>

      <div className="rounded-lg border border-gray-300 bg-gray-100 p-3 space-y-3">
        <label className="flex cursor-pointer items-center justify-between">
          <span className="text-sm font-medium text-gray-700">Suivi de stock activé</span>
          <button type="button" onClick={() => set('track_stock', !form.track_stock)} className="text-gray-500">
            {form.track_stock ? <ToggleRight className="h-6 w-6 text-blue-400" /> : <ToggleLeft className="h-6 w-6" />}
          </button>
        </label>
        {form.track_stock && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Stock initial</label>
              <input type="number" step="0.01" min="0" className="input" value={form.stock_quantity} onChange={e => set('stock_quantity', e.target.value)} />
            </div>
            <div>
              <label className="label">Seuil d'alerte</label>
              <input type="number" step="0.01" min="0" className="input" value={form.stock_min} onChange={e => set('stock_min', e.target.value)} />
            </div>
          </div>
        )}
      </div>

      {showMultiLocation && (
        <div className="rounded-lg border border-gray-200 bg-gray-50 p-3 space-y-2">
          <div className="flex items-center gap-1.5 mb-1">
            <MapPin className="h-3.5 w-3.5 text-gray-400" />
            <span className="text-xs font-semibold text-gray-500">Disponibilité et prix par boutique</span>
          </div>
          {!locLoaded ? (
            <p className="text-xs text-gray-400 animate-pulse">Chargement…</p>
          ) : activeLocations.map(l => {
            const e = locEntries[l.id] ?? { location_id: l.id, enabled: false, price: '', stock_quantity: '0', stock_min: '0' };
            return (
              <div key={l.id} className={`rounded-md border ${e.enabled ? 'border-blue-200 bg-white' : 'border-gray-200 bg-gray-50'} p-2.5`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-gray-700 flex items-center gap-1.5">
                    <MapPin className="h-3 w-3 text-gray-400" />
                    {l.name}
                  </span>
                  <button type="button" onClick={() => setLocEntries(prev => ({ ...prev, [l.id]: { ...e, enabled: !e.enabled } }))} className="text-gray-500">
                    {e.enabled ? <ToggleRight className="h-5 w-5 text-blue-500" /> : <ToggleLeft className="h-5 w-5" />}
                  </button>
                </div>
                {e.enabled && (
                  <div className="space-y-2">
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="block text-[10px] font-medium text-gray-500 mb-0.5">Prix base ({currency})</label>
                        <input type="number" step="any" min="0" value={e.price} onChange={ev => setLocEntries(prev => ({ ...prev, [l.id]: { ...e, price: ev.target.value } }))} placeholder={form.price || '0'} className="w-full rounded-md border border-gray-200 bg-white px-2 py-1 text-xs text-gray-800 outline-none focus:border-blue-500" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium text-gray-500 mb-0.5">Stock</label>
                        <input type="number" step="0.01" min="0" value={e.stock_quantity} onChange={ev => setLocEntries(prev => ({ ...prev, [l.id]: { ...e, stock_quantity: ev.target.value } }))} className="w-full rounded-md border border-gray-200 bg-white px-2 py-1 text-xs text-gray-800 outline-none focus:border-blue-500" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium text-gray-500 mb-0.5">Seuil</label>
                        <input type="number" step="0.01" min="0" value={e.stock_min} onChange={ev => setLocEntries(prev => ({ ...prev, [l.id]: { ...e, stock_min: ev.target.value } }))} className="w-full rounded-md border border-gray-200 bg-white px-2 py-1 text-xs text-gray-800 outline-none focus:border-blue-500" />
                      </div>
                    </div>
                    {activePriceTypes.length > 0 && (
                      <div className="space-y-1 pt-1 border-t border-gray-100">
                        <p className="text-[10px] font-medium text-gray-400">Types de prix spécifiques à cette boutique</p>
                        {activePriceTypes.map(pt => {
                          const tpMap = locTypePrices[l.id] ?? {};
                          return (
                            <div key={pt.id} className="flex items-center gap-1.5">
                              <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: pt.color }} />
                              <span className="text-[10px] text-gray-500 w-16 shrink-0 truncate">{pt.name}</span>
                              <input
                                type="number" step="any" min="0"
                                value={tpMap[pt.id] ?? ''}
                                onChange={ev => setLocTypePrices(prev => ({
                                  ...prev,
                                  [l.id]: { ...tpMap, [pt.id]: ev.target.value },
                                }))}
                                placeholder={typePrices[pt.id] || e.price || form.price || '0'}
                                className="flex-1 rounded border border-gray-200 bg-white px-1.5 py-0.5 text-[11px] text-gray-800 outline-none focus:border-blue-500"
                              />
                              <span className="text-[10px] text-gray-400 shrink-0">{currency}</span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {activePriceTypes.length > 0 && !showMultiLocation && (
        <div className="rounded-lg border border-gray-200 bg-gray-50 p-3 space-y-2">
          <div className="flex items-center gap-1.5 mb-1">
            <Tag className="h-3.5 w-3.5 text-gray-400" />
            <span className="text-xs font-semibold text-gray-500">Prix par type de tarif</span>
          </div>
          {activePriceTypes.map(pt => (
            <div key={pt.id} className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: pt.color }} />
              <span className="text-xs text-gray-600 w-24 shrink-0 truncate">{pt.name}</span>
              <input
                type="number"
                step="any"
                min="0"
                value={typePrices[pt.id] ?? ''}
                onChange={e => setTypePrices(prev => ({ ...prev, [pt.id]: e.target.value }))}
                placeholder={form.price || '0'}
                className="flex-1 rounded-md border border-gray-200 bg-white px-2.5 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-500 transition"
              />
              <span className="text-xs text-gray-400 shrink-0">{currency}</span>
            </div>
          ))}
        </div>
      )}

      {suppliers.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-gray-50 p-3 space-y-2">
          <div className="flex items-center gap-1.5 mb-1">
            <Truck className="h-3.5 w-3.5 text-gray-400" />
            <span className="text-xs font-semibold text-gray-500">Fournisseurs</span>
          </div>
          {!suppliersLoaded ? (
            <p className="text-xs text-gray-400 animate-pulse">Chargement…</p>
          ) : suppliers.map(s => {
            const e = productSuppliers[s.id] ?? { enabled: false, is_default: false, supply_price: '', supply_unit: '' };
            return (
              <div key={s.id} className={`rounded-md border ${e.enabled ? 'border-blue-200 bg-white' : 'border-gray-200 bg-gray-50'} p-2.5`}>
                <div className="flex items-center justify-between mb-2">
                  <label className="flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={e.enabled}
                      onChange={ev => setProductSuppliers(prev => ({ ...prev, [s.id]: { ...e, enabled: ev.target.checked, is_default: ev.target.checked && e.is_default ? false : e.is_default } }))}
                      className="h-3.5 w-3.5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    {s.name}
                    {s.phone && <span className="text-[10px] text-gray-400">{s.phone}</span>}
                  </label>
                  {e.enabled && (
                    <label className="flex items-center gap-1 text-[10px] text-gray-500 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={e.is_default}
                        onChange={ev => {
                          const checked = ev.target.checked;
                          setProductSuppliers(prev => {
                            const next = { ...prev };
                            for (const k of Object.keys(next)) next[k] = { ...next[k], is_default: false };
                            next[s.id] = { ...e, is_default: checked };
                            return next;
                          });
                        }}
                        className="h-3 w-3 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      Fournisseur principal
                    </label>
                  )}
                </div>
                {e.enabled && (
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-medium text-gray-500 mb-0.5">Prix d'achat ({currency})</label>
                      <input type="number" step="any" min="0" value={e.supply_price} onChange={ev => setProductSuppliers(prev => ({ ...prev, [s.id]: { ...e, supply_price: ev.target.value } }))} placeholder={form.purchase_price || '0'} className="w-full rounded-md border border-gray-200 bg-white px-2 py-1 text-xs text-gray-800 outline-none focus:border-blue-500" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-medium text-gray-500 mb-0.5">Unité fournisseur</label>
                      <input type="text" value={e.supply_unit} onChange={ev => setProductSuppliers(prev => ({ ...prev, [s.id]: { ...e, supply_unit: ev.target.value } }))} placeholder={form.unit || 'pcs'} className="w-full rounded-md border border-gray-200 bg-white px-2 py-1 text-xs text-gray-800 outline-none focus:border-blue-500" />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          {suppliers.length === 0 && (
            <p className="text-xs text-gray-400">Aucun fournisseur. Créez-en un dans l'onglet Approvisionnement.</p>
          )}
        </div>
      )}

      <label className="flex cursor-pointer items-center gap-3">
        <span className="text-sm text-gray-500">Article actif</span>
        <button type="button" onClick={() => set('active', !form.active)} className="text-gray-500">
          {form.active ? <ToggleRight className="h-6 w-6 text-blue-400" /> : <ToggleLeft className="h-6 w-6" />}
        </button>
      </label>

      {err && <p className="text-xs text-red-400">{err}</p>}
      <div className="flex gap-2 pt-1">
        <button type="button" onClick={onClose} className="flex-1 rounded-lg border border-gray-300 py-2.5 text-sm text-gray-500 hover:bg-gray-100">Annuler</button>
        <button type="submit" disabled={saving} className="flex-1 rounded-lg bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
          {saving ? 'Enregistrement…' : 'Enregistrer'}
        </button>
      </div>
    </form>
  );
}

// ── Family Form ──────────────────────────────────────────────────
function FamilyForm({ initial, families, onSubmit, onClose }: {
  initial?: ProductFamily;
  families: ProductFamily[];
  onSubmit: (d: { name: string; color: string; sort_order: number; printer_name: string | null }) => Promise<void>;
  onClose: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? '');
  const [color, setColor] = useState(initial?.color ?? FAMILY_COLORS[0]);
  const [sortOrder, setSortOrder] = useState(String(initial?.sort_order ?? 0));
  const [printerName, setPrinterName] = useState(initial?.printer_name ?? '');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const knownPrinters = useMemo(
    () => Array.from(new Set(families.map(f => f.printer_name).filter((p): p is string => !!p))).sort(),
    [families],
  );

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) { setErr('Le nom est requis.'); return; }
    setSaving(true);
    try {
      await onSubmit({ name: name.trim(), color, sort_order: parseInt(sortOrder) || 0, printer_name: printerName.trim() || null });
      onClose();
    } catch (e) { setErr(e instanceof Error ? translateError(e.message) : 'Erreur'); setSaving(false); }
  }

  return (
    <form onSubmit={submit} className="space-y-4 p-5">
      <div>
        <label className="label">Nom de la famille *</label>
        <input className="input" value={name} onChange={e => setName(e.target.value)} placeholder="ex. Boissons" />
      </div>
      <div>
        <label className="label">Couleur</label>
        <div className="flex flex-wrap gap-2 mt-1">
          {FAMILY_COLORS.map(c => (
            <button key={c} type="button" onClick={() => setColor(c)}
              className="h-7 w-7 rounded-full border-2 transition"
              style={{ backgroundColor: c, borderColor: color === c ? '#1d4ed8' : 'transparent' }}
            />
          ))}
        </div>
      </div>
      <div>
        <label className="label">Ordre d'affichage</label>
        <input type="number" min="0" className="input" value={sortOrder} onChange={e => setSortOrder(e.target.value)} />
      </div>
      <div>
        <label className="label">Imprimante</label>
        <div className="relative">
          <input
            className="input pr-9"
            value={printerName}
            onChange={e => setPrinterName(e.target.value)}
            placeholder="Imprimante par défaut"
            list="printer-names-list"
          />
          <datalist id="printer-names-list">
            {knownPrinters.map(p => <option key={p} value={p} />)}
          </datalist>
          {printerName && (
            <button
              type="button"
              onClick={() => setPrinterName('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <div className="mt-1.5 flex flex-wrap gap-1">
          <button
            type="button"
            onClick={() => setPrinterName('')}
            className={`rounded-full px-2.5 py-0.5 text-[11px] font-medium transition ${!printerName ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            Par défaut
          </button>
          {knownPrinters.map(p => (
            <button
              key={p}
              type="button"
              onClick={() => setPrinterName(p)}
              className={`rounded-full px-2.5 py-0.5 text-[11px] font-medium transition ${printerName === p ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>
      {err && <p className="text-xs text-red-400">{err}</p>}
      <div className="flex gap-2 pt-1">
        <button type="button" onClick={onClose} className="flex-1 rounded-lg border border-gray-300 py-2.5 text-sm text-gray-500 hover:bg-gray-100">Annuler</button>
        <button type="submit" disabled={saving} className="flex-1 rounded-lg bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
          {saving ? 'Enregistrement…' : 'Enregistrer'}
        </button>
      </div>
    </form>
  );
}

// ── Main Page ────────────────────────────────────────────────────
type Tab = 'catalogue' | 'familles';
type NavSel = 'all' | string | 'uncategorized';

export function ProductsPage({ products, families, priceTypes, suppliers, onSave, onSavePrices, onRemove, onSaveFamily, onRemoveFamily, onBulkImport, onFetchProductLocations, onSaveProductLocations, onFetchLocationProductPrices, onSaveLocationProductPrices, onFetchProductSuppliers, onSaveProductSuppliers, currency, locationId, locations, tenantId }: ProductsPageProps) {
  const [showImport, setShowImport] = useState(false);
  const [tab, setTab] = useState<Tab>('catalogue');
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [navSel, setNavSel] = useState<NavSel>('all');
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query.trim()), 200);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === '/' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'SELECT' && document.activeElement?.tagName !== 'TEXTAREA') {
        e.preventDefault();
        searchRef.current?.focus();
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  const [editing, setEditing] = useState<Product | null | 'new'>(null);
  const [confirm, setConfirm] = useState<string | null>(null);
  const [familyModal, setFamilyModal] = useState<ProductFamily | null | 'new'>(null);
  const [confirmFamily, setConfirmFamily] = useState<string | null>(null);

  const { units: customUnits, addUnit, removeUnit } = useCustomUnits(tenantId);

  const knownUnits = useMemo(
    () => Array.from(new Set([...UNITS, ...customUnits, ...products.map(p => p.unit).filter(Boolean)])).sort((a, b) => a.localeCompare(b)),
    [products, customUnits],
  );

  const filtered = useMemo(() => {
    let list = products;
    if (navSel === 'uncategorized') list = list.filter(p => !p.family_id);
    else if (navSel !== 'all') list = list.filter(p => p.family_id === navSel);
    if (!debouncedQuery) return list;
    const q = debouncedQuery.toLowerCase();
    const matches = list.map(p => {
      const name = p.name.toLowerCase();
      const ref = (p.reference ?? '').toLowerCase();
      const desc = (p.description ?? '').toLowerCase();
      const famName = (p.family?.name ?? '').toLowerCase();
      let score = -1;
      if (name === q) score = 0;
      else if (name.startsWith(q)) score = 1;
      else if (ref === q) score = 2;
      else if (ref.startsWith(q)) score = 3;
      else if (name.includes(q)) score = 4;
      else if (ref.includes(q)) score = 5;
      else if (famName.includes(q)) score = 6;
      else if (desc.includes(q)) score = 7;
      return { p, score };
    }).filter(x => x.score >= 0);
    matches.sort((a, b) => a.score - b.score);
    return matches.map(x => x.p);
  }, [products, debouncedQuery, navSel]);

  const unassignedCount = products.filter(p => !p.family_id).length;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-gray-900">Articles</h1>
          <p className="text-sm text-gray-400">Catalogue produits et services</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowImport(true)} className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3.5 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50 hover:border-gray-400 transition active:scale-95">
            <Upload className="h-4 w-4" /> Importer Excel
          </button>
          <button onClick={() => setEditing('new')} className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition active:scale-95">
            <PlusCircle className="h-4 w-4" /> Nouvel article
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 rounded-xl bg-gray-100 p-1 w-fit">
        {([['catalogue', 'Catalogue', Package], ['familles', 'Familles', Layers]] as const).map(([key, label, Icon]) => (
          <button key={key} onClick={() => setTab(key)}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-sm font-medium transition ${tab === key ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>
            <Icon className="h-4 w-4" />{label}
          </button>
        ))}
      </div>

      {/* ── Catalogue tab ── */}
      {tab === 'catalogue' && (
        <div className="flex gap-4">
          {/* Left nav */}
          <aside className="hidden md:flex w-48 shrink-0 flex-col gap-0.5">
            <NavItem
              icon={<Package className="h-4 w-4" />}
              label="Tous"
              count={products.length}
              active={navSel === 'all'}
              onClick={() => setNavSel('all')}
            />
            {families.map(f => (
              <NavItem key={f.id}
                icon={<span className="h-3 w-3 rounded-full shrink-0" style={{ backgroundColor: f.color }} />}
                label={f.name}
                count={products.filter(p => p.family_id === f.id).length}
                active={navSel === f.id}
                onClick={() => setNavSel(f.id)}
              />
            ))}
            {unassignedCount > 0 && (
              <NavItem
                icon={<FolderOpen className="h-4 w-4 text-gray-300" />}
                label="Non classés"
                count={unassignedCount}
                active={navSel === 'uncategorized'}
                onClick={() => setNavSel('uncategorized')}
              />
            )}
          </aside>

          {/* Products table */}
          <div className="flex-1 space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input ref={searchRef} value={query} onChange={e => setQuery(e.target.value)} placeholder="Rechercher par nom, référence, famille…  ( / )"
                className="w-full rounded-lg border border-gray-300 bg-white py-2.5 pl-9 pr-9 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition" />
              {query && (
                <button onClick={() => { setQuery(''); searchRef.current?.focus(); }}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition">
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            {debouncedQuery && (
              <p className="text-xs text-gray-400">{filtered.length} résultat{filtered.length > 1 ? 's' : ''} pour « {debouncedQuery} »</p>
            )}

            <div className="overflow-hidden rounded-xl border border-gray-200">
              {filtered.length === 0 ? (
                <div className="py-14 text-center text-sm text-gray-400">{query ? 'Aucun article trouvé.' : 'Aucun article.'}</div>
              ) : (
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      {['Référence', 'Désignation', 'Famille', 'Unité', locationId ? 'Prix boutique' : 'Prix vente', 'Prix achat', 'Stock', 'Statut', ''].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 first:pl-5">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filtered.map(p => {
                      const lowStock = p.track_stock && p.stock_quantity <= p.stock_min;
                      const fam = p.family;
                      return (
                        <tr key={p.id} className="group bg-white hover:bg-gray-50">
                          <td className="px-4 py-3 pl-5">
                            <p className="text-xs tabular-nums text-gray-500">{p.reference ?? '—'}</p>
                          </td>
                          <td className="px-4 py-3 max-w-[180px]">
                            <div className="flex items-center gap-2.5">
                              {p.photo_url ? (
                                <img src={p.photo_url} alt="" className="h-9 w-9 rounded-lg object-cover border border-gray-200 shrink-0" />
                              ) : (
                                <div className="h-9 w-9 rounded-lg bg-gray-100 flex items-center justify-center shrink-0">
                                  <ImageIcon className="h-4 w-4 text-gray-300" />
                                </div>
                              )}
                              <div className="min-w-0">
                                <p className="font-medium text-gray-800 truncate">{p.name}</p>
                                {p.description && <p className="text-xs text-gray-400 truncate">{p.description}</p>}
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            {fam ? (
                              <span className="flex items-center gap-1.5">
                                <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: fam.color }} />
                                <span className="text-xs text-gray-600">{fam.name}</span>
                              </span>
                            ) : <span className="text-xs text-gray-300">—</span>}
                          </td>
                          <td className="px-4 py-3">
                            <span className="text-gray-500">{p.unit}</span>
                          </td>
                          <td className="px-4 py-3">
                            <p className="tabular-nums font-semibold text-gray-900">{fmt(p.price, currency)}</p>
                            {(p.prices ?? []).length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-1.5">
                                {[...(p.prices ?? [])].sort((a, b) => (a.price_type?.sort_order ?? 0) - (b.price_type?.sort_order ?? 0)).map(pr => (
                                  <span
                                    key={pr.id}
                                    className="inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-semibold"
                                    style={{ backgroundColor: `${pr.price_type?.color}18`, color: pr.price_type?.color }}
                                  >
                                    <span className="h-1.5 w-1.5 rounded-full shrink-0" style={{ backgroundColor: pr.price_type?.color }} />
                                    {pr.price_type?.name} · {fmt(pr.price, currency)}
                                  </span>
                                ))}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-3 tabular-nums text-gray-600">
                            {fmt(p.purchase_price, currency)}
                          </td>
                          <td className={`px-4 py-3 tabular-nums font-medium ${!p.track_stock ? 'text-gray-300' : lowStock ? 'text-amber-400' : 'text-gray-700'}`}>
                            {p.track_stock ? `${fmtQty(p.stock_quantity)} ${p.unit}` : '—'}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${p.active ? 'bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/30' : 'bg-gray-200 text-gray-500 ring-1 ring-gray-300'}`}>
                              {p.active ? 'Actif' : 'Inactif'}
                            </span>
                          </td>
                          <td className="px-4 py-3 pr-4">
                            <div className="flex items-center justify-end gap-1 opacity-60 transition group-hover:opacity-100">
                              <button onClick={() => setEditing(p)} className="rounded p-1.5 text-gray-500 hover:bg-gray-200 hover:text-gray-800">
                                <Pencil className="h-4 w-4" />
                              </button>
                              {confirm === p.id ? (
                                <div className="flex items-center gap-1">
                                  <button onClick={() => onRemove(p.id).then(() => setConfirm(null))} className="rounded px-2 py-1 text-xs font-semibold text-red-400 ring-1 ring-red-800 hover:bg-red-950">Supprimer</button>
                                  <button onClick={() => setConfirm(null)} className="text-xs text-gray-400 px-1">×</button>
                                </div>
                              ) : (
                                <button onClick={() => setConfirm(p.id)} className="rounded p-1.5 text-gray-500 hover:bg-red-950/60 hover:text-red-400">
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── Familles tab ── */}
      {tab === 'familles' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-gray-500">{families.length} famille{families.length > 1 ? 's' : ''}</p>
            <button onClick={() => setFamilyModal('new')} className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition active:scale-95">
              <PlusCircle className="h-4 w-4" /> Nouvelle famille
            </button>
          </div>

          {families.length === 0 ? (
            <div className="rounded-xl border border-dashed border-gray-300 py-14 text-center text-sm text-gray-400">
              Aucune famille. Créez-en une pour organiser vos articles.
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {families.map(f => {
                const count = products.filter(p => p.family_id === f.id).length;
                return (
                  <div key={f.id} className="group rounded-xl border border-gray-200 bg-white p-4 flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full shrink-0 flex items-center justify-center" style={{ backgroundColor: f.color + '22' }}>
                      <span className="h-5 w-5 rounded-full" style={{ backgroundColor: f.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-800 truncate">{f.name}</p>
                      <p className="text-xs text-gray-400">{count} article{count > 1 ? 's' : ''}</p>
                    </div>
                    <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100 transition">
                      <button onClick={() => setFamilyModal(f)} className="rounded p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-700">
                        <Pencil className="h-4 w-4" />
                      </button>
                      {confirmFamily === f.id ? (
                        <div className="flex items-center gap-1">
                          <button onClick={() => onRemoveFamily(f.id).then(() => setConfirmFamily(null))} className="rounded px-2 py-1 text-xs text-red-400 ring-1 ring-red-800 hover:bg-red-950">Suppr.</button>
                          <button onClick={() => setConfirmFamily(null)} className="text-xs text-gray-400 px-1">×</button>
                        </div>
                      ) : (
                        <button onClick={() => setConfirmFamily(f.id)} className="rounded p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-400">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Product modal */}
      {editing !== null && (
        <Modal title={editing === 'new' ? 'Nouvel article' : 'Modifier l\'article'} onClose={() => setEditing(null)}>
          <ProductForm
            initial={editing === 'new' ? undefined : editing}
            currency={currency}
            families={families}
            priceTypes={priceTypes}
            suppliers={suppliers}
            locationId={locationId}
            locations={locations ?? []}
            knownUnits={knownUnits}
            customUnits={customUnits}
            onAddUnit={addUnit}
            onRemoveUnit={removeUnit}
            onFetchProductLocations={onFetchProductLocations}
            onSaveProductLocations={onSaveProductLocations}
            onFetchLocationProductPrices={onFetchLocationProductPrices}
            onSaveLocationProductPrices={onSaveLocationProductPrices}
            onFetchProductSuppliers={onFetchProductSuppliers}
            onSaveProductSuppliers={onSaveProductSuppliers}
            onSubmit={d => onSave(d, editing === 'new' ? undefined : (editing as Product).id)}
            onSavePrices={onSavePrices}
            onClose={() => setEditing(null)}
          />
        </Modal>
      )}

      {/* Family modal */}
      {familyModal !== null && (
        <Modal title={familyModal === 'new' ? 'Nouvelle famille' : 'Modifier la famille'} onClose={() => setFamilyModal(null)}>
          <FamilyForm
            initial={familyModal === 'new' ? undefined : familyModal}
            families={families}
            onSubmit={d => onSaveFamily(d, familyModal === 'new' ? undefined : (familyModal as ProductFamily).id)}
            onClose={() => setFamilyModal(null)}
          />
        </Modal>
      )}

      {/* Import modal */}
      <ImportProductsModal
        open={showImport}
        onClose={() => setShowImport(false)}
        onImport={onBulkImport}
        locations={locations ?? []}
        defaultLocationId={locationId}
        priceTypes={priceTypes}
      />
    </div>
  );
}

// ── Nav Item ─────────────────────────────────────────────────────
function NavItem({ icon, label, count, active, onClick }: {
  icon: React.ReactNode; label: string; count: number; active: boolean; onClick: () => void;
}) {
  return (
    <button onClick={onClick}
      className={`w-full flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-sm transition text-left ${active ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-600 hover:bg-gray-100'}`}>
      {icon}
      <span className="flex-1 truncate">{label}</span>
      <span className={`text-xs tabular-nums ${active ? 'text-blue-500' : 'text-gray-400'}`}>{count}</span>
    </button>
  );
}
