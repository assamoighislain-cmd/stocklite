import { useState, useMemo, useRef, useCallback } from 'react';
import { ClipboardList, Search, CheckCircle2, AlertCircle, Save, Loader2, FileDown, ArrowDown, Minus } from 'lucide-react';
import type { Product } from '../types';
import { fmtQty } from '../lib/format';
import { translateError } from '../lib/translateError';
import { exportHtmlToPdf } from '../lib/pdf';
import { printDocument } from '../lib/printEngine';

interface InventoryPageProps {
  products: Product[];
  onValidate: (entries: { product_id: string; real_quantity: number; notes?: string }[]) => Promise<void>;
}

export function InventoryPage({ products, onValidate }: InventoryPageProps) {
  const [search, setSearch] = useState('');
  const [realQtys, setRealQtys] = useState<Record<string, string>>({});
  const [globalNote, setGlobalNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [pdfSaving, setPdfSaving] = useState(false);
  const inputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const trackedProducts = useMemo(
    () => products.filter(p => p.track_stock && p.active),
    [products]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return trackedProducts;
    return trackedProducts.filter(p =>
      p.name.toLowerCase().includes(q) ||
      (p.reference ?? '').toLowerCase().includes(q)
    );
  }, [trackedProducts, search]);

  const entriesWithEcart = useMemo(() => {
    return filtered.map(p => {
      const realStr = realQtys[p.id];
      const real = realStr != null && realStr !== '' ? parseFloat(realStr) : null;
      const ecart = real != null ? Math.round((real - p.stock_quantity) * 100) / 100 : null;
      return { product: p, real, ecart };
    });
  }, [filtered, realQtys]);

  const stats = useMemo(() => {
    let counted = 0;
    let withEcart = 0;
    let totalPieces = 0;
    for (const e of entriesWithEcart) {
      if (e.real != null) counted++;
      if (e.ecart != null && e.ecart !== 0) withEcart++;
      totalPieces += e.product.stock_quantity;
    }
    return { counted, total: filtered.length, withEcart, totalPieces };
  }, [entriesWithEcart]);

  const filteredIds = useMemo(() => filtered.map(p => p.id), [filtered]);

  const focusNextInput = useCallback((currentId: string) => {
    const idx = filteredIds.indexOf(currentId);
    if (idx < 0 || idx >= filteredIds.length - 1) return;
    const nextId = filteredIds[idx + 1];
    const nextInput = inputRefs.current[nextId];
    if (nextInput) {
      nextInput.focus();
      nextInput.select();
    }
  }, [filteredIds]);

  function setRealQty(productId: string, value: string) {
    setRealQtys(prev => ({ ...prev, [productId]: value }));
    setSuccess(false);
  }

  function setInputRef(productId: string, el: HTMLInputElement | null) {
    inputRefs.current[productId] = el;
  }

  function fillFromVirtual() {
    const newQtys: Record<string, string> = {};
    for (const p of trackedProducts) {
      newQtys[p.id] = String(p.stock_quantity);
    }
    setRealQtys(newQtys);
    setSuccess(false);
  }

  async function handleValidate() {
    const entries: { product_id: string; real_quantity: number; notes?: string }[] = [];
    for (const p of trackedProducts) {
      const realStr = realQtys[p.id];
      if (realStr == null || realStr === '') continue;
      const real = parseFloat(realStr);
      if (Number.isNaN(real) || real < 0) continue;
      entries.push({ product_id: p.id, real_quantity: real, notes: globalNote || undefined });
    }
    if (entries.length === 0) {
      setError('Saisissez au moins une quantité réelle avant de valider.');
      return;
    }
    setSaving(true);
    setError('');
    setSuccess(false);
    try {
      await onValidate(entries);
      setSuccess(true);
      setRealQtys({});
      setGlobalNote('');
    } catch (e) {
      setError(e instanceof Error ? translateError(e.message) : 'Erreur lors de la validation');
    } finally {
      setSaving(false);
    }
  }

  async function handleExportPdf() {
    setPdfSaving(true);
    setError('');
    try {
      const now = new Date();
      const dateStr = now.toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' });
      const f = (n: number | null | undefined) =>
        new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(n ?? 0);

      const rows = entriesWithEcart.map(({ product: p, real, ecart }) => {
        const ecartColor = ecart == null ? '#999' : ecart > 0 ? '#059669' : ecart < 0 ? '#dc2626' : '#999';
        const ecartSign = ecart != null && ecart > 0 ? '+' : '';
        return `<tr>
          <td style="text-align:left;padding:6px 10px;border-bottom:1px solid #e5e7eb;font-size:12px;color:#6b7280;font-family:monospace;">${p.reference ?? '—'}</td>
          <td style="text-align:left;padding:6px 10px;border-bottom:1px solid #e5e7eb;font-size:13px;font-weight:600;color:#1f2937;">${p.name}<br><span style="font-size:10px;color:#9ca3af;font-weight:400;">${p.unit}</span></td>
          <td style="text-align:right;padding:6px 10px;border-bottom:1px solid #e5e7eb;font-size:13px;font-weight:600;color:#374151;">${f(p.stock_quantity)}</td>
          <td style="text-align:right;padding:6px 10px;border-bottom:1px solid #e5e7eb;font-size:13px;font-weight:700;color:#1f2937;">${real != null ? f(real) : '—'}</td>
          <td style="text-align:right;padding:6px 10px;border-bottom:1px solid #e5e7eb;font-size:13px;font-weight:700;color:${ecartColor};">${ecart == null ? '—' : ecartSign + f(ecart)}</td>
        </tr>`;
      }).join('');

      const html = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<title>Fiche d'inventaire</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, 'Segoe UI', Roboto, sans-serif; color: #111; background: #fff; padding: 24px; }
  h1 { font-size: 22px; font-weight: 800; color: #1e3a5f; margin-bottom: 4px; }
  .subtitle { font-size: 13px; color: #6b7280; margin-bottom: 16px; }
  .meta { display: flex; gap: 24px; margin-bottom: 16px; }
  .meta-item { font-size: 12px; }
  .meta-label { color: #9ca3af; font-weight: 600; text-transform: uppercase; font-size: 10px; letter-spacing: 0.5px; }
  .meta-value { color: #1f2937; font-weight: 600; }
  .stats { display: flex; gap: 12px; margin-bottom: 20px; }
  .stat { flex: 1; border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px 16px; }
  .stat-label { font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; }
  .stat-value { font-size: 20px; font-weight: 700; color: #1f2937; margin-top: 2px; }
  table { width: 100%; border-collapse: collapse; }
  th { background: #f3f4f6; padding: 8px 10px; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; border-bottom: 2px solid #d1d5db; }
  .note { margin-top: 20px; font-size: 12px; color: #6b7280; }
  .note-label { font-weight: 600; color: #374151; }
  .footer { margin-top: 32px; border-top: 1px solid #e5e7eb; padding-top: 12px; font-size: 10px; color: #9ca3af; text-align: center; }
</style></head><body>
  <h1>Fiche d'inventaire</h1>
  <p class="subtitle">Comptage physique du stock</p>
  <div class="meta">
    <div class="meta-item"><p class="meta-label">Date</p><p class="meta-value">${dateStr}</p></div>
    <div class="meta-item"><p class="meta-label">Références</p><p class="meta-value">${stats.total}</p></div>
    <div class="meta-item"><p class="meta-label">Total pièces</p><p class="meta-value">${f(stats.totalPieces)}</p></div>
    <div class="meta-item"><p class="meta-label">Comptés</p><p class="meta-value">${stats.counted}</p></div>
    <div class="meta-item"><p class="meta-label">Avec écart</p><p class="meta-value" style="color:${stats.withEcart > 0 ? '#d97706' : '#059669'}">${stats.withEcart}</p></div>
  </div>
  <table>
    <thead>
      <tr>
        <th style="text-align:left;">Réf.</th>
        <th style="text-align:left;">Désignation</th>
        <th style="text-align:right;">Stock virtuel</th>
        <th style="text-align:right;">Stock réel</th>
        <th style="text-align:right;">Écart</th>
      </tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>
  ${globalNote ? `<p class="note"><span class="note-label">Motif : </span>${globalNote}</p>` : ''}
  <div class="footer">Document généré automatiquement — Stocklite</div>
</body></html>`;

      await exportHtmlToPdf(html, `inventaire-${now.toISOString().slice(0, 10)}.pdf`, 'a4');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur lors de l\'export PDF');
    } finally {
      setPdfSaving(false);
    }
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-lg font-bold text-gray-900">
            <ClipboardList className="h-5 w-5 text-blue-600" />
            Inventaire
          </h1>
          <p className="text-sm text-gray-400">
            Comptage physique et ajustement automatique du stock
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleExportPdf}
            disabled={pdfSaving || filtered.length === 0}
            className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
          >
            <FileDown className="h-4 w-4" />
            {pdfSaving ? 'PDF…' : 'Exporter PDF'}
          </button>
          <button
            onClick={fillFromVirtual}
            className="rounded-lg border border-gray-300 bg-gray-100 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200 transition"
          >
            Pré-remplir avec le stock virtuel
          </button>
          <button
            onClick={handleValidate}
            disabled={saving || stats.counted === 0}
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            {saving ? 'Validation…' : 'Valider l\'inventaire'}
          </button>
        </div>
      </div>

      {/* Info banner */}
      <div className="flex items-start gap-3 rounded-xl border border-blue-200 bg-blue-50/50 p-4">
        <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-blue-500" />
        <div className="text-sm text-blue-800">
          <p className="font-semibold">Comment ça marche</p>
          <p className="mt-0.5 text-blue-700">
            Saisissez la quantité comptée physiquement pour chaque article. L'écart avec le stock virtuel est calculé automatiquement.
            Appuyez sur <kbd className="rounded border border-blue-300 bg-white px-1.5 py-0.5 text-[10px] font-bold text-blue-700">Entrée</kbd> pour passer à la ligne suivante.
            Au clic sur « Valider », le stock est ajusté à la quantité réelle et un mouvement d'inventaire est enregistré pour chaque écart.
          </p>
        </div>
      </div>

      {/* Summary chips */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Références</p>
          <p className="mt-1 text-xl font-bold text-gray-900">{stats.total}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Total pièces</p>
          <p className="mt-1 text-xl font-bold text-gray-900">{fmtQty(stats.totalPieces)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Articles comptés</p>
          <p className="mt-1 text-xl font-bold text-blue-600">{stats.counted}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Avec écart</p>
          <p className={`mt-1 text-xl font-bold ${stats.withEcart > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
            {stats.withEcart}
          </p>
        </div>
      </div>

      {/* Search + note */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Rechercher par référence ou désignation…"
            className="w-full rounded-lg border border-gray-300 bg-white py-2 pl-9 pr-3 text-sm text-gray-800 outline-none focus:border-blue-500 transition"
          />
        </div>
        <input
          type="text"
          value={globalNote}
          onChange={e => setGlobalNote(e.target.value)}
          placeholder="Note globale (motif d'inventaire)…"
          className="flex-1 min-w-[200px] rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 transition"
        />
      </div>

      {/* Error / success messages */}
      {error && (
        <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-600">{error}</div>
      )}
      {success && (
        <div className="flex items-center gap-2 rounded-lg bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700">
          <CheckCircle2 className="h-4 w-4" />
          Inventaire validé. Le stock a été ajusté pour chaque article avec écart.
        </div>
      )}

      {/* Inventory table */}
      <div className="overflow-auto rounded-xl border border-gray-200" style={{ maxHeight: '70vh' }}>
        {filtered.length === 0 ? (
          <div className="py-14 text-center text-sm text-gray-400">Aucun article à inventorier.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 w-28">Réf.</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Désignation</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400 w-32">Stock virtuel</th>
                <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-gray-400 w-36">Stock réel</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400 w-24">Écart</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {entriesWithEcart.map(({ product: p, real, ecart }) => {
                const hasEcart = ecart != null && ecart !== 0;
                const ecartPositive = ecart != null && ecart > 0;
                const isCounted = real != null;
                return (
                  <tr key={p.id} className={`transition ${hasEcart ? (ecartPositive ? 'bg-emerald-50/40' : 'bg-red-50/40') : isCounted ? 'bg-blue-50/30' : 'bg-white'} hover:bg-gray-50/60`}>
                    <td className="px-4 py-2.5 text-xs tabular-nums text-gray-500">
                      {p.reference || <span className="text-gray-300">—</span>}
                    </td>
                    <td className="px-4 py-2.5">
                      <p className="font-semibold text-gray-800">{p.name}</p>
                      <p className="text-xs text-gray-400">{p.unit}</p>
                    </td>
                    <td className="px-4 py-2.5 text-right tabular-nums font-semibold text-gray-700">
                      {fmtQty(p.stock_quantity)}
                    </td>
                    <td className="px-4 py-2">
                      <input
                        ref={el => setInputRef(p.id, el)}
                        type="number"
                        step="0.01"
                        min="0"
                        value={realQtys[p.id] ?? ''}
                        onChange={e => setRealQty(p.id, e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            focusNextInput(p.id);
                          }
                        }}
                        placeholder="—"
                        className={`w-full rounded-lg border-2 px-2.5 py-2 text-center text-base tabular-nums font-semibold outline-none transition ${
                          hasEcart
                            ? ecartPositive
                              ? 'border-emerald-400 bg-emerald-50 text-emerald-900 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100'
                              : 'border-red-400 bg-red-50 text-red-900 focus:border-red-500 focus:ring-2 focus:ring-red-100'
                            : 'border-gray-300 bg-white text-gray-900 focus:border-blue-500 focus:ring-2 focus:ring-blue-100'
                        }`}
                      />
                    </td>
                    <td className={`px-4 py-2.5 text-right tabular-nums text-base font-bold ${
                      !hasEcart ? 'text-gray-300' : ecartPositive ? 'text-emerald-600' : 'text-red-500'
                    }`}>
                      {ecart == null ? (
                        <span className="text-gray-200">—</span>
                      ) : ecart === 0 ? (
                        <span className="inline-flex items-center gap-0.5 text-gray-400">
                          <Minus className="h-3.5 w-3.5" />
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-0.5">
                          {ecart > 0 ? '+' : ''}{fmtQty(ecart)}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {filtered.length > 0 && (
        <div className="flex items-center justify-between">
          <p className="text-xs text-gray-400">
            {stats.counted} / {stats.total} articles comptés
            {stats.withEcart > 0 && ` · ${stats.withEcart} avec écart`}
          </p>
          <p className="flex items-center gap-1 text-xs text-gray-400">
            <ArrowDown className="h-3 w-3" />
            <kbd className="rounded border border-gray-300 bg-gray-50 px-1.5 py-0.5 text-[10px] font-bold text-gray-600">Entrée</kbd>
            pour passer à la ligne suivante
          </p>
        </div>
      )}
    </div>
  );
}
