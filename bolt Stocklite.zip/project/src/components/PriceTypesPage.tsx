import { useState } from 'react';
import { Plus, Pencil, Trash2, Tag } from 'lucide-react';
import type { PriceType } from '../types';
import type { usePriceTypes } from '../hooks/usePriceTypes';

interface Props {
  priceTypes: PriceType[];
  loading: boolean;
  onSave: ReturnType<typeof usePriceTypes>['save'];
  onRemove: ReturnType<typeof usePriceTypes>['remove'];
}

const PRESET_COLORS = [
  '#3b82f6', '#10b981', '#f59e0b', '#ef4444',
  '#8b5cf6', '#06b6d4', '#f97316', '#6b7280',
];

const EMPTY: Omit<PriceType, 'id' | 'created_at'> = {
  name: '', color: '#3b82f6', sort_order: 0, active: true, is_default: false,
};

export default function PriceTypesPage({ priceTypes, loading, onSave, onRemove }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<PriceType | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  function openNew() {
    setEditing(null);
    setForm({ ...EMPTY, sort_order: priceTypes.length });
    setShowForm(true);
  }

  function openEdit(p: PriceType) {
    setEditing(p);
    setForm({ name: p.name, color: p.color, sort_order: p.sort_order, active: p.active, is_default: p.is_default });
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      await onSave({ ...form, ...(editing ? { id: editing.id } : {}) });
      setShowForm(false);
      setEditing(null);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Types de prix</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Définissez les grilles tarifaires (Détail, Gros, Demi-gros…)
          </p>
        </div>
        <button
          onClick={openNew}
          className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95"
        >
          <Plus className="h-4 w-4" />
          Nouveau type
        </button>
      </div>

      {loading ? (
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-14 rounded-xl bg-gray-100 animate-pulse" />
          ))}
        </div>
      ) : priceTypes.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-300 py-16 text-center">
          <Tag className="h-10 w-10 text-gray-300 mb-3" />
          <p className="text-sm font-medium text-gray-400">Aucun type de prix</p>
          <p className="text-xs text-gray-400 mt-1">Créez des grilles tarifaires pour les assigner aux articles.</p>
          <button onClick={openNew} className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition">
            Créer un type de prix
          </button>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white divide-y divide-gray-100">
          {priceTypes.map(pt => (
            <div key={pt.id} className="flex items-center gap-4 px-5 py-4">
              <span
                className="h-3 w-3 rounded-full shrink-0"
                style={{ backgroundColor: pt.color }}
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-gray-900">{pt.name}</p>
                  {pt.is_default && (
                    <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-600 ring-1 ring-blue-200">
                      Défaut
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-400">Ordre : {pt.sort_order}</p>
              </div>
              <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-semibold ${pt.active ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-400'}`}>
                {pt.active ? 'Actif' : 'Inactif'}
              </span>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => openEdit(pt)} className="rounded-lg p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-700 transition">
                  <Pencil className="h-4 w-4" />
                </button>
                <button onClick={() => setConfirmDelete(pt.id)} className="rounded-lg p-2 text-gray-400 hover:bg-red-50 hover:text-red-500 transition">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Info box */}
      {priceTypes.length > 0 && (
        <div className="rounded-xl border border-blue-100 bg-blue-50 px-4 py-3">
          <p className="text-xs text-blue-700 font-medium">
            Les prix par type se configurent dans la fiche de chaque article (page Articles).
            En caisse, le caissier peut choisir le type de prix avant ou pendant la vente.
          </p>
        </div>
      )}

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white shadow-2xl overflow-hidden">
            <div className="border-b border-gray-100 px-6 py-4">
              <h2 className="text-base font-semibold text-gray-900">
                {editing ? 'Modifier le type de prix' : 'Nouveau type de prix'}
              </h2>
            </div>
            <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Nom *</label>
                <input
                  autoFocus
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  required
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                  placeholder="Ex : Détail, Gros, Demi-gros…"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-2">Couleur</label>
                <div className="flex items-center gap-2 flex-wrap">
                  {PRESET_COLORS.map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setForm(f => ({ ...f, color: c }))}
                      className={`h-7 w-7 rounded-full transition ${form.color === c ? 'ring-2 ring-offset-2 ring-gray-500 scale-110' : 'hover:scale-110'}`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                  <input
                    type="color"
                    value={form.color}
                    onChange={e => setForm(f => ({ ...f, color: e.target.value }))}
                    className="h-7 w-7 rounded-full cursor-pointer border-0 p-0 bg-transparent"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Ordre d'affichage</label>
                  <input
                    type="number"
                    min="0"
                    value={form.sort_order}
                    onChange={e => setForm(f => ({ ...f, sort_order: parseInt(e.target.value) || 0 }))}
                    className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input type="checkbox" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} className="h-4 w-4 rounded border-gray-300 accent-blue-600" />
                  <span className="text-sm text-gray-700">Actif</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input type="checkbox" checked={form.is_default} onChange={e => setForm(f => ({ ...f, is_default: e.target.checked }))} className="h-4 w-4 rounded border-gray-300 accent-blue-600" />
                  <span className="text-sm text-gray-700">Tarif par défaut</span>
                </label>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition">
                  Annuler
                </button>
                <button type="submit" disabled={saving} className="flex-1 rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50">
                  {saving ? 'Enregistrement…' : editing ? 'Mettre à jour' : 'Créer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white shadow-2xl p-6 space-y-4">
            <p className="text-sm font-medium text-gray-800">Supprimer ce type de prix ?</p>
            <p className="text-xs text-gray-500">Les prix des articles utilisant ce type seront également supprimés.</p>
            <div className="flex gap-3">
              <button onClick={() => setConfirmDelete(null)} className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition">Annuler</button>
              <button onClick={async () => { await onRemove(confirmDelete); setConfirmDelete(null); }} className="flex-1 rounded-xl bg-red-600 py-2.5 text-sm font-semibold text-white hover:bg-red-500 transition">Supprimer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
