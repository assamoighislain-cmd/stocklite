import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, PlusCircle, CreditCard, FileText, Phone, MapPin, Mail, User, Trash2, Pencil, Star } from 'lucide-react';
import type { Customer, CustomerContact, Invoice, Payment, PaymentMethod } from '../types';
import { ALL_PAYMENT_METHODS, METHOD_LABELS } from '../types';
import { StatusBadge } from './StatusBadge';
import type { Route } from '../App';
import { translateError } from '../lib/translateError';
import { Modal } from './Modal';

interface Props {
  customer: Customer;
  onNavigate: (r: Route) => void;
  fetchInvoices: (customerId: string) => Promise<Invoice[]>;
  recordPayment: (payload: {
    customer_id: string;
    invoice_id: string | null;
    amount: number;
    method: PaymentMethod;
    payment_date: string;
    notes: string;
  }) => Promise<Payment>;
  applyPaymentToInvoice: (id: string, input: { status: import('../types').InvoiceStatus }) => Promise<void>;
  fetchPayments: (customerId: string) => Promise<Payment[]>;
  fetchContacts: (customerId: string) => Promise<CustomerContact[]>;
  onSaveContact: (payload: Omit<CustomerContact, 'id' | 'created_at' | 'updated_at'>, id?: string) => Promise<CustomerContact>;
  onRemoveContact: (id: string) => Promise<void>;
}

function fmt(n: number) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n);
}
function fmtDate(d: string | null | undefined) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function CustomerDetail({
  customer, onNavigate, fetchInvoices, recordPayment, applyPaymentToInvoice, fetchPayments, fetchContacts, onSaveContact, onRemoveContact,
}: Props) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [contacts, setContacts] = useState<CustomerContact[]>([]);
  const [tab, setTab] = useState<'invoices' | 'payments' | 'contacts'>('invoices');
  const [loading, setLoading] = useState(true);
  const [showPayForm, setShowPayForm] = useState(false);
  const [payInvoiceId, setPayInvoiceId] = useState<string>('');
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('especes');
  const [payDate, setPayDate] = useState(new Date().toISOString().slice(0, 10));
  const [payNotes, setPayNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [contactEditing, setContactEditing] = useState<CustomerContact | null | 'new'>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const [invs, pays, cnts] = await Promise.all([
      fetchInvoices(customer.id),
      fetchPayments(customer.id),
      fetchContacts(customer.id),
    ]);
    setInvoices(invs);
    setPayments(pays);
    setContacts(cnts);
    setLoading(false);
  }, [customer.id, fetchInvoices, fetchPayments, fetchContacts]);

  useEffect(() => { load(); }, [load]);

  const totalInvoiced = invoices.reduce((s, i) => s + i.total, 0);
  const totalPaid     = invoices.reduce((s, i) => s + i.amount_paid, 0);
  const balance       = invoices.reduce((s, i) => s + i.balance_due, 0);

  async function handleRecordPayment(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      await recordPayment({
        customer_id: customer.id,
        invoice_id:  payInvoiceId || null,
        amount:      parseFloat(payAmount),
        method:      payMethod,
        payment_date: payDate,
        notes:        payNotes,
      });
      if (payInvoiceId) {
        const inv = invoices.find(i => i.id === payInvoiceId);
        if (inv) {
          const newPaid = inv.amount_paid + parseFloat(payAmount);
          const newStatus = newPaid >= inv.total ? 'payee' : 'partielle';
          await applyPaymentToInvoice(payInvoiceId, { status: newStatus });
        }
      }
      setShowPayForm(false);
      setPayAmount('');
      setPayNotes('');
      setPayInvoiceId('');
      await load();
    } catch (err: unknown) {
      setError(err instanceof Error ? translateError(err.message) : 'Erreur');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => onNavigate({ page: 'customers' })}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Clients
        </button>
      </div>

      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{customer.name}</h1>
          <div className="mt-1 flex flex-wrap gap-4 text-sm text-gray-500">
            <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ${customer.type === 'entreprise' ? 'bg-blue-50 text-blue-700' : 'bg-gray-100 text-gray-600'}`}>
              {customer.type === 'entreprise' ? 'Entreprise' : 'Particulier'}
            </span>
            {customer.type === 'entreprise' && customer.ncc && (
              <span className="flex items-center gap-1.5 font-mono text-xs"><CreditCard className="h-3.5 w-3.5" />NCC : {customer.ncc}</span>
            )}
            {customer.phone && (
              <span className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" />{customer.phone}</span>
            )}
            {customer.email && (
              <span className="flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" />{customer.email}</span>
            )}
            {customer.city && (
              <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" />{customer.city}</span>
            )}
          </div>
        </div>
        <div className="flex gap-2 flex-shrink-0">
          <button
            onClick={() => onNavigate({ page: 'invoice-form', customerId: customer.id })}
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition-colors"
          >
            <FileText className="h-4 w-4" />
            Nouvelle facture
          </button>
          <button
            onClick={() => setShowPayForm(v => !v)}
            className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
          >
            <CreditCard className="h-4 w-4" />
            Encaisser
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Facturé', value: fmt(totalInvoiced), color: 'text-gray-900' },
          { label: 'Payé', value: fmt(totalPaid), color: 'text-emerald-600' },
          { label: 'Solde dû', value: fmt(balance), color: balance > 0 ? 'text-red-600' : 'text-gray-400' },
        ].map(kpi => (
          <div key={kpi.label} className="rounded-xl border border-gray-200 bg-white p-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">{kpi.label}</p>
            <p className={`mt-1 text-xl font-bold tabular-nums ${kpi.color}`}>{kpi.value}</p>
          </div>
        ))}
      </div>

      {/* Payment form */}
      {showPayForm && (
        <form onSubmit={handleRecordPayment} className="rounded-xl border border-gray-200 bg-white p-5 space-y-4">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <PlusCircle className="h-4 w-4 text-blue-600" />
            Enregistrer un paiement
          </h3>
          {error && <p className="text-sm text-red-500">{error}</p>}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Facture (optionnel)</label>
              <select className="input" value={payInvoiceId} onChange={e => setPayInvoiceId(e.target.value)}>
                <option value="">— Paiement libre —</option>
                {invoices.filter(i => i.status !== 'payee' && i.status !== 'annulee').map(i => (
                  <option key={i.id} value={i.id}>{i.invoice_number} — {fmt(i.balance_due)}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Montant</label>
              <input type="number" min="0" step="0.01" className="input" required
                value={payAmount} onChange={e => setPayAmount(e.target.value)} />
            </div>
            <div>
              <label className="label">Mode de règlement</label>
              <select className="input" value={payMethod} onChange={e => setPayMethod(e.target.value as PaymentMethod)}>
                {ALL_PAYMENT_METHODS.map(m => (
                  <option key={m.value} value={m.value}>{m.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Date</label>
              <input type="date" className="input" required value={payDate} onChange={e => setPayDate(e.target.value)} />
            </div>
          </div>
          <div>
            <label className="label">Notes</label>
            <input type="text" className="input" placeholder="Référence, remarque…"
              value={payNotes} onChange={e => setPayNotes(e.target.value)} />
          </div>
          <div className="flex gap-2 justify-end">
            <button type="button" onClick={() => setShowPayForm(false)}
              className="px-4 py-2 rounded-lg border border-gray-300 text-gray-600 text-sm hover:bg-gray-50 transition-colors">
              Annuler
            </button>
            <button type="submit" disabled={saving}
              className="px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-500 disabled:opacity-50 transition-colors">
              {saving ? 'Enregistrement…' : 'Enregistrer'}
            </button>
          </div>
        </form>
      )}

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <div className="flex gap-6">
          {(['invoices', 'payments', 'contacts'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`pb-3 text-sm font-semibold transition-colors border-b-2 -mb-px ${
                tab === t ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-800'
              }`}>
              {t === 'invoices' ? `Factures (${invoices.length})` : t === 'payments' ? `Paiements (${payments.length})` : `Contacts (${contacts.length})`}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="h-40 animate-pulse rounded-xl bg-gray-100" />
      ) : tab === 'invoices' ? (
        <div className="rounded-xl border border-gray-200 bg-white overflow-hidden">
          {invoices.length === 0 ? (
            <p className="py-12 text-center text-sm text-gray-400">Aucune facture</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">N°</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Statut</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider">Total</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider">Solde</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {invoices.map(inv => (
                  <tr key={inv.id}
                    onClick={() => onNavigate({ page: 'invoice-detail', id: inv.id })}
                    className="cursor-pointer hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-mono text-xs text-blue-600">{inv.invoice_number}</td>
                    <td className="px-4 py-3 text-gray-600">{fmtDate(inv.date)}</td>
                    <td className="px-4 py-3"><StatusBadge status={inv.status} /></td>
                    <td className="px-4 py-3 text-right tabular-nums text-gray-800 font-medium">{fmt(inv.total)}</td>
                    <td className={`px-4 py-3 text-right tabular-nums font-semibold ${inv.balance_due > 0 ? 'text-red-600' : 'text-gray-400'}`}>
                      {fmt(inv.balance_due)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ) : tab === 'payments' ? (
        <div className="rounded-xl border border-gray-200 bg-white overflow-hidden">
          {payments.length === 0 ? (
            <p className="py-12 text-center text-sm text-gray-400">Aucun paiement</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Mode</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Facture</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider">Montant</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {payments.map(p => (
                  <tr key={p.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-gray-600">{fmtDate(p.payment_date)}</td>
                    <td className="px-4 py-3 text-gray-700">{METHOD_LABELS[p.method]}</td>
                    <td className="px-4 py-3 font-mono text-xs text-blue-600">
                      {p.invoice?.invoice_number ?? '—'}
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums font-semibold text-emerald-600">
                      +{fmt(p.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-400">
              {contacts.length} contact{contacts.length > 1 ? 's' : ''}
            </p>
            <button
              onClick={() => setContactEditing('new')}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition active:scale-95"
            >
              <PlusCircle className="h-4 w-4" /> Ajouter un interlocuteur
            </button>
          </div>
          {contacts.length === 0 ? (
            <div className="rounded-xl border border-gray-200 bg-white py-12 text-center text-sm text-gray-400">
              Aucun interlocuteur. Ajoutez les personnes de contact de cette entreprise.
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {contacts.map(c => (
                <div key={c.id} className="group rounded-xl border border-gray-200 bg-white p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-50">
                        <User className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-gray-900">{c.name}</p>
                          {c.is_default && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-600">
                              <Star className="h-3 w-3" /> Principal
                            </span>
                          )}
                        </div>
                        {c.title && <p className="text-xs text-gray-500">{c.title}</p>}
                      </div>
                    </div>
                    <div className="flex gap-1 opacity-0 transition group-hover:opacity-100">
                      <button onClick={() => setContactEditing(c)} className="rounded p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-700">
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={async () => { await onRemoveContact(c.id); setContacts(await fetchContacts(customer.id)); }}
                        className="rounded p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="mt-3 space-y-1 text-sm">
                    {c.phone && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="h-3.5 w-3.5 text-gray-400" /> {c.phone}
                      </div>
                    )}
                    {c.email && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Mail className="h-3.5 w-3.5 text-gray-400" /> {c.email}
                      </div>
                    )}
                    {c.notes && <p className="pt-1 text-xs text-gray-400">{c.notes}</p>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {contactEditing !== null && (
        <ContactFormModal
          customerId={customer.id}
          initial={contactEditing === 'new' ? null : contactEditing}
          onClose={() => setContactEditing(null)}
          onSave={async (payload, id) => {
            await onSaveContact(payload, id);
            setContacts(await fetchContacts(customer.id));
            setContactEditing(null);
          }}
        />
      )}
    </div>
  );
}

function ContactFormModal({
  customerId,
  initial,
  onClose,
  onSave,
}: {
  customerId: string;
  initial: CustomerContact | null;
  onClose: () => void;
  onSave: (payload: Omit<CustomerContact, 'id' | 'created_at' | 'updated_at'>, id?: string) => Promise<void>;
}) {
  const [form, setForm] = useState({
    name: initial?.name ?? '',
    title: initial?.title ?? '',
    phone: initial?.phone ?? '',
    email: initial?.email ?? '',
    is_default: initial?.is_default ?? false,
    notes: initial?.notes ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  function set(k: string, v: string | boolean) { setForm(f => ({ ...f, [k]: v })); }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setErr('Le nom est requis.'); return; }
    setSaving(true);
    try {
      await onSave(
        {
          customer_id: customerId,
          name: form.name.trim(),
          title: form.title.trim() || null,
          phone: form.phone,
          email: form.email,
          is_default: form.is_default,
          notes: form.notes,
        },
        initial?.id
      );
    } catch (e) {
      setErr(e instanceof Error ? translateError(e.message) : 'Erreur');
      setSaving(false);
    }
  }

  return (
    <Modal title={initial ? 'Modifier l\'interlocuteur' : 'Nouvel interlocuteur'} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4 p-5">
        <div>
          <label className="label">Nom complet *</label>
          <input className="input" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Ex : Jean Kouassi" />
        </div>
        <div>
          <label className="label">Fonction / Poste</label>
          <input className="input" value={form.title} onChange={e => set('title', e.target.value)} placeholder="Ex : Directeur des achats" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Téléphone</label>
            <input className="input" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+xxx" />
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" className="input" value={form.email} onChange={e => set('email', e.target.value)} placeholder="mail@example.com" />
          </div>
        </div>
        <div>
          <label className="label">Notes</label>
          <input className="input" value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="Optionnel" />
        </div>
        <label className="flex items-center gap-2 text-sm text-gray-600">
          <input
            type="checkbox"
            checked={form.is_default}
            onChange={e => set('is_default', e.target.checked)}
            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          />
          Contact principal
        </label>
        {err && <p className="text-xs text-red-400">{err}</p>}
        <div className="flex gap-2 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-lg border border-gray-300 py-2.5 text-sm text-gray-500 hover:bg-gray-100">Annuler</button>
          <button type="submit" disabled={saving} className="flex-1 rounded-lg bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
