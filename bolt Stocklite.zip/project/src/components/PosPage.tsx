import { useState, useMemo, useRef, useEffect } from 'react';
import {
  Search, Plus, Minus, Trash2, ShoppingCart, X, CheckCircle, Printer,
  Users, ArrowLeft, Pause, Play, UserCheck, Tag, AlertTriangle, Unlock, FileDown, Receipt, Package, RotateCcw,
} from 'lucide-react';
import type { Product, Customer, CompanySettings, PaymentMethod, PosSale, ProductFamily, Commercial, HeldCart, PriceType, Caisse } from '../types';
import type { CaisseWithUser } from '../hooks/useCaisses';
import { ALL_PAYMENT_METHODS } from '../types';
import type { CreateSaleInput } from '../hooks/usePosSales';
import type { SaveHeldCartInput } from '../hooks/useHeldCarts';
import { ReturnItemsModal } from './ReturnItemsModal';
import { fmtQty } from '../lib/format';
import { exportHtmlToPdf } from '../lib/pdf';
import { printInIframe } from '../lib/printEngine';
import { translateError } from '../lib/translateError';

interface PosPageProps {
  posSales: PosSale[];
  products: Product[];
  customers: Customer[];
  settings: CompanySettings | null;
  families: ProductFamily[];
  commerciaux: Commercial[];
  heldCarts: HeldCart[];
  priceTypes: PriceType[];
  locationId: string | null;
  activeCaisseId: string | null;
  caisseOpenedAt: string | null;
  caisseOpeningAmount: number | null;
  openCaisses: CaisseWithUser[];
  onOpenCaisse: (input: { opening_amount?: number; notes?: string }) => Promise<void>;
  onCloseCaisse: (caisseId: string, input: { closing_amount?: number; notes?: string }) => Promise<void>;
  onCreateSale: (input: CreateSaleInput) => Promise<PosSale>;
  onHoldCart: (input: SaveHeldCartInput) => Promise<HeldCart>;
  onDeleteHeldCart: (id: string) => Promise<void>;
  isAdmin?: boolean;
  onDeleteSale?: (saleId: string) => Promise<void>;
  onReturnSaleItems?: (saleId: string, returns: { item_id: string; product_id: string | null; quantity: number }[], reason: string) => Promise<void>;
}

interface CartLine {
  key: string;
  product_id: string | null;
  description: string;
  unit_price: number;
  unit_cost: number;
  quantity: number;
}

interface TenderLine {
  method: PaymentMethod;
  amount: string;
  reference: string;
}

function uid() { return Math.random().toString(36).slice(2); }

function fmtN(n: number, currency = 'FCFA') {
  return new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}

const POS_METHODS = ALL_PAYMENT_METHODS.filter(m =>
  ['especes', 'carte', 'orange_money', 'wave', 'mtn_money', 'moov_money', 'virement', 'cheque', 'avoir', 'autre'].includes(m.value)
);

const NEEDS_REF = new Set(['orange_money', 'wave', 'mtn_money', 'moov_money', 'virement', 'cheque']);

// ── Receipt HTML (customer ticket) ─────────────────────────────────
function buildReceiptHtml(sale: PosSale, settings: CompanySettings | null, products: Product[]) {
  const currency = settings?.currency ?? 'FCFA';
  const f = (n: number | string | null | undefined) =>
    new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(Number(n) || 0);
  const date = new Date(sale.created_at).toLocaleString('fr-FR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
  const totalPaid = (sale.payments ?? []).reduce((s, p) => s + Number(p.amount), 0);
  const change = Math.max(0, totalPaid - Number(sale.total));

  const itemsHtml = (sale.items ?? []).map(i => {
    const prod = i.product_id ? products.find(p => p.id === i.product_id) : undefined;
    const ref = prod?.reference ? `<span class="article-ref">${prod.reference}</span> ` : '';
    return `<tr>
      <td class="desc">${ref}${i.description}</td>
      <td class="qty">${f(i.quantity)}</td>
      <td class="price">${f(i.unit_price)}</td>
      <td class="total">${f(i.total)}</td>
    </tr>`;
  }).join('');

  const paymentsHtml = (sale.payments ?? []).map(p => {
    const label = ALL_PAYMENT_METHODS.find(m => m.value === p.method)?.label ?? p.method;
    return `<tr>
      <td>${label}${p.reference ? ` <span class="ref">(${p.reference})</span>` : ''}</td>
      <td class="total bold">${f(p.amount)} ${currency}</td>
    </tr>`;
  }).join('');

  return `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<title>Ticket ${sale.sale_number}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Courier New', monospace; font-size: 13px; color: #000; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  @media screen {
    html { background: #e8e8e8; min-height: 100vh; }
    body { width: 80mm; max-width: 100%; margin: 20px auto; padding: 6mm 5mm 12mm;
           box-shadow: 0 4px 20px rgba(0,0,0,.18); border-radius: 2px; }
  }
  @media print {
    body { width: 80mm; padding: 3mm 4mm 8mm; }
  }

  .header { text-align: center; padding-bottom: 4px; }
  .company-name { font-size: 18px; font-weight: 900; letter-spacing: 1px; text-transform: uppercase; color: #000; }
  .company-sub  { font-size: 11px; font-weight: 700; color: #000; margin-top: 1px; }
  .sep       { border: none; border-top: 1px dashed #000; margin: 5px 0; }
  .sep-solid { border: none; border-top: 2px solid #000; margin: 5px 0; }
  .ticket-title { text-align: center; font-weight: 900; font-size: 14px; letter-spacing: 2px; text-transform: uppercase; padding: 2px 0; color: #000; }
  .ticket-meta  { text-align: center; font-size: 11px; font-weight: 700; color: #000; margin-top: 1px; }
  table { width: 100%; border-collapse: collapse; }
  td { padding: 2px 2px; vertical-align: top; font-size: 12px; font-weight: 700; color: #000; }
  .items-header td { font-weight: 900; font-size: 11px; text-transform: uppercase; border-bottom: 2px solid #000; padding-bottom: 3px; color: #000; }
  .desc  { width: 45%; }
  .qty   { width: 10%; text-align: center; }
  .price { width: 22%; text-align: right; }
  .total { width: 23%; text-align: right; }
  .ref   { font-size: 11px; font-weight: 700; color: #000; }
  .article-ref { font-size: 10px; font-weight: 700; color: #555; }
  .totals-table td { font-size: 13px; font-weight: 700; color: #000; }
  .totals-table .lbl { text-align: left; }
  .totals-table .val { text-align: right; }
  .total-row td { font-weight: 900; font-size: 17px; padding-top: 4px; color: #000; }
  .discount td { color: #000; font-weight: 900; }
  .tax td      { color: #000; font-weight: 700; }
  .pay-label { font-weight: 900; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 2px; color: #000; }
  .bold { font-weight: 900; }
  .change-row { background: #eee; border-radius: 2px; padding: 3px 4px; margin-top: 2px; }
  .change-row td { font-weight: 900; font-size: 14px; color: #000; }
  .footer { text-align: center; font-size: 11px; font-weight: 700; color: #000; margin-top: 4px; line-height: 1.5; }
  .customer { font-size: 12px; text-align: center; font-weight: 700; color: #000; }

  @media print {
    @page { size: 80mm auto; margin: 0; }
    body { padding: 2mm 3mm 5mm; }
  }
</style></head>
<body>

<div class="header">
  <div class="company-name">${settings?.name ?? 'MON ENTREPRISE'}</div>
  ${settings?.address ? `<div class="company-sub">${settings.address}${settings.city ? ', ' + settings.city : ''}</div>` : ''}
  ${settings?.phone ? `<div class="company-sub">Tél : ${settings.phone}</div>` : ''}
  ${settings?.email ? `<div class="company-sub">${settings.email}</div>` : ''}
</div>

<hr class="sep-solid">

<div class="ticket-title">Ticket de caisse</div>
<div class="ticket-meta"><strong>FACTURE</strong></div>
<div class="ticket-meta">${sale.sale_number}</div>
<div class="ticket-meta">${date}</div>
${sale.customer ? `<div class="customer">Client : ${sale.customer.name}</div>` : ''}

<hr class="sep">

<table>
  <tr class="items-header">
    <td class="desc">Article</td>
    <td class="qty">Qté</td>
    <td class="price">P.U.</td>
    <td class="total">Total</td>
  </tr>
  ${itemsHtml}
</table>

<hr class="sep">

<table class="totals-table">
  <tr>
    <td class="lbl">Sous-total</td>
    <td class="val">${f(sale.subtotal)} ${currency}</td>
  </tr>
  ${sale.discount_amount > 0 ? `
  <tr class="discount">
    <td class="lbl">Remise</td>
    <td class="val">- ${f(sale.discount_amount)} ${currency}</td>
  </tr>` : ''}
  ${sale.tax_rate > 0 ? `
  <tr class="tax">
    <td class="lbl">TVA (${sale.tax_rate}%)</td>
    <td class="val">${f(sale.tax_amount)} ${currency}</td>
  </tr>` : ''}
  <tr class="total-row">
    <td class="lbl">TOTAL</td>
    <td class="val">${f(sale.total)} ${currency}</td>
  </tr>
</table>

<hr class="sep">

<div class="pay-label">Règlement</div>
<table>
  ${paymentsHtml}
  <tr class="total-row" style="font-size:12px">
    <td class="lbl">Total réglé</td>
    <td class="val">${f(totalPaid)} ${currency}</td>
  </tr>
</table>
${change > 0 ? `
<table>
  <tr class="change-row">
    <td>Monnaie rendue</td>
    <td class="total bold">${f(change)} ${currency}</td>
  </tr>
</table>` : ''}

<hr class="sep">

<div class="footer">
  ${settings?.invoice_footer ?? 'Merci pour votre visite !'}
  <br>— Conservez ce ticket —
</div>

</body></html>`;
}

// ── Order ticket HTML (kitchen/bar printer) ────────────────────────
function buildOrderTicketHtml(sale: PosSale, settings: CompanySettings | null, printerName: string, families: ProductFamily[], products: Product[]) {
  const f = (n: number | string | null | undefined) =>
    new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(Number(n) || 0);
  const date = new Date(sale.created_at).toLocaleString('fr-FR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });

  const items = (sale.items ?? []).filter(i => {
    if (!i.product_id) return false;
    const prod = products.find(p => p.id === i.product_id);
    const fam = prod ? families.find(fa => fa.id === prod.family_id) : undefined;
    return fam?.printer_name === printerName;
  });
  if (items.length === 0) return null;

  const itemsHtml = items.map(i =>
    `<tr>
      <td class="qty">${f(i.quantity)}</td>
      <td class="desc">${i.description}</td>
    </tr>`
  ).join('');

  return `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<title>Bon de commande ${printerName} — ${sale.sale_number}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Courier New', monospace; font-size: 14px; color: #000; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  @media screen {
    html { background: #e8e8e8; min-height: 100vh; }
    body { width: 80mm; max-width: 100%; margin: 20px auto; padding: 6mm 5mm 12mm;
           box-shadow: 0 4px 20px rgba(0,0,0,.18); border-radius: 2px; }
  }
  @media print {
    body { width: 80mm; padding: 3mm 4mm 8mm; }
  }

  .printer-label { text-align: center; font-weight: 900; font-size: 18px; background: #000; color: #fff; padding: 6px; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 2px; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .title { text-align: center; font-weight: 900; font-size: 15px; letter-spacing: 1px; text-transform: uppercase; color: #000; }
  .meta  { text-align: center; font-size: 12px; font-weight: 700; color: #000; margin-top: 1px; }
  .customer { font-size: 13px; text-align: center; font-weight: 900; color: #000; margin-top: 3px; }
  .sep       { border: none; border-top: 1px dashed #000; margin: 5px 0; }
  .sep-solid { border: none; border-top: 2px solid #000; margin: 5px 0; }

  table { width: 100%; border-collapse: collapse; }
  td { padding: 4px 2px; vertical-align: top; font-size: 14px; font-weight: 700; color: #000; }
  .items-header td { font-weight: 900; font-size: 11px; text-transform: uppercase; border-bottom: 2px solid #000; padding-bottom: 3px; color: #000; }
  .qty  { width: 15%; text-align: center; font-weight: 900; font-size: 17px; color: #000; }
  .desc { width: 85%; font-weight: 700; color: #000; }

  .footer { text-align: center; font-size: 11px; font-weight: 700; color: #000; margin-top: 6px; }

  @media print {
    @page { size: 80mm auto; margin: 0; }
    body { padding: 2mm 3mm 5mm; }
  }
</style></head>
<body>

<div class="printer-label">${printerName}</div>
<div class="title">Bon de commande</div>
<div class="meta">${sale.sale_number}</div>
<div class="meta">${date}</div>
${sale.customer ? `<div class="customer">${sale.customer.name}</div>` : ''}

<hr class="sep-solid">

<table>
  <tr class="items-header">
    <td class="qty">Qté</td>
    <td class="desc">Article</td>
  </tr>
  ${itemsHtml}
</table>

<hr class="sep-solid">

<div class="footer">
  ${settings?.name ?? ''}
</div>

</body></html>`;
}

// ── Main POS component ──────────────────────────────────────────
export function PosPage({ posSales, products, customers, settings, families, commerciaux, heldCarts, priceTypes, locationId, activeCaisseId, caisseOpenedAt, caisseOpeningAmount, openCaisses, onOpenCaisse, onCreateSale, onHoldCart, onDeleteHeldCart, isAdmin, onDeleteSale, onReturnSaleItems }: PosPageProps) {
  const [returnSale, setReturnSale] = useState<PosSale | null>(null);
  const [returnSaving, setReturnSaving] = useState(false);
  const currency = settings?.currency ?? 'FCFA';

  const [cart, setCart] = useState<CartLine[]>([]);
  const [discountAmt, setDiscountAmt] = useState('0');
  const [taxRate, setTaxRate] = useState('0');
  const [selectedCustomer, setSelectedCustomer] = useState<string>('');
  const [selectedCommercial, setSelectedCommercial] = useState<string>('');
  const [selectedPriceType, setSelectedPriceType] = useState<string>('');
  const [notes, setNotes] = useState('');

  const [tenders, setTenders] = useState<TenderLine[]>([]);
  const [, setShowPayment] = useState(false);

  const [query, setQuery] = useState('');
  const [familyFilter, setFamilyFilter] = useState<string>('all');
  const [category, setCategory] = useState<'all' | 'low'>('all');

  const [showRecent, setShowRecent] = useState(false);
  const [lastSale, setLastSale] = useState<PosSale | null>(null);
  const [saving, setSaving] = useState(false);

  // Hold cart modal
  const [showHold, setShowHold] = useState(false);
  const [holdLabel, setHoldLabel] = useState('');
  const [holdSaving, setHoldSaving] = useState(false);

  // Caisse open/close modal
  const [showCaisse, setShowCaisse] = useState(false);
  const [openingAmount, setOpeningAmount] = useState('0');
  const [caisseNotes, setCaisseNotes] = useState('');
  const [caisseSaving, setCaisseSaving] = useState(false);
  const [nowTick, setNowTick] = useState(Date.now());



  useEffect(() => {
    if (!caisseOpenedAt) return;
    const t = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(t);
  }, [caisseOpenedAt]);

  const caisseElapsed = useMemo(() => {
    if (!caisseOpenedAt) return '';
    const ms = nowTick - new Date(caisseOpenedAt).getTime();
    const s = Math.max(0, Math.floor(ms / 1000));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0 ? `${h}h ${String(m).padStart(2, '0')}m` : `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  }, [caisseOpenedAt, nowTick]);

  // Mobile: 'products' | 'cart' | 'held'
  const [mobileView, setMobileView] = useState<'products' | 'cart' | 'held'>('products');

  const searchRef = useRef<HTMLInputElement>(null);

  const activeProducts = useMemo(() => {
    return products.filter(p => p.active && (
      category !== 'low' || (p.track_stock && p.stock_quantity <= p.stock_min)
    ) && (
      !query || p.name.toLowerCase().includes(query.toLowerCase()) || (p.reference ?? '').toLowerCase().includes(query.toLowerCase())
    ) && (
      familyFilter === 'all' || p.family_id === familyFilter
    ));
  }, [products, query, category, familyFilter]);

  const subtotal    = useMemo(() => cart.reduce((s, l) => s + l.unit_price * l.quantity, 0), [cart]);
  const discAmt     = Math.min(Math.round((parseFloat(discountAmt) || 0) * 100) / 100, subtotal);
  const afterDisc   = subtotal - discAmt;
  const taxAmt      = Math.round(afterDisc * (parseFloat(taxRate) || 0) / 100);
  const total       = afterDisc + taxAmt;
  const totalTendered = useMemo(() => tenders.reduce((s, t) => s + (parseFloat(t.amount) || 0), 0), [tenders]);
  const change      = Math.max(0, totalTendered - total);
  const remaining   = Math.max(0, total - totalTendered);
  const cartQty     = cart.reduce((s, l) => s + l.quantity, 0);

  function getPriceForProduct(p: Product): number {
    if (!selectedPriceType) return p.price;
    const entry = (p.prices ?? []).find(e => e.price_type_id === selectedPriceType);
    return entry != null ? entry.price : p.price;
  }

  function stockFor(productId: string | null): number | null {
    if (!productId) return null;
    const p = products.find(pr => pr.id === productId);
    if (!p || !p.track_stock) return null;
    return p.stock_quantity;
  }

  function clampQty(productId: string | null, requested: number): number {
    const max = stockFor(productId);
    if (max == null) return requested;
    return Math.min(requested, Math.max(0, max));
  }

  function addToCart(p: Product) {
    const unitPrice = getPriceForProduct(p);
    setCart(prev => {
      const existing = prev.find(l => l.product_id === p.id);
      if (existing) {
        const next = clampQty(p.id, existing.quantity + 1);
        if (next === existing.quantity) return prev;
        return prev.map(l => l.product_id === p.id ? { ...l, quantity: next } : l);
      }
      if (p.track_stock && p.stock_quantity <= 0) return prev;
      return [...prev, { key: uid(), product_id: p.id, description: p.name, unit_price: unitPrice, unit_cost: Number(p.purchase_price) || 0, quantity: 1 }];
    });
  }

  function updateQty(key: string, delta: number) {
    setCart(prev => prev.map(l => {
      if (l.key !== key) return l;
      const next = clampQty(l.product_id, l.quantity + delta);
      return { ...l, quantity: next };
    }).filter(l => l.quantity > 0));
  }

  function setQty(key: string, val: string) {
    if (val === '') { setCart(prev => prev.map(l => l.key === key ? { ...l, quantity: 0 } : l)); return; }
    const q = parseFloat(val) || 0;
    setCart(prev => prev.map(l => {
      if (l.key !== key) return l;
      return { ...l, quantity: clampQty(l.product_id, q) };
    }));
  }

  function setPrice(key: string, val: string) {
    setCart(prev => prev.map(l => l.key === key ? { ...l, unit_price: parseFloat(val) || 0 } : l));
  }

  function setDescription(key: string, val: string) {
    setCart(prev => prev.map(l => l.key === key ? { ...l, description: val } : l));
  }

  function removeFromCart(key: string) { setCart(prev => prev.filter(l => l.key !== key)); }

  function clearCart() {
    setCart([]); setDiscountAmt('0'); setTaxRate('0');
    setSelectedCustomer(''); setSelectedCommercial(''); setSelectedPriceType(''); setNotes(''); setTenders([]);
    setShowPayment(false); setLastSale(null); setMobileView('products');
  }

  async function handleHoldCart() {
    const validCart = cart.filter(l => l.quantity > 0);
    if (validCart.length === 0) return;
    setHoldSaving(true);
    try {
      await onHoldCart({
        label: holdLabel.trim() || `Panier ${new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`,
        commercial_id: selectedCommercial || null,
        customer_id: selectedCustomer || null,
        items: validCart,
        discount_pct: 0,
        discount_amount: parseFloat(discountAmt) || 0,
        tax_rate: parseFloat(taxRate) || 0,
        notes,
        location_id: locationId,
      });
      setShowHold(false);
      setHoldLabel('');
      clearCart();
    } finally {
      setHoldSaving(false);
    }
  }

  function resumeHeldCart(held: HeldCart) {
    setCart(held.items.map(i => ({ ...i })));
    setDiscountAmt(String(held.discount_amount ?? 0));
    setTaxRate(String(held.tax_rate));
    setSelectedCustomer(held.customer_id ?? '');
    setSelectedCommercial(held.commercial_id ?? '');
    setSelectedPriceType('');
    setNotes(held.notes);
    setTenders([]);
    onDeleteHeldCart(held.id);
    setMobileView('products');
  }

  function addTender(method: PaymentMethod) {
    if (tenders.find(t => t.method === method)) return;
    const amt = remaining > 0 ? String(Math.ceil(remaining)) : '';
    setTenders(prev => [...prev, { method, amount: amt, reference: '' }]);
  }

  function removeTender(method: PaymentMethod) { setTenders(prev => prev.filter(t => t.method !== method)); }

  function updateTender(method: PaymentMethod, patch: Partial<TenderLine>) {
    setTenders(prev => prev.map(t => t.method === method ? { ...t, ...patch } : t));
  }

  const stockErrors = useMemo(() => {
    return cart
      .map(l => {
        const max = stockFor(l.product_id);
        if (max == null) return null;
        if (l.quantity > max) return { name: l.description, max };
        return null;
      })
      .filter((x): x is { name: string; max: number } => x != null);
  }, [cart, products]);

  async function handleCaisseSubmit() {
    setCaisseSaving(true);
    try {
      await onOpenCaisse({
        opening_amount: parseFloat(openingAmount) || 0,
        notes: caisseNotes,
      });
      setShowCaisse(false);
    } catch (e) {
      alert(e instanceof Error ? translateError(e.message) : 'Erreur caisse');
    } finally {
      setCaisseSaving(false);
    }
  }


  async function handleValidate() {
    if (cart.length === 0 || remaining > 0) return;
    const validCart = cart.filter(l => l.quantity > 0);
    if (validCart.length === 0) return;
    if (stockErrors.length > 0) {
      alert(`Stock insuffisant pour :\n${stockErrors.map(e => `${e.name} (dispo. ${e.max})`).join('\n')}`);
      return;
    }
    setSaving(true);
    try {
      const input: CreateSaleInput = {
        customer_id: selectedCustomer || null,
        commercial_id: selectedCommercial || null,
        caisse_id: activeCaisseId ?? null,
        items: validCart.map(l => ({ product_id: l.product_id, description: l.description, quantity: l.quantity, unit_price: l.unit_price, unit_cost: l.unit_cost })),
        tenders: tenders.map(t => ({ method: t.method, amount: parseFloat(t.amount) || 0, reference: t.reference })).filter(t => t.amount > 0),
        discount_pct: 0,
        discount_amount: parseFloat(discountAmt) || 0,
        tax_rate: parseFloat(taxRate) || 0,
        notes,
      };
      const sale = await onCreateSale(input);
      setLastSale(sale);
    } catch (e) {
      alert(e instanceof Error ? translateError(e.message) : 'Erreur lors de la vente');
    } finally {
      setSaving(false);
    }
  }

  function printHtmlInIframe(html: string) {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);
    const doc = iframe.contentWindow?.document;
    if (!doc) { iframe.remove(); return; }
    doc.open();
    doc.write(html);
    doc.close();
    iframe.onload = () => {
      try {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
      } catch { /* ignore */ }
      setTimeout(() => iframe.remove(), 1000);
    };
  }

  function printReceipt(sale: PosSale) {
    printHtmlInIframe(buildReceiptHtml(sale, settings, products));

    const printerNames = new Set<string>();
    for (const item of (sale.items ?? [])) {
      if (!item.product_id) continue;
      const prod = products.find(p => p.id === item.product_id);
      const fam = prod ? families.find(fa => fa.id === prod.family_id) : undefined;
      if (fam?.printer_name) printerNames.add(fam.printer_name);
    }

    let delay = 800;
    for (const pn of printerNames) {
      const html = buildOrderTicketHtml(sale, settings, pn, families, products);
      if (!html) continue;
      setTimeout(() => printHtmlInIframe(html), delay);
      delay += 800;
    }
  }

  const [pdfExporting, setPdfExporting] = useState(false);

  async function exportReceiptPdf(sale: PosSale) {
    setPdfExporting(true);
    try {
      await exportHtmlToPdf(buildReceiptHtml(sale, settings, products), `${sale.sale_number}.pdf`, 'receipt');
    } finally {
      setPdfExporting(false);
    }
  }

  // ── Sale confirmation screen ──────────────────────────────────
  if (lastSale) {
    const paidTotal = (lastSale.payments ?? []).reduce((s, p) => s + Number(p.amount), 0);
    const saleChange = Math.max(0, paidTotal - Number(lastSale.total));
    return (
      <div className="flex h-full flex-col items-center justify-center p-6">
        {/* Receipt card */}
        <div className="w-full max-w-xs bg-white rounded-2xl border border-gray-200 shadow-xl overflow-hidden">
          {/* Header band */}
          <div className="bg-emerald-600 px-5 py-4 text-white text-center">
            <CheckCircle className="h-10 w-10 mx-auto mb-2 opacity-90" />
            <p className="font-bold text-lg">Vente enregistrée</p>
            <p className="text-emerald-100 text-sm">{lastSale.sale_number}</p>
          </div>

          {/* Items summary */}
          <div className="px-5 py-3 divide-y divide-gray-100">
            {(lastSale.items ?? []).map((item, i) => (
              <div key={i} className="flex justify-between py-2 text-base">
                <span className="text-gray-800 font-semibold flex-1 pr-2 truncate">{item.description} × {fmtQty(item.quantity)}</span>
                <span className="font-bold tabular-nums text-gray-900">{fmtN(item.total, '')}</span>
              </div>
            ))}
          </div>

          {/* Totals */}
          <div className="border-t border-dashed border-gray-300 mx-4" />
          <div className="px-5 py-3 space-y-1.5">
            {lastSale.discount_amount > 0 && (
              <div className="flex justify-between text-base text-red-500">
                <span>Remise</span>
                <span className="tabular-nums">− {fmtN(lastSale.discount_amount, '')}</span>
              </div>
            )}
            {lastSale.tax_rate > 0 && (
              <div className="flex justify-between text-base font-semibold text-gray-600">
                <span>TVA ({lastSale.tax_rate}%)</span>
                <span className="tabular-nums">{fmtN(lastSale.tax_amount, '')}</span>
              </div>
            )}
            <div className="flex justify-between text-lg font-bold text-gray-900">
              <span>TOTAL</span>
              <span className="tabular-nums">{fmtN(lastSale.total, currency)}</span>
            </div>
          </div>

          {/* Payments */}
          <div className="border-t border-gray-100 px-5 py-3 space-y-1">
            <p className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-1.5">Règlement</p>
            {(lastSale.payments ?? []).map((p, i) => {
              const label = ALL_PAYMENT_METHODS.find(m => m.value === p.method)?.label ?? p.method;
              return (
                <div key={i} className="flex justify-between text-base">
                  <span className="font-semibold text-gray-700">{label}</span>
                  <span className="font-bold tabular-nums text-gray-900">{fmtN(p.amount, currency)}</span>
                </div>
              );
            })}
          </div>

          {/* Change */}
          {saleChange > 0 && (
            <div className="mx-4 mb-3 flex justify-between rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-base font-bold text-amber-700">
              <span>Monnaie à rendre</span>
              <span className="tabular-nums">{fmtN(saleChange, currency)}</span>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="mt-5 flex gap-3 w-full max-w-xs">
          <button
            onClick={() => printReceipt(lastSale)}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition shadow-sm"
          >
            <Printer className="h-4 w-4" />
            Imprimer
          </button>
          <button
            onClick={() => exportReceiptPdf(lastSale)}
            disabled={pdfExporting}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition shadow-sm disabled:opacity-50"
          >
            <FileDown className="h-4 w-4" />
            {pdfExporting ? 'PDF…' : 'PDF'}
          </button>
          <button
            onClick={clearCart}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-500 transition shadow-sm"
          >
            Nouvelle vente
          </button>
        </div>
      </div>
    );
  }

  // ── Caisse status bar (page-level, above panels) ──────────────
  const CaisseBar = !locationId ? (
    <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2">
      <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
      <p className="text-xs text-amber-700">Aucune boutique rattachée à votre compte. La vente est bloquée. Contactez un administrateur.</p>
    </div>
  ) : (
    <div>
      {activeCaisseId ? (
        <div className="rounded-xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50/60 px-3.5 py-3 shadow-sm">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="relative flex h-2.5 w-2.5 shrink-0">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
              </span>
              <div className="min-w-0">
                <p className="text-xs font-bold text-emerald-800 tracking-wide uppercase">Caisse ouverte</p>
                <p className="text-[10px] text-emerald-600/80 truncate">
                  {caisseOpenedAt ? `Ouverte ${new Date(caisseOpenedAt).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}` : ''}
                </p>
              </div>
            </div>
          </div>
          <div className="mt-2.5 flex items-center gap-3 text-[11px]">
            <div className="flex items-center gap-1.5 rounded-md bg-white/70 px-2 py-1">
              <span className="text-emerald-600/70 font-medium">Durée</span>
              <span className="font-bold tabular-nums text-emerald-800">{caisseElapsed || '—'}</span>
            </div>
            {caisseOpeningAmount != null && (
              <div className="flex items-center gap-1.5 rounded-md bg-white/70 px-2 py-1">
                <span className="text-emerald-600/70 font-medium">Fond</span>
                <span className="font-bold tabular-nums text-emerald-800">{fmtN(caisseOpeningAmount, currency)}</span>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between rounded-xl border border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50/60 px-3.5 py-3 shadow-sm">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-100 shrink-0">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-amber-800 tracking-wide uppercase">Caisse fermée</p>
              <p className="text-[10px] text-amber-600/80 truncate">Ouvrez la caisse pour encaisser</p>
            </div>
          </div>
          <button
            onClick={() => { setOpeningAmount('0'); setCaisseNotes(''); setShowCaisse(true); }}
            className="shrink-0 rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-amber-500 transition active:scale-95"
          >
            Ouvrir
          </button>
        </div>
      )}
    </div>
  );

  // ── Product panel ─────────────────────────────────────────────
  const ProductPanel = (
    <div className="flex flex-1 flex-col overflow-hidden rounded-xl border border-gray-200 bg-white">
      <div className="border-b border-gray-200 p-3 flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            ref={searchRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Rechercher par nom ou référence…"
            className="w-full rounded-lg border border-gray-200 bg-gray-50 py-2.5 pl-9 pr-3 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500 focus:bg-white transition"
          />
        </div>
        <button
          onClick={() => setCategory(c => c === 'low' ? 'all' : 'low')}
          className={`rounded-lg border px-3 py-2 text-xs font-medium transition ${category === 'low' ? 'border-amber-400 bg-amber-50 text-amber-700' : 'border-gray-200 text-gray-500 hover:bg-gray-100'}`}
        >
          Stock bas
        </button>
        {heldCarts.length > 0 && (
          <button
            onClick={() => setMobileView('held')}
            className="lg:hidden relative rounded-lg border border-blue-300 bg-blue-50 px-3 py-2 text-xs font-medium text-blue-700"
          >
            <Pause className="h-4 w-4" />
            <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-blue-600 text-[9px] font-bold text-white">{heldCarts.length}</span>
          </button>
        )}
      </div>

      {/* Held carts banner (desktop) */}
      {heldCarts.length > 0 && (
        <div className="hidden lg:block border-b border-amber-200 bg-amber-50 px-3 py-2">
          <div className="flex items-center gap-2 mb-2">
            <Pause className="h-3.5 w-3.5 text-amber-600" />
            <span className="text-xs font-semibold text-amber-700">{heldCarts.length} panier{heldCarts.length > 1 ? 's' : ''} en attente</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {heldCarts.map(hc => (
              <div key={hc.id} className="flex items-center gap-1.5 rounded-lg border border-amber-200 bg-white px-2.5 py-1.5 shadow-sm">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-gray-800 truncate max-w-[120px]">{hc.label || 'Panier'}</p>
                  {(hc.commercial || hc.customer) && (
                    <p className="text-[10px] text-gray-400 truncate max-w-[120px]">
                      {hc.commercial?.name ?? hc.customer?.name}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => resumeHeldCart(hc)}
                  className="shrink-0 flex items-center gap-1 rounded-md bg-amber-500 px-2 py-1 text-[10px] font-bold text-white hover:bg-amber-400 transition"
                >
                  <Play className="h-2.5 w-2.5" />
                  Reprendre
                </button>
                <button
                  onClick={() => onDeleteHeldCart(hc.id)}
                  className="shrink-0 text-gray-300 hover:text-red-400 transition"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Family tabs */}
      {families.length > 0 && (
        <div className="flex gap-1 overflow-x-auto border-b border-gray-100 px-3 py-2 scrollbar-none">
          <button
            onClick={() => setFamilyFilter('all')}
            className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium transition ${familyFilter === 'all' ? 'bg-gray-800 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            Tous
          </button>
          {families.map(f => (
            <button key={f.id}
              onClick={() => setFamilyFilter(familyFilter === f.id ? 'all' : f.id)}
              className="shrink-0 flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium transition"
              style={familyFilter === f.id
                ? { backgroundColor: f.color, color: '#fff' }
                : { backgroundColor: f.color + '1a', color: f.color }
              }
            >
              <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: familyFilter === f.id ? 'rgba(255,255,255,0.6)' : f.color }} />
              {f.name}
            </button>
          ))}
        </div>
      )}
      <div className="flex-1 overflow-y-auto p-3">
        {activeProducts.length === 0 ? (
          <div className="flex h-full items-center justify-center text-sm text-gray-400">
            {query ? 'Aucun article trouvé.' : 'Aucun article actif.'}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-4">
            {activeProducts.map(p => {
              const inCart = cart.find(l => l.product_id === p.id);
              const lowStock = p.track_stock && p.stock_quantity <= p.stock_min;
              const outOfStock = p.track_stock && p.stock_quantity <= 0;
              return (
                <button
                  key={p.id}
                  onClick={() => { addToCart(p); }}
                  disabled={outOfStock}
                  className={`relative rounded-xl border p-3 text-left transition active:scale-95 ${
                    outOfStock ? 'border-gray-200 bg-gray-50 opacity-50 cursor-not-allowed'
                    : inCart ? 'border-blue-500 bg-blue-50 shadow-sm' : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50/40'
                  }`}
                >
                  {lowStock && !outOfStock && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-amber-400" title="Stock bas" />}
                  {outOfStock && <span className="absolute right-2 top-1 text-[9px] font-bold uppercase text-red-500">Rupture</span>}
                  {inCart && (
                    <span className="absolute left-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-[10px] font-bold text-white shadow">
                      {fmtQty(inCart.quantity)}
                    </span>
                  )}
                  {p.photo_url ? (
                    <div className="relative -mx-3 -mt-3 mb-2 h-24 overflow-hidden rounded-t-xl bg-gray-100">
                      <img src={p.photo_url} alt="" className="h-full w-full object-cover" />
                      {lowStock && !outOfStock && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-amber-400" title="Stock bas" />}
                      {outOfStock && <span className="absolute right-2 top-1 text-[9px] font-bold uppercase text-red-500 bg-white/80 px-1 rounded">Rupture</span>}
                    </div>
                  ) : (
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 mb-1">
                      <Package className="h-5 w-5 text-gray-300" />
                    </div>
                  )}
                  {!p.photo_url && lowStock && !outOfStock && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-amber-400" title="Stock bas" />}
                  {!p.photo_url && outOfStock && <span className="absolute right-2 top-1 text-[9px] font-bold uppercase text-red-500">Rupture</span>}
                  <p className="mt-1 text-sm font-semibold leading-tight text-gray-800 line-clamp-2">{p.name}</p>
                  <p className="mt-1.5 text-sm font-bold text-blue-600 tabular-nums">{fmtN(getPriceForProduct(p), currency)}</p>
                  {(p.prices ?? []).length > 0 && (
                    <div className="flex gap-0.5 mt-1 flex-wrap">
                      {[...(p.prices ?? [])].sort((a, b) => (a.price_type?.sort_order ?? 0) - (b.price_type?.sort_order ?? 0)).map(pr => (
                        <span
                          key={pr.id}
                          title={`${pr.price_type?.name}: ${fmtN(pr.price, currency)}`}
                          className="h-1.5 w-1.5 rounded-full shrink-0"
                          style={{ backgroundColor: selectedPriceType === pr.price_type_id ? pr.price_type?.color : `${pr.price_type?.color}60` }}
                        />
                      ))}
                    </div>
                  )}
                  {p.track_stock && (
                    <p className={`text-xs mt-0.5 ${p.stock_quantity <= 0 ? 'text-red-500' : 'text-gray-400'}`}>
                      {fmtQty(p.stock_quantity)} {p.unit}
                    </p>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );

  // ── Cart panel ────────────────────────────────────────────────
  const CartPanel = (
    <div className="flex w-full h-full lg:w-[30rem] xl:w-[34rem] shrink-0 flex-col overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
      {/* Cart header — fixed */}
      <div className="flex items-center justify-between border-b border-gray-200 px-4 py-3 shrink-0 bg-gradient-to-r from-gray-50 to-white">
        <div className="flex items-center gap-2">
          <button onClick={() => setMobileView('products')} className="mr-1 text-gray-400 hover:text-gray-700 lg:hidden">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50">
            <ShoppingCart className="h-4 w-4 text-blue-600" />
          </div>
          <span className="text-sm font-bold text-gray-800">
            Panier
            {cartQty > 0 && (
              <span className="ml-2 rounded-full bg-blue-600 px-2 py-0.5 text-xs font-bold text-white">{cartQty}</span>
            )}
          </span>
        </div>
        {cart.length > 0 && (
          <button onClick={clearCart} className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-gray-400 hover:bg-red-50 hover:text-red-500 transition">
            <Trash2 className="h-3.5 w-3.5" />
            Vider
          </button>
        )}
        <button onClick={() => setShowRecent(v => !v)} className={`flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium transition ${showRecent ? 'text-blue-600 bg-blue-50' : 'text-gray-400 hover:bg-gray-100 hover:text-gray-600'}`}>
          <Receipt className="h-3.5 w-3.5" />
          Reçus
        </button>
      </div>

      {showRecent ? (
        <div className="flex-1 overflow-y-auto min-h-0">
          <div className="px-3 py-2 border-b border-gray-100 flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Ventes récentes</span>
            <button onClick={() => setShowRecent(false)} className="text-gray-400 hover:text-gray-600">
              <X className="h-4 w-4" />
            </button>
          </div>
          {posSales.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-gray-300">
              <Receipt className="h-8 w-8 mb-2 opacity-40" />
              <p className="text-sm">Aucune vente récente</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {posSales.slice(0, 50).map(s => (
                <div key={s.id} className="flex items-center justify-between px-3 py-2.5 hover:bg-gray-50 transition">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-800 truncate">{s.sale_number}</span>
                      <span className="text-xs text-gray-400 shrink-0">
                        {new Date(s.created_at).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400 mt-0.5">
                      {s.customer?.name ?? 'Comptant'} — {fmtN(s.total, currency)}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    {isAdmin && onDeleteSale && (
                      <button
                        onClick={async () => {
                          if (!confirm(`Supprimer la vente ${s.sale_number} ? Le stock sera restitué.`)) return;
                          try { await onDeleteSale(s.id); } catch (e) { alert(e instanceof Error ? e.message : 'Erreur'); }
                        }}
                        className="flex items-center gap-1 rounded-lg border border-red-200 px-2 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 hover:border-red-300 transition"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        Supprimer
                      </button>
                    )}
                    {onReturnSaleItems && (s.items ?? []).some(i => i.product_id) && (
                      <button
                        onClick={() => setReturnSale(s)}
                        className="flex items-center gap-1 rounded-lg border border-amber-200 px-2 py-1.5 text-xs font-medium text-amber-600 hover:bg-amber-50 hover:border-amber-300 transition"
                        title="Retour en stock"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => printReceipt(s)}
                      className="flex items-center gap-1 rounded-lg border border-gray-200 px-2.5 py-1.5 text-xs font-medium text-gray-600 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition"
                    >
                      <Printer className="h-3.5 w-3.5" />
                      Re-imprimer
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : cart.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center text-center p-6">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gray-50 mb-3">
            <ShoppingCart className="h-7 w-7 text-gray-300" />
          </div>
          <p className="text-sm font-medium text-gray-400">Panier vide</p>
          <p className="text-xs text-gray-300 mt-0.5">Cliquez sur un article pour l'ajouter</p>
        </div>
      ) : (
        <>
          {/* Scrollable area: table + form + summary + payment */}
          <div className="cart-scroll flex-1 overflow-y-auto min-h-0">
            {/* Cart items — table */}
            <table className="w-full text-sm border-collapse">
              <thead className="sticky top-0 z-10 bg-gray-200 text-[11px] font-bold uppercase tracking-wide text-gray-700">
                <tr>
                  <th className="px-3 py-2.5 text-left border-b-2 border-gray-300">Article</th>
                  <th className="px-2 py-2.5 text-right border-b-2 border-gray-300 w-24">P.U.</th>
                  <th className="px-2 py-2.5 text-center border-b-2 border-gray-300 w-28">Qté</th>
                  <th className="px-3 py-2.5 text-right border-b-2 border-gray-300 w-24">Total</th>
                  <th className="w-10 border-b-2 border-gray-300"></th>
                </tr>
              </thead>
              <tbody>
                {cart.map((line, idx) => {
                  const max = stockFor(line.product_id);
                  const over = max != null && line.quantity > max;
                  return (
                    <tr key={line.key} className={`align-middle border-b border-gray-200 ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-blue-50 transition`}>
                      <td className="px-3 py-2">
                        <input
                          type="text" value={line.description}
                          onChange={e => setDescription(line.key, e.target.value)}
                          placeholder="Nom de l'article"
                          className="w-full rounded-md border border-gray-200 bg-white px-2 py-1 text-sm font-semibold text-gray-900 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition"
                        />
                        {max != null && (
                          <span className={`ml-1 text-[10px] font-medium ${over ? 'text-red-500' : 'text-gray-400'}`}>
                            Stock : {fmtQty(max)}{over ? ' !' : ''}
                          </span>
                        )}
                      </td>
                      <td className="px-2 py-2 text-right">
                        <input
                          type="number" step="any" min="0" value={line.unit_price}
                          onChange={e => setPrice(line.key, e.target.value)}
                          className="w-20 rounded-md border border-gray-200 bg-white px-1.5 py-1 text-sm font-semibold tabular-nums text-blue-700 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition text-right"
                        />
                      </td>
                      <td className="px-2 py-2">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => updateQty(line.key, -1)} className="rounded-md border border-gray-200 bg-white p-1 text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition">
                            <Minus className="h-3 w-3" />
                          </button>
                          <input
                            type="number" min="0.01" step="0.01" value={line.quantity}
                            onChange={e => setQty(line.key, e.target.value)}
                            className="w-14 rounded-md border border-gray-200 bg-white px-1 py-1 text-center text-sm font-semibold tabular-nums text-gray-900 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition"
                          />
                          <button onClick={() => updateQty(line.key, 1)} className="rounded-md border border-gray-200 bg-white p-1 text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition">
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                      </td>
                      <td className="px-3 py-2 text-right text-sm font-bold tabular-nums text-gray-900">
                        {fmtN(line.unit_price * line.quantity, '')}
                      </td>
                      <td className="px-1 py-2 text-center">
                        <button onClick={() => removeFromCart(line.key)} className="text-gray-300 hover:text-red-400 transition">
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {/* Form + summary + payment — inside scroll */}
            <div className="border-t-2 border-gray-100 bg-gray-50/50">
            {/* Form fields */}
            <div className="px-3 pt-3 pb-2 space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-gray-600 mb-0.5 uppercase tracking-wide">Remise (montant)</label>
                  <input type="number" min="0" step="any" value={discountAmt}
                    onChange={e => setDiscountAmt(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 bg-white px-2 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition" />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-600 mb-0.5 uppercase tracking-wide">TVA %</label>
                  <input type="number" min="0" max="100" step="any" value={taxRate}
                    onChange={e => setTaxRate(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 bg-white px-2 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="flex items-center gap-1 text-[11px] font-bold text-gray-600 mb-0.5 uppercase tracking-wide">
                    <Users className="h-3 w-3" /> Client
                  </label>
                  <select className="w-full rounded-lg border border-gray-200 bg-white px-2 py-1.5 text-sm text-gray-700 outline-none focus:border-blue-400 transition"
                    value={selectedCustomer} onChange={e => setSelectedCustomer(e.target.value)}>
                    <option value="">Comptant</option>
                    {customers.filter(c => c.location_id === locationId).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                {commerciaux.filter(c => c.active).length > 0 ? (
                  <div>
                    <label className="flex items-center gap-1 text-[11px] font-bold text-gray-600 mb-0.5 uppercase tracking-wide">
                      <UserCheck className="h-3 w-3" /> Commercial
                    </label>
                    <select className="w-full rounded-lg border border-gray-200 bg-white px-2 py-1.5 text-sm text-gray-700 outline-none focus:border-blue-400 transition"
                      value={selectedCommercial} onChange={e => setSelectedCommercial(e.target.value)}>
                      <option value="">Aucun</option>
                      {commerciaux.filter(c => c.active).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                ) : priceTypes.filter(pt => pt.active).length > 0 ? (
                  <div>
                    <label className="flex items-center gap-1 text-[11px] font-bold text-gray-600 mb-0.5 uppercase tracking-wide">
                      <Tag className="h-3 w-3" /> Prix
                    </label>
                    <select
                      className="w-full rounded-lg border border-gray-200 bg-white px-2 py-1.5 text-sm text-gray-700 outline-none focus:border-blue-400 transition"
                      value={selectedPriceType}
                      onChange={e => {
                        const typeId = e.target.value;
                        setSelectedPriceType(typeId);
                        if (typeId) {
                          setCart(prev => prev.map(line => {
                            const prod = products.find(p => p.id === line.product_id);
                            if (!prod) return line;
                            const entry = (prod.prices ?? []).find(pr => pr.price_type_id === typeId);
                            return { ...line, unit_price: entry != null ? entry.price : prod.price };
                          }));
                        } else {
                          setCart(prev => prev.map(line => {
                            const prod = products.find(p => p.id === line.product_id);
                            return prod ? { ...line, unit_price: prod.price } : line;
                          }));
                        }
                      }}
                    >
                      <option value="">Standard</option>
                      {priceTypes.filter(pt => pt.active).map(pt => (
                        <option key={pt.id} value={pt.id}>{pt.name}</option>
                      ))}
                    </select>
                  </div>
                ) : null}
              </div>
              {commerciaux.filter(c => c.active).length > 0 && priceTypes.filter(pt => pt.active).length > 0 && (
                <div>
                  <label className="flex items-center gap-1 text-[11px] font-bold text-gray-600 mb-0.5 uppercase tracking-wide">
                    <Tag className="h-3 w-3" /> Type de prix
                  </label>
                  <select
                    className="w-full rounded-lg border border-gray-200 bg-white px-2 py-1.5 text-sm text-gray-700 outline-none focus:border-blue-400 transition"
                    value={selectedPriceType}
                    onChange={e => {
                      const typeId = e.target.value;
                      setSelectedPriceType(typeId);
                      if (typeId) {
                        setCart(prev => prev.map(line => {
                          const prod = products.find(p => p.id === line.product_id);
                          if (!prod) return line;
                          const entry = (prod.prices ?? []).find(pr => pr.price_type_id === typeId);
                          return { ...line, unit_price: entry != null ? entry.price : prod.price };
                        }));
                      } else {
                        setCart(prev => prev.map(line => {
                          const prod = products.find(p => p.id === line.product_id);
                          return prod ? { ...line, unit_price: prod.price } : line;
                        }));
                      }
                    }}
                  >
                    <option value="">Prix standard</option>
                    {priceTypes.filter(pt => pt.active).map(pt => (
                      <option key={pt.id} value={pt.id}>{pt.name}</option>
                    ))}
                  </select>
                  {selectedPriceType && (
                    <p className="mt-0.5 text-[10px] font-medium text-blue-500">
                      Tarif {priceTypes.find(pt => pt.id === selectedPriceType)?.name} appliqué
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Summary card */}
            <div className="mx-3 mb-2 rounded-xl border border-gray-200 bg-white px-3 py-2.5 space-y-1 shadow-sm">
              <div className="flex justify-between text-sm font-semibold text-gray-600">
                <span>Sous-total</span>
                <span className="tabular-nums">{fmtN(subtotal, currency)}</span>
              </div>
              {discAmt > 0 && (
                <div className="flex justify-between text-sm font-semibold text-red-500">
                  <span>Remise</span>
                  <span className="tabular-nums">− {fmtN(discAmt, currency)}</span>
                </div>
              )}
              {taxAmt > 0 && (
                <div className="flex justify-between text-sm font-semibold text-gray-600">
                  <span>TVA ({taxRate}%)</span>
                  <span className="tabular-nums">{fmtN(taxAmt, currency)}</span>
                </div>
              )}
              <div className="flex justify-between border-t border-gray-100 pt-1.5">
                <span className="text-base font-bold text-gray-900">TOTAL</span>
                <span className="text-base font-bold tabular-nums text-gray-900">{fmtN(total, currency)}</span>
              </div>
            </div>

            {/* Payment methods — dropdown */}
            <div className="px-3 pb-2">
              <p className="text-[11px] font-bold text-gray-600 uppercase tracking-wide mb-1.5">Règlement</p>
              <select
                value=""
                onChange={e => { if (e.target.value) addTender(e.target.value as PaymentMethod); }}
                className="w-full rounded-lg border border-gray-200 bg-white px-2.5 py-2 text-sm text-gray-700 outline-none focus:border-blue-400 transition cursor-pointer"
              >
                <option value="">+ Ajouter un mode de règlement…</option>
                {POS_METHODS.filter(m => !tenders.find(t => t.method === m.value)).map(m => (
                  <option key={m.value} value={m.value}>{m.icon} {m.label}</option>
                ))}
              </select>

              {tenders.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  {tenders.map(t => {
                    const meta = ALL_PAYMENT_METHODS.find(m => m.value === t.method)!;
                    return (
                      <div key={t.method} className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-2.5 py-1.5 shadow-sm">
                        <span className="text-xs font-bold text-gray-800 shrink-0 w-24">{meta.icon} {meta.label}</span>
                        <input
                          type="number" step="any" min="0" placeholder="Montant" value={t.amount}
                          onChange={e => updateTender(t.method, { amount: e.target.value })}
                          className="flex-1 rounded border border-gray-200 bg-gray-50 px-2 py-1 text-sm tabular-nums text-gray-900 outline-none focus:border-blue-500 focus:bg-white transition"
                        />
                        {NEEDS_REF.has(t.method) && (
                          <input
                            type="text" placeholder="Réf." value={t.reference}
                            onChange={e => updateTender(t.method, { reference: e.target.value })}
                            className="w-16 rounded border border-gray-200 bg-gray-50 px-2 py-1 text-xs text-gray-500 outline-none focus:border-blue-500 focus:bg-white transition"
                          />
                        )}
                        <button onClick={() => removeTender(t.method)} className="text-gray-300 hover:text-red-400 transition shrink-0">
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

              {tenders.length > 0 && (
                <div className="rounded-lg bg-gray-100 px-3 py-2 text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="font-semibold text-gray-600">Reçu</span>
                    <span className="tabular-nums font-semibold text-gray-900">{fmtN(totalTendered, currency)}</span>
                  </div>
                  {remaining > 0 && (
                    <div className="flex justify-between">
                      <span className="font-bold text-red-500">Reste</span>
                      <span className="tabular-nums font-bold text-red-500">{fmtN(remaining, currency)}</span>
                    </div>
                  )}
                  {change > 0 && (
                    <div className="flex justify-between">
                      <span className="font-bold text-emerald-600">Monnaie</span>
                      <span className="tabular-nums font-bold text-emerald-600">{fmtN(change, currency)}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Validate + Hold — pinned at bottom */}
          <div className="shrink-0 border-t border-gray-200 p-3 space-y-2 bg-white">
              <button
                onClick={handleValidate}
                disabled={saving || cart.length === 0 || remaining > 0 || stockErrors.length > 0 || !locationId || !activeCaisseId}
                className="w-full rounded-xl bg-emerald-600 py-3.5 text-sm font-bold text-white shadow shadow-emerald-200 transition hover:bg-emerald-500 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {saving ? 'Enregistrement…' : !locationId ? 'Boutique requise' : !activeCaisseId ? 'Ouvrez une caisse' : stockErrors.length > 0 ? 'Stock insuffisant' : `✓  Valider — ${fmtN(total, currency)}`}
              </button>
              <button
                onClick={() => { setHoldLabel(''); setShowHold(true); }}
                className="w-full flex items-center justify-center gap-2 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-500 hover:bg-amber-50 hover:border-amber-300 hover:text-amber-700 transition"
              >
                <Pause className="h-4 w-4" />
                Mettre en attente
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop layout */}
      <div className="hidden lg:flex h-screen flex-col gap-3 overflow-hidden -m-7 p-5">
        {CaisseBar}
        <div className="flex flex-1 gap-4 overflow-hidden">
          {ProductPanel}
          {CartPanel}
        </div>
      </div>

      {/* Mobile layout */}
      <div className="flex lg:hidden flex-col h-[calc(100vh-3.5rem)] overflow-hidden -m-5">
        <div className="p-3 pb-0">{CaisseBar}</div>
        {mobileView === 'products' ? (
          <div className="flex flex-col flex-1 overflow-hidden">
            <div className="flex-1 overflow-hidden p-3 pb-0">
              {ProductPanel}
            </div>
            {cart.length > 0 && (
              <div className="p-3 pt-2">
                <button
                  onClick={() => setMobileView('cart')}
                  className="w-full flex items-center justify-between rounded-xl bg-blue-600 px-4 py-3.5 text-sm font-bold text-white shadow-lg shadow-blue-200 active:scale-[0.98] transition"
                >
                  <div className="flex items-center gap-2">
                    <ShoppingCart className="h-4 w-4" />
                    <span>{cartQty} article{cartQty > 1 ? 's' : ''}</span>
                  </div>
                  <span className="tabular-nums">{fmtN(total, currency)}</span>
                </button>
              </div>
            )}
          </div>
        ) : mobileView === 'held' ? (
          <div className="flex flex-col flex-1 overflow-hidden p-3">
            <div className="flex items-center gap-3 mb-4">
              <button onClick={() => setMobileView('products')} className="text-gray-400 hover:text-gray-700">
                <ArrowLeft className="h-5 w-5" />
              </button>
              <h2 className="text-sm font-semibold text-gray-800">Paniers en attente</h2>
            </div>
            <div className="flex-1 overflow-y-auto space-y-3">
              {heldCarts.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-gray-300">
                  <Pause className="h-10 w-10 mb-2 opacity-40" />
                  <p className="text-sm">Aucun panier en attente</p>
                </div>
              ) : heldCarts.map(hc => (
                <div key={hc.id} className="rounded-xl border border-gray-200 bg-white p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-semibold text-gray-900">{hc.label || 'Panier'}</p>
                      {hc.commercial && <p className="text-xs text-gray-400">{hc.commercial.name}</p>}
                      {hc.customer && <p className="text-xs text-gray-400">{hc.customer.name}</p>}
                    </div>
                    <button onClick={() => onDeleteHeldCart(hc.id)} className="text-gray-300 hover:text-red-400 transition">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="text-xs text-gray-500">{hc.items.length} article{hc.items.length > 1 ? 's' : ''}</p>
                  <button
                    onClick={() => resumeHeldCart(hc)}
                    className="w-full flex items-center justify-center gap-2 rounded-lg bg-amber-500 py-2.5 text-sm font-semibold text-white hover:bg-amber-400 transition"
                  >
                    <Play className="h-4 w-4" />
                    Reprendre
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col flex-1 overflow-hidden p-3">
            {CartPanel}
          </div>
        )}
      </div>

      {/* Caisse open modal */}
      {showCaisse && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white shadow-2xl overflow-hidden">
            <div className="border-b border-gray-100 px-5 py-4">
              <div className="flex items-center gap-2">
                <Unlock className="h-4 w-4 text-emerald-500" />
                <h2 className="text-base font-semibold text-gray-900">Ouvrir la caisse</h2>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">Déclarez le fond de caisse initial pour démarrer les ventes.</p>
            </div>
            <div className="px-5 py-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Fond de caisse initial</label>
                <input
                  autoFocus
                  inputMode="decimal"
                  value={openingAmount}
                  onChange={e => setOpeningAmount(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') handleCaisseSubmit(); }}
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notes (optionnel)</label>
                <textarea
                  value={caisseNotes}
                  onChange={e => setCaisseNotes(e.target.value)}
                  rows={2}
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition resize-none"
                />
              </div>
              <div className="flex gap-3">
                <button onClick={() => setShowCaisse(false)} className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition">
                  Annuler
                </button>
                <button
                  onClick={handleCaisseSubmit}
                  disabled={caisseSaving}
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-emerald-600 py-2.5 text-sm font-semibold text-white transition disabled:opacity-50 hover:bg-emerald-500"
                >
                  {caisseSaving ? 'Enregistrement…' : 'Ouvrir'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hold cart modal */}
      {showHold && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white shadow-2xl overflow-hidden">
            <div className="border-b border-gray-100 px-5 py-4">
              <div className="flex items-center gap-2">
                <Pause className="h-4 w-4 text-amber-500" />
                <h2 className="text-base font-semibold text-gray-900">Mettre en attente</h2>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">Le panier sera sauvegardé et récupérable à tout moment.</p>
            </div>
            <div className="px-5 py-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Étiquette (optionnel)</label>
                <input
                  autoFocus
                  value={holdLabel}
                  onChange={e => setHoldLabel(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') handleHoldCart(); }}
                  placeholder="Ex : Table 3, Client VIP…"
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                />
              </div>
              <div className="flex gap-3">
                <button onClick={() => setShowHold(false)} className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition">
                  Annuler
                </button>
                <button
                  onClick={handleHoldCart}
                  disabled={holdSaving}
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-amber-500 py-2.5 text-sm font-semibold text-white hover:bg-amber-400 transition disabled:opacity-50"
                >
                  <Pause className="h-4 w-4" />
                  {holdSaving ? 'Sauvegarde…' : 'Mettre en attente'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {returnSale && onReturnSaleItems && (
        <ReturnItemsModal
          title={`Retour en stock — ${returnSale.sale_number}`}
          items={(returnSale.items ?? []).map(i => ({ id: i.id, product_id: i.product_id, description: i.description, quantity: i.quantity, unit_price: i.unit_price }))}
          onSubmit={async (returns, reason) => {
            setReturnSaving(true);
            try {
              await onReturnSaleItems(returnSale.id, returns, reason);
            } catch (e) {
              throw e;
            } finally {
              setReturnSaving(false);
            }
          }}
          onClose={() => setReturnSale(null)}
        />
      )}
    </>
  );
}
