import { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Package, TrendingUp, TrendingDown, AlertTriangle, ArrowUpCircle,
  ArrowDownCircle, SlidersHorizontal, History, Search, MapPin, Printer, Banknote,
} from 'lucide-react';
import type { Product, StockMovement, StockMovementType } from '../types';
import { MOVEMENT_LABELS } from '../types';
import { Modal } from './Modal';
import { fmtQty } from '../lib/format';
import { translateError } from '../lib/translateError';
import { supabase } from '../lib/supabase';
import { exportHtmlToPdf } from '../lib/pdf';
import { printDocument } from '../lib/printEngine';

interface LocationStockRow {
  product_id: string;
  stock_quantity: number;
  stock_min: number;
}

interface StockPageProps {
  products: Product[];
  currency: string;
  onAddMovement: (payload: {
    product_id: string;
    type: StockMovementType;
    quantity: number;
    unit_cost?: number;
    reference?: string;
    notes?: string;
  }) => Promise<void>;
  fetchMovements: (productId?: string) => Promise<void>;
  movements: StockMovement[];
  movementsLoading: boolean;
  locations?: { id: string; name: string }[];
  activeLocationId?: string | null;
  readOnly?: boolean;
  showPurchasePrice?: boolean;
}

type StockFilter = 'all' | 'low' | 'out' | 'untracked';

const TYPE_COLORS: Record<StockMovementType, string> = {
  entree:      'text-emerald-400',
  sortie:      'text-red-400',
  ajustement:  'text-amber-400',
  vente:       'text-blue-400',
  retour:      'text-purple-400',
};

interface MovementFormProps {
  products: Product[];
  type: 'entree' | 'sortie' | 'ajustement';
  preselectedId?: string;
  onSubmit: (p: { product_id: string; type: StockMovementType; quantity: number; unit_cost: number; reference: string; notes: string }) => Promise<void>;
  onClose: () => void;
}

function MovementForm({ products, type, preselectedId, onSubmit, onClose }: MovementFormProps) {
  const [productId, setProductId] = useState(preselectedId ?? '');
  const [quantity, setQuantity] = useState('');
  const [unitCost, setUnitCost] = useState('');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const product = products.find(p => p.id === productId);

  const titles: Record<string, string> = {
    entree: 'Entrée de stock',
    sortie: 'Sortie de stock',
    ajustement: 'Inventaire',
  };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!productId) { setErr('Sélectionnez un article.'); return; }
    const q = parseFloat(quantity);
    if (Number.isNaN(q) || q < 0 || (type !== 'ajustement' && q <= 0)) { setErr('Quantité invalide.'); return; }
    setSaving(true);
    try {
      await onSubmit({ product_id: productId, type, quantity: q, unit_cost: parseFloat(unitCost) || 0, reference, notes });
      onClose();
    } catch (e) { setErr(e instanceof Error ? translateError(e.message) : 'Erreur'); setSaving(false); }
  }

  const labelQty = type === 'ajustement' ? 'Nouvelle quantité (stock réel)' : 'Quantité';

  return (
    <form onSubmit={submit} className="space-y-4 p-5">
      <div>
        <label className="label">Article *</label>
        <select className="input" value={productId} onChange={e => setProductId(e.target.value)}>
          <option value="">— Sélectionner —</option>
          {products.filter(p => p.active).map(p => (
            <option key={p.id} value={p.id}>
              {p.name} (stock actuel : {fmtQty(p.stock_quantity)} {p.unit})
            </option>
          ))}
        </select>
        {product && type !== 'ajustement' && (
          <p className="mt-1 text-xs text-gray-400">
            Stock actuel : <span className="font-semibold text-gray-700">
              {fmtQty(product.stock_quantity)} {product.unit}
            </span>
          </p>
        )}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">{labelQty} *</label>
          <input type="number" step="0.01" min={type === 'ajustement' ? 0 : 0.01} className="input" value={quantity} onChange={e => setQuantity(e.target.value)} placeholder="0" />
        </div>
        {type === 'entree' && (
          <div>
            <label className="label">Coût unitaire</label>
            <input type="number" step="any" min="0" className="input" value={unitCost} onChange={e => setUnitCost(e.target.value)} placeholder="0" />
          </div>
        )}
      </div>
      <div>
        <label className="label">Référence</label>
        <input className="input" value={reference} onChange={e => setReference(e.target.value)} placeholder="N° BL, facture fournisseur…" />
      </div>
      <div>
        <label className="label">Notes</label>
        <input className="input" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Motif, commentaire…" />
      </div>
      {err && <p className="text-xs text-red-400">{err}</p>}
      <div className="flex gap-2 pt-1">
        <button type="button" onClick={onClose} className="flex-1 rounded-lg border border-gray-300 py-2.5 text-sm text-gray-500 hover:bg-gray-100">Annuler</button>
        <button type="submit" disabled={saving} className="flex-1 rounded-lg bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
          {saving ? 'Enregistrement…' : titles[type]}
        </button>
      </div>
    </form>
  );
}

export function StockPage({ products, currency, onAddMovement, fetchMovements, movements, movementsLoading, locations, activeLocationId, readOnly, showPurchasePrice }: StockPageProps) {
  const [filter, setFilter] = useState<StockFilter>('all');
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'stock' | 'movements'>('stock');
  const [modalType, setModalType] = useState<'entree' | 'sortie' | 'ajustement' | null>(null);
  const [preselectedId, setPreselectedId] = useState<string | undefined>();
  const [selectedLocId, setSelectedLocId] = useState<string>(activeLocationId ?? 'all');
  const [crossStock, setCrossStock] = useState<Map<string, LocationStockRow> | null>(null);
  const [crossLoading, setCrossLoading] = useState(false);
  const [crossMovements, setCrossMovements] = useState<StockMovement[]>([]);
  const [crossMovLoading, setCrossMovLoading] = useState(false);
  const [locRefCounts, setLocRefCounts] = useState<{ locationId: string; count: number }[]>([]);

  const isViewingOtherLocation = selectedLocId !== 'all' && selectedLocId !== activeLocationId;
  const isViewingSpecificLocation = selectedLocId !== 'all';

  const fetchCrossStock = useCallback(async (locId: string) => {
    setCrossLoading(true);
    const { data, error } = await supabase
      .from('location_stock')
      .select('product_id, stock_quantity, stock_min')
      .eq('location_id', locId);
    if (!error && data) {
      const map = new Map<string, LocationStockRow>();
      for (const row of data as LocationStockRow[]) {
        map.set(row.product_id, row);
      }
      setCrossStock(map);
    } else {
      setCrossStock(new Map());
    }
    setCrossLoading(false);
  }, []);

  useEffect(() => {
    if (isViewingSpecificLocation) {
      fetchCrossStock(selectedLocId);
    } else {
      setCrossStock(null);
    }
  }, [selectedLocId, isViewingSpecificLocation, fetchCrossStock]);

  // Reset to default when activeLocationId changes
  useEffect(() => {
    setSelectedLocId(activeLocationId ?? 'all');
  }, [activeLocationId]);

  // Fetch reference counts per location
  useEffect(() => {
    if (!locations || locations.length === 0) return;
    let cancelled = false;
    (async () => {
      const counts: { locationId: string; count: number }[] = [];
      for (const loc of locations) {
        const { count, error } = await supabase
          .from('location_stock')
          .select('*', { count: 'exact', head: true })
          .eq('location_id', loc.id);
        if (!cancelled && !error) {
          counts.push({ locationId: loc.id, count: count ?? 0 });
        }
      }
      if (!cancelled) setLocRefCounts(counts);
    })();
    return () => { cancelled = true; };
  }, [locations]);

  const fetchCrossMovements = useCallback(async (locId: string) => {
    setCrossMovLoading(true);
    const { data: rows, error } = await supabase
      .from('stock_movements')
      .select('*')
      .eq('location_id', locId)
      .order('created_at', { ascending: false })
      .limit(200);
    if (!error && rows) {
      const mvRows = rows as StockMovement[];
      const productIds = [...new Set(mvRows.map(m => m.product_id).filter(Boolean) as string[])];
      const prodMap = new Map<string, { id: string; name: string; unit: string }>();
      if (productIds.length) {
        const { data: prods } = await supabase.from('products').select('id, name, unit').in('id', productIds);
        for (const p of (prods ?? []) as { id: string; name: string; unit: string }[]) {
          prodMap.set(p.id, p);
        }
      }
      const stockAfterMap = new Map<string, number>();
      if (productIds.length) {
        const { data: lsRows } = await supabase.from('location_stock').select('product_id, stock_quantity').eq('location_id', locId);
        for (const ls of (lsRows ?? []) as { product_id: string; stock_quantity: number }[]) {
          stockAfterMap.set(ls.product_id, Number(ls.stock_quantity));
        }
      }
      const withStockAfter: StockMovement[] = mvRows.map(m => {
        let current = stockAfterMap.get(m.product_id) ?? null;
        if (current !== null) {
          const qty = Number(m.quantity);
          if (m.type === 'entree' || m.type === 'retour') current -= qty;
          else if (m.type === 'sortie' || m.type === 'vente') current += qty;
          stockAfterMap.set(m.product_id, current);
        }
        return {
          ...m,
          product: prodMap.get(m.product_id) ? { id: m.product_id, name: prodMap.get(m.product_id)!.name, unit: prodMap.get(m.product_id)!.unit } : undefined,
          stock_after: current,
        };
      });
      setCrossMovements(withStockAfter);
    } else {
      setCrossMovements([]);
    }
    setCrossMovLoading(false);
  }, []);

  useEffect(() => {
    if (activeTab === 'movements') {
      if (isViewingOtherLocation) {
        fetchCrossMovements(selectedLocId);
      } else {
        fetchMovements();
      }
    }
  }, [activeTab, isViewingOtherLocation, selectedLocId, fetchMovements, fetchCrossMovements]);

  const displayProducts = useMemo(() => {
    if (!isViewingSpecificLocation || !crossStock) return products;
    return products
      .filter(p => crossStock.has(p.id))
      .map(p => {
        const ls = crossStock.get(p.id)!;
        return { ...p, stock_quantity: ls.stock_quantity, stock_min: ls.stock_min };
      });
  }, [products, isViewingSpecificLocation, crossStock]);

  const trackedProducts = useMemo(() => displayProducts.filter(p => p.track_stock), [displayProducts]);

  const filtered = useMemo(() => {
    const base = displayProducts.filter(p => p.active);
    const q = search.trim().toLowerCase();
    const matchSearch = (p: Product) => !q || p.name.toLowerCase().includes(q) || (p.reference ?? '').toLowerCase().includes(q);
    switch (filter) {
      case 'low':    return base.filter(p => p.track_stock && p.stock_quantity > 0 && p.stock_quantity <= p.stock_min).filter(matchSearch);
      case 'out':    return base.filter(p => p.track_stock && p.stock_quantity <= 0).filter(matchSearch);
      case 'untracked': return base.filter(p => !p.track_stock).filter(matchSearch);
      default:       return base.filter(matchSearch);
    }
  }, [displayProducts, filter, search]);

  const stats = useMemo(() => {
    const tracked = displayProducts.filter(p => p.track_stock && p.active);
    const stockValue = tracked.reduce((s, p) => s + p.stock_quantity * p.purchase_price, 0);
    const caPotentiel = tracked.reduce((s, p) => s + p.stock_quantity * p.price, 0);
    const margeTotale = tracked.reduce((s, p) => s + (p.stock_quantity * (p.price - p.purchase_price)), 0);
    const totalPieces = tracked.reduce((s, p) => s + (p.stock_quantity > 0 ? p.stock_quantity : 0), 0);
    const low = tracked.filter(p => p.stock_quantity > 0 && p.stock_quantity <= p.stock_min).length;
    const out = tracked.filter(p => p.stock_quantity <= 0).length;
    return { stockValue, caPotentiel, margeTotale, totalPieces, low, out, total: tracked.length };
  }, [displayProducts]);

  function openModal(type: 'entree' | 'sortie' | 'ajustement', productId?: string) {
    setPreselectedId(productId);
    setModalType(type);
  }

  async function handleMovement(payload: Parameters<typeof onAddMovement>[0]) {
    await onAddMovement(payload);
    setModalType(null);
    if (isViewingSpecificLocation) {
      fetchCrossStock(selectedLocId);
    }
  }

  const fmt = (n: number) =>
    new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;

  const canEdit = !readOnly && !isViewingOtherLocation && isViewingSpecificLocation;
  const selectedLocName = locations?.find(l => l.id === selectedLocId)?.name ?? 'Ma boutique';

  async function printStock() {
    const now = new Date().toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' });
    const locLabel = isViewingSpecificLocation ? selectedLocName : 'Toutes les boutiques';
    const filterLabel = { all: 'Tous', low: 'Stock bas', out: 'Rupture', untracked: 'Non suivis' }[filter];

    const rows = filtered.map((p, i) => {
      const isOut = p.track_stock && p.stock_quantity <= 0;
      const isLow = p.track_stock && p.stock_quantity > 0 && p.stock_quantity <= p.stock_min;
      const stateLabel = !p.track_stock ? 'Non suivi' : isOut ? 'Rupture' : isLow ? 'Stock bas' : 'OK';
      const stockVal = p.stock_quantity * p.purchase_price;
      const caPotentiel = p.track_stock ? p.stock_quantity * p.price : 0;
      const marge = p.price > 0 && p.purchase_price > 0 ? p.price - p.purchase_price : 0;
      const margePct = p.price > 0 && p.purchase_price > 0 ? ((p.price - p.purchase_price) / p.price) * 100 : 0;
      return `<tr>
        <td style="text-align:center">${i + 1}</td>
        <td>${p.name}</td>
        <td>${p.reference || '—'}</td>
        <td style="text-align:center">${p.track_stock ? fmtQty(p.stock_quantity) : '—'}</td>
        <td style="text-align:center">${p.track_stock ? fmtQty(p.stock_min) : '—'}</td>
        <td style="text-align:right">${p.price > 0 ? fmt(p.price) : '—'}</td>
        ${showPurchasePrice ? `<td style="text-align:right">${p.purchase_price > 0 ? fmt(p.purchase_price) : '—'}</td>` : ''}
        ${showPurchasePrice ? `<td style="text-align:right">${p.track_stock && p.purchase_price > 0 ? fmt(stockVal) : '—'}</td>` : ''}
        ${showPurchasePrice ? `<td style="text-align:right">${p.track_stock && p.price > 0 ? fmt(caPotentiel) : '—'}</td>` : ''}
        ${showPurchasePrice ? `<td style="text-align:right">${marge > 0 ? fmt(marge) + ' (' + margePct.toFixed(0) + '%)' : '—'}</td>` : ''}
        <td style="text-align:center">${stateLabel}</td>
      </tr>`;
    }).join('');

    const html = `<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'Segoe UI',Arial,sans-serif;color:#1f2937;padding:24px;font-size:12px}
      h1{font-size:20px;margin-bottom:4px}
      .meta{color:#6b7280;font-size:11px;margin-bottom:16px}
      .info{display:flex;gap:24px;margin-bottom:16px;font-size:11px}
      .info span{color:#374151}
      .info b{color:#111827}
      table{width:100%;border-collapse:collapse}
      th{background:#f3f4f6;padding:8px 6px;font-size:10px;text-transform:uppercase;letter-spacing:.5px;color:#6b7280;border-bottom:2px solid #e5e7eb}
      td{padding:6px;border-bottom:1px solid #f3f4f6}
      tbody tr:nth-child(even){background:#fafafa}
      .footer{margin-top:18px;padding-top:10px;border-top:1px solid #e5e7eb;font-size:10px;color:#9ca3af;display:flex;justify-content:space-between}
      .spacer{height:40px}
      @media print{body{padding:0}}
    </style></head><body>
      <h1>Etat du stock</h1>
      <div class="meta">Edite le ${now}</div>
      <div class="info">
        <span>Point de vente : <b>${locLabel}</b></span>
        <span>Filtre : <b>${filterLabel}</b></span>
        <span>Articles : <b>${filtered.length}</b></span>
        <span>Valeur d'achat : <b>${fmt(stats.stockValue)}</b></span>
        <span>Total pièces : <b>${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(stats.totalPieces)}</b></span>
        <span>CA potentiel : <b>${fmt(stats.caPotentiel)}</b></span>
        <span>Marge totale : <b>${fmt(stats.margeTotale)}</b></span>
      </div>
      <table>
        <thead><tr>
          <th style="text-align:center">#</th>
          <th>Article</th>
          <th>Référence</th>
          <th style="text-align:center">Stock</th>
          <th style="text-align:center">Seuil</th>
          <th style="text-align:right">Prix vente</th>
          ${showPurchasePrice ? '<th style="text-align:right">Prix achat</th>' : ''}
          ${showPurchasePrice ? '<th style="text-align:right">Valeur stock</th>' : ''}
          ${showPurchasePrice ? '<th style="text-align:right">CA potentiel</th>' : ''}
          ${showPurchasePrice ? '<th style="text-align:right">Marge</th>' : ''}
          <th style="text-align:center">Etat</th>
        </tr></thead>
        <tbody>${rows || '<tr><td colspan="10" style="text-align:center;padding:20px;color:#9ca3af">Aucun article</td></tr>'}</tbody>
      </table>
      <div class="footer"><span>Stock au ${now}</span><span>${filtered.length} article(s)</span></div>
      <div class="spacer"></div>
    </body></html>`;

    const filename = `stock_${isViewingSpecificLocation ? selectedLocName.replace(/\s+/g, '_') : 'tous'}_${new Date().toISOString().slice(0, 10)}.pdf`;
    await exportHtmlToPdf(html, filename, 'a4');
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-lg font-bold text-gray-900">
            {readOnly ? 'Consultation des stocks' : 'Gestion des stocks'}
          </h1>
          <p className="text-sm text-gray-400">
            {readOnly ? 'Niveaux de stock de tous les points de vente' : 'Suivi des niveaux et mouvements de stock'}
          </p>
        </div>
        {canEdit && (
          <div className="flex gap-2">
            <button onClick={() => openModal('ajustement')} className="flex items-center gap-1.5 rounded-lg border border-gray-300 bg-gray-100 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200 transition">
              <SlidersHorizontal className="h-4 w-4" /> Inventaire
            </button>
            <button onClick={() => openModal('sortie')} className="flex items-center gap-1.5 rounded-lg border border-red-800/60 bg-red-950/30 px-3 py-2 text-sm font-medium text-red-400 hover:bg-red-950/60 transition">
              <ArrowDownCircle className="h-4 w-4" /> Sortie
            </button>
            <button onClick={() => openModal('entree')} className="flex items-center gap-1.5 rounded-lg bg-emerald-700 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-600 transition">
              <ArrowUpCircle className="h-4 w-4" /> Entrée
            </button>
          </div>
        )}
      </div>

      {/* Location selector */}
      {locations && locations.length > 0 && (
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <MapPin className="h-4 w-4" />
            <span>Point de vente :</span>
          </div>
          <select
            className="rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-500 transition"
            value={selectedLocId}
            onChange={e => setSelectedLocId(e.target.value)}
          >
            <option value="all">Toutes les boutiques</option>
            {locations.map(l => {
              const c = locRefCounts.find(rc => rc.locationId === l.id);
              return (
                <option key={l.id} value={l.id}>{l.name}{c ? ` (${c.count})` : ''}</option>
              );
            })}
          </select>
          {isViewingOtherLocation && (
            <span className="rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-semibold text-blue-600 ring-1 ring-blue-200">
              Consultation (lecture seule)
            </span>
          )}
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        {[
          { label: 'Valeur d\'achat', value: fmt(stats.stockValue), icon: Package, color: 'bg-blue-500/10 text-blue-500' },
          { label: 'CA potentiel', value: fmt(stats.caPotentiel), icon: TrendingUp, color: 'bg-emerald-500/10 text-emerald-600' },
          { label: 'Marge totale', value: fmt(stats.margeTotale), icon: Banknote, color: 'bg-amber-500/10 text-amber-600' },
          { label: 'Pièces en stock', value: new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(stats.totalPieces), icon: Package, color: 'bg-gray-100/40 text-gray-600' },
          { label: 'Stock bas', value: String(stats.low), icon: AlertTriangle, color: stats.low > 0 ? 'bg-amber-500/10 text-amber-500' : 'bg-gray-100/40 text-gray-400' },
          { label: 'Rupture de stock', value: String(stats.out), icon: AlertTriangle, color: stats.out > 0 ? 'bg-red-500/10 text-red-500' : 'bg-gray-100/40 text-gray-400' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="rounded-xl border border-gray-200 bg-white p-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">{label}</p>
              <div className={`flex h-7 w-7 items-center justify-center rounded-lg ${color}`}>
                <Icon className="h-4 w-4" />
              </div>
            </div>
            <p className="text-xl font-bold text-gray-900">{value}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 rounded-lg border border-gray-300 bg-gray-100 p-1 w-fit">
        {([['stock', `Niveaux de stock${isViewingOtherLocation ? ' — ' + selectedLocName : ''}`], ['movements', 'Mouvements']] as const).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`rounded-md px-4 py-1.5 text-sm font-medium transition ${activeTab === key ? 'bg-gray-200 text-gray-900' : 'text-gray-500 hover:text-gray-800'}`}
          >
            {label}
          </button>
        ))}
      </div>

      {activeTab === 'stock' && (
        <>
          {/* Filter chips + search */}
          <div className="flex items-center gap-2 flex-wrap">
            {([['all', 'Tous'], ['low', 'Stock bas'], ['out', 'Rupture'], ['untracked', 'Non suivis']] as const).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`rounded-full px-3 py-1 text-xs font-semibold transition ring-1 ${
                  filter === key
                    ? 'bg-blue-600 text-white ring-blue-600'
                    : 'bg-gray-100 text-gray-500 ring-gray-200 hover:text-gray-800'
                }`}
              >
                {label}
              </button>
            ))}
            <div className="ml-auto flex items-center gap-2">
              <button
                onClick={() => printStock()}
                disabled={crossLoading || filtered.length === 0}
                className="flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 hover:bg-gray-100 transition disabled:opacity-50"
                title="Imprimer le stock"
              >
                <Printer className="h-3.5 w-3.5" />
                Imprimer
              </button>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Rechercher un article…"
                  className="w-44 rounded-full border border-gray-200 bg-white py-1.5 pl-8 pr-3 text-xs text-gray-800 outline-none focus:border-blue-500 transition sm:w-56"
                />
              </div>
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-gray-200">
            {crossLoading ? (
              <div className="py-14 text-center text-sm text-gray-400 animate-pulse">Chargement du stock de {selectedLocName}…</div>
            ) : filtered.length === 0 ? (
              <div className="py-14 text-center text-sm text-gray-400">Aucun article dans cette catégorie.</div>
            ) : (
              <div className="overflow-x-auto">
              <table className="w-full min-w-[700px] text-sm">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    {['Article', 'Référence', 'Stock actuel', 'Seuil alerte', 'Prix vente', ...(showPurchasePrice ? ['Prix achat', 'Valeur stock', 'CA potentiel', 'Marge'] : []), 'État', canEdit ? '' : ''].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 first:pl-5">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filtered.map(p => {
                    const isOut = p.track_stock && p.stock_quantity <= 0;
                    const isLow = p.track_stock && p.stock_quantity > 0 && p.stock_quantity <= p.stock_min;
                    const stockVal = p.stock_quantity * p.purchase_price;
                    const caPotentiel = p.track_stock ? p.stock_quantity * p.price : 0;
                    const marge = p.price > 0 && p.purchase_price > 0 ? p.price - p.purchase_price : 0;
                    const margePct = p.price > 0 && p.purchase_price > 0 ? ((p.price - p.purchase_price) / p.price) * 100 : 0;
                    return (
                      <tr key={p.id} className="group bg-white hover:bg-gray-100/50">
                        <td className="px-4 py-3 pl-5">
                          <p className="font-semibold text-gray-800">{p.name}</p>
                          <p className="text-xs text-gray-400">{p.unit}</p>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-500 tabular-nums">
                          {p.reference || <span className="text-gray-300">—</span>}
                        </td>
                        <td className={`px-4 py-3 tabular-nums font-bold ${isOut ? 'text-red-400' : isLow ? 'text-amber-400' : 'text-gray-900'}`}>
                          {p.track_stock ? fmtQty(p.stock_quantity) : <span className="text-gray-300">—</span>}
                        </td>
                        <td className="px-4 py-3 tabular-nums text-gray-500">
                          {p.track_stock ? fmtQty(p.stock_min) : <span className="text-gray-300">—</span>}
                        </td>
                        <td className="px-4 py-3 tabular-nums text-gray-700">
                          {p.price > 0 ? fmt(p.price) : '—'}
                        </td>
                        {showPurchasePrice && (
                          <td className="px-4 py-3 tabular-nums text-gray-700">
                            {p.purchase_price > 0 ? fmt(p.purchase_price) : '—'}
                          </td>
                        )}
                        {showPurchasePrice && (
                          <td className="px-4 py-3 tabular-nums font-semibold text-gray-800">
                            {p.track_stock && p.purchase_price > 0 ? fmt(stockVal) : '—'}
                          </td>
                        )}
                        {showPurchasePrice && (
                          <td className="px-4 py-3 tabular-nums text-gray-700">
                            {p.track_stock && p.price > 0 ? fmt(caPotentiel) : '—'}
                          </td>
                        )}
                        {showPurchasePrice && (
                          <td className="px-4 py-3 tabular-nums text-gray-700">
                            {marge > 0 ? (
                              <span className="text-emerald-600">{fmt(marge)} <span className="text-xs text-gray-400">({margePct.toFixed(0)}%)</span></span>
                            ) : '—'}
                          </td>
                        )}
                        <td className="px-4 py-3">
                          {!p.track_stock ? (
                            <span className="text-xs text-gray-300">Non suivi</span>
                          ) : isOut ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-red-500/10 px-2.5 py-0.5 text-xs font-semibold text-red-400 ring-1 ring-red-500/30">
                              <AlertTriangle className="h-3 w-3" /> Rupture
                            </span>
                          ) : isLow ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2.5 py-0.5 text-xs font-semibold text-amber-400 ring-1 ring-amber-500/30">
                              <AlertTriangle className="h-3 w-3" /> Stock bas
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-xs font-semibold text-emerald-400 ring-1 ring-emerald-500/30">
                              OK
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 pr-4">
                          {canEdit && (
                            <div className="flex gap-1 opacity-0 transition group-hover:opacity-100">
                              <button onClick={() => openModal('entree', p.id)} className="rounded p-1 text-gray-400 hover:bg-emerald-950/60 hover:text-emerald-400" title="Entrée">
                                <TrendingUp className="h-4 w-4" />
                              </button>
                              <button onClick={() => openModal('sortie', p.id)} className="rounded p-1 text-gray-400 hover:bg-red-950/60 hover:text-red-400" title="Sortie">
                                <TrendingDown className="h-4 w-4" />
                              </button>
                              <button onClick={() => openModal('ajustement', p.id)} className="rounded p-1 text-gray-400 hover:bg-amber-950/60 hover:text-amber-400" title="Inventaire">
                                <SlidersHorizontal className="h-4 w-4" />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              </div>
            )}
          </div>
        </>
      )}

      {activeTab === 'movements' && !isViewingOtherLocation && (
        <div className="overflow-hidden rounded-xl border border-gray-200">
          {movementsLoading ? (
            <div className="py-14 text-center text-sm text-gray-400 animate-pulse">Chargement…</div>
          ) : movements.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-14 text-sm text-gray-400">
              <History className="mb-2 h-8 w-8 opacity-30" />
              Aucun mouvement enregistré.
            </div>
          ) : (
            <>
              {/* Mobile: card layout */}
              <div className="divide-y divide-gray-100 lg:hidden">
                {movements.map(m => (
                  <div key={m.id} className="bg-white p-3.5 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-gray-800 text-sm">{m.product?.name ?? '—'}</span>
                      <span className={`text-xs font-bold ${TYPE_COLORS[m.type]}`}>{MOVEMENT_LABELS[m.type]}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-400">{new Date(m.created_at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}</span>
                      <span className={`tabular-nums font-bold ${m.type === 'entree' ? 'text-emerald-500' : m.type === 'sortie' || m.type === 'vente' ? 'text-red-500' : 'text-amber-500'}`}>
                        {m.type === 'entree' ? '+' : m.type === 'sortie' || m.type === 'vente' ? '−' : '='}{fmtQty(m.quantity)} {m.product?.unit}
                      </span>
                    </div>
                    {m.stock_after != null && (
                      <div className="text-xs text-gray-500">
                        Stock final : <span className="font-semibold text-gray-800">{fmtQty(m.stock_after)} {m.product?.unit}</span>
                      </div>
                    )}
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500">
                      {m.unit_cost > 0 && <span>Coût U.: <span className="font-semibold text-gray-700">{fmt(m.unit_cost)}</span></span>}
                      {m.reference && <span>Réf: <span className="text-gray-700">{m.reference}</span></span>}
                      {m.notes && <span>Notes: <span className="text-gray-700">{m.notes}</span></span>}
                    </div>
                  </div>
                ))}
              </div>
              {/* Desktop: table with horizontal scroll */}
              <div className="hidden overflow-x-auto lg:block">
                <table className="w-full min-w-[900px] text-sm">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      {['Date', 'Article', 'Type', 'Quantité', 'Stock final', 'Coût U.', 'Référence', 'Notes'].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-500 first:pl-5">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {movements.map(m => (
                      <tr key={m.id} className="bg-white hover:bg-gray-100/40">
                        <td className="px-4 py-3 pl-5 text-xs text-gray-500">
                          {new Date(m.created_at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}
                        </td>
                        <td className="px-4 py-3 font-semibold text-gray-800">{m.product?.name ?? '—'}</td>
                        <td className={`px-4 py-3 text-xs font-bold ${TYPE_COLORS[m.type]}`}>
                          {MOVEMENT_LABELS[m.type]}
                        </td>
                        <td className="px-4 py-3 tabular-nums font-semibold">
                          <span className={m.type === 'entree' ? 'text-emerald-500' : m.type === 'sortie' || m.type === 'vente' ? 'text-red-500' : 'text-amber-500'}>
                            {m.type === 'entree' ? '+' : m.type === 'sortie' || m.type === 'vente' ? '−' : '='}{fmtQty(m.quantity)} {m.product?.unit}
                          </span>
                        </td>
                        <td className="px-4 py-3 tabular-nums font-semibold text-gray-800">
                          {m.stock_after != null ? `${fmtQty(m.stock_after)} ${m.product?.unit ?? ''}` : '—'}
                        </td>
                        <td className="px-4 py-3 tabular-nums text-gray-600">
                          {m.unit_cost > 0 ? fmt(m.unit_cost) : '—'}
                        </td>
                        <td className="px-4 py-3 text-xs text-gray-500">{m.reference || '—'}</td>
                        <td className="px-4 py-3 text-xs text-gray-500">{m.notes || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {activeTab === 'movements' && isViewingOtherLocation && (
        <div className="overflow-hidden rounded-xl border border-gray-200">
          {crossMovLoading ? (
            <div className="py-14 text-center text-sm text-gray-400 animate-pulse">Chargement des mouvements de {selectedLocName}…</div>
          ) : crossMovements.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-14 text-sm text-gray-400">
              <History className="mb-2 h-8 w-8 opacity-30" />
              Aucun mouvement enregistré pour {selectedLocName}.
            </div>
          ) : (
            <>
              {/* Mobile: card layout */}
              <div className="divide-y divide-gray-100 lg:hidden">
                {crossMovements.map(m => (
                  <div key={m.id} className="bg-white p-3.5 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-gray-800 text-sm">{m.product?.name ?? '—'}</span>
                      <span className={`text-xs font-bold ${TYPE_COLORS[m.type]}`}>{MOVEMENT_LABELS[m.type]}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-400">{new Date(m.created_at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}</span>
                      <span className={`tabular-nums font-bold ${m.type === 'entree' ? 'text-emerald-500' : m.type === 'sortie' || m.type === 'vente' ? 'text-red-500' : 'text-amber-500'}`}>
                        {m.type === 'entree' ? '+' : m.type === 'sortie' || m.type === 'vente' ? '−' : '='}{fmtQty(m.quantity)} {m.product?.unit}
                      </span>
                    </div>
                    {m.stock_after != null && (
                      <div className="text-xs text-gray-500">
                        Stock final : <span className="font-semibold text-gray-800">{fmtQty(m.stock_after)} {m.product?.unit}</span>
                      </div>
                    )}
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500">
                      {m.unit_cost > 0 && <span>Coût U.: <span className="font-semibold text-gray-700">{fmt(m.unit_cost)}</span></span>}
                      {m.reference && <span>Réf: <span className="text-gray-700">{m.reference}</span></span>}
                      {m.notes && <span>Notes: <span className="text-gray-700">{m.notes}</span></span>}
                    </div>
                  </div>
                ))}
              </div>
              {/* Desktop: table with horizontal scroll */}
              <div className="hidden overflow-x-auto lg:block">
                <table className="w-full min-w-[900px] text-sm">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      {['Date', 'Article', 'Type', 'Quantité', 'Stock final', 'Coût U.', 'Référence', 'Notes'].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-500 first:pl-5">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {crossMovements.map(m => (
                      <tr key={m.id} className="bg-white hover:bg-gray-100/40">
                        <td className="px-4 py-3 pl-5 text-xs text-gray-500">
                          {new Date(m.created_at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}
                        </td>
                        <td className="px-4 py-3 font-semibold text-gray-800">{m.product?.name ?? '—'}</td>
                        <td className={`px-4 py-3 text-xs font-bold ${TYPE_COLORS[m.type]}`}>
                          {MOVEMENT_LABELS[m.type]}
                        </td>
                        <td className="px-4 py-3 tabular-nums font-semibold">
                          <span className={m.type === 'entree' ? 'text-emerald-500' : m.type === 'sortie' || m.type === 'vente' ? 'text-red-500' : 'text-amber-500'}>
                            {m.type === 'entree' ? '+' : m.type === 'sortie' || m.type === 'vente' ? '−' : '='}{fmtQty(m.quantity)} {m.product?.unit}
                          </span>
                        </td>
                        <td className="px-4 py-3 tabular-nums font-semibold text-gray-800">
                          {m.stock_after != null ? `${fmtQty(m.stock_after)} ${m.product?.unit ?? ''}` : '—'}
                        </td>
                        <td className="px-4 py-3 tabular-nums text-gray-600">
                          {m.unit_cost > 0 ? fmt(m.unit_cost) : '—'}
                        </td>
                        <td className="px-4 py-3 text-xs text-gray-500">{m.reference || '—'}</td>
                        <td className="px-4 py-3 text-xs text-gray-500">{m.notes || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {modalType && (
        <Modal
          title={modalType === 'entree' ? 'Entrée de stock' : modalType === 'sortie' ? 'Sortie de stock' : 'Inventaire'}
          onClose={() => setModalType(null)}
        >
          <MovementForm
            products={trackedProducts.length > 0 ? trackedProducts : products.filter(p => p.active)}
            type={modalType}
            preselectedId={preselectedId}
            onSubmit={handleMovement}
            onClose={() => setModalType(null)}
          />
        </Modal>
      )}
    </div>
  );
}
