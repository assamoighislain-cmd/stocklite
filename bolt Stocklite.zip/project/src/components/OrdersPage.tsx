import { useState } from 'react';
import { Search, PlusCircle, Eye, CheckCircle2, FileText, Loader2, Trash2, Pencil } from 'lucide-react';
import type { Order, OrderStatus } from '../types';
import { ORDER_STATUS_LABELS } from '../types';
import type { Route } from '../App';

interface OrdersPageProps {
  orders: Order[];
  onNavigate: (r: Route) => void;
  onValidate: (id: string) => Promise<void>;
  onConvert: (id: string) => Promise<void>;
  onDelete?: (id: string) => Promise<void>;
  canValidate: boolean;
}

const STATUSES: OrderStatus[] = ['brouillon', 'validee', 'convertie', 'annulee'];

function fmt(n: number) {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XOF', maximumFractionDigits: 0 }).format(n);
}

const STATUS_STYLES: Record<OrderStatus, string> = {
  brouillon: 'bg-gray-100 text-gray-600 ring-gray-200',
  validee: 'bg-blue-50 text-blue-700 ring-blue-200',
  convertie: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  annulee: 'bg-red-50 text-red-600 ring-red-200',
};

export function OrdersPage({ orders, onNavigate, onValidate, onConvert, onDelete, canValidate }: OrdersPageProps) {
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [convertingId, setConvertingId] = useState<string | null>(null);
  const [validatingId, setValidatingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filtered = orders.filter(o => {
    const matchStatus = statusFilter === 'all' || o.status === statusFilter;
    const matchQuery =
      o.order_number.toLowerCase().includes(query.toLowerCase()) ||
      (o.customer?.name ?? '').toLowerCase().includes(query.toLowerCase());
    return matchStatus && matchQuery;
  });

  const totalFiltered = filtered.reduce((s, o) => s + o.total, 0);

  async function handleValidate(id: string) {
    setValidatingId(id);
    try { await onValidate(id); } finally { setValidatingId(null); }
  }

  async function handleConvert(id: string) {
    setConvertingId(id);
    try { await onConvert(id); } finally { setConvertingId(null); }
  }

  async function handleDelete(id: string) {
    if (!onDelete) return;
    if (!confirm('Supprimer cette commande ?')) return;
    setDeletingId(id);
    try { await onDelete(id); } finally { setDeletingId(null); }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-gray-900">Commandes</h1>
          <p className="text-sm text-gray-400">{orders.length} commande{orders.length > 1 ? 's' : ''}</p>
        </div>
        <button
          onClick={() => onNavigate({ page: 'order-form' })}
          className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition active:scale-95"
        >
          <PlusCircle className="h-4 w-4" /> Nouvelle commande
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Numéro, client…"
            className="w-full rounded-lg border border-gray-300 bg-gray-100 py-2 pl-9 pr-4 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500"
          />
        </div>
        <div className="flex gap-1 rounded-lg border border-gray-300 bg-gray-100 p-1">
          <button
            onClick={() => setStatusFilter('all')}
            className={`rounded-md px-3 py-1 text-xs font-medium transition ${statusFilter === 'all' ? 'bg-gray-200 text-gray-900' : 'text-gray-500 hover:text-gray-800'}`}
          >
            Toutes
          </button>
          {STATUSES.map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`rounded-md px-3 py-1 text-xs font-medium transition ${statusFilter === s ? 'bg-gray-200 text-gray-900' : 'text-gray-500 hover:text-gray-800'}`}
            >
              {ORDER_STATUS_LABELS[s]}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200">
        {filtered.length === 0 ? (
          <div className="py-14 text-center text-sm text-gray-400">
            {query || statusFilter !== 'all' ? 'Aucune commande correspondante.' : 'Aucune commande. Créez votre première commande.'}
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[700px] text-sm">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    {['Numéro', 'Client', 'Commercial', 'Date', 'Total', 'Statut', ''].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 first:pl-5">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filtered.map(o => (
                    <tr key={o.id} className="group bg-white hover:bg-gray-100">
                      <td className="px-4 py-3 pl-5 font-mono text-xs font-semibold text-blue-400">{o.order_number}</td>
                      <td className="px-4 py-3 font-medium text-gray-800">{o.customer?.name ?? '—'}</td>
                      <td className="px-4 py-3 text-gray-500">{o.commercial?.name ?? '—'}</td>
                      <td className="px-4 py-3 tabular-nums text-gray-500">{new Date(o.date).toLocaleDateString('fr-FR')}</td>
                      <td className="px-4 py-3 tabular-nums font-semibold text-gray-900">{fmt(o.total)}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ${STATUS_STYLES[o.status]}`}>
                          {ORDER_STATUS_LABELS[o.status]}
                        </span>
                      </td>
                      <td className="px-4 py-3 pr-4">
                        <div className="flex items-center gap-1 opacity-0 transition group-hover:opacity-100">
                          {o.status === 'brouillon' && (
                            <button
                              onClick={() => onNavigate({ page: 'order-form', editId: o.id })}
                              className="rounded p-1.5 text-blue-500 hover:bg-blue-50 hover:text-blue-600"
                              title="Modifier / ajouter des articles"
                            >
                              <Pencil className="h-4 w-4" />
                            </button>
                          )}
                          {o.status === 'brouillon' && canValidate && (
                            <button
                              onClick={() => handleValidate(o.id)}
                              disabled={validatingId === o.id}
                              className="flex items-center gap-1 rounded-md bg-blue-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50"
                              title="Valider la commande"
                            >
                              {validatingId === o.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                              Valider
                            </button>
                          )}
                          {o.status === 'validee' && (
                            <button
                              onClick={() => handleConvert(o.id)}
                              disabled={convertingId === o.id}
                              className="flex items-center gap-1 rounded-md bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 transition disabled:opacity-50"
                              title="Convertir en facture"
                            >
                              {convertingId === o.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileText className="h-3.5 w-3.5" />}
                              Convertir
                            </button>
                          )}
                          {o.status === 'brouillon' && onDelete && (
                            <button
                              onClick={() => handleDelete(o.id)}
                              disabled={deletingId === o.id}
                              className="rounded p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500"
                              title="Supprimer"
                            >
                              {deletingId === o.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                            </button>
                          )}
                          <button
                            onClick={() => onNavigate({ page: 'order-detail', id: o.id })}
                            className="rounded p-1.5 text-gray-500 hover:bg-gray-200 hover:text-gray-800"
                            title="Voir le détail"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between border-t border-gray-200 bg-gray-50 px-5 py-3">
              <span className="text-xs text-gray-400">{filtered.length} commande{filtered.length > 1 ? 's' : ''}</span>
              <span className="text-xs text-gray-500">Total : <span className="font-semibold text-gray-900">{fmt(totalFiltered)}</span></span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
