import type { InvoiceStatus } from '../types';
import { STATUS_LABELS } from '../types';

const colors: Record<InvoiceStatus, string> = {
  brouillon: 'bg-gray-100 text-gray-500 ring-1 ring-gray-400',
  envoyee: 'bg-blue-500/10 text-blue-400 ring-1 ring-blue-500/30',
  payee: 'bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/30',
  partielle: 'bg-amber-500/10 text-amber-400 ring-1 ring-amber-500/30',
  annulee: 'bg-red-500/10 text-red-400 ring-1 ring-red-500/30',
};

export function StatusBadge({ status }: { status: InvoiceStatus }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${colors[status]}`}>
      {STATUS_LABELS[status]}
    </span>
  );
}
