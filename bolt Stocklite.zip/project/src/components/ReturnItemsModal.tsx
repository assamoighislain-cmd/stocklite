import { useState } from 'react';
import { RotateCcw, Package } from 'lucide-react';
import { Modal } from './Modal';
import { fmtQty } from '../lib/format';

interface ReturnItem {
  id: string;
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
}

interface ReturnItemsModalProps {
  title: string;
  items: ReturnItem[];
  onSubmit: (returns: { item_id: string; product_id: string | null; quantity: number }[]) => Promise<void>;
  onClose: () => void;
}

export function ReturnItemsModal({ title, items, onSubmit, onClose }: ReturnItemsModalProps) {
  const [quantities, setQuantities] = useState<Record<string, string>>({});
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const trackedItems = items.filter(i => i.product_id);

  function setQty(itemId: string, qty: string) {
    setQuantities(q => ({ ...q, [itemId]: qty }));
  }

  function getReturnQty(item: ReturnItem): number {
    const raw = quantities[item.id];
    if (!raw) return 0;
    const n = parseFloat(raw);
    if (Number.isNaN(n) || n <= 0) return 0;
    return Math.min(n, item.quantity);
  }

  const selectedReturns = trackedItems
    .map(i => ({ item_id: i.id, product_id: i.product_id, quantity: getReturnQty(i) }))
    .filter(r => r.quantity > 0);

  const totalReturn = selectedReturns.reduce((s, r) => s + r.quantity, 0);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (selectedReturns.length === 0) { setErr('Indiquez au moins une quantité à retourner.'); return; }
    setSaving(true);
    setErr('');
    try {
      await onSubmit(selectedReturns);
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Erreur lors du retour');
      setSaving(false);
    }
  }

  if (trackedItems.length === 0) {
    return (
      <Modal title={title} onClose={onClose}>
        <div className="flex flex-col items-center justify-center py-10 text-center">
          <Package className="mb-3 h-10 w-10 text-gray-300" />
          <p className="text-sm text-gray-500">Aucun article suivi en stock dans cette vente.</p>
          <button onClick={onClose} className="mt-4 rounded-lg border border-gray-300 px-4 py-2 text-sm text-gray-600 hover:bg-gray-100">
            Fermer
          </button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title={title} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4 p-5">
        <p className="text-sm text-gray-500">
          Sélectionnez les articles à remettre en stock. Le stock sera incrémenté et un mouvement de retour sera enregistré.
        </p>

        <div className="space-y-2">
          {trackedItems.map(item => {
            const returnQty = quantities[item.id] ?? '';
            const max = item.quantity;
            return (
              <div key={item.id} className="flex items-center gap-3 rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-gray-800 truncate">{item.description}</p>
                  <p className="text-xs text-gray-400">
                    Vendu : {fmtQty(item.quantity)}
                    {parseFloat(returnQty) > 0 && parseFloat(returnQty) <= max && (
                      <span className="ml-2 text-blue-500 font-medium">Retour : {fmtQty(parseFloat(returnQty))}</span>
                    )}
                  </p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max={max}
                    value={returnQty}
                    onChange={e => setQty(item.id, e.target.value)}
                    placeholder="0"
                    className="w-20 rounded-md border border-gray-300 bg-white px-2 py-1.5 text-center text-sm tabular-nums text-gray-900 outline-none focus:border-blue-500"
                  />
                  <span className="text-xs text-gray-400">/ {fmtQty(max)}</span>
                </div>
              </div>
            );
          })}
        </div>

        <div>
          <label className="label">Motif du retour</label>
          <input
            type="text"
            className="input"
            value={reason}
            onChange={e => setReason(e.target.value)}
            placeholder="Client insatisfait, article défectueux, erreur de saisie…"
          />
        </div>

        {err && <p className="rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{err}</p>}

        <div className="flex items-center justify-between border-t border-gray-100 pt-3">
          <span className="text-sm text-gray-500">
            {totalReturn > 0 ? `${fmtQty(totalReturn)} article(s) à retourner` : 'Aucun retour sélectionné'}
          </span>
          <div className="flex gap-2">
            <button type="button" onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm text-gray-600 hover:bg-gray-100">
              Annuler
            </button>
            <button
              type="submit"
              disabled={saving || selectedReturns.length === 0}
              className="flex items-center gap-2 rounded-lg bg-amber-600 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-500 disabled:opacity-50"
            >
              <RotateCcw className="h-4 w-4" />
              {saving ? 'Retour en cours…' : 'Valider le retour'}
            </button>
          </div>
        </div>
      </form>
    </Modal>
  );
}
