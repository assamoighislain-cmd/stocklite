import { useState, useRef, useCallback } from 'react';
import { Upload, FileSpreadsheet, AlertTriangle, CheckCircle2, Download, Users, FileText, Receipt, X, MapPin, Loader2 } from 'lucide-react';
import * as XLSX from 'xlsx';
import { useImportData, parseExcel } from '../hooks/useImportData';
import type { ImportResult } from '../hooks/useImportData';
import type { SalesLocation } from '../types';
import { translateError } from '../lib/translateError';

interface Props {
  open: boolean;
  onClose: () => void;
  locationId?: string | null;
  locations?: SalesLocation[];
}

type FileKey = 'customers' | 'invoices' | 'invoiceItems' | 'payments';

const FILE_CONFIG: { key: FileKey; label: string; icon: typeof Users; headers: string[]; sample: string[] }[] = [
  {
    key: 'customers',
    label: 'Clients',
    icon: Users,
    headers: ['Code', 'Nom', 'Telephone', 'Email', 'Adresse', 'Ville', 'Type', 'NCC'],
    sample: ['CLI-001', 'Boutique Example', '+22501020304', 'contact@example.com', 'Rue 12', 'Abidjan', 'entreprise', '9606123E'],
  },
  {
    key: 'invoices',
    label: 'Factures',
    icon: FileText,
    headers: ['Numero', 'Code Client', 'Date', 'Echeance', 'Statut', 'Sous-total', 'TVA', 'Montant TVA', 'Total', 'Montant Paye', 'Notes'],
    sample: ['FAC-001', 'CLI-001', '2026-01-15', '2026-02-15', 'payee', '100000', '18', '18000', '118000', '118000', ''],
  },
  {
    key: 'invoiceItems',
    label: 'Lignes facture',
    icon: Receipt,
    headers: ['Numero Facture', 'Reference', 'Article', 'Designation', 'Quantite', 'Prix unitaire', 'Total'],
    sample: ['FAC-001', 'REF-001', 'Coca-Cola 1L', 'Bouteille 1 litre', '2', '50000', '100000'],
  },
  {
    key: 'payments',
    label: 'Reglements',
    icon: Receipt,
    headers: ['Numero Facture', 'Code Client', 'Montant', 'Methode', 'Date', 'Reference'],
    sample: ['FAC-001', 'CLI-001', '50000', 'especes', '2026-01-20', 'REF-001'],
  },
];

export function ImportDataModal({ open, onClose, locationId, locations = [] }: Props) {
  const [targetLocationId, setTargetLocationId] = useState<string | null>(locationId ?? null);
  const { doImport } = useImportData(targetLocationId);
  const [files, setFiles] = useState<Partial<Record<FileKey, File>>>({});
  const [previews, setPreviews] = useState<Partial<Record<FileKey, Record<string, string>[]>>>({});
  const [error, setError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState<{ current: number; total: number; label: string } | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);
  const inputRefs = useRef<Partial<Record<FileKey, HTMLInputElement>>>({});

  const reset = useCallback(() => {
    setFiles({});
    setPreviews({});
    setError(null);
    setResult(null);
    setProgress(null);
  }, []);

  const handleFile = useCallback(async (key: FileKey, file: File) => {
    setError(null);
    try {
      const rows = await parseExcel(file);
      if (rows.length === 0) {
        setError(`Le fichier "${file.name}" est vide ou ne contient pas de données.`);
        return;
      }
      setFiles(f => ({ ...f, [key]: file }));
      setPreviews(p => ({ ...p, [key]: rows.slice(0, 5) }));
    } catch (e) {
      setError(`Lecture de "${file.name}" impossible: ${e instanceof Error ? translateError(e.message) : 'erreur'}`);
    }
  }, []);

  const removeFile = useCallback((key: FileKey) => {
    setFiles(f => { const n = { ...f }; delete n[key]; return n; });
    setPreviews(p => { const n = { ...p }; delete n[key]; return n; });
  }, []);

  const downloadTemplate = useCallback((key: FileKey) => {
    const config = FILE_CONFIG.find(c => c.key === key)!;
    const ws = XLSX.utils.aoa_to_sheet([config.headers, config.sample]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, config.label);
    XLSX.writeFile(wb, `modele_${key}.xlsx`, { bookType: 'xlsx' });
  }, []);

  async function runImport() {
    if (Object.keys(files).length === 0) return;
    if (!targetLocationId) {
      setError('Veuillez sélectionner un point de vente avant d\'importer.');
      return;
    }
    setImporting(true);
    setError(null);
    setProgress({ current: 0, total: 0, label: 'Préparation…' });
    try {
      const res = await doImport(files, (current, total, label) => {
        setProgress({ current, total, label });
      });
      setResult(res);
      setFiles({});
      setPreviews({});
      setProgress(null);
    } catch (e) {
      setError(e instanceof Error ? translateError(e.message) : 'Erreur lors de l\'import.');
      setProgress(null);
    } finally {
      setImporting(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-3xl rounded-2xl bg-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-blue-600" />
            <h2 className="text-base font-semibold text-gray-900">Importer clients, factures et règlements</h2>
          </div>
          <button onClick={() => { reset(); onClose(); }} className="text-gray-400 hover:text-gray-700 text-xl leading-none">×</button>
        </div>

        <div className="overflow-y-auto px-6 py-5 space-y-5">
          {/* Point of sale selector */}
          {!result && (
            <div className="rounded-lg border border-blue-200 bg-blue-50 px-4 py-3 space-y-2">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-blue-600" />
                <label className="text-sm font-semibold text-blue-800">Point de vente</label>
              </div>
              <select
                value={targetLocationId ?? ''}
                onChange={e => setTargetLocationId(e.target.value || null)}
                className="w-full rounded-lg border border-blue-200 bg-white px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 transition"
              >
                <option value="">— Sélectionner un point de vente —</option>
                {locations.filter(l => l.active).map(l => (
                  <option key={l.id} value={l.id}>{l.name}</option>
                ))}
              </select>
              <p className="text-xs text-blue-600">
                Les clients, factures et règlements importés seront rattachés à ce point de vente.
              </p>
            </div>
          )}

          {/* Success state */}
          {result && (
            <div className="space-y-3">
              <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-semibold text-emerald-800">Import terminé</p>
                  <div className="mt-2 space-y-1 text-emerald-700">
                    {result.customers > 0 && <p>{result.customers} client{result.customers > 1 ? 's' : ''} importé{result.customers > 1 ? 's' : ''}</p>}
                    {result.invoices > 0 && <p>{result.invoices} facture{result.invoices > 1 ? 's' : ''} importée{result.invoices > 1 ? 's' : ''}</p>}
                    {result.invoiceItems > 0 && <p>{result.invoiceItems} ligne{result.invoiceItems > 1 ? 's' : ''} de facture importée{result.invoiceItems > 1 ? 's' : ''}</p>}
                    {result.payments > 0 && <p>{result.payments} règlement{result.payments > 1 ? 's' : ''} importé{result.payments > 1 ? 's' : ''}</p>}
                  </div>
                </div>
              </div>
              {result.errors.length > 0 && (
                <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
                  <p className="text-sm font-semibold text-amber-800 mb-2">{result.errors.length} avertissement{result.errors.length > 1 ? 's' : ''}</p>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {result.errors.map((e, i) => (
                      <p key={i} className="text-xs text-amber-700">{e}</p>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Upload zones */}
          {!result && (
            <>
              {importing && progress && (
                <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 font-semibold text-blue-800">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      {progress.label}
                    </span>
                    <span className="tabular-nums text-blue-600 font-medium">
                      {progress.total > 0 ? `${Math.round((progress.current / progress.total) * 100)}%` : '…'}
                      <span className="text-blue-400 ml-1">({progress.current}/{progress.total || '?'})</span>
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-blue-100">
                    <div
                      className="h-full rounded-full bg-blue-500 transition-all duration-300 ease-out"
                      style={{ width: progress.total > 0 ? `${(progress.current / progress.total) * 100}%` : '0%' }}
                    />
                  </div>
                </div>
              )}
              <div className="rounded-lg bg-blue-50 border border-blue-100 px-4 py-3">
                <p className="text-xs text-blue-700">
                  Importez vos fichiers Excel dans l'ordre : d'abord les <strong>clients</strong>, puis les <strong>factures</strong>, les <strong>lignes</strong> et les <strong>règlements</strong>.
                  Les factures sont reliées aux clients par leur code, et les règlements aux factures par leur numéro.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {FILE_CONFIG.map(config => {
                  const Icon = config.icon;
                  const file = files[config.key];
                  const preview = previews[config.key];
                  return (
                    <div key={config.key} className="rounded-xl border border-gray-200 overflow-hidden">
                      <div className="bg-gray-50 px-4 py-2.5 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Icon className="h-4 w-4 text-gray-500" />
                          <span className="text-sm font-semibold text-gray-700">{config.label}</span>
                        </div>
                        <button
                          onClick={() => downloadTemplate(config.key)}
                          className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-medium"
                        >
                          <Download className="h-3 w-3" /> Modèle
                        </button>
                      </div>

                      <div className="p-3">
                        {file ? (
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-gray-700 truncate">{file.name}</p>
                              <p className="text-[11px] text-gray-400">{preview?.length ?? 0} ligne{preview && preview.length > 1 ? 's' : ''} aperçu</p>
                            </div>
                            <button onClick={() => removeFile(config.key)} className="rounded p-1 text-gray-400 hover:bg-red-50 hover:text-red-500">
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => inputRefs.current[config.key]?.click()}
                            className="w-full flex items-center gap-2 rounded-lg border-2 border-dashed border-gray-300 px-3 py-4 text-center hover:border-blue-400 hover:bg-blue-50/50 transition"
                          >
                            <Upload className="h-4 w-4 text-gray-400" />
                            <span className="text-xs text-gray-500">Cliquer pour sélectionner un Excel</span>
                          </button>
                        )}
                        <input
                          ref={el => { if (el) inputRefs.current[config.key] = el; }}
                          type="file"
                          accept=".xlsx,.xls"
                          className="hidden"
                          onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(config.key, f); }}
                        />
                      </div>

                      {/* Expected columns */}
                      <div className="px-3 pb-3">
                        <div className="flex flex-wrap gap-1">
                          {config.headers.map(h => (
                            <span key={h} className="rounded bg-gray-100 px-1.5 py-0.5 text-[10px] font-medium text-gray-500">{h}</span>
                          ))}
                        </div>
                      </div>

                      {/* Preview table */}
                      {preview && preview.length > 0 && (
                        <div className="border-t border-gray-100 max-h-32 overflow-auto">
                          <table className="w-full text-[11px]">
                            <thead className="sticky top-0 bg-gray-50">
                              <tr>
                                {Object.keys(preview[0]).map(h => (
                                  <th key={h} className="px-2 py-1 text-left font-semibold text-gray-500 whitespace-nowrap">{h}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50">
                              {preview.map((row, i) => (
                                <tr key={i} className="bg-white">
                                  {Object.keys(preview[0]).map(h => (
                                    <td key={h} className="px-2 py-1 text-gray-600 whitespace-nowrap max-w-[120px] truncate">{row[h]}</td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {error && (
                <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3 py-2.5">
                  <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-red-700">{error}</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-100 px-6 py-4 flex gap-3">
          <button
            onClick={() => { reset(); onClose(); }}
            className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition"
          >
            {result ? 'Fermer' : 'Annuler'}
          </button>
          {!result && (
            <button
              onClick={runImport}
              disabled={importing || Object.keys(files).length === 0}
              className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50"
            >
              <Upload className="h-4 w-4" />
              {importing ? 'Import en cours…' : `Importer (${Object.keys(files).length} fichier${Object.keys(files).length > 1 ? 's' : ''})`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
