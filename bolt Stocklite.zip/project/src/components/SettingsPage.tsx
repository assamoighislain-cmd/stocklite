import { useState, useRef, useEffect } from 'react';
import { Save, Upload, Loader2, X, ShieldCheck, Calendar, AlertTriangle, FileText, Plus, Trash2, Check } from 'lucide-react';
import type { CompanySettings, SalesContract } from '../types';
import { supabase } from '../lib/supabase';
import { translateError } from '../lib/translateError';
import { useSalesContracts } from '../hooks/useSalesContracts';

const CURRENCIES = [
  { value: 'FCFA', label: 'FCFA — Franc CFA' },
  { value: 'MAD', label: 'MAD — Dirham marocain' },
  { value: 'DZD', label: 'DZD — Dinar algérien' },
  { value: 'TND', label: 'TND — Dinar tunisien' },
  { value: 'EUR', label: 'EUR — Euro' },
  { value: 'USD', label: 'USD — Dollar américain' },
  { value: 'XOF', label: 'XOF — Franc CFA UEMOA' },
  { value: 'XAF', label: 'XAF — Franc CFA CEMAC' },
  { value: 'GHS', label: 'GHS — Cédi ghanéen' },
  { value: 'NGN', label: 'NGN — Naira nigérian' },
  { value: 'KES', label: 'KES — Shilling kényan' },
];

interface SettingsPageProps {
  settings: CompanySettings | null;
  onSave: (d: Omit<CompanySettings, 'id'>) => Promise<void>;
  tenantId: string | null;
  activeContract: SalesContract | null;
}

export function SettingsPage({ settings, onSave, tenantId, activeContract }: SettingsPageProps) {
  const [form, setForm] = useState({
    name: settings?.name ?? '',
    address: settings?.address ?? '',
    city: settings?.city ?? '',
    phone: settings?.phone ?? '',
    email: settings?.email ?? '',
    tax_id: settings?.tax_id ?? '',
    invoice_footer: settings?.invoice_footer ?? 'Merci pour votre confiance.',
    delivery_notice: settings?.delivery_notice ?? '',
    currency: settings?.currency ?? 'FCFA',
    logo_url: settings?.logo_url ?? '',
    fne_ncc: settings?.fne_ncc ?? '',
    fne_api_key: settings?.fne_api_key ?? '',
    fne_point_of_sale: settings?.fne_point_of_sale ?? '',
    fne_establishment: settings?.fne_establishment ?? '',
    fne_api_url: settings?.fne_api_url ?? '',
    fne_bank_reference: settings?.fne_bank_reference ?? '',
    fne_tax_regime: settings?.fne_tax_regime ?? '',
    fne_tax_center: settings?.fne_tax_center ?? '',
    fne_rne: settings?.fne_rne ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [err, setErr] = useState('');
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [licenseInfo, setLicenseInfo] = useState<{ license_expires_at: string | null } | null>(null);

  useEffect(() => {
    if (!tenantId) return;
    supabase.from('tenants').select('license_expires_at').eq('id', tenantId).maybeSingle()
      .then(({ data }) => setLicenseInfo(data as { license_expires_at: string | null } | null));
  }, [tenantId]);

  function set(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); setSaved(false); }

  async function handleLogoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !tenantId) return;
    if (file.size > 2 * 1024 * 1024) { setErr('Le logo ne doit pas dépasser 2 Mo.'); return; }
    if (!['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml'].includes(file.type)) {
      setErr('Format accepté : PNG, JPG, WebP ou SVG.'); return;
    }
    setUploading(true); setErr('');
    try {
      const ext = file.name.split('.').pop() ?? 'png';
      const path = `${tenantId}/logo.${ext}`;
      const { error: upErr } = await supabase.storage
        .from('company-logos')
        .upload(path, file, { upsert: true, contentType: file.type });
      if (upErr) throw new Error(upErr.message);
      const { data: urlData } = supabase.storage
        .from('company-logos')
        .getPublicUrl(path);
      const logoUrl = `${urlData.publicUrl}?t=${Date.now()}`;
      set('logo_url', logoUrl);
    } catch (e) {
      setErr(e instanceof Error ? translateError(e.message) : 'Erreur lors du téléversement');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  async function removeLogo() {
    if (!tenantId || !form.logo_url) return;
    setUploading(true); setErr('');
    try {
      const path = form.logo_url.split('/company-logos/')[1]?.split('?')[0];
      if (path) {
        await supabase.storage.from('company-logos').remove([path]);
      }
      set('logo_url', '');
    } catch {
      set('logo_url', '');
    } finally {
      setUploading(false);
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setErr('Le nom de l\'entreprise est requis.'); return; }
    setSaving(true); setErr('');
    try { await onSave(form); setSaved(true); }
    catch (e) { setErr(e instanceof Error ? translateError(e.message) : 'Erreur'); }
    finally { setSaving(false); }
  }

  return (
    <div className="max-w-xl space-y-5">
      <div>
        <h1 className="text-lg font-bold text-gray-900">Paramètres</h1>
        <p className="text-sm text-gray-400">Informations entreprise — apparaissent sur vos factures et tickets</p>
      </div>

      <form onSubmit={submit} className="rounded-xl border border-gray-200 bg-white p-5 space-y-4">
        {/* Logo upload */}
        <div>
          <label className="label">Logo de l'entreprise</label>
          <p className="mb-2 text-xs text-gray-400">Apparaît en haut de vos factures et tickets. Format : PNG, JPG, WebP ou SVG. Max 2 Mo.</p>
          <div className="flex items-center gap-4">
            <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl border-2 border-gray-200 bg-gray-50 flex items-center justify-center">
              {form.logo_url ? (
                <>
                  <img src={form.logo_url} alt="Logo" className="h-full w-full object-contain" />
                  <button
                    type="button"
                    onClick={removeLogo}
                    disabled={uploading}
                    className="absolute right-0 top-0 rounded-bl-lg bg-red-500/90 px-1.5 py-0.5 text-white hover:bg-red-600 transition disabled:opacity-50"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </>
              ) : (
                <div className="text-center text-[10px] font-medium text-gray-300">Aucun logo</div>
              )}
            </div>
            <div className="flex-1">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                onChange={handleLogoUpload}
                disabled={uploading || !tenantId}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading || !tenantId}
                className="flex items-center gap-2 rounded-lg border border-gray-300 bg-gray-50 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 transition disabled:opacity-50"
              >
                {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                {uploading ? 'Téléversement…' : form.logo_url ? 'Changer le logo' : 'Choisir un logo'}
              </button>
              {!tenantId && (
                <p className="mt-1 text-xs text-amber-500">Tenant non défini — impossible de téléverser.</p>
              )}
            </div>
          </div>
        </div>

        <div>
          <label className="label">Raison sociale *</label>
          <input className="input" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Nom de votre entreprise" />
        </div>
        <div>
          <label className="label">Adresse</label>
          <input className="input" value={form.address} onChange={e => set('address', e.target.value)} placeholder="Rue, quartier, BP…" />
        </div>
        <div>
          <label className="label">Ville / Pays</label>
          <input className="input" value={form.city} onChange={e => set('city', e.target.value)} placeholder="Ville, Pays" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Téléphone</label>
            <input className="input" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+xxx xx xx xx" />
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" className="input" value={form.email} onChange={e => set('email', e.target.value)} placeholder="contact@exemple.com" />
          </div>
        </div>
        <div>
          <label className="label">SIRET / NIF / Numéro fiscal</label>
          <input className="input" value={form.tax_id} onChange={e => set('tax_id', e.target.value)} placeholder="Optionnel" />
        </div>
        <div>
          <label className="label">Devise</label>
          <select className="input" value={form.currency} onChange={e => set('currency', e.target.value)}>
            {CURRENCIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Pied de facture / ticket</label>
          <textarea rows={2} className="input resize-none" value={form.invoice_footer} onChange={e => set('invoice_footer', e.target.value)} placeholder="Merci pour votre confiance." />
        </div>
        <div>
          <label className="label">Observation bon de livraison</label>
          <textarea rows={2} className="input resize-none" value={form.delivery_notice} onChange={e => set('delivery_notice', e.target.value)} placeholder="Vérifiez vos articles à la réception. Aucune réclamation ne sera acceptée passé 48h." />
          <p className="mt-1 text-xs text-gray-400">Texte affiché au pied du tableau d'articles sur les bons de livraison.</p>
        </div>

        <div className="border-t border-gray-200 pt-4">
          <h3 className="text-sm font-semibold text-gray-900">Certification FNE (DGI Côte d'Ivoire)</h3>
          <p className="mt-1 text-xs text-gray-400">Paramètres pour l'interfaçage avec la plateforme Facture Normalisée Électronique. La clé API est fournie dans votre espace FNE (section Paramétrage).</p>
          <div className="mt-3 space-y-3">
            <div>
              <label className="label">NCC (Numéro Compte Contribuable)</label>
              <input className="input font-mono" value={form.fne_ncc} onChange={e => set('fne_ncc', e.target.value)} placeholder="Ex : 9606123E" />
            </div>
            <div>
              <label className="label">RNE (Registre du Commerce)</label>
              <input className="input font-mono" value={form.fne_rne} onChange={e => set('fne_rne', e.target.value)} placeholder="Ex : CI-ABJ-2018-B-12345" />
              <p className="mt-1 text-xs text-gray-400">Le RNE est distinct du NCC. Renseignez-le pour éviter les avertissements DGI.</p>
            </div>
            <div>
              <label className="label">Clé API FNE (Bearer Token)</label>
              <input type="password" className="input font-mono" value={form.fne_api_key} onChange={e => set('fne_api_key', e.target.value)} placeholder="kAF01gEM40r1Uz5WLJn5lxAnGMwVjCME" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Point de vente</label>
                <input className="input" value={form.fne_point_of_sale} onChange={e => set('fne_point_of_sale', e.target.value)} placeholder="Ex : 23" />
              </div>
              <div>
                <label className="label">Établissement</label>
                <input className="input" value={form.fne_establishment} onChange={e => set('fne_establishment', e.target.value)} placeholder="Nom de l'établissement" />
              </div>
            </div>
            <div>
              <label className="label">URL API FNE (laisser vide pour l'URL par défaut)</label>
              <input className="input font-mono text-xs" value={form.fne_api_url} onChange={e => set('fne_api_url', e.target.value)} placeholder="http://54.247.95.108/ws (test)" />
            </div>
            <div className="grid grid-cols-1 gap-3 pt-2 border-t border-gray-100">
              <div>
                <label className="label">Régime d'imposition</label>
                <input className="input" value={form.fne_tax_regime} onChange={e => set('fne_tax_regime', e.target.value)} placeholder="Ex : Réel simplifié, Forfait, Réel normal" />
              </div>
              <div>
                <label className="label">Centre des impôts</label>
                <input className="input" value={form.fne_tax_center} onChange={e => set('fne_tax_center', e.target.value)} placeholder="Ex : Centre des Impôts de Cocody" />
              </div>
              <div>
                <label className="label">Référence bancaire (RIB)</label>
                <input className="input font-mono text-xs" value={form.fne_bank_reference} onChange={e => set('fne_bank_reference', e.target.value)} placeholder="Ex : CI01 00001 0001234567890 12" />
              </div>
            </div>
          </div>
        </div>

        {err && <p className="text-xs text-red-400">{err}</p>}
        {saved && <p className="text-xs text-emerald-400">Paramètres enregistrés avec succès.</p>}
        <div className="flex justify-end pt-1">
          <button type="submit" disabled={saving} className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50 transition">
            <Save className="h-4 w-4" />
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </div>
      </form>

      {/* License & renewal */}
      {licenseInfo && (
        <div className="mt-6 rounded-xl border border-gray-200 bg-white p-5 space-y-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-blue-600" />
            <h3 className="text-sm font-semibold text-gray-900">Licence & abonnement</h3>
          </div>
          <div className="flex items-center gap-3 rounded-lg bg-gray-50 border border-gray-200 px-4 py-3">
            <Calendar className="h-5 w-5 text-gray-400" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-700">Expiration de la licence</p>
              <p className="text-xs text-gray-500">
                {licenseInfo.license_expires_at
                  ? new Date(licenseInfo.license_expires_at).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })
                  : 'Aucune licence définie'}
              </p>
            </div>
            {licenseInfo.license_expires_at && (() => {
              const days = Math.ceil((new Date(licenseInfo.license_expires_at).getTime() - Date.now()) / 86_400_000);
              if (days < 0) return <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-semibold text-red-700">Expirée</span>;
              if (days <= 30) return <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-700">{days}j restants</span>;
              return <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">{days}j restants</span>;
            })()}
          </div>
          {licenseInfo.license_expires_at && new Date(licenseInfo.license_expires_at).getTime() - Date.now() < 30 * 86_400_000 && (
            <div className="flex items-start gap-2 text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
              <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
              <span>Votre licence expire bientôt. Renouvelez dès maintenant pour éviter toute interruption de service.</span>
            </div>
          )}

        </div>
      )}

      {/* Sales Contract Management */}
      <SalesContractSection tenantId={tenantId} activeContract={activeContract} />

    </div>
  );
}

function SalesContractSection({ tenantId, activeContract }: { tenantId: string | null; activeContract: SalesContract | null }) {
  const { contracts, loading, save, remove, setActive } = useSalesContracts(tenantId);
  const [editing, setEditing] = useState<SalesContract | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', intro_text: '', terms: '', signature_label: 'Signature' });
  const [savingContract, setSavingContract] = useState(false);
  const [contractErr, setContractErr] = useState('');

  function openCreate() {
    setEditing(null);
    setForm({ title: 'Conditions de vente', intro_text: '', terms: '', signature_label: 'Signature' });
    setShowForm(true);
    setContractErr('');
  }

  function openEdit(c: SalesContract) {
    setEditing(c);
    setForm({
      title: c.title,
      intro_text: c.intro_text,
      terms: c.terms.join('\n'),
      signature_label: c.signature_label,
    });
    setShowForm(true);
    setContractErr('');
  }

  async function submitContract(e: React.FormEvent) {
    e.preventDefault();
    if (!form.title.trim()) { setContractErr('Le titre est requis.'); return; }
    setSavingContract(true); setContractErr('');
    try {
      const termsArr = form.terms.split('\n').map(t => t.trim()).filter(Boolean);
      await save(editing?.id ?? null, {
        title: form.title.trim(),
        intro_text: form.intro_text,
        terms: termsArr,
        signature_label: form.signature_label || 'Signature',
        is_active: editing ? editing.is_active : contracts.length === 0,
      });
      setShowForm(false);
      setEditing(null);
    } catch (err) {
      setContractErr(err instanceof Error ? translateError(err.message) : 'Erreur');
    } finally {
      setSavingContract(false);
    }
  }

  return (
    <div className="mt-6 rounded-xl border border-gray-200 bg-white p-5 space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-blue-600" />
          <div>
            <h3 className="text-sm font-semibold text-gray-900">Conditions de vente</h3>
            <p className="text-xs text-gray-400">S'imprime en deuxième page de la facture A4</p>
          </div>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 rounded-lg border border-blue-600 bg-blue-50 px-3.5 py-2 text-sm font-semibold text-blue-700 hover:bg-blue-100 transition"
        >
          <Plus className="h-4 w-4" /> Nouveau modèle
        </button>
      </div>

      {activeContract && !showForm && (
        <div className="flex items-center gap-2 rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-2 text-xs text-emerald-700">
          <Check className="h-4 w-4 shrink-0" />
          Modèle actif : <span className="font-semibold">{activeContract.title}</span>
        </div>
      )}

      {showForm && (
        <form onSubmit={submitContract} className="space-y-3 rounded-lg border border-gray-200 bg-gray-50/50 p-4">
          <div>
            <label className="label">Titre</label>
            <input className="input" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Conditions de vente" />
          </div>
          <div>
            <label className="label">Texte d'introduction</label>
            <textarea rows={3} className="input resize-none" value={form.intro_text} onChange={e => setForm(f => ({ ...f, intro_text: e.target.value }))} placeholder="Entre les soussignés…" />
          </div>
          <div>
            <label className="label">Conditions / Clauses (une par ligne)</label>
            <textarea rows={6} className="input resize-none font-mono text-xs" value={form.terms} onChange={e => setForm(f => ({ ...f, terms: e.target.value }))} placeholder={"Délai de livraison : 3 jours\nGarantie : 12 mois\nPaiement : 50% à la commande, solde à la livraison"} />
          </div>
          <div>
            <label className="label">Libellé signature</label>
            <input className="input" value={form.signature_label} onChange={e => setForm(f => ({ ...f, signature_label: e.target.value }))} placeholder="Signature" />
          </div>
          {contractErr && <p className="text-xs text-red-400">{contractErr}</p>}
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => { setShowForm(false); setEditing(null); }} className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100">Annuler</button>
            <button type="submit" disabled={savingContract} className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
              <Save className="h-4 w-4" /> {savingContract ? 'Enregistrement…' : 'Enregistrer'}
            </button>
          </div>
        </form>
      )}

      {!showForm && (
        loading ? (
          <p className="text-xs text-gray-400">Chargement…</p>
        ) : contracts.length === 0 ? (
          <p className="text-xs text-gray-400">Aucun modèle de conditions. Créez-en un pour qu'il s'imprime avec vos factures.</p>
        ) : (
          <div className="space-y-2">
            {contracts.map(c => (
              <div key={c.id} className="flex items-center justify-between gap-3 rounded-lg border border-gray-200 px-4 py-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-gray-800 truncate">{c.title}</p>
                    {c.is_active && <span className="shrink-0 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">Actif</span>}
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">{c.terms.length} clause{c.terms.length > 1 ? 's' : ''}</p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {!c.is_active && (
                    <button
                      onClick={() => setActive(c.id).catch(() => {})}
                      className="rounded-lg px-2.5 py-1.5 text-xs font-medium text-emerald-600 hover:bg-emerald-50"
                    >
                      Activer
                    </button>
                  )}
                  <button
                    onClick={() => openEdit(c)}
                    className="rounded-lg px-2.5 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-50"
                  >
                    Modifier
                  </button>
                  <button
                    onClick={() => { if (confirm('Supprimer ce modèle ?')) remove(c.id).catch(() => {}); }}
                    className="rounded-lg p-1.5 text-gray-400 hover:text-red-500"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
}
