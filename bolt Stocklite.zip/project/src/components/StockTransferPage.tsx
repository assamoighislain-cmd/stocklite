import { useState, useRef, useEffect, useMemo } from 'react';
import { ArrowRightLeft, Plus, MapPin, FileText, AlertTriangle, Search, Check, X, CheckCircle, Ban, Clock, Trash2, Printer } from 'lucide-react';
import type { Product, SalesLocation, StockTransfer } from '../types';
import type { CreateTransferInput, TransferItemInput } from '../hooks/useStockTransfers';
import { fmtQty } from '../lib/format';
import { translateError } from '../lib/translateError';
import { printDocument } from '../lib/printEngine';

interface Props {
  products: Product[];
  locations: SalesLocation[];
  transfers: StockTransfer[];
  loading: boolean;
  onCreate: (input: CreateTransferInput) => Promise<void>;
  onValidate: (transferId: string) => Promise<void>;
  onCancel: (transferId: string) => Promise<void>;
}

function fmt(n: number) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 4 }).format(n);
}

function fmtDate(d: string) {
  return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(d));
}

function SearchableProductSelect({ products, value, onChange }: {
  products: Product[];
  value: string;
  onChange: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = products.find(p => p.id === value);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products;
    return products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      (p.reference ?? '').toLowerCase().includes(q)
    );
  }, [products, query]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  useEffect(() => {
    if (open) { setQuery(''); setTimeout(() => inputRef.current?.focus(), 50); }
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="flex w-full items-center justify-between gap-2 rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
      >
        <span className={selected ? 'text-gray-800' : 'text-gray-400'}>
          {selected ? `${selected.name} (${selected.unit})` : 'Rechercher un article…'}
        </span>
        {selected ? (
          <span className="flex items-center gap-1 shrink-0">
            <Check className="h-3.5 w-3.5 text-blue-500" />
            <X
              className="h-3.5 w-3.5 text-gray-400 hover:text-red-500"
              onClick={(e) => { e.stopPropagation(); onChange(''); }}
            />
          </span>
        ) : (
          <Search className="h-3.5 w-3.5 text-gray-400 shrink-0" />
        )}
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-lg border border-gray-200 bg-white shadow-xl">
          <div className="flex items-center gap-2 border-b border-gray-100 px-3 py-2">
            <Search className="h-3.5 w-3.5 text-gray-400 shrink-0" />
            <input
              ref={inputRef}
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Tapez le nom de l'article…"
              className="flex-1 text-sm text-gray-800 outline-none placeholder:text-gray-400"
            />
            {query && (
              <button type="button" onClick={() => setQuery('')} className="text-gray-400 hover:text-gray-600">
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <div className="max-h-56 overflow-y-auto">
            {filtered.length === 0 ? (
              <p className="px-3 py-4 text-center text-xs text-gray-400">Aucun article trouvé</p>
            ) : (
              filtered.map(p => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => { onChange(p.id); setOpen(false); }}
                  className={`flex w-full items-center justify-between px-3 py-2 text-sm transition hover:bg-blue-50 ${
                    p.id === value ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                  }`}
                >
                  <span className="truncate">{p.name}</span>
                  <span className="flex items-center gap-2 shrink-0">
                    <span className="text-[11px] text-gray-400">{p.unit}</span>
                    {p.id === value && <Check className="h-3.5 w-3.5 text-blue-500" />}
                  </span>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

const STATUS_CONFIG: Record<string, { label: string; icon: typeof Clock; color: string }> = {
  en_attente: { label: 'En attente', icon: Clock, color: 'bg-amber-50 text-amber-700 border-amber-200' },
  valide: { label: 'Validé', icon: CheckCircle, color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  annule: { label: 'Annulé', icon: Ban, color: 'bg-red-50 text-red-700 border-red-200' },
};

export default function StockTransferPage({ products, locations, transfers, loading, onCreate, onValidate, onCancel }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [fromLocation, setFromLocation] = useState('');
  const [toLocation, setToLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [lineItems, setLineItems] = useState<TransferItemInput[]>([{ product_id: '', quantity: '' as unknown as number }]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [validatingId, setValidatingId] = useState<string | null>(null);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  const activeLocations = locations.filter(l => l.active);
  const trackedProducts = products.filter(p => p.active);

  function addLine() {
    setLineItems(prev => [...prev, { product_id: '', quantity: '' as unknown as number }]);
  }

  function removeLine(index: number) {
    setLineItems(prev => prev.length > 1 ? prev.filter((_, i) => i !== index) : prev);
  }

  function updateLine(index: number, field: 'product_id' | 'quantity', value: string) {
    setLineItems(prev => prev.map((item, i) => {
      if (i !== index) return item;
      if (field === 'quantity') return { ...item, quantity: parseFloat(value) || 0 };
      return { ...item, product_id: value };
    }));
  }

  function resetForm() {
    setFromLocation('');
    setToLocation('');
    setNotes('');
    setLineItems([{ product_id: '', quantity: '' as unknown as number }]);
    setError(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!fromLocation || !toLocation) {
      setError('Veuillez sélectionner les boutiques source et destination.');
      return;
    }
    if (fromLocation === toLocation) {
      setError('Les boutiques source et destination doivent être différentes.');
      return;
    }

    const validItems = lineItems.filter(item => item.product_id && Number(item.quantity) > 0);
    if (validItems.length === 0) {
      setError('Ajoutez au moins un article avec une quantité supérieure à 0.');
      return;
    }

    setSubmitting(true);
    try {
      await onCreate({
        items: validItems.map(it => ({ product_id: it.product_id, quantity: Number(it.quantity) })),
        from_location_id: fromLocation,
        to_location_id: toLocation,
        notes,
      });
      setShowForm(false);
      resetForm();
    } catch (err) {
      setError(err instanceof Error ? translateError(err.message) : 'Erreur lors du transfert');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleValidate(transferId: string) {
    setValidatingId(transferId);
    try {
      await onValidate(transferId);
    } catch (err) {
      setError(err instanceof Error ? translateError(err.message) : 'Erreur lors de la validation');
    } finally {
      setValidatingId(null);
    }
  }

  async function handleCancel(transferId: string) {
    setCancellingId(transferId);
    try {
      await onCancel(transferId);
    } catch (err) {
      setError(err instanceof Error ? translateError(err.message) : 'Erreur lors de l\'annulation');
    } finally {
      setCancellingId(null);
    }
  }

  const locName = (id: string) => locations.find(l => l.id === id)?.name ?? id;
  const [printing, setPrinting] = useState(false);

  const statusLabel = (s: string) => STATUS_CONFIG[s]?.label ?? s;
  const prodName = (id: string) => products.find(p => p.id === id)?.name ?? '—';
  const prodUnit = (id: string) => products.find(p => p.id === id)?.unit ?? '';

  function printTransfer(t: StockTransfer) {
    const allItems = t.items && t.items.length > 0
      ? t.items
      : t.product_id && t.quantity != null
        ? [{ id: 'legacy', transfer_id: t.id, product_id: t.product_id, product: t.product ?? undefined, quantity: t.quantity, created_at: t.created_at }]
        : [];
    const fromName = t.from_location?.name ?? locName(t.from_location_id);
    const toName = t.to_location?.name ?? locName(t.to_location_id);
    const itemRows = allItems.map((it, i) => `<tr>
      <td style="text-align:center">${i + 1}</td>
      <td>${it.product?.name ?? prodName(it.product_id)}</td>
      <td style="text-align:center">${it.product?.unit ?? prodUnit(it.product_id)}</td>
      <td style="text-align:right;font-weight:600">${fmtQty(it.quantity)}</td>
    </tr>`).join('');
    const html = `<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'Segoe UI',Arial,sans-serif;color:#1f2937;padding:24px;font-size:12px}
      h1{font-size:20px;margin-bottom:4px}
      h2{font-size:14px;margin-top:16px;margin-bottom:8px;color:#374151}
      .meta{color:#6b7280;font-size:11px;margin-bottom:16px}
      .route{display:flex;align-items:center;gap:12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:12px 16px;margin-bottom:16px}
      .route span{font-size:14px;font-weight:600;color:#1e40af}
      .badge{display:inline-block;padding:2px 10px;border-radius:12px;font-size:10px;font-weight:600}
      .badge.en_attente{background:#fffbeb;color:#92400e;border:1px solid #fde68a}
      .badge.valide{background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0}
      .badge.annule{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}
      table{width:100%;border-collapse:collapse}
      th{background:#f3f4f6;padding:8px 6px;font-size:10px;text-transform:uppercase;letter-spacing:.5px;color:#6b7280;border-bottom:2px solid #e5e7eb}
      td{padding:6px;border-bottom:1px solid #f3f4f6}
      tbody tr:nth-child(even){background:#fafafa}
      .notes{margin-top:12px;font-size:11px;color:#6b7280}
      .footer{margin-top:18px;padding-top:10px;border-top:1px solid #e5e7eb;font-size:10px;color:#9ca3af}
      .print-btn{position:fixed;top:16px;right:16px;padding:10px 20px;background:#1f2937;color:#fff;border:none;border-radius:8px;font-size:14px;cursor:pointer;font-weight:600}
      .print-btn:hover{background:#374151}
      @media print{body{padding:0}.print-btn{display:none}}
    </style></head><body>
      <button class="print-btn" onclick="window.print()">Imprimer / PDF</button>
      <h1>Bon de transfert</h1>
      <div class="meta">Édité le ${new Date().toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}</div>
      <div class="route">
        <span>${fromName}</span>
        <span style="color:#3b82f6">→</span>
        <span>${toName}</span>
        <span class="badge ${t.status}" style="margin-left:auto">${statusLabel(t.status)}</span>
      </div>
      <table>
        <thead><tr>
          <th style="text-align:center;width:40px">#</th>
          <th>Article</th>
          <th style="text-align:center;width:60px">Unité</th>
          <th style="text-align:right;width:100px">Quantité</th>
        </tr></thead>
        <tbody>${itemRows || '<tr><td colspan="4" style="text-align:center;padding:16px;color:#9ca3af">Aucun article</td></tr>'}</tbody>
      </table>
      ${t.notes ? `<p class="notes"><b>Notes :</b> ${t.notes}</p>` : ''}
      <div class="footer">Transfert du ${fmtDate(t.created_at)} · ${allItems.length} article(s) · ${statusLabel(t.status)}</div>
    </body></html>`;
    printDocument(html, { format: 'a4', title: 'Transfert de stock' });
  }

  function printSynthese() {
    const now = new Date().toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' });
    const rows = transfers.map((t, i) => {
      const allItems = t.items && t.items.length > 0
        ? t.items
        : t.product_id && t.quantity != null
          ? [{ id: 'legacy', transfer_id: t.id, product_id: t.product_id, product: t.product ?? undefined, quantity: t.quantity, created_at: t.created_at }]
          : [];
      const fromName = t.from_location?.name ?? locName(t.from_location_id);
      const toName = t.to_location?.name ?? locName(t.to_location_id);
      const itemSummary = allItems.map(it => `${it.product?.name ?? prodName(it.product_id)} (${fmtQty(it.quantity)} ${it.product?.unit ?? prodUnit(it.product_id)})`).join(', ');
      return `<tr>
        <td style="text-align:center">${i + 1}</td>
        <td style="font-weight:600">${fromName} → ${toName}</td>
        <td style="text-align:center">${allItems.length}</td>
        <td>${itemSummary}</td>
        <td style="text-align:center"><span class="badge ${t.status}">${statusLabel(t.status)}</span></td>
        <td style="text-align:center">${fmtDate(t.created_at)}</td>
      </tr>`;
    }).join('');
    const enAttente = transfers.filter(t => t.status === 'en_attente').length;
    const valide = transfers.filter(t => t.status === 'valide').length;
    const annule = transfers.filter(t => t.status === 'annule').length;
    const html = `<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'Segoe UI',Arial,sans-serif;color:#1f2937;padding:24px;font-size:12px}
      h1{font-size:20px;margin-bottom:4px}
      .meta{color:#6b7280;font-size:11px;margin-bottom:16px}
      .stats{display:flex;gap:16px;margin-bottom:16px}
      .stat{flex:1;text-align:center;background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:10px}
      .stat b{display:block;font-size:20px;color:#111827}
      .stat span{font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:.5px}
      table{width:100%;border-collapse:collapse}
      th{background:#f3f4f6;padding:8px 6px;font-size:10px;text-transform:uppercase;letter-spacing:.5px;color:#6b7280;border-bottom:2px solid #e5e7eb}
      td{padding:6px;border-bottom:1px solid #f3f4f6;vertical-align:top}
      tbody tr:nth-child(even){background:#fafafa}
      .badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:9px;font-weight:600}
      .badge.en_attente{background:#fffbeb;color:#92400e;border:1px solid #fde68a}
      .badge.valide{background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0}
      .badge.annule{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}
      .footer{margin-top:18px;padding-top:10px;border-top:1px solid #e5e7eb;font-size:10px;color:#9ca3af;display:flex;justify-content:space-between}
      .print-btn{position:fixed;top:16px;right:16px;padding:10px 20px;background:#1f2937;color:#fff;border:none;border-radius:8px;font-size:14px;cursor:pointer;font-weight:600}
      .print-btn:hover{background:#374151}
      @media print{body{padding:0}.print-btn{display:none}}
    </style></head><body>
      <button class="print-btn" onclick="window.print()">Imprimer / PDF</button>
      <h1>Synthèse des transferts de stock</h1>
      <div class="meta">Édité le ${now}</div>
      <div class="stats">
        <div class="stat"><b>${transfers.length}</b><span>Total transferts</span></div>
        <div class="stat"><b>${enAttente}</b><span>En attente</span></div>
        <div class="stat"><b>${valide}</b><span>Validés</span></div>
        <div class="stat"><b>${annule}</b><span>Annulés</span></div>
      </div>
      <table>
        <thead><tr>
          <th style="text-align:center;width:40px">#</th>
          <th>Trajet</th>
          <th style="text-align:center;width:50px">Art.</th>
          <th>Détail</th>
          <th style="text-align:center;width:80px">Statut</th>
          <th style="text-align:center;width:120px">Date</th>
        </tr></thead>
        <tbody>${rows || '<tr><td colspan="6" style="text-align:center;padding:20px;color:#9ca3af">Aucun transfert</td></tr>'}</tbody>
      </table>
      <div class="footer"><span>Synthèse au ${now}</span><span>${transfers.length} transfert(s)</span></div>
    </body></html>`;
    printDocument(html, { format: 'a4', title: 'Synthèse des transferts' });
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Transferts de stock</h1>
          <p className="text-sm text-gray-500 mt-0.5">{transfers.length} transfert{transfers.length !== 1 ? 's' : ''} enregistré{transfers.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={printSynthese}
            disabled={transfers.length === 0}
            className="flex items-center gap-1.5 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
          >
            <Printer className="h-4 w-4" />
            Imprimer synthèse
          </button>
          <button
            onClick={() => { setShowForm(true); setError(null); }}
            className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95"
          >
            <Plus className="h-4 w-4" />
            Nouveau transfert
          </button>
        </div>
      </div>

      {/* No locations warning */}
      {activeLocations.length < 2 && (
        <div className="flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
          <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
          <p className="text-xs text-amber-700">
            Il faut au moins 2 boutiques actives pour effectuer un transfert. Configurez vos boutiques dans les Paramètres.
          </p>
        </div>
      )}

      {/* Transfer history */}
      {loading ? (
        <div className="space-y-2">
          {[...Array(4)].map((_, i) => <div key={i} className="h-16 rounded-xl bg-gray-100 animate-pulse" />)}
        </div>
      ) : transfers.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-300 py-16 text-center">
          <ArrowRightLeft className="h-10 w-10 text-gray-300 mb-3" />
          <p className="text-sm font-medium text-gray-400">Aucun transfert</p>
          <p className="text-xs text-gray-400 mt-1">Les transferts inter-boutiques apparaîtront ici.</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white divide-y divide-gray-100">
          {transfers.map(t => {
            const statusCfg = STATUS_CONFIG[t.status] ?? STATUS_CONFIG.en_attente;
            const StatusIcon = statusCfg.icon;
            const allItems = t.items && t.items.length > 0
              ? t.items
              : t.product_id && t.quantity != null
                ? [{ id: 'legacy', transfer_id: t.id, product_id: t.product_id, product: t.product ?? undefined, quantity: t.quantity, created_at: t.created_at }]
                : [];
            return (
              <div key={t.id} className="px-5 py-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="h-9 w-9 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
                      <ArrowRightLeft className="h-4 w-4 text-blue-600" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold text-gray-900">
                          {allItems.length} article{allItems.length !== 1 ? 's' : ''}
                        </span>
                        <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold ${statusCfg.color}`}>
                          <StatusIcon className="h-2.5 w-2.5" />
                          {statusCfg.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-gray-500 mt-0.5 flex-wrap">
                        <MapPin className="h-3 w-3" />
                        <span>{t.from_location?.name ?? locName(t.from_location_id)}</span>
                        <ArrowRightLeft className="h-3 w-3 text-gray-400" />
                        <span>{t.to_location?.name ?? locName(t.to_location_id)}</span>
                      </div>
                      {allItems.length > 0 && (
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {allItems.map((it, i) => (
                            <span key={i} className="inline-flex items-center gap-1 rounded-md bg-gray-100 px-2 py-0.5 text-[11px] text-gray-700">
                              {it.product?.name ?? '—'}
                              <span className="font-medium text-gray-900">{fmtQty(it.quantity)}</span>
                              <span className="text-gray-400">{it.product?.unit}</span>
                            </span>
                          ))}
                        </div>
                      )}
                      {t.notes && <p className="text-xs text-gray-400 mt-1 flex items-center gap-1"><FileText className="h-3 w-3" />{t.notes}</p>}
                    </div>
                  </div>
                  <div className="shrink-0 flex flex-col items-end gap-2">
                    <p className="text-xs text-gray-400">{fmtDate(t.created_at)}</p>
                    {t.status === 'en_attente' && (
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => handleValidate(t.id)}
                          disabled={validatingId === t.id}
                          className="flex items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 transition disabled:opacity-50"
                        >
                          <CheckCircle className="h-3.5 w-3.5" />
                          {validatingId === t.id ? '…' : 'Valider'}
                        </button>
                        <button
                          onClick={() => handleCancel(t.id)}
                          disabled={cancellingId === t.id}
                          className="flex items-center gap-1 rounded-lg border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-100 transition disabled:opacity-50"
                        >
                          <Ban className="h-3.5 w-3.5" />
                          {cancellingId === t.id ? '…' : 'Annuler'}
                        </button>
                      </div>
                    )}
                    <button
                      onClick={() => printTransfer(t)}
                      className="flex items-center gap-1 rounded-lg border border-gray-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-gray-600 hover:bg-gray-50 transition"
                      title="Imprimer ce transfert"
                    >
                      <Printer className="h-3.5 w-3.5" />
                      Imprimer
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Transfer form modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="border-b border-gray-100 px-6 py-4 shrink-0">
              <div className="flex items-center gap-2">
                <ArrowRightLeft className="h-4 w-4 text-blue-600" />
                <h2 className="text-base font-semibold text-gray-900">Nouveau transfert de stock</h2>
              </div>
            </div>
            <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4 overflow-y-auto">
              {error && (
                <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3 py-2.5">
                  <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-red-700">{error}</p>
                </div>
              )}

              {/* From / To */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Boutique source *</label>
                  <select
                    value={fromLocation}
                    onChange={e => setFromLocation(e.target.value)}
                    required
                    className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
                  >
                    <option value="">Source…</option>
                    {activeLocations.filter(l => l.id !== toLocation).map(l => (
                      <option key={l.id} value={l.id}>{l.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Boutique destination *</label>
                  <select
                    value={toLocation}
                    onChange={e => setToLocation(e.target.value)}
                    required
                    className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
                  >
                    <option value="">Destination…</option>
                    {activeLocations.filter(l => l.id !== fromLocation).map(l => (
                      <option key={l.id} value={l.id}>{l.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Arrow visual */}
              {fromLocation && toLocation && (
                <div className="flex items-center justify-center gap-3 rounded-lg bg-gray-50 border border-gray-200 py-2.5 text-xs">
                  <span className="font-semibold text-gray-700">{locName(fromLocation)}</span>
                  <ArrowRightLeft className="h-4 w-4 text-blue-500" />
                  <span className="font-semibold text-gray-700">{locName(toLocation)}</span>
                </div>
              )}

              {/* Articles */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-medium text-gray-600">Articles à transférer *</label>
                  <button
                    type="button"
                    onClick={addLine}
                    className="flex items-center gap-1 rounded-lg bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-100 transition"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Ajouter
                  </button>
                </div>
                <div className="space-y-2">
                  {lineItems.map((item, index) => {
                    const selectedProduct = trackedProducts.find(p => p.id === item.product_id);
                    return (
                      <div key={index} className="flex gap-2 items-start">
                        <div className="flex-1">
                          <SearchableProductSelect
                            products={trackedProducts}
                            value={item.product_id}
                            onChange={id => updateLine(index, 'product_id', id)}
                          />
                        </div>
                        <div className="w-24">
                          <input
                            type="number"
                            min="0.01"
                            step="0.01"
                            value={item.quantity || ''}
                            onChange={e => updateLine(index, 'quantity', e.target.value)}
                            className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition tabular-nums"
                            placeholder="Qté"
                          />
                        </div>
                        {selectedProduct && (
                          <span className="text-xs text-gray-400 w-10 text-center pt-2.5">{selectedProduct.unit}</span>
                        )}
                        {lineItems.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeLine(index)}
                            className="rounded-lg p-2.5 text-gray-400 hover:bg-red-50 hover:text-red-500 transition shrink-0"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
                <input
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
                  placeholder="Raison du transfert…"
                />
              </div>

              <div className="flex gap-3 pt-2 shrink-0">
                <button
                  type="button"
                  onClick={() => { setShowForm(false); resetForm(); }}
                  className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={submitting || activeLocations.length < 2}
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50"
                >
                  <ArrowRightLeft className="h-4 w-4" />
                  {submitting ? 'Création…' : 'Créer le transfert'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
