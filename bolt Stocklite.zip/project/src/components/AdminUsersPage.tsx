import { useEffect, useState } from 'react';
import {
  Users, CheckCircle, XCircle, Ban, ChevronDown,
  MapPin, PlusCircle, Pencil, Trash2, Phone, Building2,
  ToggleLeft, ToggleRight,
} from 'lucide-react';
import { useAdminUsers } from '../hooks/useAdminUsers';
import { useSalesLocations } from '../hooks/useSalesLocations';
import { useCommerciaux } from '../hooks/useCommerciaux';
import type { UserProfile, UserRole, UserStatus, SalesLocation, Commercial } from '../types';
import { ROLE_LABELS, STATUS_USER_LABELS } from '../types';
import { Modal } from './Modal';
import { translateError } from '../lib/translateError';

const CREATABLE_ROLES: UserRole[] = ['admin', 'caissier', 'gerant', 'commercial', 'controleur'];

const STATUS_COLORS: Record<UserStatus, string> = {
  pending:   'bg-amber-500/10 text-amber-400 ring-1 ring-amber-500/30',
  active:    'bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/30',
  suspended: 'bg-red-500/10 text-red-400 ring-1 ring-red-500/30',
};

interface Props {
  currentUserId: string;
}

// ── Location Form ─────────────────────────────────────────────────
function LocationForm({ initial, onSubmit, onClose }: {
  initial?: SalesLocation;
  onSubmit: (d: Omit<SalesLocation, 'id' | 'created_at'>) => Promise<void>;
  onClose: () => void;
}) {
  const [form, setForm] = useState({
    name: initial?.name ?? '',
    address: initial?.address ?? '',
    city: initial?.city ?? '',
    phone: initial?.phone ?? '',
    active: initial?.active ?? true,
    sort_order: String(initial?.sort_order ?? 0),
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  function set(k: string, v: string | boolean) { setForm(f => ({ ...f, [k]: v })); }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setErr('Le nom est requis.'); return; }
    setSaving(true);
    try {
      await onSubmit({
        name: form.name.trim(),
        address: form.address.trim(),
        city: form.city.trim(),
        phone: form.phone.trim(),
        active: form.active,
        sort_order: parseInt(form.sort_order) || 0,
      });
      onClose();
    } catch (e) { setErr(e instanceof Error ? translateError(e.message) : 'Erreur'); setSaving(false); }
  }

  return (
    <form onSubmit={submit} className="space-y-4 p-5">
      <div>
        <label className="label">Nom du lieu *</label>
        <input className="input" value={form.name} onChange={e => set('name', e.target.value)} placeholder="ex. Boutique Centre-ville" />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">Adresse</label>
          <input className="input" value={form.address} onChange={e => set('address', e.target.value)} placeholder="Rue / Quartier" />
        </div>
        <div>
          <label className="label">Ville</label>
          <input className="input" value={form.city} onChange={e => set('city', e.target.value)} placeholder="Ville" />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">Téléphone</label>
          <input className="input" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+225 …" />
        </div>
        <div>
          <label className="label">Ordre d'affichage</label>
          <input type="number" min="0" className="input" value={form.sort_order} onChange={e => set('sort_order', e.target.value)} />
        </div>
      </div>
      <label className="flex cursor-pointer items-center gap-3">
        <span className="text-sm text-gray-500">Lieu actif</span>
        <button type="button" onClick={() => set('active', !form.active)}>
          {form.active ? <ToggleRight className="h-6 w-6 text-blue-400" /> : <ToggleLeft className="h-6 w-6 text-gray-400" />}
        </button>
      </label>
      {err && <p className="text-xs text-red-400">{err}</p>}
      <div className="flex gap-2 pt-1">
        <button type="button" onClick={onClose} className="flex-1 rounded-lg border border-gray-300 py-2.5 text-sm text-gray-500 hover:bg-gray-100">Annuler</button>
        <button type="submit" disabled={saving} className="flex-1 rounded-lg bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
          {saving ? 'Enregistrement…' : 'Enregistrer'}
        </button>
      </div>
    </form>
  );
}

// ── Main page ─────────────────────────────────────────────────────
export default function AdminUsersPage({ currentUserId }: Props) {
  const { users, loading, fetchUsers, updateStatus, updateRole, updateLocation, updateCommercial, removeUser, createUser } = useAdminUsers();
  const { locations, save: saveLocation, remove: removeLocation } = useSalesLocations();
  const { commerciaux } = useCommerciaux();

  const [tab, setTab] = useState<'users' | 'locations'>('users');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [locationModal, setLocationModal] = useState<SalesLocation | null | 'new'>(null);
  const [confirmLoc, setConfirmLoc] = useState<string | null>(null);
  const [confirmUser, setConfirmUser] = useState<UserProfile | null>(null);
  const [createModal, setCreateModal] = useState(false);

  async function handleDelete(u: UserProfile) {
    setBusy(u.id); setError('');
    try { await removeUser(u.id); setConfirmUser(null); }
    catch (e: unknown) { setError(e instanceof Error ? translateError(e.message) : 'Erreur'); }
    finally { setBusy(null); }
  }

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  async function handleStatus(u: UserProfile, status: UserStatus) {
    setBusy(u.id); setError('');
    try { await updateStatus(u.id, status); }
    catch (e: unknown) { setError(e instanceof Error ? translateError(e.message) : 'Erreur'); }
    finally { setBusy(null); }
  }

  async function handleRole(u: UserProfile, role: UserRole) {
    setBusy(u.id); setError('');
    try { await updateRole(u.id, role); setEditingId(null); }
    catch (e: unknown) { setError(e instanceof Error ? translateError(e.message) : 'Erreur'); }
    finally { setBusy(null); }
  }

  async function handleLocation(userId: string, locationId: string | null) {
    setBusy(userId); setError('');
    try { await updateLocation(userId, locationId); }
    catch (e: unknown) { setError(e instanceof Error ? translateError(e.message) : 'Erreur'); }
    finally { setBusy(null); }
  }

  async function handleCommercial(userId: string, commercialId: string | null) {
    setBusy(userId); setError('');
    try { await updateCommercial(userId, commercialId); }
    catch (e: unknown) { setError(e instanceof Error ? translateError(e.message) : 'Erreur'); }
    finally { setBusy(null); }
  }

  const pending = users.filter(u => u.status === 'pending');
  const rest    = users.filter(u => u.status !== 'pending');

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/10 flex items-center justify-center">
            <Users className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">Gestion des utilisateurs</h1>
            <p className="text-sm text-gray-500">{users.length} compte{users.length > 1 ? 's' : ''} · {locations.length} lieu{locations.length > 1 ? 'x' : ''} de vente</p>
          </div>
        </div>
        {tab === 'users' && (
          <button onClick={() => setCreateModal(true)}
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition active:scale-95">
            <PlusCircle className="h-4 w-4" /> Nouvel utilisateur
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 rounded-xl bg-gray-100 p-1 w-fit">
        <button onClick={() => setTab('users')}
          className={`flex items-center gap-1.5 rounded-lg px-4 py-1.5 text-sm font-medium transition ${tab === 'users' ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>
          <Users className="h-4 w-4" /> Utilisateurs
        </button>
        <button onClick={() => setTab('locations')}
          className={`flex items-center gap-1.5 rounded-lg px-4 py-1.5 text-sm font-medium transition ${tab === 'locations' ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>
          <MapPin className="h-4 w-4" /> Lieux de vente
        </button>
      </div>

      {error && (
        <div className="px-4 py-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">{error}</div>
      )}

      {/* ── Users tab ── */}
      {tab === 'users' && (
        <div className="space-y-6">
          {pending.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-amber-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                En attente d'approbation ({pending.length})
              </h2>
              <div className="space-y-2">
                {pending.map(u => (
                  <UserRow key={u.id} user={u} isSelf={u.id === currentUserId} busy={busy === u.id}
                    editing={editingId === u.id} locations={locations} commerciaux={commerciaux}
                    onToggleEdit={() => setEditingId(id => id === u.id ? null : u.id)}
                    onStatus={handleStatus} onRole={handleRole} onLocation={handleLocation} onCommercial={handleCommercial}
                    onDelete={() => setConfirmUser(u)} />
                ))}
              </div>
            </div>
          )}
          {rest.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
                Utilisateurs ({rest.length})
              </h2>
              <div className="space-y-2">
                {rest.map(u => (
                  <UserRow key={u.id} user={u} isSelf={u.id === currentUserId} busy={busy === u.id}
                    editing={editingId === u.id} locations={locations} commerciaux={commerciaux}
                    onToggleEdit={() => setEditingId(id => id === u.id ? null : u.id)}
                    onStatus={handleStatus} onRole={handleRole} onLocation={handleLocation} onCommercial={handleCommercial}
                    onDelete={() => setConfirmUser(u)} />
                ))}
              </div>
            </div>
          )}
          {loading && <div className="text-gray-400 text-sm text-center py-8">Chargement…</div>}
          {!loading && users.length === 0 && <div className="text-gray-400 text-sm text-center py-8">Aucun utilisateur</div>}
        </div>
      )}

      {/* ── Locations tab ── */}
      {tab === 'locations' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button onClick={() => setLocationModal('new')}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition active:scale-95">
              <PlusCircle className="h-4 w-4" /> Nouveau lieu
            </button>
          </div>

          {locations.length === 0 ? (
            <div className="rounded-xl border border-dashed border-gray-300 py-14 text-center text-sm text-gray-400">
              Aucun lieu de vente. Créez-en un pour commencer.
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {locations.map(loc => {
                const assignedCount = users.filter(u => u.location_id === loc.id).length;
                return (
                  <div key={loc.id} className="group bg-white rounded-xl border border-gray-200 p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${loc.active ? 'bg-blue-50' : 'bg-gray-100'}`}>
                          <Building2 className={`h-5 w-5 ${loc.active ? 'text-blue-600' : 'text-gray-400'}`} />
                        </div>
                        <div>
                          <p className="font-semibold text-gray-800">{loc.name}</p>
                          <span className={`text-xs font-medium ${loc.active ? 'text-emerald-500' : 'text-gray-400'}`}>
                            {loc.active ? 'Actif' : 'Inactif'}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                        <button onClick={() => setLocationModal(loc)} className="rounded p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-700">
                          <Pencil className="h-4 w-4" />
                        </button>
                        {confirmLoc === loc.id ? (
                          <div className="flex items-center gap-1">
                            <button onClick={() => removeLocation(loc.id).then(() => setConfirmLoc(null))} className="rounded px-2 py-1 text-xs text-red-400 ring-1 ring-red-800 hover:bg-red-50">Suppr.</button>
                            <button onClick={() => setConfirmLoc(null)} className="text-xs text-gray-400 px-1">×</button>
                          </div>
                        ) : (
                          <button onClick={() => setConfirmLoc(loc.id)} className="rounded p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-400">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Details */}
                    <div className="space-y-1 text-xs text-gray-500">
                      {(loc.address || loc.city) && (
                        <div className="flex items-center gap-1.5">
                          <MapPin className="h-3.5 w-3.5 text-gray-300 shrink-0" />
                          {[loc.address, loc.city].filter(Boolean).join(', ')}
                        </div>
                      )}
                      {loc.phone && (
                        <div className="flex items-center gap-1.5">
                          <Phone className="h-3.5 w-3.5 text-gray-300 shrink-0" />
                          {loc.phone}
                        </div>
                      )}
                    </div>

                    {/* Assigned users */}
                    <div className="border-t border-gray-100 pt-2">
                      <p className="text-xs text-gray-400 mb-1.5">
                        {assignedCount} utilisateur{assignedCount > 1 ? 's' : ''} affecté{assignedCount > 1 ? 's' : ''}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {users.filter(u => u.location_id === loc.id).map(u => (
                          <span key={u.id} className="flex items-center gap-1 rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-600">
                            <span className="w-4 h-4 rounded-full bg-blue-200 flex items-center justify-center text-[9px] font-bold text-blue-800">
                              {(u.full_name || u.email).slice(0, 1).toUpperCase()}
                            </span>
                            {u.full_name || u.email.split('@')[0]}
                          </span>
                        ))}
                        {assignedCount === 0 && <span className="text-xs text-gray-300 italic">Aucun</span>}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Delete user confirmation */}
      {confirmUser && (
        <Modal title="Supprimer l'utilisateur" onClose={() => setConfirmUser(null)}>
          <div className="p-5 space-y-4">
            <p className="text-sm text-gray-600">
              Voulez-vous vraiment supprimer le compte de{' '}
              <span className="font-semibold text-gray-900">{confirmUser.full_name || confirmUser.email}</span> ?
              Cette action est irréversible et supprimera son profil ainsi que son accès.
            </p>
            {error && <p className="text-xs text-red-400">{error}</p>}
            <div className="flex gap-2 pt-1">
              <button type="button" onClick={() => setConfirmUser(null)} className="flex-1 rounded-lg border border-gray-300 py-2.5 text-sm text-gray-500 hover:bg-gray-100">Annuler</button>
              <button type="button" onClick={() => handleDelete(confirmUser)} disabled={busy === confirmUser.id}
                className="flex-1 rounded-lg bg-red-600 py-2.5 text-sm font-semibold text-white hover:bg-red-500 disabled:opacity-50">
                {busy === confirmUser.id ? 'Suppression…' : 'Supprimer définitivement'}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Location modal */}
      {locationModal !== null && (
        <Modal title={locationModal === 'new' ? 'Nouveau lieu de vente' : 'Modifier le lieu'} onClose={() => setLocationModal(null)}>
          <LocationForm
            initial={locationModal === 'new' ? undefined : locationModal}
            onSubmit={d => saveLocation(d, locationModal === 'new' ? undefined : (locationModal as SalesLocation).id)}
            onClose={() => setLocationModal(null)}
          />
        </Modal>
      )}

      {/* Create user modal */}
      {createModal && (
        <Modal title="Nouvel utilisateur" onClose={() => setCreateModal(false)}>
          <CreateUserForm
            onSubmit={async input => { await createUser(input); setCreateModal(false); }}
            onClose={() => setCreateModal(false)}
          />
        </Modal>
      )}
    </div>
  );
}

// ── User Row ──────────────────────────────────────────────────────
interface RowProps {
  user: UserProfile;
  isSelf: boolean;
  busy: boolean;
  editing: boolean;
  locations: SalesLocation[];
  commerciaux: Commercial[];
  onToggleEdit: () => void;
  onStatus: (u: UserProfile, s: UserStatus) => void;
  onRole: (u: UserProfile, r: UserRole) => void;
  onLocation: (userId: string, locationId: string | null) => void;
  onCommercial: (userId: string, commercialId: string | null) => void;
  onDelete: () => void;
}

function UserRow({ user, isSelf, busy, editing, locations, commerciaux, onToggleEdit, onStatus, onRole, onLocation, onCommercial, onDelete }: RowProps) {
  const initials = user.full_name
    ? user.full_name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()
    : user.email.slice(0, 2).toUpperCase();

  const loc = user.location;

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4">
      <div className="flex items-center gap-3 flex-wrap sm:flex-nowrap">
        {/* Avatar */}
        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-sm font-bold text-blue-700 shrink-0">
          {initials}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-sm font-semibold text-gray-800 truncate">{user.full_name || user.email}</p>
            {isSelf && <span className="text-xs bg-blue-500/10 text-blue-400 ring-1 ring-blue-500/30 px-2 py-0.5 rounded-full">Vous</span>}
          </div>
          <p className="text-xs text-gray-400 truncate">{user.email}</p>
          {loc && (
            <div className="flex items-center gap-1 mt-0.5">
              <MapPin className="h-3 w-3 text-gray-300 shrink-0" />
              <span className="text-xs text-gray-400">{loc.name}{loc.city ? ` · ${loc.city}` : ''}</span>
            </div>
          )}
        </div>

        {/* Location selector */}
        <select
          value={user.location_id ?? ''}
          disabled={isSelf || busy}
          onChange={e => onLocation(user.id, e.target.value || null)}
          className="rounded-lg border border-gray-200 bg-gray-50 px-2 py-1.5 text-xs text-gray-700 outline-none focus:border-blue-500 disabled:opacity-50 disabled:cursor-default max-w-[140px]"
        >
          <option value="">— Aucun lieu —</option>
          {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
        </select>

        {/* Commercial selector (only for commercial role) */}
        {user.role === 'commercial' && (
          <select
            value={user.commercial_id ?? ''}
            disabled={isSelf || busy}
            onChange={e => onCommercial(user.id, e.target.value || null)}
            className="rounded-lg border border-gray-200 bg-gray-50 px-2 py-1.5 text-xs text-gray-700 outline-none focus:border-blue-500 disabled:opacity-50 disabled:cursor-default max-w-[160px]"
          >
            <option value="">— Aucun commercial —</option>
            {commerciaux.filter(c => c.active).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}

        {/* Role selector */}
        <div className="relative shrink-0">
          <button onClick={onToggleEdit} disabled={isSelf || busy}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gray-100 border border-gray-200 text-xs text-gray-700 hover:border-gray-400 disabled:opacity-50 disabled:cursor-default transition-colors">
            {ROLE_LABELS[user.role]}
            {!isSelf && <ChevronDown className="w-3 h-3 text-gray-400" />}
          </button>
          {editing && (
            <div className="absolute right-0 top-full mt-1 z-10 bg-white border border-gray-200 rounded-xl shadow-xl py-1 min-w-[170px]">
              {(['admin', 'caissier', 'gerant', 'commercial', 'controleur'] as UserRole[]).map(r => (
                <button key={r} onClick={() => onRole(user, r)}
                  className={`w-full text-left px-3 py-2 text-xs hover:bg-gray-50 transition-colors ${user.role === r ? 'text-blue-600 font-semibold' : 'text-gray-700'}`}>
                  {ROLE_LABELS[r]}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Status badge */}
        <span className={`shrink-0 text-xs font-medium px-2.5 py-1 rounded-full ${STATUS_COLORS[user.status]}`}>
          {STATUS_USER_LABELS[user.status]}
        </span>

        {/* Actions */}
        {!isSelf && (
          <div className="flex items-center gap-1.5 shrink-0">
            {user.status !== 'active' && (
              <button onClick={() => onStatus(user, 'active')} disabled={busy} title="Approuver"
                className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 flex items-center justify-center disabled:opacity-50 transition-colors">
                <CheckCircle className="w-4 h-4" />
              </button>
            )}
            {user.status === 'active' && (
              <button onClick={() => onStatus(user, 'suspended')} disabled={busy} title="Suspendre"
                className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 flex items-center justify-center disabled:opacity-50 transition-colors">
                <Ban className="w-4 h-4" />
              </button>
            )}
            {user.status === 'suspended' && (
              <button onClick={() => onStatus(user, 'pending')} disabled={busy} title="Remettre en attente"
                className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 flex items-center justify-center disabled:opacity-50 transition-colors">
                <XCircle className="w-4 h-4" />
              </button>
            )}
            <button onClick={onDelete} disabled={busy} title="Supprimer l'utilisateur"
              className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 flex items-center justify-center disabled:opacity-50 transition-colors">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Create User Form ─────────────────────────────────────────────
function CreateUserForm({ onSubmit, onClose }: {
  onSubmit: (d: { email: string; password: string; full_name: string; role: UserRole }) => Promise<void>;
  onClose: () => void;
}) {
  const [form, setForm] = useState({
    email: '',
    password: '',
    full_name: '',
    role: 'caissier' as UserRole,
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  function set(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.email.trim()) { setErr('L\'email est requis.'); return; }
    if (form.password.length < 6) { setErr('Le mot de passe doit contenir au moins 6 caractères.'); return; }
    if (!form.full_name.trim()) { setErr('Le nom complet est requis.'); return; }
    setSaving(true);
    try {
      await onSubmit({
        email: form.email.trim(),
        password: form.password,
        full_name: form.full_name.trim(),
        role: form.role,
      });
    } catch (e) {
      setErr(e instanceof Error ? translateError(e.message) : 'Erreur');
      setSaving(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 p-5">
      <div>
        <label className="label">Nom complet *</label>
        <input className="input" value={form.full_name} onChange={e => set('full_name', e.target.value)} placeholder="ex. Jean Kouassi" />
      </div>
      <div>
        <label className="label">Email *</label>
        <input type="email" className="input" value={form.email} onChange={e => set('email', e.target.value)} placeholder="utilisateur@exemple.com" />
      </div>
      <div>
        <label className="label">Mot de passe *</label>
        <input type="password" className="input" value={form.password} onChange={e => set('password', e.target.value)} placeholder="Minimum 6 caractères" />
      </div>
      <div>
        <label className="label">Rôle</label>
        <select className="input" value={form.role} onChange={e => set('role', e.target.value)}>
          {CREATABLE_ROLES.map(r => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
        </select>
      </div>
      {err && <p className="text-xs text-red-400">{err}</p>}
      <div className="flex gap-2 pt-1">
        <button type="button" onClick={onClose} className="flex-1 rounded-lg border border-gray-300 py-2.5 text-sm text-gray-500 hover:bg-gray-100">Annuler</button>
        <button type="submit" disabled={saving} className="flex-1 rounded-lg bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
          {saving ? 'Création…' : 'Créer l\'utilisateur'}
        </button>
      </div>
    </form>
  );
}
