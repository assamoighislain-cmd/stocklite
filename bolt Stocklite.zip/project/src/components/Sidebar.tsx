import { useEffect, useState } from 'react';
import {
  LayoutDashboard, FileText, Users, Package, Settings,
  PlusCircle, ChevronRight, X, ShoppingCart, Archive, AlertTriangle,
  UserCog, LogOut, Store, ClipboardList, BookOpen, MapPin, UserCheck, Wallet,
  ArrowRightLeft, Tag,
  Gift, Truck, ClipboardCheck, Receipt, Building2, Presentation, Bell, PackageOpen,
  CloudOff, Download, BarChart3,
} from 'lucide-react';
import type { Route } from '../App';
import type { UserProfile, SalesLocation } from '../types';
import { ROLE_LABELS } from '../types';
import { supabase } from '../lib/supabase';

interface SidebarProps {
  route: Route;
  onNavigate: (r: Route) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  lowStockCount: number;
  profile: UserProfile;
  onSignOut: () => void;
  locations?: SalesLocation[];
  activeLocationId?: string | null;
  onLocationChange?: (id: string | null) => void;
  tenantName?: string | null;
  pendingCount?: number;
}

function isActive(current: Route, target: Route) {
  return current.page === target.page;
}

function SidebarContent({ route, onNavigate, onClose, lowStockCount, profile, onSignOut, locations, activeLocationId, onLocationChange, tenantName, pendingCount }: {
  route: Route;
  onNavigate: (r: Route) => void;
  onClose?: () => void;
  lowStockCount: number;
  profile: UserProfile;
  onSignOut: () => void;
  locations?: SalesLocation[];
  activeLocationId?: string | null;
  onLocationChange?: (id: string | null) => void;
  tenantName?: string | null;
  pendingCount?: number;
}) {
  function go(r: Route) { onNavigate(r); onClose?.(); }

  const isAdmin    = profile.role === 'admin' || profile.role === 'super_admin';
  const isCaissier = profile.role === 'caissier';
  const isGerant   = profile.role === 'gerant';
  const isCommercial = profile.role === 'commercial';
  const isControleur = profile.role === 'controleur';
  const isSuperAdmin = profile.role === 'super_admin';
  const canViewNotifications = isSuperAdmin || profile.role === 'admin';

  const initials = profile.full_name
    ? profile.full_name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()
    : profile.email.slice(0, 2).toUpperCase();
  const [notifications, setNotifications] = useState<Array<{ id: string; title: string; body: string | null; read: boolean; created_at: string }>>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [installing, setInstalling] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [showInstallHint, setShowInstallHint] = useState(false);

  useEffect(() => {
    const checkStandalone = () =>
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as Navigator & { standalone?: boolean }).standalone === true;
    setIsStandalone(checkStandalone());
  }, []);

  const isIOS = /iphone|ipad|ipod/i.test(window.navigator.userAgent) && !(window.navigator as Navigator & { standalone?: boolean }).standalone;

  useEffect(() => {
    if (isStandalone) return;
    function onBeforeInstallPrompt(e: Event) {
      e.preventDefault();
      setInstallEvent(e as BeforeInstallPromptEvent);
    }
    window.addEventListener('beforeinstallprompt', onBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', onBeforeInstallPrompt);
  }, [isStandalone]);

  async function handleInstall() {
    if (installEvent) {
      setInstalling(true);
      try {
        await installEvent.prompt();
        await installEvent.userChoice;
      } finally {
        setInstallEvent(null);
        setInstalling(false);
      }
    } else {
      setShowInstallHint(true);
    }
  }
  useEffect(() => {
    if (isIOS && !isStandalone) {
      const dismissed = localStorage.getItem('pwa-ios-hint-dismissed');
      if (!dismissed) setShowInstallHint(true);
    }
  }, [isIOS, isStandalone]);

  useEffect(() => {
    if (!canViewNotifications) return;
    const loadNotifications = async () => {
      const { data } = await supabase
        .from('admin_notifications')
        .select('id, title, body, read, created_at')
        .order('created_at', { ascending: false })
        .limit(8);
      setNotifications(data ?? []);
    };
    loadNotifications();
    const channel = supabase
      .channel('admin-notifications')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'admin_notifications' }, loadNotifications)
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [canViewNotifications]);

  const unreadCount = notifications.filter(notification => !notification.read).length;

  async function markNotificationsRead() {
    const unreadIds = notifications.filter(notification => !notification.read).map(notification => notification.id);
    if (unreadIds.length > 0) {
      await supabase.from('admin_notifications').update({ read: true }).in('id', unreadIds);
      setNotifications(current => current.map(notification => ({ ...notification, read: true })));
    }
  }

  return (
    <div className="flex h-full flex-col bg-slate-900">
      {/* Brand + location for non-admin */}
      <div className="flex items-center justify-between border-b border-slate-700/50 px-5 h-auto py-3.5">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg shadow-blue-900/50">
              <Store className="h-4.5 w-4.5 text-white" strokeWidth={2.5} />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-extrabold tracking-tight text-white lg:text-base">
                Stock<span className="text-blue-400">lite</span>
              </span>
              {tenantName && (
                <span className="text-[11px] font-semibold text-slate-400 truncate max-w-[140px]">
                  {tenantName}
                </span>
              )}
            </div>
          </div>
          {!isAdmin && (
            <div className={`flex items-center gap-1.5 pl-10 ${profile.location ? '' : 'opacity-50'}`}>
              <MapPin className="h-3 w-3 text-blue-400 shrink-0 lg:h-3.5 lg:w-3.5" />
              <span className="text-[11px] font-semibold text-blue-300 truncate lg:text-xs">
                {profile.location ? profile.location.name : 'Aucune boutique assignée'}
              </span>
            </div>
          )}
        </div>
        {onClose && (
          <button onClick={onClose} className="text-slate-400 hover:text-white lg:hidden">
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      {/* New invoice shortcut (admin + caissier + gerant + controleur) */}
      {!isCommercial && (
        <div className="p-3">
          <button
            onClick={() => go({ page: 'invoice-form' })}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 py-2.5 text-xs font-bold text-white shadow-lg shadow-blue-900/40 transition hover:from-blue-500 hover:to-blue-400 active:scale-95 lg:py-3 lg:text-sm"
          >
            <PlusCircle className="h-4 w-4 lg:h-4.5 lg:w-4.5" />
            Nouvelle facture
          </button>
        </div>
      )}
      {isCommercial && (
        <div className="p-3">
          <button
            onClick={() => go({ page: 'order-form' })}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 py-2.5 text-xs font-bold text-white shadow-lg shadow-blue-900/40 transition hover:from-blue-500 hover:to-blue-400 active:scale-95 lg:py-3 lg:text-sm"
          >
            <PlusCircle className="h-4 w-4 lg:h-4.5 lg:w-4.5" />
            Nouvelle commande
          </button>
        </div>
      )}

      {/* Location picker for admin */}
      {isAdmin && locations && locations.length > 0 && onLocationChange ? (
        <div className="px-3 pb-2">
          <div className="flex items-center gap-1.5 mb-1">
            <MapPin className="h-3 w-3 text-slate-400 lg:h-3.5 lg:w-3.5" />
            <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 lg:text-[10px]">Boutique</span>
          </div>
          <select
            value={activeLocationId ?? ''}
            onChange={e => onLocationChange(e.target.value || null)}
            className="w-full rounded-lg border border-slate-600 bg-slate-800 px-2.5 py-1.5 text-[11px] font-semibold text-slate-200 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400 lg:py-2 lg:text-xs"
          >
            <option value="">Toutes les boutiques</option>
            {locations.map(loc => (
              <option key={loc.id} value={loc.id}>{loc.name}</option>
            ))}
          </select>
          {activeLocationId && (
            <p className="mt-1 flex items-center gap-1 text-[10px] font-semibold text-blue-400 lg:mt-1.5 lg:text-[11px]">
              <MapPin className="h-2.5 w-2.5 lg:h-3 lg:w-3" />
              {locations.find(l => l.id === activeLocationId)?.name ?? 'Boutique sélectionnée'}
            </p>
          )}
        </div>
      ) : null}

      <nav className="flex-1 overflow-y-auto space-y-1 px-3 pb-3">
        {(isAdmin || isGerant || isControleur) && (
          <NavBtn route={route} target={{ page: 'dashboard' }} icon={LayoutDashboard} label="Tableau de bord" go={go} />
        )}
        {(isAdmin || isCaissier || isGerant || isControleur) && (
          <NavBtn route={route} target={{ page: 'pos' }} icon={ShoppingCart} label="Caisse" go={go} accent />
        )}
        {(isAdmin || isCaissier || isGerant || isControleur) && (
          <NavBtn route={route} target={{ page: 'caisse-closing' }} icon={ClipboardList} label="Point de caisse" go={go} />
        )}
        {(isAdmin || isCaissier || isGerant || isControleur) && (
          <NavBtn route={route} target={{ page: 'cash-ops' }} icon={Wallet} label="Opérations caisse" go={go} />
        )}
        {(isAdmin || isCaissier || isGerant || isCommercial || isControleur) && (
          <NavBtn route={route} target={{ page: 'invoices' }} icon={FileText} label="Factures" go={go} />
        )}
        {(isAdmin || isGerant || isControleur) && (
          <NavBtn route={route} target={{ page: 'invoice-report' }} icon={ClipboardList} label="Détail facturations" go={go} />
        )}
        {(isAdmin || isGerant || isControleur) && (
          <NavBtn route={route} target={{ page: 'sales-summary' }} icon={BarChart3} label="Synthèse des ventes" go={go} />
        )}
        {(isAdmin || isCaissier || isGerant || isCommercial) && (
          <NavBtn route={route} target={{ page: 'orders' }} icon={ClipboardCheck} label="Commandes" go={go} />
        )}
        {(isAdmin || isGerant || isCommercial || isCaissier) && (
          <NavBtn route={route} target={{ page: 'stock' }} icon={Archive} label="Stock" go={go} badge={lowStockCount} />
        )}
        {(isAdmin || isGerant) && (
          <NavBtn route={route} target={{ page: 'inventory' }} icon={ClipboardList} label="Inventaire" go={go} />
        )}
        {(isAdmin || isGerant) && (
          <NavBtn route={route} target={{ page: 'stock-transfers' }} icon={ArrowRightLeft} label="Transferts" go={go} />
        )}
        {(isAdmin || isGerant || isCommercial) && (
          <NavBtn route={route} target={{ page: 'approvisionnement' }} icon={Truck} label="Approvisionnement" go={go} />
        )}
        {(isAdmin || isGerant) && (
          <NavBtn route={route} target={{ page: 'deconditionnement' }} icon={PackageOpen} label="Déconditionnement" go={go} />
        )}
        {(isAdmin || isGerant) && (
          <NavBtn route={route} target={{ page: 'statement-supplier' }} icon={Receipt} label="Relevé fournisseur" go={go} />
        )}
        {(isAdmin || isGerant) && (
          <NavBtn route={route} target={{ page: 'dotations' }} icon={Gift} label="Dotations" go={go} />
        )}
        {(isAdmin || isCaissier || isGerant || isCommercial || isControleur) && (
          <NavBtn route={route} target={{ page: 'customers' }} icon={Users} label="Clients" go={go} />
        )}
        {(isAdmin || isCaissier || isGerant || isCommercial || isControleur) && (
          <NavBtn route={route} target={{ page: 'statement-client' }} icon={Receipt} label="Relevé client" go={go} />
        )}
        {(isAdmin || isGerant || isCommercial) && (
          <NavBtn route={route} target={{ page: 'products' }} icon={Package} label="Articles" go={go} />
        )}
        {(isAdmin || isGerant) && (
          <NavBtn route={route} target={{ page: 'accounting' }} icon={BookOpen} label="Comptabilité" go={go} />
        )}
        {(isAdmin || isGerant) && (
          <NavBtn route={route} target={{ page: 'commerciaux' }} icon={UserCheck} label="Commerciaux" go={go} />
        )}
        {(isAdmin || isGerant) && (
          <NavBtn route={route} target={{ page: 'price-types' }} icon={Tag} label="Types de prix" go={go} />
        )}
        {isAdmin && (
          <NavBtn route={route} target={{ page: 'admin-users' }} icon={UserCog} label="Utilisateurs" go={go} />
        )}
        {isSuperAdmin && (
          <NavBtn route={route} target={{ page: 'tenants' }} icon={Building2} label="Entreprises" go={go} />
        )}
        {(isAdmin || isCaissier || isGerant || isControleur) && (
          <NavBtn route={route} target={{ page: 'pending-sales' }} icon={CloudOff} label="Ventes en attente" go={go} badge={pendingCount} />
        )}
      </nav>

      {canViewNotifications && (
        <div className="relative px-3 pb-2">
          <button
            onClick={() => { setShowNotifications(open => !open); void markNotificationsRead(); }}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition lg:gap-3 lg:py-2.5 lg:text-sm"
          >
            <span className="relative">
              <Bell className="h-4 w-4 lg:h-4.5 lg:w-4.5" />
              {unreadCount > 0 && <span className="absolute -right-2 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">{unreadCount > 9 ? '9+' : unreadCount}</span>}
            </span>
            <span className="flex-1 text-left">Notifications</span>
            {unreadCount > 0 && <span className="text-[10px] font-bold text-red-400">Nouveau</span>}
          </button>
          {showNotifications && (
            <div className="absolute bottom-12 left-3 right-3 z-50 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-100 px-3 py-2.5">
                <span className="text-xs font-bold text-slate-800">Notifications</span>
                <button onClick={() => setShowNotifications(false)} className="text-slate-400 hover:text-slate-700"><X className="h-3.5 w-3.5" /></button>
              </div>
              {notifications.length === 0 ? (
                <p className="px-3 py-5 text-center text-xs text-slate-400">Aucune notification</p>
              ) : (
                <div className="max-h-64 overflow-y-auto divide-y divide-slate-50">
                  {notifications.map(notification => (
                    <div key={notification.id} className="px-3 py-2.5">
                      <p className="text-[11px] font-semibold text-slate-800">{notification.title}</p>
                      {notification.body && <p className="mt-0.5 text-[10px] leading-relaxed text-slate-500">{notification.body}</p>}
                      <p className="mt-1 text-[9px] text-slate-400">{new Date(notification.created_at).toLocaleString('fr-FR')}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Settings + user footer */}
      <div className="border-t border-slate-700/50 p-3 space-y-1">
        {!isStandalone && (
          <div className="relative">
            <button
              onClick={handleInstall}
              disabled={installing}
              className="flex w-full items-center gap-2.5 rounded-lg bg-blue-600/20 px-3 py-2 text-xs font-semibold text-blue-300 ring-1 ring-blue-500/30 transition hover:bg-blue-600/30 hover:text-blue-200 disabled:opacity-50 lg:gap-3 lg:py-2.5 lg:text-sm"
            >
              <Download className="h-4 w-4 lg:h-4.5 lg:w-4.5" />
              {installing ? 'Installation…' : 'Installer l\'application'}
            </button>
            {showInstallHint && (!installEvent || isIOS) && (
              <div className="absolute bottom-full left-0 right-0 mb-2 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-2xl">
                <div className="flex items-center justify-between border-b border-slate-100 px-3 py-2">
                  <span className="text-xs font-bold text-slate-800">Installer l'application</span>
                  <button onClick={() => setShowInstallHint(false)} className="text-slate-400 hover:text-slate-700"><X className="h-3.5 w-3.5" /></button>
                </div>
                <div className="px-3 py-2.5 space-y-1.5 text-[11px] leading-relaxed text-slate-600">
                  {isIOS ? (
                    <>
                      <p className="font-semibold text-slate-700">Sur iPhone / iPad (Safari) :</p>
                      <p>1. Appuyez sur le bouton Partager <span className="font-semibold">⎋</span> en bas de l'écran.</p>
                      <p>2. Faites défiler et choisissez <span className="font-semibold">« Sur l'écran d'accueil »</span>.</p>
                      <p>3. Appuyez sur <span className="font-semibold">« Ajouter »</span>.</p>
                    </>
                  ) : (
                    <>
                      <p className="font-semibold text-slate-700">Sur Chrome / Edge (ordinateur) :</p>
                      <p>Cliquez sur l'icône d'installation <span className="font-semibold">⊕</span> dans la barre d'adresse, ou menu <span className="font-semibold">⋮</span> → « Installer l'application ».</p>
                      <p className="font-semibold text-slate-700 pt-1">Sur mobile (Chrome / Safari) :</p>
                      <p>Menu <span className="font-semibold">⋮</span> → « Ajouter à l'écran d'accueil », ou sur Safari : bouton Partager <span className="font-semibold">⎋</span> → « Sur l'écran d'accueil ».</p>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
        <a
          href="/presentation.html"
          target="_blank"
          rel="noopener noreferrer"
          className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition lg:gap-3 lg:py-2.5 lg:text-sm"
        >
          <Presentation className="h-4 w-4 lg:h-4.5 lg:w-4.5" />
          Présentation
        </a>
        {isAdmin && (
          <button
            onClick={() => go({ page: 'settings' })}
            className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-semibold transition lg:gap-3 lg:py-2.5 lg:text-sm ${
              route.page === 'settings'
                ? 'bg-slate-800 text-white'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Settings className="h-4 w-4 lg:h-4.5 lg:w-4.5" />
            Paramètres
          </button>
        )}

        {/* User info + logout */}
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg lg:py-2.5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0 shadow-lg shadow-blue-900/40 lg:w-9 lg:h-9 lg:text-xs">
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[11px] font-bold text-slate-200 truncate lg:text-xs">{profile.full_name || profile.email}</p>
            <p className="text-[9px] font-semibold text-slate-500 lg:text-[10px]">{ROLE_LABELS[profile.role]}</p>
          </div>
          <button
            onClick={onSignOut}
            title="Déconnexion"
            className="text-slate-500 hover:text-red-400 transition-colors flex-shrink-0"
          >
            <LogOut className="h-4 w-4 lg:h-4.5 lg:w-4.5" />
          </button>
        </div>
      </div>

      <div className="border-t border-slate-700/50 px-3 py-2.5 text-center">
        <p className="text-[9px] font-bold text-slate-500 lg:text-[10px]">Droits réservés — AGASOFT</p>
        <p className="text-[9px] text-slate-500 lg:text-[10px]">Contact : 225 0102202062</p>
      </div>
    </div>
  );
}

function NavBtn({
  route, target, icon: Icon, label, go, accent, badge,
}: {
  route: Route;
  target: Route;
  icon: React.ElementType;
  label: string;
  go: (r: Route) => void;
  accent?: boolean;
  badge?: number;
}) {
  const active = isActive(route, target);
  return (
    <button
      onClick={() => go(target)}
      className={`group flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-semibold transition lg:gap-3 lg:py-2.5 lg:text-sm ${
        active
          ? accent ? 'bg-emerald-500/15 text-emerald-300 shadow-sm' : 'bg-blue-500/15 text-blue-300 shadow-sm'
          : accent ? 'text-emerald-400 hover:bg-emerald-500/10 hover:text-emerald-300' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
      }`}
    >
      <Icon className="h-4 w-4 shrink-0 lg:h-4.5 lg:w-4.5" />
      <span className="flex-1 text-left">{label}</span>
      {badge != null && badge > 0 && (
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-500/20 text-[10px] font-bold text-amber-400 ring-1 ring-amber-500/40">
          <AlertTriangle className="h-3 w-3" />
        </span>
      )}
      {active && !badge && <ChevronRight className="h-3.5 w-3.5 text-slate-500" />}
    </button>
  );
}

export function Sidebar({ route, onNavigate, mobileOpen, onCloseMobile, lowStockCount, profile, onSignOut, locations, activeLocationId, onLocationChange, tenantName, pendingCount }: SidebarProps) {
  return (
    <>
      <aside className="hidden w-60 shrink-0 flex-col border-r border-slate-700/50 bg-slate-900 lg:flex">
        <SidebarContent route={route} onNavigate={onNavigate} lowStockCount={lowStockCount} profile={profile} onSignOut={onSignOut} locations={locations} activeLocationId={activeLocationId} onLocationChange={onLocationChange} tenantName={tenantName} pendingCount={pendingCount} />
      </aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={onCloseMobile} />
          <aside className="absolute left-0 top-0 h-full w-60 bg-slate-900 shadow-2xl">
            <SidebarContent route={route} onNavigate={onNavigate} onClose={onCloseMobile} lowStockCount={lowStockCount} profile={profile} onSignOut={onSignOut} locations={locations} activeLocationId={activeLocationId} onLocationChange={onLocationChange} tenantName={tenantName} pendingCount={pendingCount} />
          </aside>
        </div>
      )}
    </>
  );
}
