import { Fragment, useState, useEffect, useMemo } from 'react';
import {
  Building2, Plus, Users, CreditCard, Calendar, CheckCircle, XCircle,
  Pencil, AlertTriangle, Clock, Shield, ChevronRight, X, Search,
  TrendingUp, ArrowUpRight, UserPlus, Eye, EyeOff,
  ShoppingCart, FileText, Package, MapPin, Activity, Trash2,
} from 'lucide-react';
import { useTenants, type RevenueStats } from '../hooks/useTenants';
import type { LicensePlan } from '../types';
import { supabase } from '../lib/supabase';
import type { Tenant, Subscription, UserProfile, UserStatus } from '../types';
import { ROLE_LABELS, STATUS_USER_LABELS } from '../types';
import { translateError } from '../lib/translateError';

type Tab = 'dashboard' | 'tenants' | 'detail' | 'activity' | 'revenue';

function slugify(text: string): string {
  return text.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || `tenant-${Date.now().toString(36)}`;
}

function daysUntil(dateStr: string | null): number | null {
  if (!dateStr) return null;
  return Math.ceil((new Date(dateStr).getTime() - Date.now()) / 86_400_000);
}

function licenseStatus(t: Tenant): 'active' | 'expiring' | 'expired' | 'none' {
  const d = daysUntil(t.license_expires_at);
  if (d === null) return 'none';
  if (d < 0) return 'expired';
  if (d <= 30) return 'expiring';
  return 'active';
}

const STATUS_CONFIG = {
  active:   { label: 'Active',         icon: CheckCircle,    bg: 'bg-emerald-100', text: 'text-emerald-700', iconColor: 'text-emerald-600', bar: 'bg-emerald-500' },
  expiring: { label: 'Expire bientot', icon: AlertTriangle,  bg: 'bg-amber-100',   text: 'text-amber-700',   iconColor: 'text-amber-600',   bar: 'bg-amber-500' },
  expired:  { label: 'Expiree',        icon: XCircle,        bg: 'bg-red-100',     text: 'text-red-700',     iconColor: 'text-red-600',     bar: 'bg-red-500' },
  none:     { label: 'Non definie',    icon: Clock,          bg: 'bg-gray-100',    text: 'text-gray-700',    iconColor: 'text-gray-600',    bar: 'bg-gray-500' },
} as const;

function StatCard({ icon: Icon, label, value, sub, bg, iconColor }: {
  icon: React.ElementType; label: string; value: string | number; sub?: string; bg: string; iconColor: string;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex items-start gap-4 hover:shadow-md transition">
      <div className={`flex-shrink-0 w-11 h-11 rounded-lg ${bg} flex items-center justify-center`}>
        <Icon className={`h-5 w-5 ${iconColor}`} />
      </div>
      <div className="min-w-0">
        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">{label}</p>
        <p className="text-2xl font-bold text-gray-900 mt-0.5">{value}</p>
        {sub && <p className="text-xs text-gray-500 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

export function TenantsPage() {
  const {
    tenants, subscriptions, plans, loading,
    createTenant, updateTenant, deleteTenant, createSubscription, deleteSubscription,
    fetchSubscriptions, fetchPlans, assignUserToTenant, createTenantUser,
    fetchTenantActivity, deleteUser, updateTenantUserRole, updateTenantUserStatus,
    fetchRevenueStats,
  } = useTenants();

  const [tab, setTab] = useState<Tab>('dashboard');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editTenant, setEditTenant] = useState<Tenant | null>(null);
  const [form, setForm] = useState({ name: '', max_users: '5' });
  const [subForm, setSubForm] = useState({ plan_id: '', amount: '', starts_at: '', ends_at: '', payment_method: 'orange_money', payment_reference: '' });
  const [showSubForm, setShowSubForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    supabase.from('user_profiles').select('*').then(({ data }) => setAllUsers((data ?? []) as UserProfile[]));
  }, []);

  useEffect(() => { fetchPlans().catch(() => {}); }, [fetchPlans]);

  const selected = useMemo(() => tenants.find(t => t.id === selectedId) ?? null, [tenants, selectedId]);

  useEffect(() => {
    if (selectedId) fetchSubscriptions(selectedId);
  }, [selectedId, fetchSubscriptions]);

  const stats = useMemo(() => {
    const active = tenants.filter(t => licenseStatus(t) === 'active').length;
    const expiring = tenants.filter(t => licenseStatus(t) === 'expiring').length;
    const expired = tenants.filter(t => licenseStatus(t) === 'expired').length;
    return { total: tenants.length, active, expiring, expired, users: allUsers.filter(u => u.role !== 'super_admin').length };
  }, [tenants, allUsers]);

  const filteredTenants = useMemo(() => {
    if (!search) return tenants;
    const q = search.toLowerCase();
    return tenants.filter(t => t.name.toLowerCase().includes(q) || t.slug.toLowerCase().includes(q));
  }, [tenants, search]);

  function openDetail(id: string) {
    setSelectedId(id);
    setTab('detail');
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true); setError('');
    try {
      const t = await createTenant({ name: form.name, slug: slugify(form.name), max_users: Number(form.max_users) || 5 });
      setForm({ name: '', max_users: '5' });
      setShowForm(false);
      openDetail(t.id);
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
    setSaving(false);
  }

  async function handleUpdate(e: React.FormEvent) {
    e.preventDefault();
    if (!editTenant) return;
    setSaving(true); setError('');
    try {
      await updateTenant(editTenant.id, { name: form.name, slug: slugify(form.name), max_users: Number(form.max_users) || 5 });
      setEditTenant(null); setShowForm(false);
      setForm({ name: '', max_users: '5' });
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
    setSaving(false);
  }

  function selectPlan(planId: string) {
    const plan = plans.find(p => p.id === planId);
    if (!plan) {
      setSubForm(f => ({ ...f, plan_id: '', amount: f.amount, starts_at: f.starts_at, ends_at: f.ends_at }));
      return;
    }
    const todayStr = new Date().toISOString().split('T')[0];
    const endsAt = new Date(Date.now() + plan.duration_days * 86_400_000).toISOString().split('T')[0];
    setSubForm(f => ({ ...f, plan_id: planId, amount: String(plan.price), starts_at: todayStr, ends_at: endsAt }));
  }

  async function handleSubscription(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedId) return;
    setSaving(true); setError('');
    try {
      await createSubscription({
        tenant_id: selectedId,
        amount: Number(subForm.amount),
        starts_at: subForm.starts_at,
        ends_at: subForm.ends_at,
        payment_method: subForm.payment_method,
        payment_reference: subForm.payment_reference || undefined,
        plan_id: subForm.plan_id || null,
      });
      setShowSubForm(false);
      setSubForm({ plan_id: '', amount: '', starts_at: '', ends_at: '', payment_method: 'orange_money', payment_reference: '' });
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
    setSaving(false);
  }

  async function handleAssignUser(userId: string, tenantId: string) {
    try {
      await assignUserToTenant(userId, tenantId);
      setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, tenant_id: tenantId } : u));
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
  }

  async function handleCreateUser(input: { email: string; password: string; full_name: string; role: string }) {
    if (!selectedId) return;
    setSaving(true); setError('');
    try {
      const newUser = await createTenantUser({ ...input, tenant_id: selectedId });
      setAllUsers(prev => [...prev, { ...newUser, status: 'active', created_at: new Date().toISOString(), location_id: null } as UserProfile]);
    } catch (err) {
      setSaving(false);
      throw err;
    }
    setSaving(false);
  }

  async function handleUnassignUser(userId: string) {
    try {
      const { error: e } = await supabase.from('user_profiles').update({ tenant_id: null, updated_at: new Date().toISOString() }).eq('id', userId);
      if (e) throw new Error(e.message);
      setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, tenant_id: null } : u));
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
  }

  async function handleUpdateRole(userId: string, role: string) {
    try {
      await updateTenantUserRole(userId, role);
      setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, role: role as UserProfile['role'] } : u));
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
  }

  async function handleUpdateStatus(userId: string, status: UserStatus) {
    try {
      await updateTenantUserStatus(userId, status);
      setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, status } : u));
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
  }

  async function handleDeleteUser(userId: string) {
    try {
      await deleteUser(userId);
      setAllUsers(prev => prev.filter(u => u.id !== userId));
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
  }

  const [confirmDeleteTenant, setConfirmDeleteTenant] = useState<string | null>(null);

  async function handleDeleteTenant(id: string) {
    setSaving(true); setError('');
    try {
      await deleteTenant(id);
      setAllUsers(prev => prev.filter(u => u.tenant_id !== id));
      setSelectedId(null);
      setTab('tenants');
      setConfirmDeleteTenant(null);
    } catch (err) { setError(err instanceof Error ? translateError(err.message) : 'Erreur'); }
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top nav */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-1">
          <button onClick={() => setTab('dashboard')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition ${tab === 'dashboard' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'}`}>
            Tableau de bord
          </button>
          <button onClick={() => setTab('tenants')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition ${tab === 'tenants' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'}`}>
            Entreprises
          </button>
          {selected && (
            <button onClick={() => setTab('detail')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition flex items-center gap-1 ${tab === 'detail' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'}`}>
              <Building2 className="h-3.5 w-3.5" /> {selected.name}
            </button>
          )}
          <button onClick={() => setTab('activity')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition flex items-center gap-1 ${tab === 'activity' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'}`}>
            <Activity className="h-3.5 w-3.5" /> Activité
          </button>
          <button onClick={() => setTab('revenue')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition flex items-center gap-1 ${tab === 'revenue' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'}`}>
            <TrendingUp className="h-3.5 w-3.5" /> Revenus
          </button>
        </div>
        <button onClick={() => { setShowForm(true); setEditTenant(null); setForm({ name: '', max_users: '5' }); }}
          className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow hover:bg-blue-500 transition">
          <Plus className="h-4 w-4" /> Nouvelle entreprise
        </button>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-4 py-2">
          <AlertTriangle className="h-4 w-4 flex-shrink-0" /> {error}
          <button onClick={() => setError('')} className="ml-auto"><X className="h-3.5 w-3.5" /></button>
        </div>
      )}

      {/* ─── DASHBOARD TAB ─── */}
      {tab === 'dashboard' && (
        <div className="space-y-6">
          {/* Stat cards */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            <StatCard icon={Building2} label="Entreprises" value={stats.total} bg="bg-blue-100" iconColor="text-blue-600" />
            <StatCard icon={CheckCircle} label="Licences actives" value={stats.active} bg="bg-emerald-100" iconColor="text-emerald-600" />
            <StatCard icon={AlertTriangle} label="Expirent bientot" value={stats.expiring} sub="sous 30 jours" bg="bg-amber-100" iconColor="text-amber-600" />
            <StatCard icon={XCircle} label="Expirees" value={stats.expired} bg="bg-red-100" iconColor="text-red-600" />
            <StatCard icon={Users} label="Utilisateurs" value={stats.users} bg="bg-sky-100" iconColor="text-sky-600" />
          </div>

          {/* License timeline */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-bold text-gray-900 flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-600" /> Suivi des licences
              </h2>
              <p className="text-xs text-gray-400">{tenants.length} entreprise{tenants.length !== 1 ? 's' : ''}</p>
            </div>
            {tenants.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-sm">Aucune entreprise enregistree.</div>
            ) : (
              <div className="divide-y divide-gray-50">
                {[...tenants]
                  .sort((a, b) => {
                    const order = { expired: 0, expiring: 1, none: 2, active: 3 };
                    return order[licenseStatus(a)] - order[licenseStatus(b)];
                  })
                  .map(t => {
                    const status = licenseStatus(t);
                    const cfg = STATUS_CONFIG[status];
                    const StatusIcon = cfg.icon;
                    const days = daysUntil(t.license_expires_at);
                    const userCount = allUsers.filter(u => u.tenant_id === t.id).length;

                    return (
                      <button key={t.id} onClick={() => openDetail(t.id)}
                        className="w-full px-5 py-3.5 flex items-center gap-4 hover:bg-gray-50 transition text-left group">
                        <div className={`flex-shrink-0 w-9 h-9 rounded-lg ${cfg.bg} flex items-center justify-center`}>
                          <StatusIcon className={`h-4 w-4 ${cfg.iconColor}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-gray-900 truncate">{t.name}</p>
                          <p className="text-xs text-gray-400 font-mono">{t.slug}</p>
                        </div>
                        <div className="hidden sm:flex items-center gap-1.5 text-xs text-gray-400">
                          <Users className="h-3.5 w-3.5" /> {userCount}
                        </div>
                        <div className="text-right flex-shrink-0">
                          <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${cfg.bg} ${cfg.text}`}>
                            {cfg.label}
                          </span>
                          {days !== null && (
                            <p className={`text-[11px] mt-0.5 ${days < 0 ? 'text-red-500' : days <= 30 ? 'text-amber-500' : 'text-gray-400'}`}>
                              {days < 0 ? `Expiree depuis ${Math.abs(days)}j` : days === 0 ? "Expire aujourd'hui" : `${days}j restants`}
                            </p>
                          )}
                        </div>
                        <ChevronRight className="h-4 w-4 text-gray-300 group-hover:text-gray-500 transition flex-shrink-0" />
                      </button>
                    );
                  })}
              </div>
            )}
          </div>

          {/* Unassigned users */}
          {(() => {
            const unassigned = allUsers.filter(u => !u.tenant_id && u.role !== 'super_admin');
            if (unassigned.length === 0) return null;
            return (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-5">
                <h3 className="font-semibold text-amber-800 flex items-center gap-2 mb-3">
                  <AlertTriangle className="h-4 w-4" /> {unassigned.length} utilisateur{unassigned.length > 1 ? 's' : ''} sans entreprise
                </h3>
                <div className="flex flex-wrap gap-2">
                  {unassigned.map(u => (
                    <span key={u.id} className="inline-flex items-center gap-1.5 rounded-lg bg-white border border-amber-200 px-3 py-1.5 text-xs text-amber-700">
                      {u.full_name || u.email}
                      <span className="text-amber-400">({ROLE_LABELS[u.role]})</span>
                      {u.status === 'pending' && (
                        <button
                          onClick={() => handleUpdateStatus(u.id, 'active')}
                          title="Approuver ce compte"
                          className="ml-1 rounded bg-emerald-600 px-2 py-0.5 text-[11px] font-semibold text-white hover:bg-emerald-500 transition"
                        >
                          Valider
                        </button>
                      )}
                      <button
                        onClick={() => {
                          if (confirm(`Supprimer definitivement le compte de ${u.full_name || u.email} ?`)) handleDeleteUser(u.id);
                        }}
                        title="Supprimer cet utilisateur"
                        className="ml-1 text-red-400 hover:text-red-600 transition"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* ─── TENANTS LIST TAB ─── */}
      {tab === 'tenants' && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Rechercher une entreprise..."
              className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:border-blue-500 outline-none" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredTenants.map(t => {
              const status = licenseStatus(t);
              const cfg = STATUS_CONFIG[status];
              const StatusIcon = cfg.icon;
              const days = daysUntil(t.license_expires_at);
              const userCount = allUsers.filter(u => u.tenant_id === t.id).length;
              return (
                <div key={t.id} onClick={() => openDetail(t.id)}
                  className="rounded-xl border border-gray-200 shadow-sm bg-white overflow-hidden cursor-pointer transition hover:shadow-md hover:border-gray-300 group">
                  <div className="p-5 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-bold text-gray-900 group-hover:text-blue-600 transition">{t.name}</h3>
                        <p className="text-xs text-gray-400 font-mono">{t.slug}</p>
                      </div>
                      <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${cfg.bg} ${cfg.text}`}>
                        <StatusIcon className="h-3 w-3" /> {cfg.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {userCount} utilisateur{userCount !== 1 ? 's' : ''}</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        {t.license_expires_at ? new Date(t.license_expires_at).toLocaleDateString('fr-FR') : 'Pas de licence'}
                      </span>
                    </div>
                    {days !== null && (
                      <div className="w-full bg-gray-100 rounded-full h-1.5">
                        <div
                          className={`h-1.5 rounded-full transition-all ${status === 'active' ? 'bg-emerald-500' : status === 'expiring' ? 'bg-amber-500' : 'bg-red-500'}`}
                          style={{ width: `${Math.max(0, Math.min(100, (days / 365) * 100))}%` }}
                        />
                      </div>
                    )}
                  </div>
                  <div className="border-t border-gray-100 px-5 py-2.5 bg-gray-50 flex items-center justify-between">
                    <div className="flex gap-2">
                      <button onClick={e => { e.stopPropagation(); setEditTenant(t); setForm({ name: t.name, max_users: String(t.max_users ?? 5) }); setShowForm(true); }}
                        className="text-xs text-blue-600 hover:underline flex items-center gap-1"><Pencil className="h-3 w-3" /> Modifier</button>
                    </div>
                    <ArrowUpRight className="h-3.5 w-3.5 text-gray-300 group-hover:text-blue-500 transition" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ─── DETAIL TAB ─── */}
      {tab === 'detail' && selected && (
        <TenantDetail
          tenant={selected}
          allUsers={allUsers}
          subscriptions={subscriptions.filter(s => s.tenant_id === selected.id)}
          onEdit={() => { setEditTenant(selected); setForm({ name: selected.name, max_users: String(selected.max_users ?? 5) }); setShowForm(true); }}
          onAddSub={() => setShowSubForm(true)}
          onDeleteSub={async (id) => { await deleteSubscription(id); }}
          onAssign={uid => handleAssignUser(uid, selected.id)}
          onUnassign={handleUnassignUser}
          onCreateUser={handleCreateUser}
          onDeleteUser={handleDeleteUser}
          onUpdateRole={handleUpdateRole}
          onUpdateStatus={handleUpdateStatus}
          onDeleteTenant={() => setConfirmDeleteTenant(selected.id)}
          saving={saving}
        />
      )}

      {/* ─── CREATE / EDIT MODAL ─── */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <form onSubmit={editTenant ? handleUpdate : handleCreate} className="bg-white rounded-2xl shadow-xl border border-gray-200 max-w-lg w-full p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-gray-900">{editTenant ? 'Modifier l\'entreprise' : 'Nouvelle entreprise'}</h2>
              <button type="button" onClick={() => { setShowForm(false); setEditTenant(null); }}><X className="h-5 w-5 text-gray-400 hover:text-gray-600" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Nom de l'entreprise</label>
                <input type="text" required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="Ex: Societe ABC"
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none transition" />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Quota utilisateurs max</label>
                <input type="number" min="1" value={form.max_users} onChange={e => setForm(f => ({ ...f, max_users: e.target.value }))}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none transition" />
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button type="submit" disabled={saving}
                className="flex-1 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50 transition">
                {saving ? 'Enregistrement...' : editTenant ? 'Mettre a jour' : 'Creer l\'entreprise'}
              </button>
              <button type="button" onClick={() => { setShowForm(false); setEditTenant(null); }}
                className="rounded-lg bg-gray-100 px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-200 transition">Annuler</button>
            </div>
          </form>
        </div>
      )}

      {/* ─── DELETE TENANT CONFIRMATION ─── */}
      {confirmDeleteTenant && selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 max-w-md w-full p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                <Trash2 className="h-5 w-5 text-red-600" />
              </div>
              <h2 className="text-lg font-bold text-gray-900">Supprimer l'entreprise</h2>
            </div>
            <p className="text-sm text-gray-600">
              Vous etes sur le point de supprimer definitivement <strong>{selected.name}</strong>.
              Toutes les donnees associees (utilisateurs, articles, ventes, factures, clients) seront definitivement effacees.
              Cette action est irreversible.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => handleDeleteTenant(confirmDeleteTenant)}
                disabled={saving}
                className="flex-1 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-500 disabled:opacity-50 transition"
              >
                {saving ? 'Suppression...' : 'Supprimer definitivement'}
              </button>
              <button
                onClick={() => setConfirmDeleteTenant(null)}
                className="rounded-lg bg-gray-100 px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-200 transition"
              >Annuler</button>
            </div>
          </div>
        </div>
      )}

      {/* ─── ACTIVITY TAB ─── */}
      {tab === 'activity' && (
        <TenantActivity tenants={tenants} fetchActivity={fetchTenantActivity} />
      )}

      {/* ─── REVENUE TAB ─── */}
      {tab === 'revenue' && (
        <RevenueStatsTab tenants={tenants} fetchRevenueStats={fetchRevenueStats} />
      )}

      {/* ─── SUBSCRIPTION MODAL ─── */}
      {showSubForm && selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 max-w-lg w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-gray-900">Gérer la licence</h2>
                <p className="text-xs text-gray-500 mt-0.5">{selected.name}</p>
              </div>
              <button type="button" onClick={() => setShowSubForm(false)}><X className="h-5 w-5 text-gray-400 hover:text-gray-600" /></button>
            </div>

            <form onSubmit={handleSubscription} className="space-y-4">
            {/* Plan selector */}
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-2">Choisir un plan</label>
              <div className="grid grid-cols-3 gap-2">
                {plans.length === 0 && (
                  <p className="col-span-3 text-sm text-gray-400 text-center py-3">Chargement des plans...</p>
                )}
                {plans.map(p => {
                  const selectedPlan = subForm.plan_id === p.id;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => selectPlan(p.id)}
                      className={`rounded-xl border p-3 text-center transition ${selectedPlan ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200' : 'border-gray-200 hover:border-gray-300'}`}
                    >
                      <p className="text-sm font-bold text-gray-900">{p.name}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{p.duration_days} jours</p>
                      <p className="text-sm font-semibold text-emerald-600 mt-1">
                        {p.price === 0 ? 'Gratuit' : `${new Intl.NumberFormat('fr-FR').format(p.price)} F`}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom dates toggle */}
            {subForm.plan_id && (
              <button
                type="button"
                onClick={() => setSubForm(f => ({ ...f, plan_id: '' }))}
                className="text-xs text-blue-600 hover:underline"
              >
                Saisie manuelle des dates (sans plan)
              </button>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Montant (FCFA)</label>
                <input type="number" required min="0" value={subForm.amount} onChange={e => setSubForm(f => ({ ...f, amount: e.target.value }))}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Mode de paiement</label>
                <select value={subForm.payment_method} onChange={e => setSubForm(f => ({ ...f, payment_method: e.target.value }))}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none">
                  <option value="orange_money">Orange Money</option>
                  <option value="wave">Wave</option>
                  <option value="mtn_money">MTN Money</option>
                  <option value="moov_money">Moov Money</option>
                  <option value="virement">Virement</option>
                  <option value="especes">Especes</option>
                  <option value="autre">Autre</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Debut</label>
                <input type="date" required value={subForm.starts_at} onChange={e => setSubForm(f => ({ ...f, starts_at: e.target.value }))}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Fin</label>
                <input type="date" required value={subForm.ends_at} onChange={e => setSubForm(f => ({ ...f, ends_at: e.target.value }))}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1.5">Reference paiement</label>
              <input type="text" value={subForm.payment_reference} onChange={e => setSubForm(f => ({ ...f, payment_reference: e.target.value }))}
                placeholder="Numero de transaction..."
                className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none" />
            </div>
            <div className="flex gap-2 pt-2">
              <button type="submit" disabled={saving}
                className="flex-1 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-500 disabled:opacity-50 transition">
                {saving ? 'Enregistrement...' : 'Enregistrer l\'abonnement'}
              </button>
              <button type="button" onClick={() => setShowSubForm(false)}
                className="rounded-lg bg-gray-100 px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-200 transition">Annuler</button>
            </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

/* ─── REVENUE STATS SUB-COMPONENT ─── */

const MONTH_LABELS = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];

function RevenueStatsTab({ tenants, fetchRevenueStats }: {
  tenants: Tenant[];
  fetchRevenueStats: () => Promise<RevenueStats[]>;
}) {
  const [records, setRecords] = useState<RevenueStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [yearFilter, setYearFilter] = useState(new Date().getFullYear());

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setError('');
      try {
        const data = await fetchRevenueStats();
        if (!cancelled) setRecords(data);
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? translateError(err.message) : 'Erreur de chargement');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [fetchRevenueStats]);

  const years = useMemo(() => {
    const set = new Set<number>([new Date().getFullYear()]);
    records.forEach(r => {
      const y = new Date(r.created_at).getFullYear();
      if (!isNaN(y)) set.add(y);
    });
    return Array.from(set).sort((a, b) => b - a);
  }, [records]);

  const yearRecords = records.filter(r => new Date(r.created_at).getFullYear() === yearFilter);

  const monthlyData = useMemo(() => {
    const months = Array.from({ length: 12 }, () => ({ count: 0, amount: 0 }));
    yearRecords.forEach(r => {
      const m = new Date(r.created_at).getMonth();
      if (!isNaN(m)) {
        months[m].count += 1;
        months[m].amount += Number(r.amount) || 0;
      }
    });
    return months;
  }, [yearRecords]);

  const annualTotal = monthlyData.reduce((s, m) => s + m.amount, 0);
  const annualCount = monthlyData.reduce((s, m) => s + m.count, 0);
  const maxMonthAmount = Math.max(...monthlyData.map(m => m.amount), 1);

  const tenantName = (id: string) => tenants.find(t => t.id === id)?.name ?? '—';

  const methodLabels: Record<string, string> = {
    orange_money: 'Orange Money', wave: 'Wave', mtn_money: 'MTN Money',
    moov_money: 'Moov Money', virement: 'Virement', especes: 'Espèces', autre: 'Autre',
  };

  const fmtFCFA = (n: number) => new Intl.NumberFormat('fr-FR').format(n);

  return (
    <div className="space-y-6">
      {error && (
        <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-4 py-2">
          <AlertTriangle className="h-4 w-4" /> {error}
          <button onClick={() => setError('')} className="ml-auto"><X className="h-3.5 w-3.5" /></button>
        </div>
      )}

      {/* Year selector */}
      <div className="flex items-center gap-3">
        <span className="text-sm font-semibold text-gray-700">Année</span>
        <select
          value={yearFilter}
          onChange={e => setYearFilter(Number(e.target.value))}
          className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm focus:border-blue-500 outline-none"
        >
          {years.map(y => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>

      {/* Annual KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={CreditCard} label="Revenus annuels" value={`${fmtFCFA(annualTotal)} F`} sub={`${annualCount} paiement${annualCount > 1 ? 's' : ''}`} bg="bg-emerald-100" iconColor="text-emerald-600" />
        <StatCard icon={TrendingUp} label="Moyenne mensuelle" value={`${fmtFCFA(Math.round(annualTotal / 12))} F`} bg="bg-blue-100" iconColor="text-blue-600" />
        <StatCard icon={CheckCircle} label="Moyenne par paiement" value={`${fmtFCFA(annualCount > 0 ? Math.round(annualTotal / annualCount) : 0)} F`} bg="bg-sky-100" iconColor="text-sky-600" />
        <StatCard icon={Building2} label="Entreprises actives" value={tenants.filter(t => licenseStatus(t) === 'active').length} bg="bg-amber-100" iconColor="text-amber-600" />
      </div>

      {/* Monthly bar chart */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h2 className="font-bold text-gray-900 flex items-center gap-2 mb-5">
          <TrendingUp className="h-5 w-5 text-blue-600" /> Prévisions / Revenus mensuels — {yearFilter}
        </h2>
        {loading ? (
          <div className="h-48 flex items-center justify-center">
            <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin" />
          </div>
        ) : (
          <div className="flex items-end gap-2 sm:gap-3 h-56">
            {monthlyData.map((m, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1.5 group">
                <div className="w-full flex-1 flex items-end relative">
                  <div
                    className="w-full bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-md transition-all hover:from-blue-700 hover:to-blue-500 relative group"
                    style={{ height: `${Math.max((m.amount / maxMonthAmount) * 100, 2)}%` }}
                  >
                    <div className="absolute -top-7 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition bg-gray-900 text-white text-xs font-semibold rounded px-2 py-1 whitespace-nowrap pointer-events-none z-10">
                      {fmtFCFA(m.amount)} F
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-medium text-gray-400">{MONTH_LABELS[i]}</span>
                <span className="text-[10px] text-gray-500 tabular-nums">{m.count}</span>
              </div>
            ))}
          </div>
        )}
        <div className="mt-4 flex items-center justify-between text-xs text-gray-400">
          <span className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-blue-500" /> Revenus mensuels</span>
          <span>Total annuel : <strong className="text-gray-700">{fmtFCFA(annualTotal)} F</strong></span>
        </div>
      </div>

      {/* Detailed table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h2 className="font-bold text-gray-900">Détail des paiements — {yearFilter}</h2>
        </div>
        {yearRecords.length === 0 ? (
          <div className="p-8 text-center text-gray-400 text-sm">Aucun paiement enregistré pour {yearFilter}.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-400 uppercase">Date</th>
                  <th className="text-left px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Entreprise</th>
                  <th className="text-right px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Montant</th>
                  <th className="text-left px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Mode</th>
                  <th className="text-center px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {yearRecords.map((r, i) => (
                  <tr key={i} className="hover:bg-gray-50 transition">
                    <td className="px-5 py-3 text-gray-600">
                      {new Date(r.created_at).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </td>
                    <td className="px-3 py-3 font-medium text-gray-800">{tenantName(r.tenant_id)}</td>
                    <td className="px-3 py-3 text-right tabular-nums font-semibold text-emerald-600">{fmtFCFA(Number(r.amount))} F</td>
                    <td className="px-3 py-3 text-gray-500">{methodLabels[r.payment_method] ?? r.payment_method ?? '—'}</td>
                    <td className="px-3 py-3 text-center">
                      <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                        r.status === 'active' ? 'bg-emerald-100 text-emerald-700' :
                        r.status === 'expired' ? 'bg-red-100 text-red-700' :
                        'bg-gray-100 text-gray-600'
                      }`}>{r.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── TENANT ACTIVITY SUB-COMPONENT ─── */

interface ActivityData {
  tenant_id: string;
  tenant_name: string;
  tenant_slug: string;
  total_sales: number;
  total_sales_amount: number;
  total_invoices: number;
  total_invoices_amount: number;
  unpaid_invoices: number;
  unpaid_amount: number;
  total_customers: number;
  total_products: number;
  total_users: number;
  total_locations: number;
  last_sale_date: string | null;
  last_invoice_date: string | null;
}

function TenantActivity({ tenants, fetchActivity }: {
  tenants: Tenant[];
  fetchActivity: (id: string) => Promise<ActivityData>;
}) {
  const [activities, setActivities] = useState<Record<string, ActivityData>>({});
  const [loadingIds, setLoadingIds] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<string | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function loadAll() {
      for (const tenant of tenants) {
        if (cancelled) return;
        setLoadingIds(prev => new Set(prev).add(tenant.id));
        try {
          const rows = await fetchActivity(tenant.id);
          const data = Array.isArray(rows) ? rows[0] : rows;
          if (data) setActivities(prev => ({ ...prev, [tenant.id]: data }));
        } catch (err) {
          if (!cancelled) setError(err instanceof Error ? translateError(err.message) : 'Erreur de chargement');
        } finally {
          if (!cancelled) setLoadingIds(prev => { const next = new Set(prev); next.delete(tenant.id); return next; });
        }
      }
    }
    if (tenants.length > 0) loadAll();
    return () => { cancelled = true; };
  }, [tenants, fetchActivity]);

  const totals = useMemo(() => {
    const all = Object.values(activities);
    return {
      sales: all.reduce((sum, activity) => sum + Number(activity.total_sales_amount), 0),
      invoices: all.reduce((sum, activity) => sum + Number(activity.total_invoices_amount), 0),
      unpaid: all.reduce((sum, activity) => sum + Number(activity.unpaid_amount), 0),
      customers: all.reduce((sum, activity) => sum + Number(activity.total_customers), 0),
      salesCount: all.reduce((sum, activity) => sum + Number(activity.total_sales), 0),
      invoiceCount: all.reduce((sum, activity) => sum + Number(activity.total_invoices), 0),
      unpaidCount: all.reduce((sum, activity) => sum + Number(activity.unpaid_invoices), 0),
      users: all.reduce((sum, activity) => sum + Number(activity.total_users), 0),
    };
  }, [activities]);

  const sortedTenants = [...tenants].sort((a, b) => Number(activities[b.id]?.total_sales_amount ?? 0) - Number(activities[a.id]?.total_sales_amount ?? 0));
  const formatNumber = (value: number): string => Number(value).toLocaleString('fr-FR');
  const formatDate = (value: string | null): string => value ? new Date(value).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

  return (
    <div className="space-y-6">
      {error && <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-4 py-2"><AlertTriangle className="h-4 w-4" />{error}<button onClick={() => setError('')} className="ml-auto"><X className="h-3.5 w-3.5" /></button></div>}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={ShoppingCart} label="Ventes caisse" value={formatNumber(totals.salesCount)} sub={`${formatNumber(totals.sales)} F`} bg="bg-emerald-100" iconColor="text-emerald-600" />
        <StatCard icon={FileText} label="Factures" value={formatNumber(totals.invoiceCount)} sub={`${formatNumber(totals.invoices)} F`} bg="bg-blue-100" iconColor="text-blue-600" />
        <StatCard icon={AlertTriangle} label="Impayés" value={formatNumber(totals.unpaidCount)} sub={`${formatNumber(totals.unpaid)} F`} bg="bg-amber-100" iconColor="text-amber-600" />
        <StatCard icon={Users} label="Clients / Utilisateurs" value={`${formatNumber(totals.customers)} / ${formatNumber(totals.users)}`} bg="bg-sky-100" iconColor="text-sky-600" />
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100"><h2 className="font-bold text-gray-900 flex items-center gap-2"><Activity className="h-5 w-5 text-blue-600" /> Activité par entreprise</h2><p className="text-xs text-gray-400 mt-0.5">Cliquez sur une ligne pour voir le détail</p></div>
        {sortedTenants.length === 0 ? <div className="p-8 text-center text-gray-400 text-sm">Aucune entreprise.</div> : <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b border-gray-100 bg-gray-50"><th className="text-left px-5 py-3 text-xs font-semibold text-gray-400 uppercase">Entreprise</th><th className="text-right px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Ventes</th><th className="text-right px-3 py-3 text-xs font-semibold text-gray-400 uppercase">CA Caisse</th><th className="text-right px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Factures</th><th className="text-right px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Impayés</th><th className="text-center px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Clients</th><th className="text-center px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Articles</th><th className="text-center px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Boutiques</th><th className="text-center px-3 py-3 text-xs font-semibold text-gray-400 uppercase">Dern. vente</th></tr></thead><tbody className="divide-y divide-gray-50">
          {sortedTenants.map(tenant => {
            const activity = activities[tenant.id];
            const isLoading = loadingIds.has(tenant.id);
            const isExpanded = expanded === tenant.id;
            return <Fragment key={tenant.id}><tr onClick={() => setExpanded(isExpanded ? null : tenant.id)} className="cursor-pointer hover:bg-blue-50/50 transition"><td className="px-5 py-3"><div className="flex items-center gap-2"><ChevronRight className={`h-3.5 w-3.5 text-gray-300 transition-transform ${isExpanded ? 'rotate-90' : ''}`} /><div><p className="font-semibold text-gray-900">{tenant.name}</p><p className="text-xs text-gray-400 font-mono">{tenant.slug}</p></div></div></td>{isLoading || !activity ? <td colSpan={8} className="px-3 py-3 text-center text-gray-400 text-xs"><span className="inline-block w-4 h-4 rounded-full border-2 border-blue-400 border-t-transparent animate-spin" /></td> : <><td className="px-3 py-3 text-right">{formatNumber(activity.total_sales)}</td><td className="px-3 py-3 text-right font-semibold">{formatNumber(activity.total_sales_amount)} F</td><td className="px-3 py-3 text-right">{formatNumber(activity.total_invoices)}</td><td className={`px-3 py-3 text-right ${Number(activity.unpaid_amount) > 0 ? 'text-amber-600 font-semibold' : 'text-gray-400'}`}>{formatNumber(activity.unpaid_amount)} F</td><td className="px-3 py-3 text-center">{formatNumber(activity.total_customers)}</td><td className="px-3 py-3 text-center">{formatNumber(activity.total_products)}</td><td className="px-3 py-3 text-center">{formatNumber(activity.total_locations)}</td><td className="px-3 py-3 text-center text-xs text-gray-500">{formatDate(activity.last_sale_date)}</td></>}</tr>{isExpanded && activity && <tr className="bg-gray-50"><td colSpan={9} className="px-5 py-4"><div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3"><MiniStat icon={ShoppingCart} label="Ventes caisse" value={formatNumber(activity.total_sales)} sub={`${formatNumber(activity.total_sales_amount)} F`} /><MiniStat icon={FileText} label="Factures émises" value={formatNumber(activity.total_invoices)} sub={`${formatNumber(activity.total_invoices_amount)} F`} /><MiniStat icon={AlertTriangle} label="Factures impayées" value={formatNumber(activity.unpaid_invoices)} sub={`${formatNumber(activity.unpaid_amount)} F`} /><MiniStat icon={Users} label="Clients" value={formatNumber(activity.total_customers)} /><MiniStat icon={Package} label="Articles actifs" value={formatNumber(activity.total_products)} /><MiniStat icon={MapPin} label="Boutiques" value={formatNumber(activity.total_locations)} /><MiniStat icon={Users} label="Utilisateurs" value={formatNumber(activity.total_users)} /><MiniStat icon={Calendar} label="Dernière vente" value={formatDate(activity.last_sale_date)} /><MiniStat icon={Calendar} label="Dernière facture" value={formatDate(activity.last_invoice_date)} /></div></td></tr>}</Fragment>;
          })}
        </tbody></table></div>}
      </div>
    </div>
  );
}

function MiniStat({ icon: Icon, label, value, sub }: { icon: React.ElementType; label: string; value: string; sub?: string }) {
  return <div className="bg-white rounded-lg border border-gray-200 p-3"><div className="flex items-center gap-1.5 mb-1"><Icon className="h-3.5 w-3.5 text-gray-400" /><p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">{label}</p></div><p className="text-sm font-bold text-gray-900">{value}</p>{sub && <p className="text-xs text-gray-500 mt-0.5">{sub}</p>}</div>;
}

/* ─── TENANT DETAIL SUB-COMPONENT ─── */

function TenantDetail({ tenant, allUsers, subscriptions, onEdit, onAddSub, onDeleteSub, onAssign, onUnassign, onCreateUser, onDeleteUser, onUpdateRole, onUpdateStatus, onDeleteTenant, saving }: {
  tenant: Tenant;
  allUsers: UserProfile[];
  subscriptions: Subscription[];
  onEdit: () => void;
  onAddSub: () => void;
  onDeleteSub: (id: string) => Promise<void>;
  onAssign: (uid: string) => void;
  onUnassign: (uid: string) => void;
  onCreateUser: (input: { email: string; password: string; full_name: string; role: string }) => Promise<void>;
  onDeleteUser: (uid: string) => void;
  onUpdateRole: (uid: string, role: string) => void;
  onUpdateStatus: (uid: string, status: UserStatus) => void;
  onDeleteTenant: () => void;
  saving: boolean;
}) {
  const [showCreateUser, setShowCreateUser] = useState(false);
  const [newUser, setNewUser] = useState({ email: '', password: '', full_name: '', role: 'caissier' });
  const [showPwd, setShowPwd] = useState(false);
  const [localError, setLocalError] = useState('');

  const status = licenseStatus(tenant);
  const cfg = STATUS_CONFIG[status];
  const StatusIcon = cfg.icon;
  const days = daysUntil(tenant.license_expires_at);
  const tenantUsers = allUsers.filter(u => u.tenant_id === tenant.id);
  const unassigned = allUsers.filter(u => !u.tenant_id && u.role !== 'super_admin');
  const quotaUsed = tenantUsers.length;
  const quotaMax = tenant.max_users ?? 5;
  const quotaPercent = Math.min(100, Math.round((quotaUsed / quotaMax) * 100));
  const quotaFull = quotaUsed >= quotaMax;

  async function handleSubmitUser(e: React.FormEvent) {
    e.preventDefault();
    setLocalError('');
    try {
      await onCreateUser(newUser);
      setNewUser({ email: '', password: '', full_name: '', role: 'caissier' });
      setShowCreateUser(false);
    } catch (err) {
      setLocalError(err instanceof Error ? translateError(err.message) : 'Erreur lors de la creation');
    }
  }

  return (
    <div className="space-y-5">
      {/* Header card */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className={`h-1.5 ${cfg.bar}`} />
        <div className="p-5 flex flex-col sm:flex-row sm:items-center gap-4">
          <div className={`flex-shrink-0 w-14 h-14 rounded-xl ${cfg.bg} flex items-center justify-center`}>
            <Building2 className={`h-7 w-7 ${cfg.iconColor}`} />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-bold text-gray-900">{tenant.name}</h2>
            <p className="text-sm text-gray-400 font-mono">{tenant.slug}</p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium ${cfg.bg} ${cfg.text}`}>
              <StatusIcon className="h-4 w-4" /> {cfg.label}
            </span>
            <button onClick={onEdit} className="rounded-lg border border-gray-200 p-2 hover:bg-gray-50 transition">
              <Pencil className="h-4 w-4 text-gray-500" />
            </button>
            <button onClick={onDeleteTenant} title="Supprimer cette entreprise"
              className="rounded-lg border border-red-200 p-2 hover:bg-red-50 transition">
              <Trash2 className="h-4 w-4 text-red-500" />
            </button>
          </div>
        </div>
        {/* License + quota bar */}
        <div className="border-t border-gray-100 px-5 py-3 bg-gray-50 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
          <div className="flex items-center gap-2 text-gray-600">
            <Calendar className="h-4 w-4 text-gray-400" />
            <span>Expire le :</span>
            <span className="font-semibold">
              {tenant.license_expires_at ? new Date(tenant.license_expires_at).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' }) : 'Non definie'}
            </span>
          </div>
          {days !== null && (
            <span className={`font-semibold ${days < 0 ? 'text-red-600' : days <= 30 ? 'text-amber-600' : 'text-emerald-600'}`}>
              {days < 0 ? `${Math.abs(days)} jours de retard` : days === 0 ? "Expire aujourd'hui" : `${days} jours restants`}
            </span>
          )}
          <div className="flex items-center gap-2 ml-auto">
            <Users className="h-4 w-4 text-gray-400" />
            <span className={`font-semibold ${quotaFull ? 'text-red-600' : 'text-gray-700'}`}>{quotaUsed}/{quotaMax}</span>
            <span className="text-gray-400 text-xs">utilisateurs</span>
          </div>
        </div>
        {/* Quota bar */}
        <div className="px-5 pb-3 bg-gray-50">
          <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
            <div
              className={`h-2 rounded-full transition-all ${quotaPercent >= 100 ? 'bg-red-500' : quotaPercent >= 80 ? 'bg-amber-500' : 'bg-emerald-500'}`}
              style={{ width: `${quotaPercent}%` }}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Users */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 className="font-bold text-gray-900 flex items-center gap-2"><Users className="h-4 w-4 text-gray-500" /> Utilisateurs ({quotaUsed}/{quotaMax})</h3>
            <button
              onClick={() => setShowCreateUser(true)}
              disabled={quotaFull}
              className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition">
              <UserPlus className="h-3 w-3" /> Creer un compte
            </button>
          </div>

          {quotaFull && (
            <div className="px-5 py-2 bg-red-50 border-b border-red-100 text-xs text-red-600 flex items-center gap-1.5">
              <AlertTriangle className="h-3.5 w-3.5" /> Quota atteint. Augmentez la limite ou retirez un utilisateur.
            </div>
          )}

          {tenantUsers.length === 0 ? (
            <div className="p-6 text-center text-gray-400 text-sm">Aucun utilisateur assigne.</div>
          ) : (
            <div className="divide-y divide-gray-50 max-h-72 overflow-y-auto">
              {tenantUsers.map(u => (
                <div key={u.id} className="px-5 py-3 flex items-center justify-between gap-3 hover:bg-gray-50 transition">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{u.full_name || u.email}</p>
                    <p className="text-xs text-gray-400 truncate">{u.email}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`rounded-full px-2 py-1 text-[11px] font-medium ${u.status === 'active' ? 'bg-emerald-50 text-emerald-700' : u.status === 'pending' ? 'bg-amber-50 text-amber-700' : 'bg-red-50 text-red-700'}`}>
                      {STATUS_USER_LABELS[u.status]}
                    </span>
                    <select
                      value={u.role}
                      onChange={e => onUpdateRole(u.id, e.target.value)}
                      disabled={u.role === 'super_admin'}
                      className="rounded-lg border border-gray-200 bg-gray-50 px-2 py-1 text-xs text-gray-700 outline-none focus:border-blue-500 disabled:opacity-50 disabled:cursor-default"
                    >
                      <option value="admin">Administrateur</option>
                      <option value="gerant">Gérant</option>
                      <option value="caissier">Caissier</option>
                      <option value="commercial">Commercial</option>
                      <option value="controleur">Contrôleur de caisse</option>
                    </select>
                    {u.status === 'pending' && (
                      <button
                        onClick={() => onUpdateStatus(u.id, 'active')}
                        className="rounded-lg bg-emerald-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-emerald-500 transition"
                      >
                        Valider
                      </button>
                    )}
                    <button onClick={() => onUnassign(u.id)} title="Retirer de l'entreprise"
                      className="text-xs text-red-500 hover:text-red-700 hover:underline transition">Retirer</button>
                  </div>
                </div>
              ))}
            </div>
          )}
          {unassigned.length > 0 && (
            <div className="border-t border-gray-100 px-5 py-3 bg-gray-50">
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Assigner un utilisateur existant</p>
              <div className="flex flex-wrap gap-1.5">
                {unassigned.map(u => (
                  <div key={u.id} className="inline-flex items-center gap-1.5">
                    <button onClick={() => onAssign(u.id)}
                      disabled={quotaFull}
                      className="rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-700 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition">
                      + {u.full_name || u.email}
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer definitivement le compte de ${u.full_name || u.email} ?`)) onDeleteUser(u.id);
                      }}
                      title="Supprimer cet utilisateur"
                      className="text-red-400 hover:text-red-600 transition p-1"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Subscriptions */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 className="font-bold text-gray-900 flex items-center gap-2"><CreditCard className="h-4 w-4 text-gray-500" /> Abonnements</h3>
            <button onClick={onAddSub}
              className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 transition">
              <Plus className="h-3 w-3" /> Ajouter
            </button>
          </div>
          {subscriptions.length === 0 ? (
            <div className="p-6 text-center text-gray-400 text-sm">Aucun abonnement enregistre.</div>
          ) : (
            <div className="divide-y divide-gray-50">
              {subscriptions.map(s => (
                <div key={s.id} className="px-5 py-3 hover:bg-gray-50 transition group">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-semibold text-gray-800">
                      {Number(s.amount).toLocaleString('fr-FR')} FCFA
                    </span>
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                        s.status === 'active' ? 'bg-emerald-100 text-emerald-700' :
                        s.status === 'expired' ? 'bg-red-100 text-red-700' :
                        'bg-gray-100 text-gray-600'
                      }`}>{s.status}</span>
                      <button
                        onClick={() => { if (confirm('Supprimer cet abonnement ?')) onDeleteSub(s.id); }}
                        title="Supprimer cet abonnement"
                        className="opacity-0 group-hover:opacity-100 transition rounded p-1 text-red-400 hover:bg-red-50 hover:text-red-600"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>{new Date(s.starts_at).toLocaleDateString('fr-FR')} - {new Date(s.ends_at).toLocaleDateString('fr-FR')}</span>
                    <span className="text-gray-300">|</span>
                    <span>{s.payment_method.replace(/_/g, ' ')}</span>
                    {s.payment_reference && <span className="font-mono text-gray-400">#{s.payment_reference}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Create user modal */}
      {showCreateUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <form onSubmit={handleSubmitUser} className="bg-white rounded-2xl shadow-xl border border-gray-200 max-w-md w-full p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2"><UserPlus className="h-5 w-5 text-blue-600" /> Nouveau compte</h2>
                <p className="text-xs text-gray-500 mt-0.5">{tenant.name} - {quotaUsed}/{quotaMax} utilisateurs</p>
              </div>
              <button type="button" onClick={() => setShowCreateUser(false)}><X className="h-5 w-5 text-gray-400 hover:text-gray-600" /></button>
            </div>
            <div className="space-y-3">
              {localError && (
                <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                  <span className="flex-1">{localError}</span>
                  <button type="button" onClick={() => setLocalError('')}><X className="h-3.5 w-3.5" /></button>
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Nom complet</label>
                <input type="text" required value={newUser.full_name} onChange={e => setNewUser(u => ({ ...u, full_name: e.target.value }))}
                  placeholder="Ex: Kouadio Jean"
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none transition" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Email</label>
                <input type="email" required value={newUser.email} onChange={e => setNewUser(u => ({ ...u, email: e.target.value }))}
                  placeholder="utilisateur@email.com"
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none transition" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Mot de passe</label>
                <div className="relative">
                  <input type={showPwd ? 'text' : 'password'} required minLength={6} value={newUser.password} onChange={e => setNewUser(u => ({ ...u, password: e.target.value }))}
                    placeholder="Min. 6 caracteres"
                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 pr-10 text-sm focus:border-blue-500 outline-none transition" />
                  <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                    {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">Role</label>
                <select value={newUser.role} onChange={e => setNewUser(u => ({ ...u, role: e.target.value }))}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:border-blue-500 outline-none transition">
                  <option value="admin">Administrateur</option>
                  <option value="gerant">Gerant</option>
                  <option value="caissier">Caissier</option>
                  <option value="commercial">Commercial</option>
                  <option value="controleur">Contrôleur de caisse</option>
                </select>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button type="submit" disabled={saving}
                className="flex-1 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50 transition">
                {saving ? 'Creation...' : 'Creer le compte'}
              </button>
              <button type="button" onClick={() => setShowCreateUser(false)}
                className="rounded-lg bg-gray-100 px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-200 transition">Annuler</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
