import { useState, useEffect, useCallback } from 'react';
import {
  TrendingUp, TrendingDown, Minus, Plus, Trash2,
  Printer, ChevronLeft, ChevronRight, BarChart3, BookOpen, FileBarChart,
  ArrowUpCircle, ArrowDownCircle, FileDown, Receipt, ShoppingCart, FileText, Truck,
} from 'lucide-react';
import type { CompanySettings } from '../types';
import { ALL_PAYMENT_METHODS } from '../types';
import {
  useAccounting, CHARGE_CATEGORIES, RECETTE_CATEGORIES,
  categoryLabel,
} from '../hooks/useAccounting';
import type { AccountingEntry, PnLData, MonthlyBar, HistoryItem, SalesHistoryRow } from '../hooks/useAccounting';
import { exportHtmlToPdf } from '../lib/pdf';
import { printDocument } from '../lib/printEngine';
import { translateError } from '../lib/translateError';

type Tab = 'synthese' | 'saisies' | 'resultat' | 'historique';

const MONTHS_FR = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];

function fmt(n: number, currency = 'FCFA') {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}
function fmtShort(n: number) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n);
}
void fmtShort;
/* ─── Period helpers ──────────────────────────────────────────── */
function periodBounds(year: number, month: number) {
  const start = `${year}-${String(month).padStart(2, '0')}-01`;
  const last  = new Date(year, month, 0).getDate();
  const end   = `${year}-${String(month).padStart(2, '0')}-${last}`;
  return { start, end };
}

/* ─── KPI card ────────────────────────────────────────────────── */
function KpiCard({ label, value, sub, color, icon: Icon }: {
  label: string; value: string; sub?: string;
  color: 'blue' | 'emerald' | 'red' | 'amber';
  icon: React.ElementType;
}) {
  const bg   = { blue: 'bg-blue-50',    emerald: 'bg-emerald-50', red: 'bg-red-50',   amber: 'bg-amber-50'   }[color];
  const text = { blue: 'text-blue-600', emerald: 'text-emerald-600', red: 'text-red-600', amber: 'text-amber-600' }[color];
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between">
        <p className="text-sm font-medium text-gray-500">{label}</p>
        <span className={`${bg} ${text} flex h-9 w-9 items-center justify-center rounded-lg`}>
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <p className={`mt-3 text-2xl font-bold tabular-nums ${text}`}>{value}</p>
      {sub && <p className="mt-0.5 text-xs text-gray-400">{sub}</p>}
    </div>
  );
}

/* ─── Bar chart (CSS) ─────────────────────────────────────────── */
function BarChart({ data, currency }: { data: MonthlyBar[]; currency: string }) {
  const maxVal = Math.max(...data.flatMap(d => [d.revenue, d.charges]), 1);
  return (
    <div className="flex h-48 items-end gap-1.5 px-1 pt-4">
      {data.map(d => (
        <div key={d.month} className="flex flex-1 flex-col items-center gap-1">
          <div className="flex w-full items-end gap-0.5" style={{ height: '140px' }}>
            <div
              className="flex-1 rounded-t bg-blue-500/80 transition-all duration-500 min-h-[2px]"
              style={{ height: `${Math.max((d.revenue / maxVal) * 100, 2)}%` }}
              title={`Recettes : ${fmt(d.revenue, currency)}`}
            />
            <div
              className="flex-1 rounded-t bg-red-400/70 transition-all duration-500 min-h-[2px]"
              style={{ height: `${Math.max((d.charges / maxVal) * 100, 2)}%` }}
              title={`Charges : ${fmt(d.charges, currency)}`}
            />
          </div>
          <span className="text-center text-[9px] leading-tight text-gray-400">{d.label}</span>
        </div>
      ))}
    </div>
  );
}

/* ─── Entry row ───────────────────────────────────────────────── */
function EntryRow({ entry, onDelete, currency }: { entry: AccountingEntry; onDelete: (id: string) => void; currency: string }) {
  const isCharge = entry.type === 'charge';
  return (
    <tr className="group hover:bg-gray-50">
      <td className="px-4 py-3 pl-5 text-sm tabular-nums text-gray-500">
        {new Date(entry.date).toLocaleDateString('fr-FR')}
      </td>
      <td className="px-4 py-3">
        <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
          isCharge ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-700'
        }`}>
          {isCharge ? <ArrowDownCircle className="h-3 w-3" /> : <ArrowUpCircle className="h-3 w-3" />}
          {isCharge ? 'Charge' : 'Recette'}
        </span>
      </td>
      <td className="px-4 py-3 text-sm text-gray-500">{categoryLabel(entry.category, entry.type)}</td>
      <td className="px-4 py-3 text-sm font-medium text-gray-800">{entry.description || '—'}</td>
      <td className={`px-4 py-3 text-right tabular-nums font-semibold text-sm ${isCharge ? 'text-red-600' : 'text-emerald-600'}`}>
        {isCharge ? '−' : '+'}{fmt(Number(entry.amount), currency)}
      </td>
      <td className="px-4 py-3 pr-5 text-right">
        <button
          onClick={() => onDelete(entry.id)}
          className="rounded p-1.5 text-gray-300 opacity-0 transition group-hover:opacity-100 hover:bg-red-50 hover:text-red-500"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      </td>
    </tr>
  );
}

/* ─── P&L print ───────────────────────────────────────────────── */
function buildPnLHtml(pnl: PnLData, cogs: number, period: string, companyName: string, currency: string) {
  const f  = (n: number) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n);
  const totalRevenue = pnl.pos_revenue + pnl.invoice_revenue + pnl.manual_revenue;
  const totalChargesAll = pnl.total_charges + cogs;
  const result       = totalRevenue - totalChargesAll;
  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<title>Compte de résultat ${period}</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: Arial, sans-serif; font-size: 11px; color: #111; padding: 20mm; }
@media print { @page { size: A4; margin: 15mm; } body { padding: 0; } }
h1 { font-size: 18px; font-weight: 900; text-align: center; margin-bottom: 4px; }
.sub { text-align: center; color: #666; margin-bottom: 16px; font-size: 12px; }
table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
th { background: #f0f4f8; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; padding: 6px 10px; text-align: left; }
td { padding: 6px 10px; border-bottom: 1px solid #eee; }
.r { text-align: right; }
.total td { font-weight: 700; border-top: 2px solid #333; font-size: 12px; }
.section-title { background: #1e40af; color: white; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; padding: 6px 10px; }
.result td { font-size: 14px; font-weight: 900; background: ${result >= 0 ? '#f0fdf4' : '#fef2f2'}; color: ${result >= 0 ? '#166534' : '#991b1b'}; border: 2px solid ${result >= 0 ? '#86efac' : '#fca5a5'}; }
.indent td:first-child { padding-left: 24px; color: #555; }
</style></head><body>
<h1>${companyName}</h1>
<div class="sub">Compte de résultat — ${period}</div>
<table>
  <tr><td class="section-title" colspan="2">PRODUITS</td></tr>
  <tr><td>Ventes POS (caisse)</td><td class="r">${f(pnl.pos_revenue)} ${currency}</td></tr>
  <tr><td>Factures émises</td><td class="r">${f(pnl.invoice_revenue)} ${currency}</td></tr>
  ${pnl.manual_revenue > 0 ? `<tr><td>Autres produits</td><td class="r">${f(pnl.manual_revenue)} ${currency}</td></tr>` : ''}
  <tr class="total"><td>TOTAL PRODUITS</td><td class="r">${f(totalRevenue)} ${currency}</td></tr>
</table>
<table>
  <tr><td class="section-title" colspan="2">CHARGES</td></tr>
  ${pnl.charges_by_category.map(c => `<tr class="indent"><td>${categoryLabel(c.category, 'charge')}</td><td class="r">${f(c.amount)} ${currency}</td></tr>`).join('')}
  ${cogs > 0 ? `<tr class="indent"><td>Coût d'achat des produits vendus</td><td class="r">${f(cogs)} ${currency}</td></tr>` : ''}
  ${pnl.charges_by_category.length === 0 && cogs === 0 ? '<tr><td colspan="2" style="color:#aaa;padding-left:24px">Aucune charge</td></tr>' : ''}
  <tr class="total"><td>TOTAL CHARGES</td><td class="r">${f(totalChargesAll)} ${currency}</td></tr>
</table>
<table>
  <tr class="result"><td>RÉSULTAT NET</td><td class="r">${result >= 0 ? '+' : ''}${f(result)} ${currency}</td></tr>
</table>
</body></html>`;
}

function printPnL(pnl: PnLData, cogs: number, period: string, companyName: string, currency: string) {
  printDocument(buildPnLHtml(pnl, cogs, period, companyName, currency), { format: 'a4', title: `Compte de résultat — ${period}` });
}

async function exportPnLPdf(pnl: PnLData, cogs: number, period: string, companyName: string, currency: string) {
  await exportHtmlToPdf(buildPnLHtml(pnl, cogs, period, companyName, currency), `compte_resultat_${period.replace(/\s/g, '_')}.pdf`, 'a4');
}

/* ═══════════════════════════════════════════════════════════════ */
/*  Main component                                                  */
/* ═══════════════════════════════════════════════════════════════ */
interface AccountingPageProps {
  settings: CompanySettings | null;
  locationId?: string | null;
}

export function AccountingPage({ settings, locationId }: AccountingPageProps) {
  const currency = settings?.currency ?? 'FCFA';
  const { entries, loading, fetchEntries, createEntry, deleteEntry, computePnL, computeMonthlyTrend, computeHistory, computeSalesHistory } = useAccounting(locationId);

  const now    = new Date();
  const [tab, setTab]       = useState<Tab>('synthese');
  const [year, setYear]     = useState(now.getFullYear());
  const [month, setMonth]   = useState(now.getMonth() + 1);

  /* Synthese state */
  const [monthlyBars, setMonthlyBars] = useState<MonthlyBar[]>([]);
  const [pnlData, setPnlData]         = useState<PnLData | null>(null);
  const [pnlLoading, setPnlLoading]   = useState(false);

  /* Entry form state */
  const [form, setForm] = useState({
    type: 'charge' as 'charge' | 'recette',
    date: now.toISOString().slice(0, 10),
    category: CHARGE_CATEGORIES[0].value,
    description: '',
    amount: '',
    payment_method: 'especes',
    reference: '',
    notes: '',
  });
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'pos' | 'invoice' | 'supply'>('all');
  const [salesRows, setSalesRows] = useState<SalesHistoryRow[]>([]);
  const [salesFilter, setSalesFilter] = useState<'all' | 'pos' | 'invoice'>('all');
  const [formSaving, setFormSaving]   = useState(false);
  const [pdfSaving, setPdfSaving]     = useState(false);
  const [typeFilter, setTypeFilter]   = useState<'all' | 'charge' | 'recette'>('all');

  const { start, end } = periodBounds(year, month);
  const periodLabel = `${MONTHS_FR[month - 1]} ${year}`;

  const load = useCallback(async () => {
    setPnlLoading(true);
    setHistoryLoading(true);
    try {
      const [pnl, bars, hist, sales] = await Promise.all([
        computePnL(start, end),
        computeMonthlyTrend(6),
        computeHistory(start, end),
        computeSalesHistory(start, end),
      ]);
      setPnlData(pnl);
      setMonthlyBars(bars);
      setHistoryItems(hist);
      setSalesRows(sales);
    } catch (err) {
      console.error('[accounting] load failed:', err instanceof Error ? err.message : err);
    } finally {
      setPnlLoading(false);
      setHistoryLoading(false);
    }
  }, [start, end, computePnL, computeMonthlyTrend, computeHistory, computeSalesHistory]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { fetchEntries(); }, [fetchEntries]);

  function prevMonth() { if (month === 1) { setYear(y => y - 1); setMonth(12); } else setMonth(m => m - 1); }
  function nextMonth() { if (month === 12) { setYear(y => y + 1); setMonth(1); } else setMonth(m => m + 1); }

  const totalRevenue = pnlData ? pnlData.pos_revenue + pnlData.invoice_revenue + pnlData.manual_revenue : 0;
  const cogs = salesRows.reduce((s, r) => s + r.cost, 0);
  const totalChargesAll = (pnlData?.total_charges ?? 0) + cogs;
  const result       = pnlData ? totalRevenue - totalChargesAll : 0;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.amount || Number(form.amount) <= 0) return;
    setFormSaving(true);
    try {
      await createEntry({
        date: form.date,
        type: form.type,
        category: form.category,
        description: form.description,
        amount: Number(form.amount),
        payment_method: form.payment_method,
        reference: form.reference,
        notes: form.notes,
      });
      setForm(f => ({ ...f, description: '', amount: '', reference: '', notes: '' }));
      load();
    } catch (err) {
      alert(err instanceof Error ? translateError(err.message) : 'Erreur');
    } finally {
      setFormSaving(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Supprimer cette écriture ?')) return;
    await deleteEntry(id);
    load();
  }

  const filteredEntries = entries.filter(e => typeFilter === 'all' || e.type === typeFilter);

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: 'synthese',    label: 'Synthèse',          icon: BarChart3    },
    { id: 'historique',  label: 'Historique',        icon: Receipt      },
    { id: 'saisies',     label: 'Saisies',            icon: BookOpen     },
    { id: 'resultat',    label: 'Compte de résultat', icon: FileBarChart },
  ];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-gray-900">Comptabilité</h1>
          <p className="text-sm text-gray-400">Résultats, charges et suivi financier</p>
        </div>
        {/* Period selector */}
        <div className="flex items-center gap-1 rounded-xl border border-gray-200 bg-white px-2 py-1.5 shadow-sm">
          <button onClick={prevMonth} className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-700 transition">
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="min-w-[130px] text-center text-sm font-semibold text-gray-800">{periodLabel}</span>
          <button onClick={nextMonth} className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-700 transition">
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-0.5 rounded-xl border border-gray-200 bg-gray-100 p-1">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition ${
              tab === t.id ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <t.icon className="h-4 w-4 shrink-0" />
            <span className="hidden sm:inline">{t.label}</span>
          </button>
        ))}
      </div>

      {/* ── Tab: Synthèse ── */}
      {tab === 'synthese' && (
        <div className="space-y-5">
          {pnlLoading ? (
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4 animate-pulse">
              {[...Array(4)].map((_, i) => <div key={i} className="h-28 rounded-xl bg-gray-100" />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              <KpiCard label="Chiffre d'affaires"  value={fmt(totalRevenue, currency)}            color="blue"    icon={TrendingUp}   sub={`Total des ventes`} />
              <KpiCard label="Charges + Coût produits" value={fmt(totalChargesAll, currency)} color="red"  icon={TrendingDown} sub={`Dont coût produits ${fmt(cogs, currency)}`} />
              <KpiCard label="Résultat net"         value={fmt(result, currency)}                  color={result >= 0 ? 'emerald' : 'red'} icon={result >= 0 ? TrendingUp : TrendingDown} sub={result >= 0 ? 'Bénéfice' : 'Déficit'} />
              <KpiCard label="Créances clients"     value={fmt(pnlData?.total_creances ?? 0, currency)} color="amber"         icon={Minus}    sub={`${pnlData?.creances_count ?? 0} facture(s) impayée(s)`} />
            </div>
          )}

          {/* Monthly bar chart */}
          <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-gray-700">Évolution — 6 derniers mois</h2>
              <div className="flex items-center gap-3 text-xs text-gray-400">
                <span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-sm bg-blue-500/80 inline-block" /> Recettes</span>
                <span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-sm bg-red-400/70 inline-block" /> Charges</span>
              </div>
            </div>
            {monthlyBars.length > 0 ? (
              <BarChart data={monthlyBars} currency={currency} />
            ) : (
              <div className="h-48 flex items-center justify-center text-sm text-gray-400">Aucune donnée</div>
            )}
          </div>

          {/* Quick breakdown */}
          {pnlData && (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-gray-400">Recettes par mode</h3>
                <div className="space-y-1.5 text-sm">
                  {pnlData.pos_revenue > 0 && (
                    <div className="flex justify-between text-gray-700">
                      <span className="text-gray-500">POS (caisse)</span>
                      <span className="tabular-nums font-semibold text-emerald-600">{fmt(pnlData.pos_revenue, currency)}</span>
                    </div>
                  )}
                  {pnlData.invoice_revenue > 0 && (
                    <div className="flex justify-between text-gray-700">
                      <span className="text-gray-500">Factures émises</span>
                      <span className="tabular-nums font-semibold text-emerald-600">{fmt(pnlData.invoice_revenue, currency)}</span>
                    </div>
                  )}
                  {pnlData.manual_revenue > 0 && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Autres recettes</span>
                      <span className="tabular-nums font-semibold text-emerald-600">{fmt(pnlData.manual_revenue, currency)}</span>
                    </div>
                  )}
                  {totalRevenue === 0 && <p className="text-gray-400 text-xs">Aucune recette ce mois</p>}
                </div>
              </div>
              <div className="rounded-xl border border-amber-200 bg-amber-50/50 p-4 shadow-sm">
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-amber-600">Créances clients en cours</h3>
                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Factures impayées</span>
                    <span className="tabular-nums font-semibold text-amber-600">{fmt(pnlData?.total_creances ?? 0, currency)}</span>
                  </div>
                  <p className="text-xs text-gray-400">{pnlData?.creances_count ?? 0} facture(s) en attente de règlement (envoyées ou partielles)</p>
                </div>
              </div>
              <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-gray-400">Charges par catégorie</h3>
                <div className="space-y-1.5 text-sm">
                  {pnlData.charges_by_category.slice(0, 5).map(c => (
                    <div key={c.category} className="flex justify-between">
                      <span className="text-gray-500 truncate pr-2">{categoryLabel(c.category, 'charge')}</span>
                      <span className="tabular-nums font-semibold text-red-600 shrink-0">{fmt(c.amount, currency)}</span>
                    </div>
                  ))}
                  {pnlData.charges_by_category.length === 0 && <p className="text-gray-400 text-xs">Aucune charge ce mois</p>}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Tab: Historique ── */}
      {tab === 'historique' && (
        <div className="space-y-4">
          {/* Detailed sales history */}
          <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 bg-gray-50 px-5 py-3">
              <h2 className="text-sm font-semibold text-gray-700">
                Ventes détaillées — {periodLabel}
                <span className="ml-2 text-xs font-normal text-gray-400">({salesRows.length} lignes)</span>
              </h2>
              <div className="flex flex-wrap gap-1 rounded-lg border border-gray-200 bg-white p-0.5 text-xs">
                {(['all', 'pos', 'invoice'] as const).map(t => (
                  <button key={t} onClick={() => setSalesFilter(t)}
                    className={`rounded px-2.5 py-1 font-medium transition ${salesFilter === t ? 'bg-gray-100 text-gray-800' : 'text-gray-400 hover:text-gray-700'}`}>
                    {t === 'all' ? 'Tout' : t === 'pos' ? 'POS' : 'Factures'}
                  </button>
                ))}
              </div>
            </div>
            {historyLoading ? (
              <div className="space-y-1 p-4 animate-pulse">{[...Array(6)].map((_, i) => <div key={i} className="h-10 rounded-lg bg-gray-100" />)}</div>
            ) : salesRows.length === 0 ? (
              <div className="py-12 text-center text-sm text-gray-400">Aucune vente pour cette période.</div>
            ) : (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[860px]">
                    <thead>
                      <tr className="border-b border-gray-100">
                        <th className="px-3 py-2.5 pl-5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Date</th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Réf.</th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Désignation</th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Client</th>
                        <th className="px-3 py-2.5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Qté</th>
                        <th className="px-3 py-2.5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Montant</th>
                        <th className="px-3 py-2.5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Coût</th>
                        <th className="px-3 py-2.5 pr-5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Marge</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {salesRows.filter(r => salesFilter === 'all' || r.saleType === salesFilter).map((r, idx) => (
                        <tr key={r.saleId + '-' + idx} className="group hover:bg-gray-50">
                          <td className="px-3 py-2.5 pl-5 text-sm tabular-nums text-gray-500 whitespace-nowrap">
                            {new Date(r.date).toLocaleDateString('fr-FR')}
                          </td>
                          <td className="px-3 py-2.5">
                            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
                              r.saleType === 'pos' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-700'
                            }`}>
                              {r.saleType === 'pos' ? <ShoppingCart className="h-3 w-3" /> : <FileText className="h-3 w-3" />}
                              {r.ref}
                            </span>
                          </td>
                          <td className="px-3 py-2.5 text-sm font-medium text-gray-800 max-w-[220px] truncate" title={r.designation}>
                            {r.designation}
                          </td>
                          <td className="px-3 py-2.5 text-sm text-gray-500 max-w-[140px] truncate" title={r.customer}>
                            {r.customer}
                          </td>
                          <td className="px-3 py-2.5 text-right text-sm tabular-nums text-gray-600">{r.quantity}</td>
                          <td className="px-3 py-2.5 text-right text-sm tabular-nums font-semibold text-gray-900">{fmt(r.amount, currency)}</td>
                          <td className="px-3 py-2.5 text-right text-sm tabular-nums text-red-500">{fmt(r.cost, currency)}</td>
                          <td className={`px-3 py-2.5 pr-5 text-right text-sm tabular-nums font-semibold ${r.margin >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                            {r.margin >= 0 ? '+' : '−'}{fmt(Math.abs(r.margin), currency)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="border-t-2 border-gray-200 bg-gray-50">
                        <td colSpan={5} className="px-3 py-3 pl-5 text-xs font-bold uppercase tracking-wider text-gray-500">Totaux</td>
                        <td className="px-3 py-3 text-right tabular-nums text-sm font-bold text-gray-900">
                          {fmt(salesRows.filter(r => salesFilter === 'all' || r.saleType === salesFilter).reduce((s, r) => s + r.amount, 0), currency)}
                        </td>
                        <td className="px-3 py-3 text-right tabular-nums text-sm font-bold text-red-500">
                          {fmt(salesRows.filter(r => salesFilter === 'all' || r.saleType === salesFilter).reduce((s, r) => s + r.cost, 0), currency)}
                        </td>
                        <td className={`px-3 py-3 pr-5 text-right tabular-nums text-sm font-bold ${
                          salesRows.filter(r => salesFilter === 'all' || r.saleType === salesFilter).reduce((s, r) => s + r.margin, 0) >= 0 ? 'text-emerald-600' : 'text-red-600'
                        }`}>
                          {(() => { const m = salesRows.filter(r => salesFilter === 'all' || r.saleType === salesFilter).reduce((s, r) => s + r.margin, 0); return (m >= 0 ? '+' : '−') + fmt(Math.abs(m), currency); })()}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ── Tab: Saisies ── */}
      {tab === 'saisies' && (
        <div className="space-y-4">
          {/* Entry form */}
          <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
            <div className="border-b border-gray-100 bg-gray-50 px-5 py-3">
              <h2 className="text-sm font-semibold text-gray-700">Nouvelle écriture</h2>
            </div>
            <form onSubmit={handleSubmit} className="p-5">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {/* Type */}
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Type</label>
                  <div className="flex rounded-lg border border-gray-200 overflow-hidden">
                    {(['charge', 'recette'] as const).map(t => (
                      <button
                        key={t} type="button"
                        onClick={() => setForm(f => ({ ...f, type: t, category: t === 'charge' ? CHARGE_CATEGORIES[0].value : RECETTE_CATEGORIES[0].value }))}
                        className={`flex-1 py-2 text-sm font-semibold transition ${
                          form.type === t
                            ? t === 'charge' ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-700'
                            : 'bg-white text-gray-400 hover:bg-gray-50'
                        }`}
                      >
                        {t === 'charge' ? '− Charge' : '+ Recette'}
                      </button>
                    ))}
                  </div>
                </div>
                {/* Date */}
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Date</label>
                  <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
                </div>
                {/* Category */}
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Catégorie</label>
                  <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500">
                    {(form.type === 'charge' ? CHARGE_CATEGORIES : RECETTE_CATEGORIES).map(c => (
                      <option key={c.value} value={c.value}>{c.label}</option>
                    ))}
                  </select>
                </div>
                {/* Description */}
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Description</label>
                  <input type="text" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                    placeholder="Libellé de l'opération…"
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
                </div>
                {/* Amount */}
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Montant *</label>
                  <input type="number" step="any" min="1" required value={form.amount}
                    onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
                    placeholder="0"
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white tabular-nums" />
                </div>
                {/* Payment method */}
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Mode</label>
                  <select value={form.payment_method} onChange={e => setForm(f => ({ ...f, payment_method: e.target.value }))}
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500">
                    {ALL_PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                  </select>
                </div>
                {/* Reference */}
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Référence</label>
                  <input type="text" value={form.reference} onChange={e => setForm(f => ({ ...f, reference: e.target.value }))}
                    placeholder="N° reçu, facture…"
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
                </div>
              </div>
              <div className="mt-4 flex justify-end">
                <button type="submit" disabled={formSaving || !form.amount}
                  className={`flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold text-white transition shadow-sm disabled:opacity-50 ${
                    form.type === 'charge' ? 'bg-red-500 hover:bg-red-400' : 'bg-emerald-600 hover:bg-emerald-500'
                  }`}>
                  <Plus className="h-4 w-4" />
                  {formSaving ? 'Enregistrement…' : 'Enregistrer'}
                </button>
              </div>
            </form>
          </div>

          {/* Entries list */}
          <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
            <div className="flex items-center justify-between border-b border-gray-100 bg-gray-50 px-5 py-3">
              <h2 className="text-sm font-semibold text-gray-700">
                Opérations — {periodLabel}
                <span className="ml-2 text-xs font-normal text-gray-400">({filteredEntries.length})</span>
              </h2>
              <div className="flex gap-1 rounded-lg border border-gray-200 bg-white p-0.5 text-xs">
                {(['all', 'recette', 'charge'] as const).map(t => (
                  <button key={t} onClick={() => setTypeFilter(t)}
                    className={`rounded px-2.5 py-1 font-medium transition ${typeFilter === t ? 'bg-gray-100 text-gray-800' : 'text-gray-400 hover:text-gray-700'}`}>
                    {t === 'all' ? 'Toutes' : t === 'recette' ? 'Recettes' : 'Charges'}
                  </button>
                ))}
              </div>
            </div>
            {loading ? (
              <div className="space-y-1 p-4 animate-pulse">{[...Array(4)].map((_, i) => <div key={i} className="h-10 rounded-lg bg-gray-100" />)}</div>
            ) : filteredEntries.length === 0 ? (
              <div className="py-12 text-center text-sm text-gray-400">Aucune écriture pour cette période.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[580px]">
                  <thead>
                    <tr className="border-b border-gray-100">
                      <th className="px-4 py-2.5 pl-5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Date</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Type</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Catégorie</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Libellé</th>
                      <th className="px-4 py-2.5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Montant</th>
                      <th className="px-4 py-2.5 pr-5" />
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredEntries.map(e => (
                      <EntryRow key={e.id} entry={e} onDelete={handleDelete} currency={currency} />
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-gray-200 bg-gray-50">
                      <td colSpan={4} className="px-4 py-3 pl-5 text-xs font-bold uppercase tracking-wider text-gray-500">Résultat période</td>
                      <td className={`px-4 py-3 text-right tabular-nums text-sm font-bold ${result >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                        {result >= 0 ? '+' : ''}{fmt(result, currency)}
                      </td>
                      <td className="pr-5" />
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Tab: Résultat ── */}
      {tab === 'resultat' && (
        <div className="space-y-4">
          <div className="flex justify-end gap-2">
            <button
              onClick={() => pnlData && printPnL(pnlData, cogs, periodLabel, settings?.name ?? 'Mon Entreprise', currency)}
              disabled={!pnlData}
              className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 transition shadow-sm disabled:opacity-40"
            >
              <Printer className="h-4 w-4" /> Imprimer
            </button>
            <button
              onClick={async () => {
                if (!pnlData) return;
                setPdfSaving(true);
                try { await exportPnLPdf(pnlData, cogs, periodLabel, settings?.name ?? 'Mon Entreprise', currency); }
                finally { setPdfSaving(false); }
              }}
              disabled={!pnlData || pdfSaving}
              className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 transition shadow-sm disabled:opacity-40"
            >
              <FileDown className="h-4 w-4" /> {pdfSaving ? 'PDF…' : 'PDF'}
            </button>
          </div>

          {pnlLoading ? (
            <div className="space-y-2 animate-pulse">{[...Array(4)].map((_, i) => <div key={i} className="h-12 rounded-xl bg-gray-100" />)}</div>
          ) : pnlData ? (
            <div className="rounded-xl border border-gray-200 bg-white overflow-hidden shadow-sm">
              {/* Produits */}
              <div className="bg-blue-600 px-6 py-3">
                <h3 className="text-xs font-bold uppercase tracking-widest text-blue-100">Produits d'exploitation</h3>
              </div>
              <div className="divide-y divide-gray-100">
                <div className="flex items-center justify-between px-6 py-3.5">
                  <span className="text-sm text-gray-600">Ventes POS (caisse)</span>
                  <span className="tabular-nums font-semibold text-gray-900">{fmt(pnlData.pos_revenue, currency)}</span>
                </div>
                <div className="flex items-center justify-between px-6 py-3.5">
                  <span className="text-sm text-gray-600">Factures émises</span>
                  <span className="tabular-nums font-semibold text-gray-900">{fmt(pnlData.invoice_revenue, currency)}</span>
                </div>
                {pnlData.manual_revenue > 0 && (
                  <div className="flex items-center justify-between px-6 py-3.5">
                    <span className="text-sm text-gray-600">Autres produits</span>
                    <span className="tabular-nums font-semibold text-gray-900">{fmt(pnlData.manual_revenue, currency)}</span>
                  </div>
                )}
                <div className="flex items-center justify-between bg-blue-50 px-6 py-3.5">
                  <span className="text-sm font-bold text-blue-800">TOTAL PRODUITS</span>
                  <span className="tabular-nums text-lg font-bold text-blue-700">{fmt(totalRevenue, currency)}</span>
                </div>
              </div>

              {/* Charges */}
              <div className="bg-red-500 px-6 py-3 mt-4">
                <h3 className="text-xs font-bold uppercase tracking-widest text-red-100">Charges d'exploitation</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {pnlData.charges_by_category.length === 0 && cogs === 0 ? (
                  <div className="px-6 py-4 text-sm text-gray-400 italic">Aucune charge pour cette période.</div>
                ) : (
                  <>
                    {pnlData.charges_by_category.map(c => (
                      <div key={c.category} className="flex items-center justify-between px-6 py-3.5">
                        <span className="text-sm text-gray-600">{categoryLabel(c.category, 'charge')}</span>
                        <span className="tabular-nums font-semibold text-gray-900">{fmt(c.amount, currency)}</span>
                      </div>
                    ))}
                    {cogs > 0 && (
                      <div className="flex items-center justify-between px-6 py-3.5">
                        <span className="text-sm text-gray-600">Coût d'achat des produits vendus</span>
                        <span className="tabular-nums font-semibold text-gray-900">{fmt(cogs, currency)}</span>
                      </div>
                    )}
                  </>
                )}
                <div className="flex items-center justify-between bg-red-50 px-6 py-3.5">
                  <span className="text-sm font-bold text-red-800">TOTAL CHARGES</span>
                  <span className="tabular-nums text-lg font-bold text-red-600">{fmt(totalChargesAll, currency)}</span>
                </div>
              </div>

              {/* Net result */}
              <div className={`flex items-center justify-between px-6 py-5 ${result >= 0 ? 'bg-emerald-600' : 'bg-red-600'}`}>
                <div>
                  <p className={`text-sm font-bold uppercase tracking-widest ${result >= 0 ? 'text-emerald-100' : 'text-red-100'}`}>
                    Résultat net — {periodLabel}
                  </p>
                  <p className={`text-xs mt-0.5 ${result >= 0 ? 'text-emerald-200' : 'text-red-200'}`}>
                    {result >= 0 ? 'Bénéfice' : 'Déficit'}
                  </p>
                </div>
                <span className="text-2xl font-black tabular-nums text-white">
                  {result >= 0 ? '+' : ''}{fmt(result, currency)}
                </span>
              </div>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}
