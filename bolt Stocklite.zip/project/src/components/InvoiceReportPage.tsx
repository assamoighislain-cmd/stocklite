import React, { useState, useMemo } from 'react';
import {
  Calendar, Search, TrendingUp, Package, FileText, User,
} from 'lucide-react';
import type { Invoice } from '../types';
import { StatusBadge } from './StatusBadge';

interface InvoiceReportPageProps {
  invoices: Invoice[];
  currency?: string;
}

type PeriodPreset = 'all' | 'today' | 'week' | 'month' | 'year' | 'custom';

function fmt(n: number, currency = 'FCFA') {
  try {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);
  } catch {
    return `${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n)} ${currency}`;
  }
}

function presetRange(preset: PeriodPreset): { from: string; to: string } {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const fmtDate = (d: Date) => d.toISOString().slice(0, 10);
  if (preset === 'today') return { from: fmtDate(today), to: fmtDate(today) };
  if (preset === 'week') {
    const from = new Date(today);
    from.setDate(today.getDate() - today.getDay() + 1);
    return { from: fmtDate(from), to: fmtDate(today) };
  }
  if (preset === 'month') return { from: fmtDate(new Date(now.getFullYear(), now.getMonth(), 1)), to: fmtDate(today) };
  if (preset === 'year') return { from: fmtDate(new Date(now.getFullYear(), 0, 1)), to: fmtDate(today) };
  return { from: '', to: '' };
}

interface LineRow {
  invoiceId: string;
  invoiceNumber: string;
  date: string;
  customerName: string;
  creatorName: string;
  status: Invoice['status'];
  description: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  total: number;
  productName: string | null;
}

export function InvoiceReportPage({ invoices, currency = 'FCFA' }: InvoiceReportPageProps) {
  const [periodPreset, setPeriodPreset] = useState<PeriodPreset>('month');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [query, setQuery] = useState('');
  const [groupByProduct, setGroupByProduct] = useState(false);

  const activeRange = periodPreset === 'custom' ? { from: dateFrom, to: dateTo } : presetRange(periodPreset);

  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      const invDate = inv.date.slice(0, 10);
      const matchFrom = !activeRange.from || invDate >= activeRange.from;
      const matchTo = !activeRange.to || invDate <= activeRange.to;
      const matchQuery =
        !query ||
        inv.invoice_number.toLowerCase().includes(query.toLowerCase()) ||
        (inv.customer?.name ?? '').toLowerCase().includes(query.toLowerCase());
      return matchFrom && matchTo && matchQuery;
    });
  }, [invoices, activeRange, query]);

  const lineRows: LineRow[] = useMemo(() => {
    const rows: LineRow[] = [];
    for (const inv of filteredInvoices) {
      for (const item of inv.items ?? []) {
        rows.push({
          invoiceId: inv.id,
          invoiceNumber: inv.invoice_number,
          date: inv.date,
          customerName: inv.customer?.name ?? '—',
          creatorName: inv.creator?.full_name ?? '—',
          status: inv.status,
          description: item.description,
          quantity: item.quantity,
          unitPrice: item.unit_price,
          discount: item.discount,
          total: item.total,
          productName: item.description,
        });
      }
    }
    return rows;
  }, [filteredInvoices]);

  const productSummary = useMemo(() => {
    const map = new Map<string, { name: string; qty: number; total: number; count: number }>();
    for (const row of lineRows) {
      const key = row.description;
      const existing = map.get(key) ?? { name: row.description, qty: 0, total: 0, count: 0 };
      existing.qty += row.quantity;
      existing.total += row.total;
      existing.count += 1;
      map.set(key, existing);
    }
    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [lineRows]);

  const summary = useMemo(() => {
    const total = filteredInvoices.reduce((s, i) => s + i.total, 0);
    const paid = filteredInvoices.reduce((s, i) => s + i.amount_paid, 0);
    const taxAmount = filteredInvoices.reduce((s, i) => s + i.tax_amount, 0);
    const subtotal = filteredInvoices.reduce((s, i) => s + i.subtotal, 0);
    const balance = filteredInvoices.reduce((s, i) => s + i.balance_due, 0);
    return { total, paid, taxAmount, subtotal, balance, count: filteredInvoices.length };
  }, [filteredInvoices]);

  const creatorStats = useMemo(() => {
    const map = new Map<string, { name: string; count: number; total: number }>();
    for (const inv of filteredInvoices) {
      const name = inv.creator?.full_name ?? 'Inconnu';
      const existing = map.get(name) ?? { name, count: 0, total: 0 };
      existing.count += 1;
      existing.total += inv.total;
      map.set(name, existing);
    }
    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [filteredInvoices]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h1 className="text-lg font-bold text-gray-900">Détail des facturations</h1>
        <p className="text-sm text-gray-400">
          {summary.count} facture{summary.count > 1 ? 's' : ''} · {lineRows.length} ligne{lineRows.length > 1 ? 's' : ''}
        </p>
      </div>

      {/* Period filter */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-gray-500">
          <Calendar className="h-4 w-4" /> Période :
        </div>
        <div className="flex gap-1 rounded-lg border border-gray-300 bg-gray-100 p-1">
          {([['all','Toute'],['today','Aujourd\'hui'],['week','Semaine'],['month','Mois'],['year','Année'],['custom','Perso.']] as const).map(([val, label]) => (
            <button
              key={val}
              onClick={() => {
                setPeriodPreset(val);
                if (val !== 'custom') { setDateFrom(''); setDateTo(''); }
              }}
              className={`rounded-md px-3 py-1 text-xs font-medium transition ${periodPreset === val ? 'bg-blue-600 text-white' : 'text-gray-500 hover:text-gray-800'}`}
            >
              {label}
            </button>
          ))}
        </div>
        {periodPreset === 'custom' && (
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={dateFrom}
              onChange={e => setDateFrom(e.target.value)}
              className="rounded-lg border border-gray-300 bg-gray-100 px-3 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-500"
            />
            <span className="text-gray-400 text-xs">→</span>
            <input
              type="date"
              value={dateTo}
              onChange={e => setDateTo(e.target.value)}
              className="rounded-lg border border-gray-300 bg-gray-100 px-3 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-500"
            />
          </div>
        )}
        {periodPreset !== 'all' && (
          <span className="text-xs text-gray-400">
            {activeRange.from && `Du ${new Date(activeRange.from).toLocaleDateString('fr-FR')}`}
            {activeRange.from && activeRange.to && ' au '}
            {activeRange.to && new Date(activeRange.to).toLocaleDateString('fr-FR')}
          </span>
        )}
      </div>

      {/* Search + toggle */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Numéro facture, client…"
            className="w-full rounded-lg border border-gray-300 bg-gray-100 py-2 pl-9 pr-4 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500"
          />
        </div>
        <button
          onClick={() => setGroupByProduct(g => !g)}
          className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium transition ${
            groupByProduct
              ? 'border-blue-500 bg-blue-50 text-blue-700'
              : 'border-gray-300 bg-gray-100 text-gray-500 hover:text-gray-800'
          }`}
        >
          <Package className="h-4 w-4" />
          Par article
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-gray-400 mb-1">
            <FileText className="h-3.5 w-3.5" /> Factures
          </div>
          <p className="text-xl font-bold text-gray-900">{summary.count}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold text-gray-400 mb-1">Sous-total HT</p>
          <p className="text-xl font-bold text-gray-900">{fmt(summary.subtotal, currency)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold text-gray-400 mb-1">TVA</p>
          <p className="text-xl font-bold text-gray-900">{fmt(summary.taxAmount, currency)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-gray-400 mb-1">
            <TrendingUp className="h-3.5 w-3.5" /> Total TTC
          </div>
          <p className="text-xl font-bold text-blue-600">{fmt(summary.total, currency)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold text-gray-400 mb-1">Solde dû</p>
          <p className="text-xl font-bold text-amber-500">{fmt(summary.balance, currency)}</p>
        </div>
      </div>

      {/* Creator stats */}
      {creatorStats.length > 0 && (
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="flex items-center gap-2 mb-3">
            <User className="h-4 w-4 text-gray-400" />
            <h3 className="text-sm font-bold text-gray-700">Répartition par créateur</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {creatorStats.map(c => (
              <div key={c.name} className="flex items-center gap-2 rounded-lg bg-gray-50 px-3 py-2">
                <span className="text-sm font-medium text-gray-700">{c.name}</span>
                <span className="text-xs text-gray-400">{c.count} fact.</span>
                <span className="text-sm font-bold text-blue-600">{fmt(c.total, currency)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Detail table */}
      {groupByProduct ? (
        <div className="overflow-hidden rounded-xl border border-gray-200">
          {productSummary.length === 0 ? (
            <div className="py-14 text-center text-sm text-gray-400">Aucune donnée pour cette période.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px] text-sm">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    {['Article', 'Occurrences', 'Quantité', 'CA total'].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 first:pl-5">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {productSummary.map(p => (
                    <tr key={p.name} className="bg-white hover:bg-gray-50">
                      <td className="px-4 py-3 pl-5 font-medium text-gray-800">{p.name}</td>
                      <td className="px-4 py-3 text-gray-500">{p.count}</td>
                      <td className="px-4 py-3 tabular-nums text-gray-700">
                        {new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(p.qty)}
                      </td>
                      <td className="px-4 py-3 tabular-nums font-semibold text-gray-900">{fmt(p.total, currency)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-gray-200 bg-gray-50">
                    <td className="px-4 py-3 pl-5 font-bold text-gray-700">Total</td>
                    <td className="px-4 py-3 font-semibold text-gray-600">{productSummary.reduce((s, p) => s + p.count, 0)}</td>
                    <td className="px-4 py-3 tabular-nums font-semibold text-gray-600">
                      {new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(productSummary.reduce((s, p) => s + p.qty, 0))}
                    </td>
                    <td className="px-4 py-3 tabular-nums font-bold text-blue-600">{fmt(productSummary.reduce((s, p) => s + p.total, 0), currency)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-gray-200">
          {filteredInvoices.length === 0 ? (
            <div className="py-14 text-center text-sm text-gray-400">
              {query || periodPreset !== 'all' ? 'Aucune facture pour cette période.' : 'Aucune facture.'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] text-sm">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">N° Facture</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Client</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Créé par</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Date</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Statut</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Désignation</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Qté</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Prix unit.</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Remise</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Total ligne</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredInvoices.map(inv => {
                    const items = (inv.items ?? []).slice().sort((a, b) => a.sort_order - b.sort_order);
                    return (
                      <React.Fragment key={inv.id}>
                        {items.length === 0 ? (
                          <tr className="bg-white hover:bg-gray-50">
                            <td className="px-4 py-3 pl-5 font-mono text-xs font-semibold text-blue-500">{inv.invoice_number}</td>
                            <td className="px-4 py-3 font-medium text-gray-800">{inv.customer?.name ?? '—'}</td>
                            <td className="px-4 py-3 text-sm text-gray-600">{inv.creator?.full_name ?? '—'}</td>
                            <td className="px-4 py-3 tabular-nums text-gray-500">{new Date(inv.date).toLocaleDateString('fr-FR')}</td>
                            <td className="px-4 py-3"><StatusBadge status={inv.status} /></td>
                            <td className="px-4 py-3 text-gray-400 italic" colSpan={4}>Aucune ligne</td>
                            <td className="px-4 py-3 text-right tabular-nums font-semibold text-gray-900">{fmt(inv.total, currency)}</td>
                          </tr>
                        ) : (
                          items.map((item, i) => (
                            <tr key={item.id} className={`bg-white hover:bg-gray-50 ${i > 0 ? 'border-l-2 border-l-blue-100' : ''}`}>
                              {i === 0 ? (
                                <>
                                  <td className="px-4 py-2.5 pl-5 font-mono text-xs font-semibold text-blue-500">{inv.invoice_number}</td>
                                  <td className="px-4 py-2.5 font-medium text-gray-800">{inv.customer?.name ?? '—'}</td>
                                  <td className="px-4 py-2.5 text-sm text-gray-600">{inv.creator?.full_name ?? '—'}</td>
                                  <td className="px-4 py-2.5 tabular-nums text-gray-500">{new Date(inv.date).toLocaleDateString('fr-FR')}</td>
                                  <td className="px-4 py-2.5"><StatusBadge status={inv.status} /></td>
                                </>
                              ) : (
                                <>
                                  <td className="px-4 py-2 pl-5" />
                                  <td className="px-4 py-2" />
                                  <td className="px-4 py-2" />
                                  <td className="px-4 py-2" />
                                  <td className="px-4 py-2" />
                                </>
                              )}
                              <td className="px-4 py-2.5 text-sm text-gray-700">{item.description}</td>
                              <td className="px-4 py-2.5 text-right tabular-nums text-gray-600">
                                {new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(item.quantity)}
                              </td>
                              <td className="px-4 py-2.5 text-right tabular-nums text-gray-600">{fmt(item.unit_price, currency)}</td>
                              <td className="px-4 py-2.5 text-right tabular-nums text-red-500">
                                {item.discount > 0 ? `−${fmt(item.discount, currency)}` : '—'}
                              </td>
                              <td className="px-4 py-2.5 text-right tabular-nums font-semibold text-gray-800">{fmt(item.total, currency)}</td>
                            </tr>
                          ))
                        )}
                        {/* Invoice totals row */}
                        <tr className="bg-gray-50/80 border-t border-gray-200">
                          <td className="px-4 py-2.5" colSpan={5}>
                            <span className="text-xs text-gray-400">
                              {items.length} ligne{items.length > 1 ? 's' : ''}
                              {inv.tax_rate > 0 && ` · HT ${fmt(inv.subtotal, currency)} · TVA ${inv.tax_rate}%`}
                              {(inv.remise ?? 0) > 0 && ` · Remise ${fmt(inv.remise, currency)}`}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 text-right font-bold text-gray-700" colSpan={4}>Total TTC</td>
                          <td className="px-4 py-2.5 text-right tabular-nums font-bold text-blue-600">{fmt(inv.total, currency)}</td>
                        </tr>
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
