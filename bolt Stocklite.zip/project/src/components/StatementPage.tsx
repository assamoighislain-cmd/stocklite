import { useState, useMemo, useEffect, useCallback } from 'react';
import { Search, FileText, ArrowLeft, Printer, Download, Calendar, FileDown } from 'lucide-react';
import type { Customer, Supplier, Invoice, Payment, DeliveryNote, SupplierPayment } from '../types';
import { StatusBadge } from './StatusBadge';
import type { Route } from '../App';
import { exportElementToPdf } from '../lib/pdf';

type Mode = 'client' | 'supplier';

interface Props {
  mode: Mode;
  customers: Customer[];
  suppliers: Supplier[];
  deliveryNotes: DeliveryNote[];
  onNavigate: (r: Route) => void;
  fetchInvoices: (customerId: string) => Promise<Invoice[]>;
  fetchPayments: (customerId: string) => Promise<Payment[]>;
  fetchSupplierPayments?: (supplierId: string) => Promise<SupplierPayment[]>;
  currency: string;
}

interface StmtRow {
  date: string;
  label: string;
  ref: string;
  debit: number;
  credit: number;
  balance: number;
  status?: string;
  invoiceId?: string;
}

function fmt(n: number, currency: string) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}
function fmtDate(d: string | null | undefined) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function StatementPage({
  mode, customers, suppliers, deliveryNotes, onNavigate, fetchInvoices, fetchPayments, fetchSupplierPayments, currency,
}: Props) {
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [supplierPayments, setSupplierPayments] = useState<SupplierPayment[]>([]);
  const [notes, setNotes] = useState<DeliveryNote[]>([]);
  const [loading, setLoading] = useState(false);

  // Period filter
  const todayStr = new Date().toISOString().slice(0, 10);
  const firstOfMonth = new Date();
  firstOfMonth.setDate(1);
  const firstStr = firstOfMonth.toISOString().slice(0, 10);
  const [startDate, setStartDate] = useState(firstStr);
  const [endDate, setEndDate] = useState(todayStr);

  const parties = useMemo(() => {
    const list = mode === 'client' ? customers : suppliers;
    if (!query) return list;
    const q = query.toLowerCase();
    return list.filter(p => (p.name ?? '').toLowerCase().includes(q));
  }, [mode, customers, suppliers, query]);

  const selectedParty = useMemo(() => {
    if (!selectedId) return null;
    return mode === 'client'
      ? customers.find(c => c.id === selectedId) ?? null
      : suppliers.find(s => s.id === selectedId) ?? null;
  }, [selectedId, mode, customers, suppliers]);

  const loadDetails = useCallback(async () => {
    if (!selectedId) return;
    setLoading(true);
    try {
      if (mode === 'client') {
        const [invs, pays] = await Promise.all([
          fetchInvoices(selectedId),
          fetchPayments(selectedId),
        ]);
        setInvoices(invs);
        setPayments(pays);
        setNotes([]);
        setSupplierPayments([]);
      } else {
        const supNotes = deliveryNotes.filter(n => n.supplier_id === selectedId);
        setNotes(supNotes);
        setInvoices([]);
        setPayments([]);
        if (fetchSupplierPayments) {
          const supPays = await fetchSupplierPayments(selectedId);
          setSupplierPayments(supPays);
        } else {
          setSupplierPayments([]);
        }
      }
    } catch { /* ignore */ }
    setLoading(false);
  }, [selectedId, mode, fetchInvoices, fetchPayments, fetchSupplierPayments, deliveryNotes]);

  useEffect(() => { loadDetails(); }, [loadDetails]);

  // Build ALL chronological rows (no period filter yet, needed for report balance)
  const allRows: StmtRow[] = useMemo(() => {
    if (!selectedId) return [];
    const out: StmtRow[] = [];

    if (mode === 'client') {
      for (const inv of invoices) {
        out.push({
          date: inv.date,
          label: 'Facture',
          ref: inv.invoice_number,
          debit: inv.total,
          credit: 0,
          balance: 0,
          status: inv.status,
          invoiceId: inv.id,
        });
      }
      for (const p of payments) {
        out.push({
          date: p.payment_date,
          label: 'Paiement',
          ref: p.invoice?.invoice_number ?? '—',
          debit: 0,
          credit: p.amount,
          balance: 0,
        });
      }
    } else {
      for (const n of notes) {
        out.push({
          date: n.note_date,
          label: 'Bon de livraison',
          ref: n.note_number,
          debit: n.total_amount,
          credit: 0,
          balance: 0,
          status: n.status,
        });
      }
      for (const sp of supplierPayments) {
        out.push({
          date: sp.payment_date,
          label: 'Règlement',
          ref: sp.delivery_note?.note_number ?? '—',
          debit: 0,
          credit: sp.amount,
          balance: 0,
        });
      }
    }

    out.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let running = 0;
    for (const r of out) {
      running += r.debit - r.credit;
      r.balance = running;
    }
    return out;
  }, [selectedId, mode, invoices, payments, notes, supplierPayments]);

  // Report balance = cumulative balance BEFORE the start date
  const reportBalance = useMemo(() => {
    const before = allRows.filter(r => r.date < startDate);
    if (before.length === 0) return 0;
    return before[before.length - 1].balance;
  }, [allRows, startDate]);

  // Period-filtered rows
  const rows = useMemo(() => {
    const filtered = allRows.filter(r => r.date >= startDate && r.date <= endDate);
    // Recalculate running balance starting from report
    let running = reportBalance;
    return filtered.map(r => {
      running += r.debit - r.credit;
      return { ...r, balance: running };
    });
  }, [allRows, startDate, endDate, reportBalance]);

  const totalDebit = rows.reduce((s, r) => s + r.debit, 0);
  const totalCredit = rows.reduce((s, r) => s + r.credit, 0);
  const solde = reportBalance + totalDebit - totalCredit;

  function handlePrint() {
    window.print();
  }

  const [pdfSaving, setPdfSaving] = useState(false);
  async function handleExportPdf() {
    const el = document.getElementById('statement-print');
    if (!el || !selectedParty) return;
    setPdfSaving(true);
    try {
      await exportElementToPdf(el, `releve_${mode}_${selectedParty.name}.pdf`, 'a4');
    } finally { setPdfSaving(false); }
  }

  function handleExportCsv() {
    const header = ['Date', 'Libellé', 'Référence', 'Débit', 'Crédit', 'Solde'];
    const reportLine = [fmtDate(startDate), 'Report antérieur', '—', reportBalance > 0 ? reportBalance : 0, reportBalance < 0 ? -reportBalance : 0, reportBalance].join(';');
    const lines = rows.map(r => [
      fmtDate(r.date), r.label, r.ref, r.debit, r.credit, r.balance,
    ].join(';'));
    const csv = [header.join(';'), reportLine, ...lines].join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `releve_${mode}_${selectedParty?.name ?? 'compte'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const title = mode === 'client' ? 'Relevé client' : 'Relevé fournisseur';
  const partyLabel = mode === 'client' ? 'Client' : 'Fournisseur';

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center gap-4 no-print">
        <button
          onClick={() => onNavigate({ page: 'dashboard' })}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Retour
        </button>
        <h1 className="text-lg font-bold text-gray-900">{title}</h1>
      </div>

      <div className="flex gap-4">
        {/* Party list */}
        <aside className="w-64 shrink-0 space-y-3 no-print">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder={`Rechercher ${partyLabel.toLowerCase()}…`}
              className="w-full rounded-lg border border-gray-300 bg-white py-2.5 pl-9 pr-4 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500"
            />
          </div>
          <div className="overflow-hidden rounded-xl border border-gray-200 max-h-[60vh] overflow-y-auto">
            {parties.length === 0 ? (
              <p className="py-8 text-center text-sm text-gray-400">Aucun {partyLabel.toLowerCase()}.</p>
            ) : (
              <div className="divide-y divide-gray-100">
                {parties.map(p => (
                  <button
                    key={p.id}
                    onClick={() => setSelectedId(p.id)}
                    className={`w-full px-4 py-3 text-left transition ${selectedId === p.id ? 'bg-blue-50' : 'bg-white hover:bg-gray-50'}`}
                  >
                    <p className={`text-sm font-medium ${selectedId === p.id ? 'text-blue-700' : 'text-gray-800'}`}>{p.name}</p>
                    {mode === 'client' && (p as Customer).phone && (
                      <p className="text-xs text-gray-400">{(p as Customer).phone}</p>
                    )}
                    {mode === 'supplier' && (p as Supplier).phone && (
                      <p className="text-xs text-gray-400">{(p as Supplier).phone}</p>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </aside>

        {/* Statement detail */}
        <div className="flex-1 space-y-4">
          {!selectedParty ? (
            <div className="rounded-xl border border-dashed border-gray-300 py-20 text-center text-sm text-gray-400">
              Sélectionnez un {partyLabel.toLowerCase()} pour afficher son relevé.
            </div>
          ) : loading ? (
            <div className="h-40 animate-pulse rounded-xl bg-gray-100" />
          ) : (
            <>
              {/* Party header + actions */}
              <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between no-print">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">{selectedParty.name}</h2>
                  <p className="text-sm text-gray-500">
                    {mode === 'client' && (selectedParty as Customer).phone}
                    {mode === 'supplier' && (selectedParty as Supplier).phone}
                  </p>
                </div>
                <div className="flex gap-2 no-print">
                  <button
                    onClick={handleExportCsv}
                    className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3.5 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition"
                  >
                    <Download className="h-4 w-4" /> Exporter CSV
                  </button>
                  <button
                    onClick={handleExportPdf}
                    disabled={pdfSaving}
                    className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3.5 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
                  >
                    <FileDown className="h-4 w-4" /> {pdfSaving ? 'PDF…' : 'PDF'}
                  </button>
                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition"
                  >
                    <Printer className="h-4 w-4" /> Imprimer
                  </button>
                </div>
              </div>

              {/* Period filter */}
              <div className="flex flex-wrap items-end gap-3 rounded-xl border border-gray-200 bg-white p-4 no-print">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-gray-500 flex items-center gap-1"><Calendar className="h-3 w-3" /> Du</label>
                  <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm outline-none focus:border-blue-500" />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-gray-500 flex items-center gap-1"><Calendar className="h-3 w-3" /> Au</label>
                  <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm outline-none focus:border-blue-500" />
                </div>
                <div className="flex gap-2">
                  <button onClick={() => { setStartDate(firstStr); setEndDate(todayStr); }} className="rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 hover:bg-gray-50">Ce mois</button>
                  <button onClick={() => {
                    const d = new Date(); d.setMonth(d.getMonth() - 1);
                    d.setDate(1); const s = d.toISOString().slice(0, 10);
                    d.setMonth(d.getMonth() + 1, 0); const e = d.toISOString().slice(0, 10);
                    setStartDate(s); setEndDate(e);
                  }} className="rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 hover:bg-gray-50">Mois dernier</button>
                  <button onClick={() => {
                    const d = new Date(); d.setMonth(0, 1); const s = d.toISOString().slice(0, 10);
                    setStartDate(s); setEndDate(todayStr);
                  }} className="rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 hover:bg-gray-50">Année</button>
                </div>
              </div>

              {/* KPIs */}
              <div id="statement-print" className="space-y-4">
              <div className="rounded-xl border border-gray-200 bg-white p-5">
                <h2 className="text-xl font-bold text-gray-900">{selectedParty.name}</h2>
                <p className="text-sm text-gray-500">
                  {mode === 'client' && (selectedParty as Customer).phone}
                  {mode === 'supplier' && (selectedParty as Supplier).phone}
                </p>
                <p className="mt-1 text-xs text-gray-400">Période : {fmtDate(startDate)} — {fmtDate(endDate)}</p>
              </div>
              <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
                <div className="rounded-xl border border-gray-200 bg-white p-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Report antérieur</p>
                  <p className={`mt-1 text-lg font-bold tabular-nums ${reportBalance > 0 ? 'text-red-600' : 'text-gray-500'}`}>{fmt(reportBalance, currency)}</p>
                </div>
                <div className="rounded-xl border border-gray-200 bg-white p-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">{mode === 'client' ? 'Facturé' : 'Acheté'}</p>
                  <p className="mt-1 text-lg font-bold tabular-nums text-gray-900">{fmt(totalDebit, currency)}</p>
                </div>
                <div className="rounded-xl border border-gray-200 bg-white p-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">{mode === 'client' ? 'Encaissé' : 'Payé'}</p>
                  <p className="mt-1 text-lg font-bold tabular-nums text-emerald-600">{fmt(totalCredit, currency)}</p>
                </div>
                <div className="rounded-xl border border-gray-200 bg-white p-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Solde</p>
                  <p className={`mt-1 text-lg font-bold tabular-nums ${solde > 0 ? 'text-red-600' : 'text-gray-400'}`}>{fmt(solde, currency)}</p>
                </div>
              </div>

              {/* Statement table */}
              <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">
                {rows.length === 0 && reportBalance === 0 ? (
                  <p className="py-12 text-center text-sm text-gray-400">Aucun mouvement pour la période sélectionnée.</p>
                ) : (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-100 bg-gray-50">
                        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Date</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Libellé</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Référence</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Statut</th>
                        <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Débit</th>
                        <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Crédit</th>
                        <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Solde</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {/* Report row */}
                      <tr className="bg-amber-50/50">
                        <td className="px-4 py-3 text-gray-500">{fmtDate(startDate)}</td>
                        <td className="px-4 py-3 font-medium text-gray-600">Report antérieur</td>
                        <td className="px-4 py-3 text-gray-300">—</td>
                        <td className="px-4 py-3 text-gray-300">—</td>
                        <td className="px-4 py-3 text-right tabular-nums text-gray-500">{reportBalance > 0 ? fmt(reportBalance, currency) : '—'}</td>
                        <td className="px-4 py-3 text-right tabular-nums text-gray-500">{reportBalance < 0 ? fmt(-reportBalance, currency) : '—'}</td>
                        <td className={`px-4 py-3 text-right tabular-nums font-semibold ${reportBalance > 0 ? 'text-red-600' : 'text-gray-500'}`}>{fmt(reportBalance, currency)}</td>
                      </tr>
                      {rows.map((r, i) => (
                        <tr
                          key={i}
                          onClick={() => r.invoiceId && onNavigate({ page: 'invoice-detail', id: r.invoiceId })}
                          className={`bg-white hover:bg-gray-50 transition ${r.invoiceId ? 'cursor-pointer' : ''}`}
                        >
                          <td className="px-4 py-3 text-gray-600">{fmtDate(r.date)}</td>
                          <td className="px-4 py-3 text-gray-700">{r.label}</td>
                          <td className="px-4 py-3 font-mono text-xs text-blue-600">{r.ref}</td>
                          <td className="px-4 py-3">
                            {r.status ? <StatusBadge status={r.status as never} /> : <span className="text-gray-300">—</span>}
                          </td>
                          <td className="px-4 py-3 text-right tabular-nums text-gray-800">{r.debit ? fmt(r.debit, currency) : '—'}</td>
                          <td className="px-4 py-3 text-right tabular-nums text-emerald-600">{r.credit ? fmt(r.credit, currency) : '—'}</td>
                          <td className={`px-4 py-3 text-right tabular-nums font-semibold ${r.balance > 0 ? 'text-red-600' : 'text-gray-500'}`}>{fmt(r.balance, currency)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="border-t-2 border-gray-200 bg-gray-50 font-semibold">
                        <td colSpan={4} className="px-4 py-3 text-right text-gray-600">Totaux période</td>
                        <td className="px-4 py-3 text-right tabular-nums text-gray-900">{fmt(totalDebit, currency)}</td>
                        <td className="px-4 py-3 text-right tabular-nums text-emerald-600">{fmt(totalCredit, currency)}</td>
                        <td className={`px-4 py-3 text-right tabular-nums ${solde > 0 ? 'text-red-600' : 'text-gray-500'}`}>{fmt(solde, currency)}</td>
                      </tr>
                    </tfoot>
                  </table>
                )}
              </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
