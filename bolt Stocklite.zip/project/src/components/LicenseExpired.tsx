import { ShieldAlert, LogOut } from 'lucide-react';

interface LicenseExpiredProps {
  tenantName?: string;
  expiresAt?: string | null;
  onSignOut: () => void;
}

export function LicenseExpired({ tenantName, expiresAt, onSignOut }: LicenseExpiredProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl border border-gray-200 max-w-md w-full p-8 text-center space-y-5">
        <div className="mx-auto w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center">
          <ShieldAlert className="h-8 w-8 text-amber-600" />
        </div>
        <h1 className="text-xl font-bold text-gray-900">Licence expirée</h1>
        {tenantName && (
          <p className="text-sm text-gray-500">Entreprise : <span className="font-medium text-gray-700">{tenantName}</span></p>
        )}
        <p className="text-gray-600 text-sm leading-relaxed">
          Votre licence d'utilisation de Stocklite a expiré
          {expiresAt && ` le ${new Date(expiresAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}`}.
          Veuillez contacter l'administrateur pour renouveler votre abonnement.
        </p>
        <div className="pt-2">
          <button
            onClick={onSignOut}
            className="inline-flex items-center gap-2 rounded-lg bg-gray-100 px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-200 transition"
          >
            <LogOut className="h-4 w-4" /> Se déconnecter
          </button>
        </div>
      </div>
    </div>
  );
}
