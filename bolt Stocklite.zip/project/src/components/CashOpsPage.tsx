import { useState, useMemo } from 'react';
import { Plus, Trash2, Wallet, TrendingDown, Receipt, Calendar, Lock } from 'lucide-react';
import type { CompanySettings, PaymentMethod } from '../types';
import { ALL_PAYMENT_METHODS } from '../types';
import { useCashOps } from '../hooks/useCashOps';
import { CHARGE_CATEGORIES, categoryLabel } from '../hooks/useAccounting';
import { translateError } from '../lib/translateError';

interface CashOpsPageProps {
  settings: CompanySettings | null;
  locationId?: string | null;
  activeCaisseId?: string | null;
  caisseStatus?: string | null;
  tenantId?: string | null;
}

function fmt(n: number, currency = 'FCFA') {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}

export function CashOpsPage({ settings, locationId, activeCaisseId, caisseStatus, tenantId }: CashOpsPageProps) {
  const caisseOuverte = caisseStatus === 'ouverte';
  const currency = settings?.currency ?? 'FCFA';
  const { ops, totalExpenses, createOp, deleteOp } = useCashOps(locationId, tenantId);

  const now = new Date();
  const [form, setForm] = useState({
    date: now.toISOString().slice(0, 10),
    category: CHARGE_CATEGORIES[0].value,
    description: '',
    amount: '',
    payment_method: 'especes' as PaymentMethod,
    reference: '',
    notes: '',
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [filter, setFilter] = useState<string>('all');

  function set<K extends keyof typeof form>(k: K, v: (typeof form)[K]) {
    setForm(f => ({ ...f, [k]: v }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const amount = Number(form.amount);
    if (!amount || amount <= 0) { setErr('Montant invalide.'); return; }
    if (!form.description.trim()) { setErr('Veuillez décrire la dépense.'); return; }
    setSaving(true); setErr('');
    try {
      await createOp({
        date: form.date,
        category: form.category,
        description: form.description.trim(),
        amount,
        payment_method: form.payment_method,
        reference: form.reference.trim(),
        notes: form.notes.trim(),
        caisse_id: activeCaisseId ?? null,
      });
      setForm(f => ({ ...f, description: '', amount: '', reference: '', notes: '' }));
    } catch (e) {
      setErr(e instanceof Error ? translateError(e.message) : 'Erreur');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Supprimer cette dépense ?')) return;
    await deleteOp(id);
  }

  const categories = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of ops) map.set(o.category, (map.get(o.category) ?? 0) + Number(o.amount));
    return Array.from(map.entries())
      .map(([category, amount]) => ({ category, amount }))
      .sort((a, b) => b.amount - a.amount);
  }, [ops]);

  const filteredOps = filter === 'all' ? ops : ops.filter(o => o.category === filter);

  const todayStr = now.toISOString().slice(0, 10);
  const todayTotal = ops.filter(o => o.date === todayStr).reduce((s, o) => s + Number(o.amount), 0);
  const monthStr = todayStr.slice(0, 7);
  const monthTotal = ops.filter(o => o.date.slice(0, 7) === monthStr).reduce((s, o) => s + Number(o.amount), 0);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-lg font-bold text-gray-900">Opérations de caisse</h1>
        <p className="text-sm text-gray-400">Dépenses réglées par la caisse — intégrées à la comptabilité</p>
      </div>

      {!caisseOuverte && (
        <div className="flex items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 px-5 py-4 text-sm text-amber-700">
          <Lock className="h-5 w-5 shrink-0" />
          <div>
            <p className="font-semibold">Caisse fermée</p>
            <p className="text-amber-600">Aucune caisse ouverte. Ouvrez une caisse pour enregistrer une dépense.</p>
          </div>
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex items-start justify-between">
            <p className="text-sm font-medium text-gray-500">Dépenses du jour</p>
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
              <Calendar className="h-4 w-4" />
            </span>
          </div>
          <p className="mt-3 text-2xl font-bold tabular-nums text-amber-600">{fmt(todayTotal, currency)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex items-start justify-between">
            <p className="text-sm font-medium text-gray-500">Dépenses du mois</p>
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
              <Receipt className="h-4 w-4" />
            </span>
          </div>
          <p className="mt-3 text-2xl font-bold tabular-nums text-blue-600">{fmt(monthTotal, currency)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex items-start justify-between">
            <p className="text-sm font-medium text-gray-500">Total cumulé</p>
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-50 text-red-600">
              <TrendingDown className="h-4 w-4" />
            </span>
          </div>
          <p className="mt-3 text-2xl font-bold tabular-nums text-red-600">{fmt(totalExpenses, currency)}</p>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-5">
        {/* Form */}
        <div className="lg:col-span-2">
          <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
            <div className="border-b border-gray-100 bg-gray-50 px-5 py-3 flex items-center gap-2">
              <Wallet className="h-4 w-4 text-gray-500" />
              <h2 className="text-sm font-semibold text-gray-700">Nouvelle dépense de caisse</h2>
            </div>
            <form onSubmit={submit} className="p-5 space-y-3" inert={caisseOuverte ? undefined : true}>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Date</label>
                <input type="date" value={form.date} onChange={e => set('date', e.target.value)}
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Catégorie</label>
                <select value={form.category} onChange={e => set('category', e.target.value)}
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500">
                  {CHARGE_CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Description *</label>
                <input type="text" value={form.description} onChange={e => set('description', e.target.value)}
                  placeholder="Ex : Achat carburant, fournitures…"
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Montant *</label>
                  <input type="number" step="any" min="1" required value={form.amount}
                    onChange={e => set('amount', e.target.value)}
                    placeholder="0"
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm tabular-nums text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Mode</label>
                  <select value={form.payment_method} onChange={e => set('payment_method', e.target.value as PaymentMethod)}
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500">
                    {ALL_PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Référence</label>
                <input type="text" value={form.reference} onChange={e => set('reference', e.target.value)}
                  placeholder="N° reçu, facture fournisseur…"
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Notes</label>
                <textarea rows={2} value={form.notes} onChange={e => set('notes', e.target.value)}
                  placeholder="Optionnel"
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white resize-none" />
              </div>
              {err && <p className="text-xs text-red-500">{err}</p>}
              <button type="submit" disabled={saving || !form.amount || !caisseOuverte}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-red-500 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-red-400 disabled:opacity-50">
                <Plus className="h-4 w-4" />
                {saving ? 'Enregistrement…' : 'Enregistrer la dépense'}
              </button>
            </form>
          </div>

          {/* Category breakdown */}
          {categories.length > 0 && (
            <div className="mt-4 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-gray-400">Répartition par catégorie</h3>
              <div className="space-y-1.5 text-sm">
                {categories.map(c => (
                  <button key={c.category} onClick={() => setFilter(filter === c.category ? 'all' : c.category)}
                    className={`flex w-full justify-between rounded px-2 py-1 transition ${filter === c.category ? 'bg-gray-100' : 'hover:bg-gray-50'}`}>
                    <span className="text-gray-500 truncate pr-2">{categoryLabel(c.category, 'charge')}</span>
                    <span className="tabular-nums font-semibold text-red-600 shrink-0">{fmt(c.amount, currency)}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* List */}
        <div className="lg:col-span-3">
          <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
            <div className="flex items-center justify-between border-b border-gray-100 bg-gray-50 px-5 py-3">
              <h2 className="text-sm font-semibold text-gray-700">
                Dépenses enregistrées
                <span className="ml-2 text-xs font-normal text-gray-400">({filteredOps.length})</span>
              </h2>
              {filter !== 'all' && (
                <button onClick={() => setFilter('all')}
                  className="text-xs font-medium text-blue-600 hover:text-blue-500">
                  Réinitialiser le filtre
                </button>
              )}
            </div>
            {filteredOps.length === 0 ? (
              <div className="py-16 text-center text-sm text-gray-400">
                <Wallet className="mx-auto mb-2 h-8 w-8 text-gray-300" />
                Aucune dépense de caisse enregistrée.
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                <table className="w-full min-w-[520px]">
                  <thead className="sticky top-0 bg-white">
                    <tr className="border-b border-gray-100">
                      <th className="px-4 py-2.5 pl-5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Date</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Catégorie</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Libellé</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Mode</th>
                      <th className="px-4 py-2.5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Montant</th>
                      <th className="px-4 py-2.5 pr-5" />
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredOps.map(o => (
                      <tr key={o.id} className="group hover:bg-gray-50">
                        <td className="px-4 py-3 pl-5 text-sm tabular-nums text-gray-500">
                          {new Date(o.date).toLocaleDateString('fr-FR')}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">{categoryLabel(o.category, 'charge')}</td>
                        <td className="px-4 py-3 text-sm font-medium text-gray-800 max-w-[200px] truncate">{o.description || '—'}</td>
                        <td className="px-4 py-3 text-xs text-gray-500">
                          {ALL_PAYMENT_METHODS.find(m => m.value === o.payment_method)?.label ?? o.payment_method}
                        </td>
                        <td className="px-4 py-3 text-right tabular-nums font-semibold text-sm text-red-600">
                          −{fmt(Number(o.amount), currency)}
                        </td>
                        <td className="px-4 py-3 pr-5 text-right">
                          <button onClick={() => handleDelete(o.id)}
                            className="rounded p-1.5 text-gray-300 opacity-0 transition group-hover:opacity-100 hover:bg-red-50 hover:text-red-500">
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-gray-200 bg-gray-50">
                      <td colSpan={4} className="px-4 py-3 pl-5 text-xs font-bold uppercase tracking-wider text-gray-500">Total</td>
                      <td className="px-4 py-3 text-right tabular-nums text-sm font-bold text-red-600">
                        {fmt(filteredOps.reduce((s, o) => s + Number(o.amount), 0), currency)}
                      </td>
                      <td className="pr-5" />
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
