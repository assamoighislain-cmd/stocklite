import { Clock, RefreshCw, LogOut } from 'lucide-react';
import type { UserProfile } from '../types';
import { ROLE_LABELS } from '../types';

interface Props {
  profile: UserProfile;
  onRefresh: () => Promise<void>;
  onSignOut: () => void;
}

export default function PendingApproval({ profile, onRefresh, onSignOut }: Props) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-sm text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-amber-100 border border-amber-300 mb-6">
          <Clock className="w-8 h-8 text-amber-600" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Compte en attente</h2>
        <p className="text-gray-500 text-sm mb-1">
          Votre compte <span className="text-gray-700 font-medium">{profile.email}</span> a été
          créé avec le rôle{' '}
          <span className="text-blue-600 font-medium">{ROLE_LABELS[profile.role]}</span>.
        </p>
        <p className="text-gray-500 text-sm mb-8">
          Un administrateur doit valider votre accès avant que vous puissiez utiliser
          l'application.
        </p>
        <div className="space-y-3">
          <button
            onClick={onRefresh}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Vérifier l'activation
          </button>
          <button
            onClick={onSignOut}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-gray-300 text-gray-500 hover:text-gray-700 hover:border-gray-400 text-sm transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Se déconnecter
          </button>
        </div>
      </div>
    </div>
  );
}
