import { useState, useMemo } from 'react';
import { RefreshCw, Trash2, ShoppingCart, WifiOff, CheckCircle2, AlertCircle, Clock, CloudOff } from 'lucide-react';
import type { QueuedSale } from '../lib/offlineDb';
import type { CreateSaleInput } from '../hooks/usePosSales';

function fmt(n: number, currency: string): string {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}

interface PendingSalesPageProps {
  queuedSales: QueuedSale[];
  isOnline: boolean;
  pendingCount: number;
  onSync: () => Promise<void>;
  onCancel: (localId: string) => Promise<void>;
  currency: string;
}

export function PendingSalesPage({ queuedSales, isOnline, pendingCount, onSync, onCancel, currency }: PendingSalesPageProps) {
  const [syncing, setSyncing] = useState(false);
  const [canceling, setCanceling] = useState<string | null>(null);

  const sorted = useMemo(() =>
    [...queuedSales].sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
    [queuedSales],
  );

  async function handleSync() {
    setSyncing(true);
    try { await onSync(); } finally { setSyncing(false); }
  }

  async function handleCancel(localId: string) {
    setCanceling(localId);
    try { await onCancel(localId); } finally { setCanceling(null); }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Ventes en attente</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Ventes encaissées hors ligne, en attente de synchronisation
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold ${
            isOnline ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
          }`}>
            {isOnline ? <CheckCircle2 className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}
            {isOnline ? 'En ligne' : 'Hors ligne'}
          </div>
          {isOnline && pendingCount > 0 && (
            <button
              onClick={handleSync}
              disabled={syncing}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50 transition"
            >
              <RefreshCw className={`h-4 w-4 ${syncing ? 'animate-spin' : ''}`} />
              {syncing ? 'Synchronisation…' : 'Tout synchroniser'}
            </button>
          )}
        </div>
      </div>

      {sorted.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 mb-4">
            <CheckCircle2 className="h-8 w-8 text-emerald-500" />
          </div>
          <h3 className="text-sm font-semibold text-gray-700">Aucune vente en attente</h3>
          <p className="text-xs text-gray-400 mt-1">Toutes les ventes ont été synchronisées</p>
        </div>
      ) : (
        <div className="space-y-3">
          {!isOnline && (
            <div className="flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
              <CloudOff className="h-4 w-4 shrink-0" />
              <span>Vous êtes hors ligne. Les ventes seront synchronisées automatiquement au retour du réseau.</span>
            </div>
          )}
          {sorted.map((sale) => {
            const payload = sale.payload as CreateSaleInput;
            const total = payload.items.reduce((s, i) => s + i.quantity * i.unit_price, 0);
            const itemCount = payload.items.length;
            const isError = sale.status === 'error';

            return (
              <div
                key={sale.localId}
                className={`rounded-xl border bg-white p-4 shadow-sm transition ${
                  isError ? 'border-red-200' : sale.status === 'syncing' ? 'border-blue-200' : 'border-gray-200'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-lg shrink-0 ${
                      isError ? 'bg-red-50' : sale.status === 'syncing' ? 'bg-blue-50' : 'bg-amber-50'
                    }`}>
                      {isError ? (
                        <AlertCircle className="h-5 w-5 text-red-500" />
                      ) : sale.status === 'syncing' ? (
                        <RefreshCw className="h-5 w-5 text-blue-500 animate-spin" />
                      ) : (
                        <ShoppingCart className="h-5 w-5 text-amber-500" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-gray-900">
                          {fmt(total, currency)}
                        </span>
                        <span className="text-xs text-gray-400">·</span>
                        <span className="text-xs text-gray-500">{itemCount} article(s)</span>
                        <StatusBadge status={sale.status} />
                      </div>
                      <div className="mt-1 flex items-center gap-1.5 text-xs text-gray-400">
                        <Clock className="h-3 w-3" />
                        {new Date(sale.createdAt).toLocaleString('fr-FR')}
                      </div>
                      {isError && sale.error && (
                        <p className="mt-1.5 text-xs text-red-600 bg-red-50 rounded-lg px-2 py-1">
                          {sale.error}
                        </p>
                      )}
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {payload.items.slice(0, 4).map((item, idx) => (
                          <span key={idx} className="rounded-md bg-gray-100 px-2 py-0.5 text-[11px] text-gray-600 truncate max-w-[160px]">
                            {item.quantity}× {item.description}
                          </span>
                        ))}
                        {payload.items.length > 4 && (
                          <span className="rounded-md bg-gray-100 px-2 py-0.5 text-[11px] text-gray-500">
                            +{payload.items.length - 4} autre(s)
                          </span>
                        )}
                      </div>
                      {payload.tenders.length > 0 && (
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {payload.tenders.map((t, idx) => (
                            <span key={idx} className="rounded-md bg-blue-50 px-2 py-0.5 text-[11px] font-medium text-blue-600">
                              {t.method}: {fmt(t.amount, currency)}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => handleCancel(sale.localId)}
                    disabled={canceling === sale.localId || sale.status === 'syncing'}
                    className="flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-semibold text-gray-600 hover:bg-red-50 hover:text-red-600 hover:border-red-200 disabled:opacity-50 transition shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    {canceling === sale.localId ? '…' : 'Annuler'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: QueuedSale['status'] }) {
  if (status === 'syncing') {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-semibold text-blue-600">
        <RefreshCw className="h-2.5 w-2.5 animate-spin" />
        Synchro
      </span>
    );
  }
  if (status === 'error') {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-[10px] font-semibold text-red-600">
        <AlertCircle className="h-2.5 w-2.5" />
        Erreur
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-600">
      <Clock className="h-2.5 w-2.5" />
      En attente
    </span>
  );
}
