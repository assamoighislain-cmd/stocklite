import { useState, useEffect } from 'react';
import { ArrowLeft, FileText, CheckCircle2, Loader2, Printer, Plus, FileDown, Pencil } from 'lucide-react';
import type { Order, OrderItem, ProductFamily, Product, CompanySettings } from '../types';
import { ORDER_STATUS_LABELS } from '../types';
import type { Route } from '../App';
import { exportElementToPdf } from '../lib/pdf';
import { printDocument } from '../lib/printEngine';

interface OrderDetailProps {
  orderId: string;
  fetchOne: (id: string) => Promise<Order | null>;
  onNavigate: (r: Route) => void;
  onValidate?: (id: string) => Promise<void>;
  onConvert?: (id: string) => Promise<void>;
  canValidate: boolean;
  families: ProductFamily[];
  products: Product[];
  settings: CompanySettings | null;
  onMarkItemsPrinted?: (itemIds: string[]) => Promise<void>;
}

function fmt(n: number) {
  return new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);
}

const STATUS_STYLES: Record<string, string> = {
  brouillon: 'bg-gray-100 text-gray-600 ring-gray-200',
  validee: 'bg-blue-50 text-blue-700 ring-blue-200',
  convertie: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  annulee: 'bg-red-50 text-red-600 ring-red-200',
};

// ── Main order ticket (customer copy) ─────────────────────────────
function buildOrderMainHtml(order: Order, settings: CompanySettings | null) {
  const date = new Date(order.date).toLocaleString('fr-FR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });

  const itemsHtml = (order.items ?? []).map(i =>
    `<tr>
      <td class="qty">${i.quantity}</td>
      <td class="desc">${i.description}</td>
      <td class="amt">${fmt(i.total)}</td>
    </tr>`
  ).join('');

  return `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<title>Bon de commande ${order.order_number}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Courier New', monospace; font-size: 12px; color: #111; background: #fff; }
  @media screen {
    html { background: #e8e8e8; min-height: 100vh; }
    body { width: 80mm; max-width: 100%; margin: 20px auto; padding: 6mm 5mm 12mm;
           box-shadow: 0 4px 20px rgba(0,0,0,.18); border-radius: 2px; }
  }
  @media print {
    body { width: 80mm; padding: 3mm 4mm 8mm; }
    @page { size: 80mm auto; margin: 0; }
  }

  .company { text-align: center; font-weight: 900; font-size: 14px; }
  .title   { text-align: center; font-weight: 700; font-size: 13px; letter-spacing: 1px; text-transform: uppercase; margin-top: 4px; }
  .meta    { text-align: center; font-size: 11px; color: #555; margin-top: 1px; }
  .customer{ font-size: 12px; text-align: center; font-weight: 700; color: #333; margin-top: 3px; }
  .sep       { border: none; border-top: 1px dashed #999; margin: 5px 0; }
  .sep-solid { border: none; border-top: 2px solid #333; margin: 5px 0; }

  table { width: 100%; border-collapse: collapse; }
  td { padding: 3px 2px; vertical-align: top; font-size: 12px; }
  .items-header td { font-weight: 700; font-size: 10px; text-transform: uppercase; border-bottom: 2px solid #333; padding-bottom: 3px; }
  .qty  { width: 12%; text-align: center; font-weight: 700; }
  .desc { width: 58%; }
  .amt  { width: 30%; text-align: right; }

  .totals { margin-top: 5px; }
  .totals td { padding: 2px 2px; }
  .totals .label { text-align: left; }
  .totals .val   { text-align: right; font-weight: 700; }

  .footer { text-align: center; font-size: 10px; color: #666; margin-top: 6px; }
</style></head>
<body>

<div class="company">${settings?.name ?? ''}</div>
<div class="title">Bon de commande</div>
<div class="meta"><strong>${ORDER_STATUS_LABELS[order.status].toUpperCase()}</strong></div>
<div class="meta">${order.order_number}</div>
<div class="meta">${date}</div>
${order.customer ? `<div class="customer">${order.customer.name}</div>` : ''}

<hr class="sep-solid">

<table>
  <tr class="items-header">
    <td class="qty">Qté</td>
    <td class="desc">Article</td>
    <td class="amt">Total</td>
  </tr>
  ${itemsHtml}
</table>

<hr class="sep">

<table class="totals">
  <tr><td class="label">Sous-total HT</td><td class="val">${fmt(order.subtotal)}</td></tr>
  ${order.tax_rate > 0 ? `<tr><td class="label">TVA (${order.tax_rate}%)</td><td class="val">${fmt(order.tax_amount)}</td></tr>` : ''}
  <tr><td class="label" style="font-weight:900;font-size:14px;">Total TTC</td><td class="val" style="font-weight:900;font-size:14px;">${fmt(order.total)}</td></tr>
</table>

${order.notes ? `<hr class="sep"><p style="font-size:11px;color:#555;"><b>Notes:</b> ${order.notes}</p>` : ''}

<div class="footer">${settings?.name ?? ''}</div>

</body></html>`;
}

// ── Kitchen ticket (per printer, filtered by family + items subset) ──
function buildKitchenTicketHtml(
  order: Order,
  settings: CompanySettings | null,
  printerName: string,
  families: ProductFamily[],
  products: Product[],
  itemsSubset?: OrderItem[],
) {
  const date = new Date(order.date).toLocaleString('fr-FR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });

  const sourceItems = itemsSubset ?? (order.items ?? []);
  const items = sourceItems.filter(i => {
    if (!i.product_id) return false;
    const prod = products.find(p => p.id === i.product_id);
    const fam = prod ? families.find(fa => fa.id === prod.family_id) : undefined;
    return fam?.printer_name === printerName;
  });
  if (items.length === 0) return null;

  const itemsHtml = items.map(i =>
    `<tr>
      <td class="qty">${i.quantity}</td>
      <td class="desc">${i.description}</td>
    </tr>`
  ).join('');

  return `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<title>Bon de commande ${printerName} — ${order.order_number}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Courier New', monospace; font-size: 13px; color: #111; background: #fff; }
  @media screen {
    html { background: #e8e8e8; min-height: 100vh; }
    body { width: 80mm; max-width: 100%; margin: 20px auto; padding: 6mm 5mm 12mm;
           box-shadow: 0 4px 20px rgba(0,0,0,.18); border-radius: 2px; }
  }
  @media print {
    body { width: 80mm; padding: 3mm 4mm 8mm; }
    @page { size: 80mm auto; margin: 0; }
  }

  .printer-label { text-align: center; font-weight: 900; font-size: 16px; background: #000; color: #fff; padding: 6px; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 2px; }
  .title { text-align: center; font-weight: 700; font-size: 13px; letter-spacing: 1px; text-transform: uppercase; }
  .meta  { text-align: center; font-size: 11px; color: #555; margin-top: 1px; }
  .customer { font-size: 12px; text-align: center; font-weight: 700; color: #333; margin-top: 3px; }
  .sep       { border: none; border-top: 1px dashed #999; margin: 5px 0; }
  .sep-solid { border: none; border-top: 2px solid #333; margin: 5px 0; }

  table { width: 100%; border-collapse: collapse; }
  td { padding: 4px 2px; vertical-align: top; font-size: 13px; }
  .items-header td { font-weight: 700; font-size: 10px; text-transform: uppercase; border-bottom: 2px solid #333; padding-bottom: 3px; }
  .qty  { width: 15%; text-align: center; font-weight: 900; font-size: 15px; }
  .desc { width: 85%; }

  .footer { text-align: center; font-size: 10px; color: #666; margin-top: 6px; }
</style></head>
<body>

<div class="printer-label">${printerName}</div>
<div class="title">Bon de commande</div>
<div class="meta">${order.order_number}</div>
<div class="meta">${date}</div>
${order.customer ? `<div class="customer">${order.customer.name}</div>` : ''}

<hr class="sep-solid">

<table>
  <tr class="items-header">
    <td class="qty">Qté</td>
    <td class="desc">Article</td>
  </tr>
  ${itemsHtml}
</table>

<hr class="sep-solid">

<div class="footer">
  ${settings?.name ?? ''}
</div>

</body></html>`;
}

export function OrderDetail({ orderId, fetchOne, onNavigate, onValidate, onConvert, canValidate, families, products, settings, onMarkItemsPrinted }: OrderDetailProps) {
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState(false);
  const [printing, setPrinting] = useState(false);
  const [pdfSaving, setPdfSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const o = await fetchOne(orderId);
      setOrder(o);
      setLoading(false);
    })();
  }, [orderId, fetchOne]);

  async function handleValidate() {
    if (!onValidate) return;
    setActing(true);
    try {
      await onValidate(orderId);
      const o = await fetchOne(orderId);
      setOrder(o);
    } finally { setActing(false); }
  }

  async function handleConvert() {
    if (!onConvert) return;
    setActing(true);
    try { await onConvert(orderId); } finally { setActing(false); }
  }

  function printOrder() {
    if (!order) return;

    // 1. Print the main order ticket (customer copy, default printer)
    printDocument(buildOrderMainHtml(order, settings), { format: 'receipt', title: `Commande ${order.order_number}` });

    // 2. Determine which kitchen printers are needed
    const printerNames = new Set<string>();
    for (const item of (order.items ?? [])) {
      if (!item.product_id) continue;
      const prod = products.find(p => p.id === item.product_id);
      const fam = prod ? families.find(fa => fa.id === prod.family_id) : undefined;
      if (fam?.printer_name) printerNames.add(fam.printer_name);
    }

    // 3. Print one kitchen ticket per printer (staggered)
    let delay = 800;
    for (const pn of printerNames) {
      const html = buildKitchenTicketHtml(order, settings, pn, families, products);
      if (!html) continue;
      setTimeout(() => { printDocument(html, { format: 'receipt', title: `Bon ${pn} — ${order.order_number}` }); }, delay);
      delay += 800;
    }
  }

  async function printNewItems() {
    if (!order || !onMarkItemsPrinted) return;
    const newItems = (order.items ?? []).filter(i => !i.printed_at);
    if (newItems.length === 0) return;

    setPrinting(true);

    // Determine which kitchen printers are needed for new items only
    const printerNames = new Set<string>();
    for (const item of newItems) {
      if (!item.product_id) continue;
      const prod = products.find(p => p.id === item.product_id);
      const fam = prod ? families.find(fa => fa.id === prod.family_id) : undefined;
      if (fam?.printer_name) printerNames.add(fam.printer_name);
    }

    // Print one kitchen ticket per printer (staggered), new items only
    let delay = 0;
    for (const pn of printerNames) {
      const html = buildKitchenTicketHtml(order, settings, pn, families, products, newItems);
      if (!html) continue;
      setTimeout(() => { printDocument(html, { format: 'receipt', title: `Bon ${pn} — ${order.order_number}` }); }, delay);
      delay += 800;
    }

    // Mark items as printed after sending to print
    const itemIds = newItems.map(i => i.id);
    try {
      await onMarkItemsPrinted(itemIds);
      const o = await fetchOne(orderId);
      setOrder(o);
    } finally { setPrinting(false); }
  }

function OrderA4Print({ order, settings }: { order: Order; settings: CompanySettings | null }) {
  const date = new Date(order.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
  const cur = settings?.currency ?? 'FCFA';
  function money(n: number) {
    try { return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: cur, maximumFractionDigits: 0 }).format(n); }
    catch { return `${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n)} ${cur}`; }
  }
  const c = order.customer;
  return (
    <div className="p-10 text-gray-900" style={{ width: '210mm', minHeight: '297mm', background: '#fff' }}>
      <div className="flex justify-between items-start mb-10">
        <div className="flex items-start gap-4">
          {settings?.logo_url && (
            <img src={settings.logo_url} alt="Logo" className="h-16 w-16 shrink-0 rounded-lg object-contain" />
          )}
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-1">{settings?.name ?? 'Mon Entreprise'}</h1>
            {settings?.address && <p className="text-sm text-gray-600">{settings.address}</p>}
            {settings?.city && <p className="text-sm text-gray-600">{settings.city}</p>}
            {settings?.phone && <p className="text-sm text-gray-600">Tél : {settings.phone}</p>}
            {settings?.email && <p className="text-sm text-gray-600">{settings.email}</p>}
            {settings?.tax_id && <p className="text-sm text-gray-500">NIF / SIRET : {settings.tax_id}</p>}
          </div>
        </div>
        <div className="text-right">
          <div className="inline-block rounded-lg bg-blue-50 px-5 py-3 text-center">
            <p className="text-xs font-semibold uppercase tracking-widest text-blue-600 mb-1">DEVIS</p>
            <p className="text-xl font-bold text-blue-700 font-mono">{order.order_number}</p>
          </div>
          <div className="mt-3 space-y-1 text-sm text-gray-600">
            <p><span className="font-medium text-gray-700">Date :</span> {date}</p>
            <p><span className="font-medium text-gray-700">Statut :</span> {ORDER_STATUS_LABELS[order.status]}</p>
          </div>
        </div>
      </div>

      <div className="mb-8 rounded-lg border border-gray-200 bg-gray-50 p-5 max-w-xs">
        <p className="mb-2 text-xs font-bold uppercase tracking-wider text-gray-500">Client</p>
        <p className="font-bold text-gray-900">{c?.name ?? '—'}</p>
        {c?.address && <p className="text-sm text-gray-600">{c.address}</p>}
        {c?.city && <p className="text-sm text-gray-600">{c.city}</p>}
        {c?.phone && <p className="text-sm text-gray-600">Tél : {c.phone}</p>}
        {order.contact_name && (
          <div className="mt-3 border-t border-gray-200 pt-2">
            <p className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">Interlocuteur</p>
            <p className="text-sm font-semibold text-gray-800">{order.contact_name}</p>
            {order.contact_email && <p className="text-sm text-gray-600">{order.contact_email}</p>}
            {order.contact_phone && <p className="text-sm text-gray-600">Tél : {order.contact_phone}</p>}
          </div>
        )}
      </div>

      <table className="w-full mb-8 text-sm border-collapse">
        <thead>
          <tr className="border-b-2 border-gray-200">
            <th className="pb-2 text-left text-xs font-bold uppercase tracking-wider text-gray-500 w-8">#</th>
            <th className="pb-2 text-left text-xs font-bold uppercase tracking-wider text-gray-500">Désignation</th>
            <th className="pb-2 text-right text-xs font-bold uppercase tracking-wider text-gray-500 w-20">Qté</th>
            <th className="pb-2 text-right text-xs font-bold uppercase tracking-wider text-gray-500 w-28">Prix U.</th>
            <th className="pb-2 text-right text-xs font-bold uppercase tracking-wider text-gray-500 w-28">Total</th>
          </tr>
        </thead>
        <tbody>
          {(order.items ?? []).map((item, i) => (
            <tr key={item.id} className="border-b border-gray-100">
              <td className="py-2.5 text-gray-400 text-xs">{i + 1}</td>
              <td className="py-2.5 font-medium text-gray-800">{item.description}</td>
              <td className="py-2.5 text-right tabular-nums text-gray-700">{item.quantity}</td>
              <td className="py-2.5 text-right tabular-nums text-gray-700">{money(item.unit_price)}</td>
              <td className="py-2.5 text-right tabular-nums font-semibold text-gray-900">{money(item.total)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="flex justify-end mb-8">
        <div className="w-72 space-y-2 text-sm">
          <div className="flex justify-between text-gray-600">
            <span>Sous-total HT</span>
            <span className="tabular-nums font-medium">{money(order.subtotal)}</span>
          </div>
          {order.tax_rate > 0 && (
            <div className="flex justify-between text-gray-600">
              <span>TVA ({order.tax_rate}%)</span>
              <span className="tabular-nums font-medium">{money(order.tax_amount)}</span>
            </div>
          )}
          <div className="flex justify-between border-t-2 border-gray-900 pt-2 text-base font-bold text-gray-900">
            <span>TOTAL TTC</span>
            <span className="tabular-nums">{money(order.total)}</span>
          </div>
        </div>
      </div>

      {order.notes && (
        <div className="mb-6 rounded-lg border border-gray-200 bg-gray-50 p-4 text-sm text-gray-700">
          <p className="mb-1 text-xs font-bold uppercase tracking-wider text-gray-400">Notes</p>
          <p className="whitespace-pre-line">{order.notes}</p>
        </div>
      )}

      {settings?.invoice_footer && (
        <div className="border-t border-gray-200 pt-4 text-center text-xs text-gray-400">
          {settings.invoice_footer}
        </div>
      )}
    </div>
  );
}

  async function exportOrderPdf() {
    if (!order) return;
    const el = document.getElementById('order-a4-print');
    if (!el) return;
    setPdfSaving(true);
    const wasHidden = el.classList.contains('hidden');
    if (wasHidden) {
      el.classList.remove('hidden');
      el.style.position = 'fixed';
      el.style.left = '-9999px';
      el.style.top = '0';
      el.style.width = '210mm';
    }
    try {
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
      await exportElementToPdf(el, `devis_${order.order_number}.pdf`, 'a4');
    } finally {
      if (wasHidden) {
        el.classList.add('hidden');
        el.style.position = '';
        el.style.left = '';
        el.style.top = '';
        el.style.width = '';
      }
      setPdfSaving(false);
    }
  }

  if (loading) return <div className="h-64 animate-pulse rounded-xl bg-gray-100/40" />;
  if (!order) return (
    <div className="space-y-5">
      <button onClick={() => onNavigate({ page: 'orders' })} className="rounded-lg p-2 text-gray-500 hover:bg-gray-100">
        <ArrowLeft className="h-4 w-4" />
      </button>
      <p className="text-sm text-gray-400">Commande introuvable.</p>
    </div>
  );

  const subtotal = order.subtotal;
  const rate = order.tax_rate;
  const taxAmt = order.tax_amount;
  const total = order.total;
  const newItemsCount = (order.items ?? []).filter(i => !i.printed_at).length;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigate({ page: 'orders' })} className="rounded-lg p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-900 transition">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-gray-900">{order.order_number}</h1>
            <p className="text-sm text-gray-400">Commande du {new Date(order.date).toLocaleDateString('fr-FR')}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ${STATUS_STYLES[order.status]}`}>
            {ORDER_STATUS_LABELS[order.status]}
          </span>
          {newItemsCount > 0 && onMarkItemsPrinted && (
            <button
              onClick={printNewItems}
              disabled={printing}
              title={`Imprimer ${newItemsCount} nouvel(s) article(s)`}
              className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-2 text-xs font-bold text-white shadow-sm hover:bg-amber-400 transition active:scale-95 disabled:opacity-50"
            >
              {printing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              {newItemsCount} nouveau(x)
            </button>
          )}
          <button onClick={printOrder} className="rounded-lg border border-gray-300 p-2 text-gray-500 hover:bg-gray-100">
            <Printer className="h-4 w-4" />
          </button>
          <button
            onClick={exportOrderPdf}
            disabled={pdfSaving}
            className="flex items-center gap-1.5 rounded-lg border border-gray-300 bg-white px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
          >
            <FileDown className="h-4 w-4" /> {pdfSaving ? 'PDF…' : 'PDF A4'}
          </button>
        </div>
      </div>

      {/* Customer + commercial info */}
      <div className="rounded-xl border border-gray-200 bg-white p-5">
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Client</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{order.customer?.name ?? '—'}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Commercial</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{order.commercial?.name ?? '—'}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Date</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{new Date(order.date).toLocaleDateString('fr-FR')}</p>
          </div>
        </div>
        {order.contact_name && (
          <div className="mt-4 border-t border-gray-100 pt-3">
            <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Interlocuteur</p>
            <div className="mt-1 flex flex-wrap gap-x-6 gap-y-1 text-sm text-gray-700">
              <span className="font-medium text-gray-900">{order.contact_name}</span>
              {order.contact_email && <span>{order.contact_email}</span>}
              {order.contact_phone && <span>Tél : {order.contact_phone}</span>}
            </div>
          </div>
        )}
      </div>

      {/* Items */}
      <div className="overflow-hidden rounded-xl border border-gray-200">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px] text-sm">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                {['Description', 'Qté', 'Prix unitaire', 'Total'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 first:pl-5 last:text-right">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {(order.items ?? []).map(it => (
                <tr key={it.id} className="bg-white">
                  <td className="px-4 py-3 pl-5 text-gray-800">
                    {it.description}
                    {!it.printed_at && (
                      <span className="ml-2 inline-flex items-center rounded-full bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">nouveau</span>
                    )}
                  </td>
                  <td className="px-4 py-3 tabular-nums text-gray-600">{it.quantity}</td>
                  <td className="px-4 py-3 tabular-nums text-gray-600">{fmt(it.unit_price)}</td>
                  <td className="px-4 py-3 text-right tabular-nums font-medium text-gray-900">{fmt(it.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-end gap-6 border-t border-gray-200 bg-gray-50 px-5 py-3">
          <div className="space-y-1 text-sm">
            <div className="flex justify-between gap-8 text-gray-500">
              <span>Sous-total HT</span>
              <span className="tabular-nums font-medium text-gray-800">{fmt(subtotal)}</span>
            </div>
            {rate > 0 && (
              <div className="flex justify-between gap-8 text-gray-500">
                <span>TVA ({rate}%)</span>
                <span className="tabular-nums font-medium text-gray-800">{fmt(taxAmt)}</span>
              </div>
            )}
            <div className="flex justify-between gap-8 border-t border-gray-300 pt-1 text-base font-bold text-gray-900">
              <span>Total TTC</span>
              <span className="tabular-nums">{fmt(total)}</span>
            </div>
          </div>
        </div>
      </div>

      {order.notes && (
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Notes</p>
          <p className="mt-2 text-sm text-gray-600 whitespace-pre-wrap">{order.notes}</p>
        </div>
      )}

      {/* Actions */}
      {order.status === 'brouillon' && (
        <div className="flex justify-end gap-3 pb-4">
          <button
            onClick={() => onNavigate({ page: 'order-form', editId: order.id })}
            className="flex items-center gap-2 rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-100 transition"
          >
            <Pencil className="h-4 w-4" />
            Ajouter / modifier des articles
          </button>
          {canValidate && onValidate && (
            <button
              onClick={handleValidate}
              disabled={acting}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 active:scale-95 transition disabled:opacity-50"
            >
              {acting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
              Valider la commande
            </button>
          )}
        </div>
      )}
      {order.status === 'validee' && onConvert && (
        <div className="flex justify-end gap-3 pb-4">
          <button
            onClick={handleValidate}
            disabled={acting}
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 active:scale-95 transition disabled:opacity-50"
          >
            {acting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
            Valider la commande
          </button>
        </div>
      )}
      {order.status === 'validee' && onConvert && (
        <div className="flex justify-end gap-3 pb-4">
          <button
            onClick={handleConvert}
            disabled={acting}
            className="flex items-center gap-2 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-500 active:scale-95 transition disabled:opacity-50"
          >
            {acting ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
            Convertir en facture
          </button>
        </div>
      )}

      {/* Hidden A4 print area for PDF export */}
      <div id="order-a4-print" className="hidden">
        <OrderA4Print order={order} settings={settings} />
      </div>
    </div>
  );
}
