import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Plus, Trash2, Save, PackagePlus, X, WifiOff } from 'lucide-react';
import type { Customer, CustomerContact, Product, ProductFamily, PriceType } from '../types';
import type { CreateInvoiceInput, LineItemInput } from '../hooks/useInvoices';
import type { Route } from '../App';
import { translateError } from '../lib/translateError';
import { SearchableSelect } from './SearchableSelect';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface InvoiceFormProps {
  customers: Customer[];
  products: Product[];
  preselectedCustomerId?: string;
  editId?: string;
  fetchOne?: (id: string) => Promise<import('../types').Invoice | null>;
  onSave: (input: CreateInvoiceInput) => Promise<import('../types').Invoice>;
  onUpdate?: (id: string, input: Partial<CreateInvoiceInput>) => Promise<void>;
  onNavigate: (r: Route) => void;
  onCreateProduct?: (payload: Omit<Product, 'id' | 'created_at' | 'family' | 'prices'>) => Promise<string>;
  onSaveProductPrices?: (productId: string, prices: { price_type_id: string; price: number }[]) => Promise<void>;
  families?: ProductFamily[];
  priceTypes?: PriceType[];
  locationId?: string | null;
  locations?: { id: string; name: string }[];
  fetchCustomerContacts?: (customerId: string) => Promise<CustomerContact[]>;
}

interface Row {
  key: string;
  product_id: string | null;
  description: string;
  quantity: string;
  unit_price: string;
  discount: string;
}

function today() { return new Date().toISOString().split('T')[0]; }
function uid() { return Math.random().toString(36).slice(2); }

function fmt(n: number) {
  return new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);
}

export function InvoiceForm({
  customers, products, preselectedCustomerId, editId, fetchOne, onSave, onUpdate, onNavigate, onCreateProduct, onSaveProductPrices, families, priceTypes, locationId, locations, fetchCustomerContacts
}: InvoiceFormProps) {
  const [customerId, setCustomerId] = useState(preselectedCustomerId ?? '');
  const [selectedLocationId, setSelectedLocationId] = useState(locationId ?? '');
  const [date, setDate] = useState(today());
  const [dueDate, setDueDate] = useState('');
  const [taxRate, setTaxRate] = useState(() => localStorage.getItem('lastTaxRate') ?? '0');
  const [remise, setRemise] = useState('0');
  const [notes, setNotes] = useState('');
  const [orderNumber, setOrderNumber] = useState('');
  const [orderAdvance, setOrderAdvance] = useState('');
  const [deliveryDelay, setDeliveryDelay] = useState('');
  const [paymentMode, setPaymentMode] = useState('');
  const [airsi, setAirsi] = useState(() => localStorage.getItem('lastAirsiRate') ?? '0');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [customerContacts, setCustomerContacts] = useState<CustomerContact[]>([]);
  const [selectedContactId, setSelectedContactId] = useState('');
  const [rows, setRows] = useState<Row[]>([{ key: uid(), product_id: null, description: '', quantity: '1', unit_price: '', discount: '' }]);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [loadingEdit, setLoadingEdit] = useState(!!editId);
  const [showQuickCreate, setShowQuickCreate] = useState(false);
  const [quickTargetKey, setQuickTargetKey] = useState<string | null>(null);
  const isOnline = useOnlineStatus();

  const loadEdit = useCallback(async () => {
    if (!editId || !fetchOne) return;
    const inv = await fetchOne(editId);
    if (!inv) return;
    setCustomerId(inv.customer_id);
    setDate(inv.date);
    setDueDate(inv.due_date ?? '');
    setTaxRate(String(inv.tax_rate));
    setAirsi(inv.airsi != null ? String(inv.airsi) : '0');
    setRemise(String(inv.remise ?? 0));
    setNotes(inv.notes);
    setOrderNumber(inv.order_number ?? '');
    setOrderAdvance(inv.order_advance != null ? String(inv.order_advance) : '');
    setDeliveryDelay(inv.delivery_delay ?? '');
    setPaymentMode(inv.payment_mode ?? '');
    setContactName(inv.contact_name ?? '');
    setContactEmail(inv.contact_email ?? '');
    setContactPhone(inv.contact_phone ?? '');
    setSelectedContactId('');
    if (inv.location_id) setSelectedLocationId(inv.location_id);
    setRows((inv.items ?? []).map(i => ({
      key: uid(),
      product_id: i.product_id,
      description: i.description,
      quantity: String(i.quantity),
      unit_price: String(i.unit_price),
      discount: String(i.discount ?? 0),
    })));
    setLoadingEdit(false);
  }, [editId, fetchOne]);

  useEffect(() => { loadEdit(); }, [loadEdit]);

  const selectedCustomer = customers.find(c => c.id === customerId);
  const isEnterprise = selectedCustomer?.type === 'entreprise';

  useEffect(() => {
    setSelectedContactId('');
    setContactName('');
    setContactEmail('');
    setContactPhone('');
    if (!fetchCustomerContacts || !customerId || !isEnterprise) {
      setCustomerContacts([]);
      return;
    }
    fetchCustomerContacts(customerId).then(setCustomerContacts).catch(() => setCustomerContacts([]));
  }, [customerId, isEnterprise, fetchCustomerContacts]);

  function selectContact(contactId: string) {
    setSelectedContactId(contactId);
    if (!contactId) {
      setContactName('');
      setContactEmail('');
      setContactPhone('');
      return;
    }
    const c = customerContacts.find(c => c.id === contactId);
    if (c) {
      setContactName(c.name);
      setContactEmail(c.email);
      setContactPhone(c.phone);
    }
  }

  function handleTaxRateChange(value: string) {
    setTaxRate(value);
    const num = parseFloat(value);
    if (!isNaN(num) && num >= 0) localStorage.setItem('lastTaxRate', value);
  }

  function handleAirsiChange(value: string) {
    setAirsi(value);
    const num = parseFloat(value);
    if (!isNaN(num) && num >= 0) localStorage.setItem('lastAirsiRate', value);
  }

  function addRow() {
    setRows(r => [...r, { key: uid(), product_id: null, description: '', quantity: '1', unit_price: '', discount: '' }]);
  }

  function removeRow(key: string) {
    setRows(r => r.filter(x => x.key !== key));
  }

  function updateRow(key: string, patch: Partial<Row>) {
    setRows(r => r.map(x => (x.key === key ? { ...x, ...patch } : x)));
  }

  function selectProduct(key: string, productId: string) {
    const p = products.find(p => p.id === productId);
    if (!p) { updateRow(key, { product_id: null, description: '' }); return; }
    updateRow(key, { product_id: p.id, description: p.name, unit_price: String(p.price) });
  }

  function openQuickCreate(key: string) {
    setQuickTargetKey(key);
    setShowQuickCreate(true);
  }

  async function handleQuickCreate(input: QuickCreateInput) {
    if (!onCreateProduct) return;
    const id = await onCreateProduct({
      name: input.name, description: '', unit: input.unit,
      price: input.price, purchase_price: input.purchasePrice,
      stock_quantity: input.stockQuantity, stock_min: input.stockMin,
      track_stock: input.trackStock, active: true, family_id: input.familyId,
    });
    if (input.priceTypePrices.length && onSaveProductPrices) {
      await onSaveProductPrices(id, input.priceTypePrices);
    }
    if (quickTargetKey) {
      updateRow(quickTargetKey, { product_id: id, description: input.name, unit_price: String(input.price) });
    }
    setShowQuickCreate(false);
    setQuickTargetKey(null);
  }

  const ttc = rows.reduce((s, r) => {
    const q = parseFloat(r.quantity) || 0;
    const u = parseFloat(r.unit_price) || 0;
    const d = parseFloat(r.discount) || 0;
    return s + Math.max(q * u - d, 0);
  }, 0);
  const rate = parseFloat(taxRate) || 0;
  const airsiRate = parseFloat(airsi) || 0;
  const remiseAmt = parseFloat(remise) || 0;
  const totalTtc = Math.max(ttc - remiseAmt, 0);
  const divisor = 1 + (rate + airsiRate) / 100;
  const htBase = totalTtc / divisor;
  const taxAmt = totalTtc * (rate / (rate + airsiRate + 100));
  const airsiAmt = totalTtc * (airsiRate / (rate + airsiRate + 100));
  const ht = totalTtc - taxAmt - airsiAmt;
  const total = totalTtc;

  // Margin calculation
  const costTotal = rows.reduce((s, r) => {
    if (!r.product_id) return s;
    const p = products.find(pr => pr.id === r.product_id);
    if (!p) return s;
    const q = parseFloat(r.quantity) || 0;
    return s + q * (p.purchase_price || 0);
  }, 0);
  const margin = ht - costTotal;
  const marginPct = ht > 0 ? (margin / ht) * 100 : 0;

  function buildItems(): LineItemInput[] {
    return rows.map((r, i) => {
      const p = r.product_id ? products.find(pr => pr.id === r.product_id) : undefined;
      return {
        product_id: r.product_id,
        description: r.description.trim(),
        quantity: parseFloat(r.quantity) || 0,
        unit_price: parseFloat(r.unit_price) || 0,
        unit_cost: p ? Number(p.purchase_price) || 0 : 0,
        discount: parseFloat(r.discount) || 0,
        sort_order: i,
      };
    });
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setErr('');
    if (!customerId) { setErr('Sélectionnez un client.'); return; }
    const invLocationId = selectedLocationId || locationId || null;
    if (!invLocationId) { setErr('Sélectionnez une boutique.'); return; }
    const items = buildItems();
    if (items.length === 0 || items.every(i => !i.description)) { setErr('Ajoutez au moins une ligne.'); return; }
    if (items.some(i => i.description && i.unit_price < 0)) { setErr('Prix unitaire invalide.'); return; }
    const validItems = items.filter(i => i.description);
    const orderAdvanceNum = parseFloat(orderAdvance) || 0;
    setSaving(true);
    try {
      const input: CreateInvoiceInput = { customer_id: customerId, date, due_date: dueDate || null, tax_rate: rate, remise: remiseAmt, notes, items: validItems, location_id: invLocationId, order_number: orderNumber.trim() || null, order_advance: orderAdvanceNum, delivery_delay: deliveryDelay.trim() || null, payment_mode: paymentMode || null, contact_name: contactName.trim() || null, contact_email: contactEmail.trim() || null, contact_phone: contactPhone.trim() || null, airsi: airsiRate };
      let inv;
      if (editId && onUpdate) {
        await onUpdate(editId, input);
        onNavigate({ page: 'invoice-detail', id: editId });
        return;
      } else {
        inv = await onSave(input);
      }
      if (!isOnline) {
        onNavigate({ page: 'invoices' });
      } else {
        onNavigate({ page: 'invoice-detail', id: inv.id });
      }
    } catch (e) {
      setErr(e instanceof Error ? translateError(e.message) : 'Erreur lors de l\'enregistrement');
      setSaving(false);
    }
  }

  if (loadingEdit) return <div className="h-64 animate-pulse rounded-xl bg-gray-100/40" />;

  return (
    <>
    <form onSubmit={handleSave} className="space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button type="button" onClick={() => onNavigate({ page: 'invoices' })} className="rounded-lg p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-900 transition">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div>
          <h1 className="text-lg font-bold text-gray-900">{editId ? 'Modifier la facture' : 'Nouvelle facture'}</h1>
          <p className="text-sm text-gray-400">Remplissez les informations ci-dessous</p>
        </div>
      </div>

      {!isOnline && (
        <div className="flex items-center gap-2 rounded-lg bg-amber-50 px-4 py-2.5 text-sm text-amber-700 ring-1 ring-amber-200">
          <WifiOff className="h-4 w-4 shrink-0" />
          <span>Hors ligne — la facture sera enregistrée localement et synchronisée automatiquement dès le retour de la connexion.</span>
        </div>
      )}

      {/* Client + Dates */}
      <div className="rounded-xl border border-gray-200 bg-white p-5">
        <h2 className="mb-4 text-xs font-semibold uppercase tracking-wider text-gray-400">Informations</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2">
            <label className="label">Client *</label>
            <SearchableSelect
              value={customerId}
              onChange={setCustomerId}
              placeholder="— Sélectionner un client —"
              emptyOption="— Sélectionner un client —"
              options={customers.map(c => ({ value: c.id, label: c.name, sublabel: c.code ? c.code : undefined }))}
            />
          </div>
          <div>
            <label className="label">Date de facturation</label>
            <input type="date" className="input" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div>
            <label className="label">Date d'échéance</label>
            <input type="date" className="input" value={dueDate} onChange={e => setDueDate(e.target.value)} />
          </div>
        </div>
        {(!locationId && locations && locations.length > 0) && (
          <div className="mt-4">
            <label className="label">Boutique *</label>
            <select
              className="input"
              value={selectedLocationId}
              onChange={e => setSelectedLocationId(e.target.value)}
            >
              <option value="">— Sélectionner une boutique —</option>
              {locations.map(l => (
                <option key={l.id} value={l.id}>{l.name}</option>
              ))}
            </select>
          </div>
        )}

        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label className="label">Numéro de commande</label>
            <input type="text" className="input" value={orderNumber} onChange={e => setOrderNumber(e.target.value)} placeholder="Ex: CMD-2026-001" />
          </div>
          <div>
            <label className="label">Avance à la commande</label>
            <input type="number" step="any" min="0" className="input" value={orderAdvance} onChange={e => setOrderAdvance(e.target.value)} placeholder="0" />
          </div>
          <div>
            <label className="label">Délai de livraison</label>
            <input type="text" className="input" value={deliveryDelay} onChange={e => setDeliveryDelay(e.target.value)} placeholder="Ex: 3 jours" />
          </div>
          <div>
            <label className="label">Mode de paiement</label>
            <select className="input" value={paymentMode} onChange={e => setPaymentMode(e.target.value)}>
              <option value="">— Non précisé —</option>
              <option value="especes">Espèces</option>
              <option value="virement">Virement bancaire</option>
              <option value="cheque">Chèque</option>
              <option value="mobile_money">Mobile money</option>
              <option value="credit">Crédit</option>
            </select>
          </div>
        </div>

        {/* Interlocuteur */}
        {isEnterprise && customerContacts.length > 0 && (
          <div className="mt-4">
            <label className="label">Interlocuteur</label>
            <SearchableSelect
              value={selectedContactId}
              onChange={selectContact}
              placeholder="— Saisie manuelle (voir ci-dessous) —"
              emptyOption="— Saisie manuelle (voir ci-dessous) —"
              options={customerContacts.map(c => ({
                value: c.id,
                label: c.name,
                sublabel: [c.title, c.is_default ? 'Principal' : undefined].filter(Boolean).join(' — ') || undefined,
              }))}
            />
          </div>
        )}
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          <div>
            <label className="label">Interlocuteur — Nom</label>
            <input type="text" className="input" value={contactName} onChange={e => { setContactName(e.target.value); setSelectedContactId(''); }} placeholder="Nom du contact" />
          </div>
          <div>
            <label className="label">Interlocuteur — Email</label>
            <input type="email" className="input" value={contactEmail} onChange={e => { setContactEmail(e.target.value); setSelectedContactId(''); }} placeholder="contact@exemple.com" />
          </div>
          <div>
            <label className="label">Interlocuteur — Téléphone</label>
            <input type="tel" className="input" value={contactPhone} onChange={e => { setContactPhone(e.target.value); setSelectedContactId(''); }} placeholder="+xxx xx xx xx" />
          </div>
        </div>
      </div>
      <div className="rounded-xl border border-gray-200 bg-white">
        <div className="border-b border-gray-200 px-5 py-4">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-gray-400">Lignes de facturation</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-400 pl-5">Article / Description</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-400 w-28">Référence</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-400 w-24">Qté</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-400 w-32">Prix unit. TTC</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-400 w-28">Remise</th>
                <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-400 w-32">Total</th>
                <th className="w-10" />
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200/40">
              {rows.map((row, idx) => {
                const lineTotal = Math.max((parseFloat(row.quantity) || 0) * (parseFloat(row.unit_price) || 0) - (parseFloat(row.discount) || 0), 0);
                return (
                  <tr key={row.key}>
                    <td className="px-4 py-2 pl-5">
                      <div className="space-y-1.5">
                        <SearchableSelect
                          value={row.product_id ?? ''}
                          onChange={v => v ? selectProduct(row.key, v) : updateRow(row.key, { product_id: null })}
                          placeholder="— Article libre —"
                          emptyOption="— Article libre —"
                          size="sm"
                          options={products.filter(p => p.active).map(p => ({
                            value: p.id,
                            label: p.name,
                            sublabel: new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(p.price),
                          }))}
                        />
                        <input
                          className="w-full rounded border border-gray-300 bg-gray-100/50 px-2 py-1.5 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500"
                          value={row.description}
                          onChange={e => updateRow(row.key, { description: e.target.value })}
                          placeholder={`Description ligne ${idx + 1}`}
                        />
                      </div>
                    </td>
                    <td className="px-3 py-2">
                      <span className="text-xs font-mono text-gray-500">{row.product_id ? products.find(p => p.id === row.product_id)?.reference ?? '—' : '—'}</span>
                    </td>
                    <td className="px-3 py-2">
                      <input
                        type="number"
                        step="0.01"
                        min="0.01"
                        className="w-full rounded border border-gray-300 bg-gray-100/50 px-2 py-1.5 text-sm tabular-nums text-gray-800 outline-none focus:border-blue-500"
                        value={row.quantity}
                        onChange={e => updateRow(row.key, { quantity: e.target.value })}
                      />
                    </td>
                    <td className="px-3 py-2">
                      <input
                        type="number"
                        step="any"
                        min="0"
                        className="w-full rounded border border-gray-300 bg-gray-100/50 px-2 py-1.5 text-sm tabular-nums text-gray-800 outline-none focus:border-blue-500"
                        value={row.unit_price}
                        onChange={e => updateRow(row.key, { unit_price: e.target.value })}
                        placeholder="0"
                      />
                    </td>
                    <td className="px-3 py-2">
                      <input
                        type="number"
                        step="any"
                        min="0"
                        className="w-full rounded border border-gray-300 bg-gray-100/50 px-2 py-1.5 text-sm tabular-nums text-red-500 outline-none focus:border-blue-500"
                        value={row.discount}
                        onChange={e => updateRow(row.key, { discount: e.target.value })}
                        placeholder="0"
                      />
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums font-medium text-gray-800">
                      {fmt(lineTotal)}
                    </td>
                    <td className="px-2 py-2">
                      {rows.length > 1 && (
                        <button type="button" onClick={() => removeRow(row.key)} className="rounded p-1 text-gray-300 hover:text-red-400">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="border-t border-gray-200 p-4 pl-5 flex flex-wrap gap-4">
          <button
            type="button"
            onClick={addRow}
            className="flex items-center gap-1.5 text-sm text-blue-400 hover:text-blue-300"
          >
            <Plus className="h-4 w-4" /> Ajouter une ligne
          </button>
          {onCreateProduct && (
            <button
              type="button"
              onClick={() => openQuickCreate(rows[0]?.key ?? '')}
              className="flex items-center gap-1.5 text-sm text-emerald-500 hover:text-emerald-400"
            >
              <PackagePlus className="h-4 w-4" /> Créer un article
            </button>
          )}
        </div>
      </div>

      {/* Bottom: tax, notes, totals */}
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="rounded-xl border border-gray-200 bg-white p-5 space-y-4">
          <div>
            <label className="label">Taux de TVA (%)</label>
            <input type="number" step="any" min="0" max="100" className="input w-32" value={taxRate} onChange={e => handleTaxRateChange(e.target.value)} placeholder="0" />
          </div>
          <div>
            <label className="label">Taux AIRSI (%)</label>
            <input type="number" step="any" min="0" max="100" className="input w-32" value={airsi} onChange={e => handleAirsiChange(e.target.value)} placeholder="0" />
          </div>
          <div>
            <label className="label">Remise globale</label>
            <input type="number" step="any" min="0" className="input w-32" value={remise} onChange={e => setRemise(e.target.value)} placeholder="0" />
          </div>
          <div>
            <label className="label">Notes / Conditions</label>
            <textarea rows={3} className="input resize-none" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Conditions de paiement, remarques…" />
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <h3 className="mb-4 text-xs font-semibold uppercase tracking-wider text-gray-400">Récapitulatif</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-gray-500">
              <span>Total TTC</span>
              <span className="tabular-nums font-medium text-gray-800">{fmt(ttc)}</span>
            </div>
            {remiseAmt > 0 && (
              <div className="flex justify-between text-red-500">
                <span>Remise</span>
                <span className="tabular-nums font-medium">−{fmt(remiseAmt)}</span>
              </div>
            )}
            {rate > 0 && (
              <div className="flex justify-between text-gray-500">
                <span>TVA</span>
                <span className="tabular-nums font-medium text-gray-800">{fmt(taxAmt)}</span>
              </div>
            )}
            {airsiRate > 0 && (
              <div className="flex justify-between text-gray-500">
                <span>AIRSI</span>
                <span className="tabular-nums font-medium text-gray-800">{fmt(airsiAmt)}</span>
              </div>
            )}
            <div className="flex justify-between border-t border-gray-300 pt-2 text-base font-bold text-gray-900">
              <span>Total à payer (TTC)</span>
              <span className="tabular-nums">{fmt(total)}</span>
            </div>
            <div className="mt-3 space-y-1.5 rounded-lg bg-emerald-50 p-3 text-xs">
              <div className="flex justify-between text-gray-500">
                <span>Coût d'achat</span>
                <span className="tabular-nums">{fmt(costTotal)}</span>
              </div>
              <div className="flex justify-between font-semibold text-emerald-700">
                <span>Marge bénéficiaire</span>
                <span className="tabular-nums">{fmt(margin)} ({marginPct.toFixed(1)}%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {err && <p className="rounded-lg bg-red-950/50 px-4 py-3 text-sm text-red-400 ring-1 ring-red-900">{err}</p>}

      <div className="flex justify-end gap-3 pb-4">
        <button type="button" onClick={() => onNavigate({ page: 'invoices' })} className="rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100">
          Annuler
        </button>
        <button type="submit" disabled={saving} className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 active:scale-95 transition disabled:opacity-50">
          <Save className="h-4 w-4" />
          {saving ? 'Enregistrement…' : (editId ? 'Mettre à jour' : 'Créer la facture')}
        </button>
      </div>
    </form>

    {showQuickCreate && (
      <QuickCreateProductModal
        onClose={() => { setShowQuickCreate(false); setQuickTargetKey(null); }}
        onSave={handleQuickCreate}
        families={families ?? []}
        priceTypes={priceTypes ?? []}
      />
    )}
    </>
  );
}

interface QuickCreateInput {
  name: string;
  price: number;
  unit: string;
  purchasePrice: number;
  trackStock: boolean;
  stockQuantity: number;
  stockMin: number;
  familyId: string | null;
  priceTypePrices: { price_type_id: string; price: number }[];
}

function QuickCreateProductModal({ onClose, onSave, families, priceTypes }: {
  onClose: () => void;
  onSave: (input: QuickCreateInput) => Promise<void>;
  families: ProductFamily[];
  priceTypes: PriceType[];
}) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [unit, setUnit] = useState('pcs');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [trackStock, setTrackStock] = useState(false);
  const [stockQuantity, setStockQuantity] = useState('0');
  const [stockMin, setStockMin] = useState('0');
  const [familyId, setFamilyId] = useState('');
  const [ptPrices, setPtPrices] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const activePriceTypes = priceTypes.filter(pt => pt.active);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr('');
    if (!name.trim()) { setErr('Nom de l\'article requis.'); return; }
    const p = parseFloat(price) || 0;
    if (p < 0) { setErr('Prix invalide.'); return; }
    const priceTypePrices = activePriceTypes
      .map(pt => ({ price_type_id: pt.id, price: parseFloat(ptPrices[pt.id] ?? '') || 0 }))
      .filter(x => x.price > 0);
    setSaving(true);
    try {
      await onSave({
        name: name.trim(), price: p, unit: unit.trim() || 'pcs',
        purchasePrice: parseFloat(purchasePrice) || 0,
        trackStock, stockQuantity: parseFloat(stockQuantity) || 0,
        stockMin: parseFloat(stockMin) || 0,
        familyId: familyId || null, priceTypePrices,
      });
    } catch (e) {
      setErr(e instanceof Error ? translateError(e.message) : 'Erreur');
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <form onSubmit={submit} className="relative z-10 w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-gray-100 px-5 py-3.5">
          <h2 className="text-base font-bold text-gray-900">Créer un article</h2>
          <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-700"><X className="h-5 w-5" /></button>
        </div>
        <div className="space-y-4 p-5">
          <div>
            <label className="label">Nom de l'article *</label>
            <input autoFocus value={name} onChange={e => setName(e.target.value)} className="input" placeholder="Ex: Sac 25kg" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Prix de vente</label>
              <input type="number" step="any" min="0" value={price} onChange={e => setPrice(e.target.value)} className="input" placeholder="0" />
            </div>
            <div>
              <label className="label">Prix d'achat</label>
              <input type="number" step="any" min="0" value={purchasePrice} onChange={e => setPurchasePrice(e.target.value)} className="input" placeholder="0" />
            </div>
            <div>
              <label className="label">Unité</label>
              <input value={unit} onChange={e => setUnit(e.target.value)} className="input" placeholder="pcs" />
            </div>
            <div>
              <label className="label">Famille</label>
              <select value={familyId} onChange={e => setFamilyId(e.target.value)} className="input">
                <option value="">— Aucune —</option>
                {families.map(f => (
                  <option key={f.id} value={f.id}>{f.name}</option>
                ))}
              </select>
            </div>
          </div>

          <label className="flex items-center gap-2.5 cursor-pointer select-none">
            <input type="checkbox" checked={trackStock} onChange={e => setTrackStock(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500" />
            <span className="text-sm font-medium text-gray-700">Suivi de stock activé</span>
          </label>
          {trackStock && (
            <div className="grid grid-cols-2 gap-3 pl-6">
              <div>
                <label className="label">Quantité en stock</label>
                <input type="number" step="any" min="0" value={stockQuantity} onChange={e => setStockQuantity(e.target.value)} className="input" placeholder="0" />
              </div>
              <div>
                <label className="label">Stock minimum</label>
                <input type="number" step="any" min="0" value={stockMin} onChange={e => setStockMin(e.target.value)} className="input" placeholder="0" />
              </div>
            </div>
          )}

          {activePriceTypes.length > 0 && (
            <div className="space-y-2">
              <label className="label">Prix par type de tarif</label>
              <div className="space-y-2">
                {activePriceTypes.map(pt => (
                  <div key={pt.id} className="flex items-center gap-2">
                    <span className="w-28 shrink-0 text-xs font-medium text-gray-600">{pt.name}</span>
                    <input
                      type="number" step="any" min="0"
                      value={ptPrices[pt.id] ?? ''}
                      onChange={e => setPtPrices(prev => ({ ...prev, [pt.id]: e.target.value }))}
                      className="input flex-1" placeholder="0"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {err && <p className="text-sm text-red-500">{err}</p>}
        </div>
        <div className="flex justify-end gap-2 border-t border-gray-100 px-5 py-3.5">
          <button type="button" onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-600 hover:bg-gray-100">Annuler</button>
          <button type="submit" disabled={saving} className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 active:scale-95 transition disabled:opacity-50">
            {saving ? 'Création…' : 'Créer et ajouter'}
          </button>
        </div>
      </form>
    </div>
  );
}
