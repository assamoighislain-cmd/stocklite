import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ArrowLeft, Plus, Trash2, Save, Search, ShoppingCart, Minus, X, Utensils, FolderOpen } from 'lucide-react';
import type { Customer, CustomerContact, Product, Commercial, ProductFamily } from '../types';
import type { CreateOrderInput, LineItemInput } from '../hooks/useOrders';
import type { Route } from '../App';
import { translateError } from '../lib/translateError';
import { SearchableSelect } from './SearchableSelect';

interface OrderFormProps {
  customers: Customer[];
  products: Product[];
  commerciaux: Commercial[];
  families: ProductFamily[];
  preselectedCustomerId?: string;
  editId?: string;
  fetchOne?: (id: string) => Promise<import('../types').Order | null>;
  onSave: (input: CreateOrderInput) => Promise<import('../types').Order>;
  onUpdate?: (id: string, input: Partial<CreateOrderInput>) => Promise<void>;
  onNavigate: (r: Route) => void;
  defaultCommercialId?: string | null;
  fetchCustomerContacts?: (customerId: string) => Promise<CustomerContact[]>;
}

interface CartLine {
  key: string;
  id?: string;
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
}

function uid() { return Math.random().toString(36).slice(2); }
function today() { return new Date().toISOString().split('T')[0]; }
function fmtN(n: number) {
  return new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(n);
}

export function OrderForm({
  customers, products, commerciaux, families, preselectedCustomerId, editId, fetchOne, onSave, onUpdate, onNavigate, defaultCommercialId, fetchCustomerContacts,
}: OrderFormProps) {
  const [customerId, setCustomerId] = useState(preselectedCustomerId ?? '');
  const [commercialId, setCommercialId] = useState(defaultCommercialId ?? '');
  const [date, setDate] = useState(today());
  const [taxRate, setTaxRate] = useState('0');
  const [notes, setNotes] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [customerContacts, setCustomerContacts] = useState<CustomerContact[]>([]);
  const [selectedContactId, setSelectedContactId] = useState('');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [loadingEdit, setLoadingEdit] = useState(!!editId);
  const [activeFamilyId, setActiveFamilyId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCartMobile, setShowCartMobile] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);

  const activeProducts = useMemo(() => products.filter(p => p.active !== false), [products]);

  const familiesWithProducts = useMemo(() => {
    const map = new Map<string, Product[]>();
    for (const p of activeProducts) {
      const fid = p.family_id ?? '__none';
      const arr = map.get(fid) ?? [];
      arr.push(p);
      map.set(fid, arr);
    }
    return map;
  }, [activeProducts]);

  const familyTabs = useMemo(() => {
    const tabs: { id: string; name: string; color: string; count: number }[] = [];
    for (const fam of families.sort((a, b) => a.sort_order - b.sort_order)) {
      const prods = familiesWithProducts.get(fam.id);
      if (prods && prods.length > 0) {
        tabs.push({ id: fam.id, name: fam.name, color: fam.color, count: prods.length });
      }
    }
    const noneProds = familiesWithProducts.get('__none');
    if (noneProds && noneProds.length > 0) {
      tabs.push({ id: '__none', name: 'Autres', color: '#6b7280', count: noneProds.length });
    }
    return tabs;
  }, [families, familiesWithProducts]);

  useEffect(() => {
    if (familyTabs.length > 0 && activeFamilyId === null) {
      setActiveFamilyId(familyTabs[0].id);
    }
  }, [familyTabs, activeFamilyId]);

  const filteredProducts = useMemo(() => {
    let list = activeFamilyId
      ? (familiesWithProducts.get(activeFamilyId) ?? [])
      : activeProducts;
    const q = searchQuery.trim().toLowerCase();
    if (q) {
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        (p.reference ?? '').toLowerCase().includes(q)
      );
    }
    return list.sort((a, b) => a.name.localeCompare(b.name));
  }, [activeFamilyId, familiesWithProducts, activeProducts, searchQuery]);

  const loadEdit = useCallback(async () => {
    if (!editId || !fetchOne) return;
    const ord = await fetchOne(editId);
    if (!ord) return;
    setCustomerId(ord.customer_id);
    setCommercialId(ord.commercial_id ?? '');
    setDate(ord.date);
    setTaxRate(String(ord.tax_rate));
    setNotes(ord.notes);
    setContactName(ord.contact_name ?? '');
    setContactEmail(ord.contact_email ?? '');
    setContactPhone(ord.contact_phone ?? '');
    setCart((ord.items ?? []).map(i => ({
      key: uid(),
      id: i.id,
      product_id: i.product_id,
      description: i.description,
      quantity: i.quantity,
      unit_price: i.unit_price,
    })));
    setLoadingEdit(false);
  }, [editId, fetchOne]);

  useEffect(() => { loadEdit(); }, [loadEdit]);

  const selectedCustomer = customers.find(c => c.id === customerId);
  const isEnterprise = selectedCustomer?.type === 'entreprise';

  useEffect(() => {
    setSelectedContactId('');
    setContactName('');
    setContactEmail('');
    setContactPhone('');
    if (!fetchCustomerContacts || !customerId || !isEnterprise) {
      setCustomerContacts([]);
      return;
    }
    fetchCustomerContacts(customerId).then(setCustomerContacts).catch(() => setCustomerContacts([]));
  }, [customerId, isEnterprise, fetchCustomerContacts]);

  function selectContact(contactId: string) {
    setSelectedContactId(contactId);
    if (!contactId) {
      setContactName(''); setContactEmail(''); setContactPhone('');
      return;
    }
    const c = customerContacts.find(c => c.id === contactId);
    if (c) { setContactName(c.name); setContactEmail(c.email); setContactPhone(c.phone); }
  }

  function addToCart(product: Product) {
    setCart(prev => {
      const existing = prev.find(l => l.product_id === product.id);
      if (existing) {
        return prev.map(l => l.product_id === product.id ? { ...l, quantity: l.quantity + 1 } : l);
      }
      return [...prev, {
        key: uid(),
        product_id: product.id,
        description: product.name,
        quantity: 1,
        unit_price: product.price,
      }];
    });
  }

  function incrementQty(key: string) {
    setCart(prev => prev.map(l => l.key === key ? { ...l, quantity: l.quantity + 1 } : l));
  }
  function decrementQty(key: string) {
    setCart(prev => prev.map(l => {
      if (l.key !== key) return l;
      if (l.quantity <= 1) return null as unknown as CartLine;
      return { ...l, quantity: l.quantity - 1 };
    }).filter(Boolean) as CartLine[]);
  }
  function setQty(key: string, qty: number) {
    setCart(prev => prev.map(l => l.key === key ? { ...l, quantity: Math.max(1, qty) } : l));
  }
  function setPrice(key: string, price: number) {
    setCart(prev => prev.map(l => l.key === key ? { ...l, unit_price: Math.max(0, price) } : l));
  }
  function removeFromCart(key: string) {
    setCart(prev => prev.filter(l => l.key !== key));
  }

  const subtotal = cart.reduce((s, l) => s + l.quantity * l.unit_price, 0);
  const rate = parseFloat(taxRate) || 0;
  const taxAmt = subtotal * (rate / 100);
  const total = subtotal + taxAmt;
  const totalItems = cart.reduce((s, l) => s + l.quantity, 0);

  function buildItems(): LineItemInput[] {
    return cart.map((l, i) => ({
      id: l.id,
      product_id: l.product_id,
      description: l.description.trim(),
      quantity: l.quantity,
      unit_price: l.unit_price,
      sort_order: i,
    }));
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setErr('');
    if (!customerId) { setErr('Sélectionnez un client.'); return; }
    const items = buildItems();
    if (items.length === 0) { setErr('Ajoutez au moins un article.'); return; }
    setSaving(true);
    try {
      const input: CreateOrderInput = {
        customer_id: customerId,
        commercial_id: commercialId || null,
        date, tax_rate: rate, notes, items,
        contact_name: contactName.trim() || null,
        contact_email: contactEmail.trim() || null,
        contact_phone: contactPhone.trim() || null,
      };
      if (editId && onUpdate) {
        await onUpdate(editId, input);
        onNavigate({ page: 'orders' });
      } else {
        await onSave(input);
        onNavigate({ page: 'orders' });
      }
    } catch (e) {
      setErr(e instanceof Error ? translateError(e.message) : 'Erreur lors de l\'enregistrement');
      setSaving(false);
    }
  }

  if (loadingEdit) return <div className="h-64 animate-pulse rounded-xl bg-gray-100/40" />;

  const CartPanel = (
    <div className="flex h-full flex-col">
      <div className="border-b border-gray-200 px-4 py-3 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5 text-blue-600" />
            <h3 className="text-sm font-bold text-gray-900">Panier</h3>
            {totalItems > 0 && (
              <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-bold text-blue-700">{totalItems}</span>
            )}
          </div>
          {cart.length > 0 && (
            <button
              type="button"
              onClick={() => setCart([])}
              className="text-xs text-red-500 hover:text-red-600 font-medium"
            >
              Vider
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-2">
        {cart.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <ShoppingCart className="h-10 w-10 text-gray-200 mb-2" />
            <p className="text-sm text-gray-400">Panier vide</p>
            <p className="text-xs text-gray-300 mt-1">Cliquez sur un article pour l'ajouter</p>
          </div>
        ) : (
          <div className="space-y-2">
            {cart.map(line => {
              const prod = line.product_id ? activeProducts.find(p => p.id === line.product_id) : undefined;
              return (
                <div key={line.key} className="rounded-lg border border-gray-200 bg-white p-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">{line.description}</p>
                      {prod?.unit && <p className="text-[10px] text-gray-400">{prod.unit}</p>}
                    </div>
                    <button
                      type="button"
                      onClick={() => removeFromCart(line.key)}
                      className="rounded p-1 text-gray-300 hover:bg-red-50 hover:text-red-500 transition shrink-0"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => decrementQty(line.key)}
                        className="flex h-7 w-7 items-center justify-center rounded-md bg-gray-100 text-gray-600 hover:bg-gray-200 transition"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <input
                        type="number"
                        min="1"
                        value={line.quantity}
                        onChange={e => setQty(line.key, parseInt(e.target.value) || 1)}
                        className="w-12 rounded-md border border-gray-200 px-1 py-1 text-center text-sm font-semibold text-gray-800 outline-none focus:border-blue-500 tabular-nums"
                      />
                      <button
                        type="button"
                        onClick={() => incrementQty(line.key)}
                        className="flex h-7 w-7 items-center justify-center rounded-md bg-blue-100 text-blue-600 hover:bg-blue-200 transition"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min="0"
                        value={line.unit_price}
                        onChange={e => setPrice(line.key, parseFloat(e.target.value) || 0)}
                        className="w-20 rounded-md border border-gray-200 px-2 py-1 text-right text-sm font-medium text-gray-800 outline-none focus:border-blue-500 tabular-nums"
                      />
                      <span className="text-xs text-gray-400">F</span>
                    </div>
                  </div>
                  <div className="mt-1.5 text-right">
                    <span className="text-sm font-bold text-gray-900 tabular-nums">{fmtN(line.quantity * line.unit_price)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {cart.length > 0 && (
        <div className="border-t border-gray-200 px-4 py-3 shrink-0 space-y-2">
          <div className="flex justify-between text-sm text-gray-500">
            <span>Sous-total HT</span>
            <span className="tabular-nums font-medium text-gray-800">{fmtN(subtotal)}</span>
          </div>
          {rate > 0 && (
            <div className="flex justify-between text-sm text-gray-500">
              <span>TVA ({rate}%)</span>
              <span className="tabular-nums font-medium text-gray-800">{fmtN(taxAmt)}</span>
            </div>
          )}
          <div className="flex justify-between border-t border-gray-300 pt-2 text-base font-bold text-gray-900">
            <span>Total</span>
            <span className="tabular-nums">{fmtN(total)}</span>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <form onSubmit={handleSave} className="flex h-[calc(100vh-3.5rem)] flex-col lg:flex-row gap-0">
      {/* Left: Products area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-200 bg-white shrink-0">
          <button type="button" onClick={() => onNavigate({ page: 'orders' })} className="rounded-lg p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-900 transition">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-lg font-bold text-gray-900 truncate">{editId ? 'Modifier la commande' : 'Nouvelle commande'}</h1>
            <p className="text-xs text-gray-400">{totalItems} article{totalItems !== 1 ? 's' : ''} dans le panier</p>
          </div>
          {/* Mobile cart toggle */}
          <button
            type="button"
            onClick={() => setShowCartMobile(v => !v)}
            className="lg:hidden flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-2 text-xs font-semibold text-white"
          >
            <ShoppingCart className="h-4 w-4" />
            {totalItems > 0 && <span className="rounded-full bg-white/20 px-1.5 text-[10px]">{totalItems}</span>}
          </button>
        </div>

        {/* Customer bar */}
        <div className="border-b border-gray-200 bg-gray-50 px-4 py-2.5 shrink-0">
          <div className="grid gap-2 sm:grid-cols-3">
            <div className="sm:col-span-1">
              <label className="block text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-0.5">Client *</label>
              <SearchableSelect
                value={customerId}
                onChange={setCustomerId}
                placeholder="— Sélectionner —"
                emptyOption="— Sélectionner un client —"
                options={customers.map(c => ({ value: c.id, label: c.name, sublabel: c.code ? c.code : undefined }))}
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-0.5">Commercial</label>
              <select className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-700 outline-none focus:border-blue-500" value={commercialId} onChange={e => setCommercialId(e.target.value)}>
                <option value="">— Aucun —</option>
                {commerciaux.filter(c => c.active).map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-0.5">Date</label>
              <input type="date" className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-700 outline-none focus:border-blue-500" value={date} onChange={e => setDate(e.target.value)} />
            </div>
          </div>
        </div>

        {/* Search + family tabs */}
        <div className="border-b border-gray-200 bg-white px-4 py-2.5 shrink-0">
          <div className="relative mb-2.5">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              ref={searchRef}
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Rechercher un article…"
              className="w-full rounded-lg border border-gray-200 bg-gray-50 py-2 pl-9 pr-9 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500 focus:bg-white transition"
            />
            {searchQuery && (
              <button type="button" onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          {!searchQuery && familyTabs.length > 0 && (
            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {familyTabs.map(tab => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveFamilyId(tab.id)}
                  className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition ${
                    activeFamilyId === tab.id
                      ? 'text-white shadow-sm'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  style={activeFamilyId === tab.id ? { backgroundColor: tab.color } : undefined}
                >
                  {tab.id === '__none' ? <FolderOpen className="h-3.5 w-3.5" /> : <Utensils className="h-3.5 w-3.5" />}
                  {tab.name}
                  <span className={`rounded-full px-1.5 py-0.5 text-[9px] font-bold ${activeFamilyId === tab.id ? 'bg-white/20' : 'bg-gray-200'}`}>{tab.count}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product grid */}
        <div className="flex-1 overflow-y-auto bg-gray-50 p-4">
          {filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Search className="h-10 w-10 text-gray-200 mb-2" />
              <p className="text-sm text-gray-400">Aucun article trouvé</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
              {filteredProducts.map(product => {
                const fam = product.family_id ? families.find(f => f.id === product.family_id) : undefined;
                const inCart = cart.find(l => l.product_id === product.id);
                return (
                  <button
                    key={product.id}
                    type="button"
                    onClick={() => addToCart(product)}
                    className="group relative flex flex-col rounded-xl border border-gray-200 bg-white p-3 text-left shadow-sm transition hover:border-blue-300 hover:shadow-md active:scale-95"
                  >
                    {fam?.color && (
                      <div className="absolute top-0 left-0 h-1 w-full rounded-t-xl" style={{ backgroundColor: fam.color }} />
                    )}
                    {inCart && (
                      <span className="absolute top-2 right-2 flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white shadow-sm">
                        {inCart.quantity}
                      </span>
                    )}
                    {product.photo_url ? (
                      <img src={product.photo_url} alt={product.name} className="mb-2 h-16 w-full rounded-lg object-cover" />
                    ) : (
                      <div className="mb-2 flex h-16 w-full items-center justify-center rounded-lg bg-gray-100">
                        <Utensils className="h-7 w-7 text-gray-300" />
                      </div>
                    )}
                    <p className="text-sm font-medium text-gray-900 line-clamp-2 leading-tight">{product.name}</p>
                    {product.reference && <p className="text-[10px] text-gray-400 mt-0.5">{product.reference}</p>}
                    <p className="mt-1.5 text-sm font-bold text-blue-600 tabular-nums">{fmtN(product.price)}</p>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Right: Cart panel (desktop sidebar, mobile overlay) */}
      <div className="hidden lg:flex w-80 xl:w-96 shrink-0 border-l border-gray-200 bg-white flex-col">
        {CartPanel}
        <div className="border-t border-gray-200 px-4 py-3 shrink-0 space-y-2">
          {/* Notes */}
          <input
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="Notes (optionnel)…"
            className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-700 outline-none focus:border-blue-500"
          />
          {/* Tax */}
          <div className="flex items-center gap-2">
            <label className="text-xs text-gray-500 shrink-0">TVA %</label>
            <input
              type="number"
              step="any"
              min="0"
              max="100"
              value={taxRate}
              onChange={e => setTaxRate(e.target.value)}
              className="w-20 rounded-lg border border-gray-200 px-2 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-500 tabular-nums"
            />
          </div>
          {err && <p className="rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{err}</p>}
          <button
            type="submit"
            disabled={saving || cart.length === 0 || !customerId}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 text-sm font-bold text-white hover:bg-blue-500 active:scale-95 transition disabled:opacity-50"
          >
            <Save className="h-4 w-4" />
            {saving ? 'Enregistrement…' : (editId ? 'Mettre à jour' : 'Créer la commande')}
          </button>
        </div>
      </div>

      {/* Mobile cart overlay */}
      {showCartMobile && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowCartMobile(false)} />
          <div className="relative z-10 ml-auto flex h-full w-80 max-w-[85%] flex-col bg-white shadow-xl">
            {CartPanel}
            <div className="border-t border-gray-200 px-4 py-3 shrink-0 space-y-2">
              <input
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Notes…"
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-700 outline-none focus:border-blue-500"
              />
              <div className="flex items-center gap-2">
                <label className="text-xs text-gray-500 shrink-0">TVA %</label>
                <input type="number" step="any" min="0" max="100" value={taxRate} onChange={e => setTaxRate(e.target.value)}
                  className="w-20 rounded-lg border border-gray-200 px-2 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-500 tabular-nums" />
              </div>
              {err && <p className="rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{err}</p>}
              <button
                type="submit"
                disabled={saving || cart.length === 0 || !customerId}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 text-sm font-bold text-white hover:bg-blue-500 active:scale-95 transition disabled:opacity-50"
              >
                <Save className="h-4 w-4" />
                {saving ? 'Enregistrement…' : (editId ? 'Mettre à jour' : 'Créer la commande')}
              </button>
            </div>
          </div>
        </div>
      )}
    </form>
  );
}
