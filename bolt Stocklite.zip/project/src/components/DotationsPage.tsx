import { useState, useMemo } from 'react';
import {
  Gift, Plus, Trash2, Search, X, Package, MapPin, ChevronDown, ChevronRight,
  AlertTriangle, FileText, Settings2, Printer, BarChart3,
} from 'lucide-react';
import { fmtQty } from '../lib/format';
import type { Product, SalesLocation, Service, Dotation } from '../types';
import type { CreateDotationInput } from '../hooks/useDotations';
import { translateError } from '../lib/translateError';
import { printDocument } from '../lib/printEngine';

interface Props {
  products: Product[];
  locations: SalesLocation[];
  services: Service[];
  dotations: Dotation[];
  loading: boolean;
  activeLocationId: string | null;
  onSaveService: (payload: { name: string; location_id: string; sort_order?: number }, id?: string) => Promise<void>;
  onRemoveService: (id: string) => Promise<void>;
  onCreateDotation: (input: CreateDotationInput) => Promise<Dotation>;
  onAfterDotation: () => void;
}

interface DraftItem {
  product_id: string;
  quantity: string;
  unit_cost: string;
}

function fmt(n: number) {
  return fmtQty(n);
}

function fmtMoney(n: number, currency: string) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(n) + ' ' + currency;
}

function fmtDate(d: string) {
  return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(d));
}

export default function DotationsPage({
  products, locations, services, dotations, loading, activeLocationId,
  onSaveService, onRemoveService, onCreateDotation, onAfterDotation,
}: Props) {
  const [tab, setTab] = useState<'dotations' | 'synthese' | 'services'>('dotations');
  const [showDotationForm, setShowDotationForm] = useState(false);
  const [showServiceForm, setShowServiceForm] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [periodStart, setPeriodStart] = useState('');
  const [periodEnd, setPeriodEnd] = useState('');

  const currency = 'FCFA';

  const trackedProducts = useMemo(() => products.filter(p => p.active), [products]);
  const activeLocations = locations.filter(l => l.active);

  const periodFilteredDotations = useMemo(() => {
    if (!periodStart && !periodEnd) return dotations;
    return dotations.filter(d => {
      const dDate = new Date(d.created_at);
      if (periodStart && dDate < new Date(periodStart + 'T00:00:00')) return false;
      if (periodEnd && dDate > new Date(periodEnd + 'T23:59:59')) return false;
      return true;
    });
  }, [dotations, periodStart, periodEnd]);

  const syntheseRows = useMemo(() => {
    const map = new Map<string, { product_id: string; product_name: string; unit: string; totalQty: number; totalCost: number; count: number }>();
    for (const d of periodFilteredDotations) {
      for (const it of (d.items ?? [])) {
        const key = it.product_id;
        const existing = map.get(key);
        if (existing) {
          existing.totalQty += Number(it.quantity);
          existing.totalCost += Number(it.quantity) * Number(it.unit_cost);
          existing.count += 1;
        } else {
          map.set(key, {
            product_id: it.product_id,
            product_name: it.product?.name ?? it.product_id,
            unit: it.product?.unit ?? '',
            totalQty: Number(it.quantity),
            totalCost: Number(it.quantity) * Number(it.unit_cost),
            count: 1,
          });
        }
      }
    }
    return [...map.values()].sort((a, b) => b.totalQty - a.totalQty);
  }, [periodFilteredDotations]);

  const syntheseServices = useMemo(() => {
    const map = new Map<string, { service_id: string; service_name: string; location_name: string; totalQty: number; totalCost: number; count: number; effectif: number }>();
    for (const d of periodFilteredDotations) {
      const key = d.service_id;
      const itemQty = (d.items ?? []).reduce((s, it) => s + Number(it.quantity), 0);
      const itemCost = (d.items ?? []).reduce((s, it) => s + Number(it.quantity) * Number(it.unit_cost), 0);
      const existing = map.get(key);
      if (existing) {
        existing.totalQty += itemQty;
        existing.totalCost += itemCost;
        existing.count += 1;
        existing.effectif += d.effectif;
      } else {
        map.set(key, {
          service_id: d.service_id,
          service_name: d.service?.name ?? '—',
          location_name: d.location?.name ?? '—',
          totalQty: itemQty,
          totalCost: itemCost,
          count: 1,
          effectif: d.effectif,
        });
      }
    }
    return [...map.values()].sort((a, b) => b.totalCost - a.totalCost);
  }, [periodFilteredDotations]);

  const syntheseServiceItems = useMemo(() => {
    const map = new Map<string, { product_id: string; product_name: string; unit: string; totalQty: number; totalCost: number; count: number }[]>();
    for (const d of periodFilteredDotations) {
      const svcKey = d.service_id;
      const arr = map.get(svcKey) ?? [];
      const itemMap = new Map<string, { product_id: string; product_name: string; unit: string; totalQty: number; totalCost: number; count: number }>();
      for (const existing of arr) itemMap.set(existing.product_id, existing);
      for (const it of (d.items ?? [])) {
        const existing = itemMap.get(it.product_id);
        if (existing) {
          existing.totalQty += Number(it.quantity);
          existing.totalCost += Number(it.quantity) * Number(it.unit_cost);
          existing.count += 1;
        } else {
          itemMap.set(it.product_id, {
            product_id: it.product_id,
            product_name: it.product?.name ?? it.product_id,
            unit: it.product?.unit ?? '',
            totalQty: Number(it.quantity),
            totalCost: Number(it.quantity) * Number(it.unit_cost),
            count: 1,
          });
        }
      }
      map.set(svcKey, [...itemMap.values()].sort((a, b) => b.totalQty - a.totalQty));
    }
    return map;
  }, [periodFilteredDotations]);

  const syntheseTotals = useMemo(() => {
    const totalQty = syntheseRows.reduce((s, r) => s + r.totalQty, 0);
    const totalCost = syntheseRows.reduce((s, r) => s + r.totalCost, 0);
    const totalDotations = periodFilteredDotations.length;
    return { totalQty, totalCost, totalDotations };
  }, [syntheseRows, periodFilteredDotations]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Dotations</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Dotation d'articles de la boutique vers un ou plusieurs services
          </p>
        </div>
        {tab === 'dotations' ? (
          <button
            onClick={() => setShowDotationForm(true)}
            disabled={activeLocations.length === 0 || services.length === 0}
            className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95 disabled:opacity-50"
          >
            <Plus className="h-4 w-4" />
            Nouvelle dotation
          </button>
        ) : (
          <button
            onClick={() => setShowServiceForm(true)}
            disabled={activeLocations.length === 0}
            className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition active:scale-95 disabled:opacity-50"
          >
            <Plus className="h-4 w-4" />
            Nouveau service
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-gray-200">
        {(['dotations', 'synthese', 'services'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 transition ${
              tab === t
                ? 'border-blue-600 text-blue-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            {t === 'dotations' ? `Dotations (${dotations.length})` : t === 'synthese' ? 'Synthèse' : `Services (${services.length})`}
          </button>
        ))}
      </div>

      {tab === 'services' ? (
        <ServicesTab
          services={services}
          locations={locations}
          loading={loading}
          onRemove={onRemoveService}
        />
      ) : tab === 'synthese' ? (
        <SyntheseTab
          dotations={periodFilteredDotations}
          syntheseRows={syntheseRows}
          syntheseServices={syntheseServices}
          syntheseServiceItems={syntheseServiceItems}
          totals={syntheseTotals}
          periodStart={periodStart}
          periodEnd={periodEnd}
          setPeriodStart={setPeriodStart}
          setPeriodEnd={setPeriodEnd}
          currency={currency}
        />
      ) : (
        <DotationsTab
          dotations={dotations}
          loading={loading}
          expanded={expanded}
          setExpanded={setExpanded}
          search={search}
          setSearch={setSearch}
          currency={currency}
        />
      )}

      {/* Dotation form modal */}
      {showDotationForm && (
        <DotationFormModal
          products={trackedProducts}
          locations={activeLocations}
          services={services}
          defaultLocationId={activeLocationId}
          onClose={() => setShowDotationForm(false)}
          onSubmit={async (input) => {
            await onCreateDotation(input);
            onAfterDotation();
            setShowDotationForm(false);
          }}
          currency={currency}
        />
      )}

      {/* Service form modal */}
      {showServiceForm && (
        <ServiceFormModal
          locations={activeLocations}
          defaultLocationId={activeLocationId}
          onClose={() => setShowServiceForm(false)}
          onSubmit={async (payload) => {
            await onSaveService(payload);
            setShowServiceForm(false);
          }}
        />
      )}
    </div>
  );
}

// ── Dotations tab ──
function DotationsTab({ dotations, loading, expanded, setExpanded, search, setSearch, currency }: {
  dotations: Dotation[];
  loading: boolean;
  expanded: string | null;
  setExpanded: (id: string | null) => void;
  search: string;
  setSearch: (s: string) => void;
  currency: string;
}) {
  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return dotations;
    return dotations.filter(d =>
      d.dotation_number.toLowerCase().includes(q) ||
      d.service?.name?.toLowerCase().includes(q) ||
      d.location?.name?.toLowerCase().includes(q) ||
      d.notes?.toLowerCase().includes(q)
    );
  }, [dotations, search]);

  if (loading) {
    return <div className="space-y-2">{[...Array(4)].map((_, i) => <div key={i} className="h-16 rounded-xl bg-gray-100 animate-pulse" />)}</div>;
  }

  if (dotations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-300 py-16 text-center">
        <Gift className="h-10 w-10 text-gray-300 mb-3" />
        <p className="text-sm font-medium text-gray-400">Aucune dotation</p>
        <p className="text-xs text-gray-400 mt-1">Créez une dotation pour transférer des articles vers un service.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Rechercher une dotation…"
          className="w-full rounded-lg border border-gray-200 bg-white pl-9 pr-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 transition"
        />
      </div>

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white divide-y divide-gray-100">
        {filtered.map(d => {
          const isOpen = expanded === d.id;
          const totalQty = (d.items ?? []).reduce((s, i) => s + Number(i.quantity), 0);
          const totalCost = (d.items ?? []).reduce((s, i) => s + Number(i.quantity) * Number(i.unit_cost), 0);
          return (
            <div key={d.id}>
              <button
                onClick={() => setExpanded(isOpen ? null : d.id)}
                className="w-full px-5 py-4 flex items-start justify-between gap-4 hover:bg-gray-50 transition text-left"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="h-9 w-9 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
                    <Gift className="h-4 w-4 text-blue-600" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-gray-900">{d.dotation_number}</p>
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mt-0.5 flex-wrap">
                      <span className="font-medium text-gray-700">{d.service?.name ?? '—'}</span>
                      <span className="text-gray-300">·</span>
                      <MapPin className="h-3 w-3" />
                      <span>{d.location?.name ?? '—'}</span>
                      <span className="text-gray-300">·</span>
                      <span>{fmtQty(totalQty)} article{totalQty > 1 ? 's' : ''}</span>
                      {d.effectif > 0 && (
                        <>
                          <span className="text-gray-300">·</span>
                          <span className="font-medium text-emerald-600">{d.effectif} pers.</span>
                        </>
                      )}
                    </div>
                    {d.notes && <p className="text-xs text-gray-400 mt-0.5 flex items-center gap-1"><FileText className="h-3 w-3" />{d.notes}</p>}
                  </div>
                </div>
                <div className="shrink-0 text-right flex items-center gap-2">
                  <div>
                    <p className="text-xs font-semibold text-gray-700">{fmtMoney(totalCost, currency)}</p>
                    <p className="text-[10px] text-gray-400">{fmtDate(d.created_at)}</p>
                  </div>
                  {isOpen ? <ChevronDown className="h-4 w-4 text-gray-400" /> : <ChevronRight className="h-4 w-4 text-gray-400" />}
                </div>
              </button>
              {isOpen && (d.items ?? []).length > 0 && (
                <div className="px-5 pb-4 bg-gray-50/50">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-gray-200 text-left text-gray-500">
                        <th className="py-2 font-semibold">Article</th>
                        <th className="py-2 font-semibold text-right">Quantité</th>
                        <th className="py-2 font-semibold text-right">Coût unit.</th>
                        <th className="py-2 font-semibold text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {d.items!.map(it => (
                        <tr key={it.id} className="text-gray-700">
                          <td className="py-2 font-medium">{it.product?.name ?? it.product_id}</td>
                          <td className="py-2 text-right tabular-nums">{fmt(Number(it.quantity))} {it.product?.unit ?? ''}</td>
                          <td className="py-2 text-right tabular-nums">{fmtMoney(Number(it.unit_cost), currency)}</td>
                          <td className="py-2 text-right tabular-nums font-medium">{fmtMoney(Number(it.quantity) * Number(it.unit_cost), currency)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Synthese tab ──
function SyntheseTab({ dotations, syntheseRows, syntheseServices, syntheseServiceItems, totals, periodStart, periodEnd, setPeriodStart, setPeriodEnd, currency }: {
  dotations: Dotation[];
  syntheseRows: { product_id: string; product_name: string; unit: string; totalQty: number; totalCost: number; count: number }[];
  syntheseServices: { service_id: string; service_name: string; location_name: string; totalQty: number; totalCost: number; count: number; effectif: number }[];
  syntheseServiceItems: Map<string, { product_id: string; product_name: string; unit: string; totalQty: number; totalCost: number; count: number }[]>;
  totals: { totalQty: number; totalCost: number; totalDotations: number };
  periodStart: string;
  periodEnd: string;
  setPeriodStart: (s: string) => void;
  setPeriodEnd: (s: string) => void;
  currency: string;
}) {
  const [expandedSvc, setExpandedSvc] = useState<string | null>(null);
  const [printing, setPrinting] = useState(false);
  async function printSynthese() {
    const now = new Date().toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' });
    const periodLabel = periodStart || periodEnd
      ? `${periodStart ? new Date(periodStart).toLocaleDateString('fr-FR') : '…'} → ${periodEnd ? new Date(periodEnd).toLocaleDateString('fr-FR') : '…'}`
      : 'Toutes les périodes';
    const rows = syntheseRows.map((r, i) => `<tr>
      <td style="text-align:center">${i + 1}</td>
      <td>${r.product_name}</td>
      <td style="text-align:center">${r.unit || '—'}</td>
      <td style="text-align:right">${fmtQty(r.totalQty)}</td>
      <td style="text-align:center">${r.count}</td>
      <td style="text-align:right">${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(r.totalCost)} ${currency}</td>
    </tr>`).join('');
    const svcRows = syntheseServices.map((s, i) => {
      const items = syntheseServiceItems.get(s.service_id) ?? [];
      const itemRows = items.map(it => `<tr style="background:#fafafa">
        <td style="padding:4px 6px 4px 24px">↳ ${it.product_name}</td>
        <td style="text-align:center">${it.unit || '—'}</td>
        <td></td><td></td>
        <td style="text-align:right">${fmtQty(it.totalQty)}</td>
        <td style="text-align:center">${it.count}</td>
        <td style="text-align:right">${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(it.totalCost)} ${currency}</td>
      </tr>`).join('');
      return `<tr>
        <td style="text-align:center">${i + 1}</td>
        <td style="font-weight:600">${s.service_name}</td>
        <td>${s.location_name}</td>
        <td style="text-align:center">${s.effectif || '—'}</td>
        <td style="text-align:center">${s.count}</td>
        <td style="text-align:right">${fmtQty(s.totalQty)}</td>
        <td style="text-align:right">${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(s.totalCost)} ${currency}</td>
      </tr>${itemRows}`;
    }).join('');
    const html = `<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'Segoe UI',Arial,sans-serif;color:#1f2937;padding:24px;font-size:12px}
      h1{font-size:20px;margin-bottom:4px}
      h2{font-size:14px;margin-top:20px;margin-bottom:8px;color:#374151}
      .meta{color:#6b7280;font-size:11px;margin-bottom:16px}
      .info{display:flex;gap:24px;margin-bottom:16px;font-size:11px}
      .info span{color:#374151}
      .info b{color:#111827}
      table{width:100%;border-collapse:collapse;margin-bottom:8px}
      th{background:#f3f4f6;padding:8px 6px;font-size:10px;text-transform:uppercase;letter-spacing:.5px;color:#6b7280;border-bottom:2px solid #e5e7eb}
      td{padding:6px;border-bottom:1px solid #f3f4f6}
      tbody tr:nth-child(even){background:#fafafa}
      .footer{margin-top:18px;padding-top:10px;border-top:1px solid #e5e7eb;font-size:10px;color:#9ca3af;display:flex;justify-content:space-between}
      .spacer{height:40px}
      .print-btn{position:fixed;top:16px;right:16px;padding:10px 20px;background:#1f2937;color:#fff;border:none;border-radius:8px;font-size:14px;cursor:pointer;font-weight:600}
      .print-btn:hover{background:#374151}
      @media print{body{padding:0}.print-btn{display:none}}
    </style></head><body>
      <button class="print-btn" onclick="window.print()">Imprimer / PDF</button>
      <h1>Synthèse des dotations</h1>
      <div class="meta">Édité le ${now}</div>
      <div class="info">
        <span>Période : <b>${periodLabel}</b></span>
        <span>Dotations : <b>${totals.totalDotations}</b></span>
        <span>Articles total : <b>${fmtQty(totals.totalQty)}</b></span>
        <span>Coût total : <b>${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(totals.totalCost)} ${currency}</b></span>
      </div>
      <h2>Synthèse par service (articles détaillés)</h2>
      <table>
        <thead><tr>
          <th style="text-align:center">#</th>
          <th>Service / Article</th>
          <th>Boutique</th>
          <th style="text-align:center">Effectif</th>
          <th style="text-align:center">Nb dotations</th>
          <th style="text-align:right">Qté totale</th>
          <th style="text-align:right">Coût total</th>
        </tr></thead>
        <tbody>${svcRows || '<tr><td colspan="7" style="text-align:center;padding:20px;color:#9ca3af">Aucune donnée</td></tr>'}</tbody>
      </table>
      <h2>Synthèse par article</h2>
      <table>
        <thead><tr>
          <th style="text-align:center">#</th>
          <th>Article</th>
          <th style="text-align:center">Unité</th>
          <th style="text-align:right">Qté totale</th>
          <th style="text-align:center">Nb dotations</th>
          <th style="text-align:right">Coût total</th>
        </tr></thead>
        <tbody>${rows || '<tr><td colspan="6" style="text-align:center;padding:20px;color:#9ca3af">Aucune donnée</td></tr>'}</tbody>
      </table>
      <div class="footer"><span>Synthèse au ${now}</span><span>${syntheseRows.length} article(s) · ${syntheseServices.length} service(s)</span></div>
      <div class="spacer"></div>
    </body></html>`;
    try {
      setPrinting(true);
      printDocument(html, { format: 'a4', title: 'Synthèse des dotations' });
    } finally {
      setPrinting(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* Period filter */}
      <div className="flex flex-wrap items-end gap-3 rounded-xl border border-gray-200 bg-white p-4">
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Du</label>
          <input
            type="date"
            value={periodStart}
            onChange={e => setPeriodStart(e.target.value)}
            className="rounded-lg border border-gray-200 bg-gray-50 px-3 py-2 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Au</label>
          <input
            type="date"
            value={periodEnd}
            onChange={e => setPeriodEnd(e.target.value)}
            className="rounded-lg border border-gray-200 bg-gray-50 px-3 py-2 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
          />
        </div>
        {(periodStart || periodEnd) && (
          <button
            onClick={() => { setPeriodStart(''); setPeriodEnd(''); }}
            className="text-xs font-medium text-gray-500 hover:text-gray-700 underline"
          >
            Effacer
          </button>
        )}
        <button
          onClick={printSynthese}
          disabled={syntheseRows.length === 0 || printing}
          className="ml-auto flex items-center gap-1.5 rounded-lg bg-gray-800 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-700 transition disabled:opacity-50"
        >
          <Printer className="h-4 w-4" />
          {printing ? 'Génération…' : 'Imprimer'}
        </button>
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Dotations</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{totals.totalDotations}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Quantité totale</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{fmtQty(totals.totalQty)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">Coût total</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{fmtMoney(totals.totalCost, currency)}</p>
        </div>
      </div>

      {/* Service aggregation table with expandable article detail */}
      <div>
        <h3 className="text-sm font-bold text-gray-700 mb-2 flex items-center gap-1.5">
          <Settings2 className="h-4 w-4 text-gray-500" />
          Synthèse par service (cliquez pour voir les articles)
        </h3>
        {syntheseServices.length === 0 ? (
          <div className="rounded-xl border border-dashed border-gray-300 py-8 text-center text-sm text-gray-400">Aucun service pour cette période.</div>
        ) : (
          <div className="overflow-hidden rounded-xl border border-gray-200 divide-y divide-gray-100">
            {syntheseServices.map(s => {
              const isOpen = expandedSvc === s.service_id;
              const items = syntheseServiceItems.get(s.service_id) ?? [];
              return (
                <div key={s.service_id}>
                  <button
                    onClick={() => setExpandedSvc(isOpen ? null : s.service_id)}
                    className="w-full px-5 py-3.5 flex items-center justify-between gap-4 hover:bg-gray-50 transition text-left"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-8 w-8 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
                        <Settings2 className="h-4 w-4 text-emerald-600" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-gray-800">{s.service_name}</p>
                        <div className="flex items-center gap-1.5 text-xs text-gray-500 mt-0.5 flex-wrap">
                          <MapPin className="h-3 w-3" />
                          <span>{s.location_name}</span>
                          <span className="text-gray-300">·</span>
                          <span>{s.count} dotation{s.count > 1 ? 's' : ''}</span>
                          {s.effectif > 0 && (<><span className="text-gray-300">·</span><span className="text-emerald-600">{s.effectif} pers.</span></>)}
                          <span className="text-gray-300">·</span>
                          <span>{items.length} article{items.length > 1 ? 's' : ''}</span>
                        </div>
                      </div>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <div className="text-right">
                        <p className="text-sm font-bold text-gray-900">{fmtQty(s.totalQty)}</p>
                        <p className="text-xs font-semibold text-gray-600">{fmtMoney(s.totalCost, currency)}</p>
                      </div>
                      {isOpen ? <ChevronDown className="h-4 w-4 text-gray-400" /> : <ChevronRight className="h-4 w-4 text-gray-400" />}
                    </div>
                  </button>
                  {isOpen && items.length > 0 && (
                    <div className="px-5 pb-4 bg-gray-50/50">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-gray-200 text-left text-gray-500">
                            <th className="py-2 font-semibold">Article</th>
                            <th className="py-2 font-semibold text-center">Unité</th>
                            <th className="py-2 font-semibold text-right">Qté totale</th>
                            <th className="py-2 font-semibold text-center">Nb fois</th>
                            <th className="py-2 font-semibold text-right">Coût total</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                          {items.map(it => (
                            <tr key={it.product_id} className="text-gray-700">
                              <td className="py-2 font-medium">{it.product_name}</td>
                              <td className="py-2 text-center text-gray-500">{it.unit || '—'}</td>
                              <td className="py-2 text-right tabular-nums font-semibold">{fmtQty(it.totalQty)} {it.unit}</td>
                              <td className="py-2 text-center tabular-nums text-gray-500">{it.count}</td>
                              <td className="py-2 text-right tabular-nums font-medium">{fmtMoney(it.totalCost, currency)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Article aggregation table */}
      <div>
        <h3 className="text-sm font-bold text-gray-700 mb-2 flex items-center gap-1.5">
          <Package className="h-4 w-4 text-gray-500" />
          Synthèse par article
        </h3>
        {syntheseRows.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-300 py-12 text-center">
            <BarChart3 className="h-10 w-10 text-gray-300 mb-3" />
            <p className="text-sm font-medium text-gray-400">Aucune donnée pour cette période</p>
            <p className="text-xs text-gray-400 mt-1">Sélectionnez une période ou créez des dotations.</p>
          </div>
        ) : (
          <div className="overflow-hidden rounded-xl border border-gray-200">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px] text-sm">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    {['Article', 'Unité', 'Qté totale', 'Nb dotations', 'Coût total'].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-gray-500 first:pl-5">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {syntheseRows.map(r => (
                    <tr key={r.product_id} className="bg-white hover:bg-gray-100/40">
                      <td className="px-4 py-3 pl-5 font-semibold text-gray-800">{r.product_name}</td>
                      <td className="px-4 py-3 text-gray-500">{r.unit || '—'}</td>
                      <td className="px-4 py-3 tabular-nums font-bold text-gray-900">{fmtQty(r.totalQty)} {r.unit}</td>
                      <td className="px-4 py-3 tabular-nums text-gray-600">{r.count}</td>
                      <td className="px-4 py-3 tabular-nums font-semibold text-gray-800">{fmtMoney(r.totalCost, currency)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-gray-200 bg-gray-50">
                    <td className="px-4 py-3 pl-5 font-bold text-gray-900" colSpan={2}>Total</td>
                    <td className="px-4 py-3 tabular-nums font-bold text-gray-900">{fmtQty(totals.totalQty)}</td>
                    <td className="px-4 py-3" />
                    <td className="px-4 py-3 tabular-nums font-bold text-gray-900">{fmtMoney(totals.totalCost, currency)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Services tab ──
function ServicesTab({ services, locations, loading, onRemove }: {
  services: Service[];
  locations: SalesLocation[];
  loading: boolean;
  onRemove: (id: string) => Promise<void>;
}) {
  if (loading) {
    return <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-16 rounded-xl bg-gray-100 animate-pulse" />)}</div>;
  }
  if (services.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-gray-300 py-16 text-center">
        <Settings2 className="h-10 w-10 text-gray-300 mb-3" />
        <p className="text-sm font-medium text-gray-400">Aucun service</p>
        <p className="text-xs text-gray-400 mt-1">Créez des services (cuisine, bar, réception…) pour leur dotation des articles.</p>
      </div>
    );
  }
  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white divide-y divide-gray-100">
      {services.map(s => {
        const loc = locations.find(l => l.id === s.location_id);
        return (
          <div key={s.id} className="px-5 py-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="h-9 w-9 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
                <Settings2 className="h-4 w-4 text-emerald-600" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-gray-900">{s.name}</p>
                <div className="flex items-center gap-1.5 text-xs text-gray-500 mt-0.5">
                  <MapPin className="h-3 w-3" />
                  <span>{loc?.name ?? '—'}</span>
                  <span className="text-gray-300">·</span>
                  <span className={s.active ? 'text-emerald-600' : 'text-gray-400'}>
                    {s.active ? 'Actif' : 'Inactif'}
                  </span>
                </div>
              </div>
            </div>
            <button
              onClick={() => {
                if (confirm(`Supprimer le service « ${s.name} » ?`)) onRemove(s.id);
              }}
              className="text-gray-400 hover:text-red-500 transition p-1.5 rounded-lg hover:bg-red-50"
              title="Supprimer"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}

// ── Service form modal ──
function ServiceFormModal({ locations, defaultLocationId, onClose, onSubmit }: {
  locations: SalesLocation[];
  defaultLocationId: string | null;
  onClose: () => void;
  onSubmit: (payload: { name: string; location_id: string }) => Promise<void>;
}) {
  const [name, setName] = useState('');
  const [locationId, setLocationId] = useState(defaultLocationId ?? locations[0]?.id ?? '');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !locationId) {
      setError('Nom et boutique sont obligatoires.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await onSubmit({ name: name.trim(), location_id: locationId });
    } catch (err) {
      setError(err instanceof Error ? translateError(err.message) : 'Erreur');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white shadow-2xl overflow-hidden">
        <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings2 className="h-4 w-4 text-blue-600" />
            <h2 className="text-base font-semibold text-gray-900">Nouveau service</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700"><X className="h-5 w-5" /></button>
        </div>
        <form onSubmit={submit} className="px-6 py-5 space-y-4">
          {error && (
            <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3 py-2.5">
              <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
              <p className="text-xs text-red-700">{error}</p>
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Nom du service *</label>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Ex: Cuisine, Bar, Réception…"
              className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
              autoFocus
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Boutique *</label>
            <select
              value={locationId}
              onChange={e => setLocationId(e.target.value)}
              className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
            >
              {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
            </select>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition">Annuler</button>
            <button type="submit" disabled={submitting} className="flex-1 rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50">
              {submitting ? 'Création…' : 'Créer le service'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ── Dotation form modal ──
function DotationFormModal({ products, locations, services, defaultLocationId, onClose, onSubmit, currency }: {
  products: Product[];
  locations: SalesLocation[];
  services: Service[];
  defaultLocationId: string | null;
  onClose: () => void;
  onSubmit: (input: CreateDotationInput) => Promise<void>;
  currency: string;
}) {
  const [locationId, setLocationId] = useState(defaultLocationId ?? locations[0]?.id ?? '');
  const [serviceId, setServiceId] = useState('');
  const [effectif, setEffectif] = useState('');
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<DraftItem[]>([{ product_id: '', quantity: '', unit_cost: '' }]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const availableServices = services.filter(s => s.active && s.location_id === locationId);

  function updateItem(idx: number, patch: Partial<DraftItem>) {
    setItems(arr => arr.map((it, i) => i === idx ? { ...it, ...patch } : it));
  }
  function addItem() { setItems(arr => [...arr, { product_id: '', quantity: '', unit_cost: '' }]); }
  function removeItem(idx: number) { setItems(arr => arr.filter((_, i) => i !== idx)); }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!locationId || !serviceId) {
      setError('Boutique et service sont obligatoires.');
      return;
    }
    const validItems = items
      .filter(it => it.product_id && parseFloat(it.quantity) > 0)
      .map(it => ({
        product_id: it.product_id,
        quantity: parseFloat(it.quantity),
        unit_cost: parseFloat(it.unit_cost) || 0,
      }));
    if (validItems.length === 0) {
      setError('Ajoutez au moins un article avec une quantité positive.');
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit({
        location_id: locationId,
        service_id: serviceId,
        notes: notes.trim(),
        effectif: parseInt(effectif) || 0,
        items: validItems,
      });
    } catch (err) {
      setError(err instanceof Error ? translateError(err.message) : 'Erreur');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Gift className="h-5 w-5 text-blue-600" />
            <h2 className="text-base font-semibold text-gray-900">Nouvelle dotation</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700"><X className="h-5 w-5" /></button>
        </div>
        <form onSubmit={submit} className="overflow-y-auto px-6 py-5 space-y-4">
          {error && (
            <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3 py-2.5">
              <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
              <p className="text-xs text-red-700">{error}</p>
            </div>
          )}

          {/* Boutique + Service */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Boutique source *</label>
              <select
                value={locationId}
                onChange={e => { setLocationId(e.target.value); setServiceId(''); }}
                className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
              >
                {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Service destinataire *</label>
              <select
                value={serviceId}
                onChange={e => setServiceId(e.target.value)}
                className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
              >
                <option value="">Sélectionner…</option>
                {availableServices.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              {availableServices.length === 0 && (
                <p className="mt-1 text-[10px] text-amber-600">Aucun service pour cette boutique. Créez-en un d'abord.</p>
              )}
            </div>
          </div>

          {/* Items */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-gray-600">Articles à doter *</label>
              <button type="button" onClick={addItem} className="flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-700">
                <Plus className="h-3.5 w-3.5" /> Ajouter une ligne
              </button>
            </div>
            <div className="space-y-2">
              {items.map((it, idx) => {
                const prod = products.find(p => p.id === it.product_id);
                return (
                  <div key={idx} className="flex items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 p-2">
                    <Package className="h-4 w-4 text-gray-400 shrink-0" />
                    <select
                      value={it.product_id}
                      onChange={e => updateItem(idx, { product_id: e.target.value })}
                      className="flex-1 rounded-md border border-gray-200 bg-white px-2 py-2 text-xs text-gray-700 outline-none focus:border-blue-500"
                    >
                      <option value="">Article…</option>
                      {products.map(p => <option key={p.id} value={p.id}>{p.name} ({p.unit})</option>)}
                    </select>
                    <input
                      type="number"
                      min="0.01"
                      step="0.01"
                      value={it.quantity}
                      onChange={e => updateItem(idx, { quantity: e.target.value })}
                      placeholder="Qté"
                      className="w-20 rounded-md border border-gray-200 bg-white px-2 py-2 text-xs text-gray-800 outline-none focus:border-blue-500 tabular-nums"
                    />
                    <input
                      type="number"
                      min="0"
                      step="any"
                      value={it.unit_cost}
                      onChange={e => updateItem(idx, { unit_cost: e.target.value })}
                      placeholder="Coût"
                      className="w-24 rounded-md border border-gray-200 bg-white px-2 py-2 text-xs text-gray-800 outline-none focus:border-blue-500 tabular-nums"
                    />
                    {items.length > 1 && (
                      <button type="button" onClick={() => removeItem(idx)} className="text-gray-400 hover:text-red-500 p-1">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
            {items.length > 0 && (
              <p className="mt-1.5 text-[10px] text-gray-400">
                Total : {fmtQty(items.reduce((s, it) => s + (parseFloat(it.quantity) || 0), 0))} article(s),
                {' '}{fmtMoney(items.reduce((s, it) => s + (parseFloat(it.quantity) || 0) * (parseFloat(it.unit_cost) || 0), 0), currency)}
              </p>
            )}
          </div>

          {/* Notes + Effectif */}
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
              <input
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Motif de la dotation…"
                className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Effectif</label>
              <input
                type="number"
                min="0"
                value={effectif}
                onChange={e => setEffectif(e.target.value)}
                placeholder="0"
                className="w-full rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white transition tabular-nums"
              />
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition">Annuler</button>
            <button type="submit" disabled={submitting} className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50">
              <Gift className="h-4 w-4" />
              {submitting ? 'Dotation en cours…' : 'Valider la dotation'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
