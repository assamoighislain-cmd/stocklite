import { useState, useRef, useCallback } from 'react';
import { Upload, FileSpreadsheet, AlertTriangle, CheckCircle2, Download, ArrowRight, Loader2 } from 'lucide-react';
import * as XLSX from 'xlsx';
import type { SalesLocation, PriceType } from '../types';
import { translateError } from '../lib/translateError';

interface Props {
  open: boolean;
  onClose: () => void;
  onImport: (
    rows: { family: string; name: string; reference?: string; stock: number; price: number; purchase_price: number; priceTypePrices?: Record<string, number> }[],
    targetLocationId: string | null,
    onProgress?: (current: number, total: number) => void,
  ) => Promise<{ created: number; updated: number; familiesCreated: number }>;
  locations: SalesLocation[];
  defaultLocationId?: string | null;
  priceTypes?: PriceType[];
}

interface ParsedRow {
  family: string;
  name: string;
  reference: string;
  stock: number;
  price: number;
  purchase_price: number;
  priceTypePrices: Record<string, number>;
}

const BASE_HEADERS = ['Famille', 'Reference', 'Article', 'Stock', 'Prix de vente', "Prix d'achat"];

export function ImportProductsModal({ open, onClose, onImport, locations, defaultLocationId, priceTypes = [] }: Props) {
  const [rows, setRows] = useState<ParsedRow[]>([]);
  const [fileName, setFileName] = useState('');
  const [targetLocationId, setTargetLocationId] = useState<string | null>(defaultLocationId ?? null);
  const [error, setError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [result, setResult] = useState<{ created: number; updated: number; familiesCreated: number } | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const activePriceTypes = priceTypes.filter(pt => pt.active);
  const allHeaders = [...BASE_HEADERS, ...activePriceTypes.map(pt => pt.name)];

  const reset = useCallback(() => {
    setRows([]);
    setFileName('');
    setError(null);
    setResult(null);
    setDragOver(false);
    setImportProgress(0);
  }, []);

  const handleFile = useCallback(async (file: File) => {
    setError(null);
    setResult(null);
    setFileName(file.name);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      if (!sheet) {
        setError('Le fichier est vide.');
        return;
      }
      const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });
      if (json.length === 0) {
        setError('Aucune ligne de données trouvée.');
        return;
      }

      const normalizeKey = (k: string) => k.toLowerCase().trim();

      const findKey = (obj: Record<string, unknown>, candidates: string[]) => {
        for (const c of candidates) {
          const found = Object.keys(obj).find(k => normalizeKey(k) === normalizeKey(c));
          if (found) return found;
        }
        return null;
      };

      const first = json[0];
      const famKey = findKey(first, ['Famille', 'famille', 'family', 'Categorie', 'Catégorie']);
      const refKey = findKey(first, ['Reference', 'Référence', 'reference', 'ref', 'Ref']);
      const nameKey = findKey(first, ['Article', 'article', 'Nom', 'nom', 'Désignation', 'Designation', 'name']);
      const stockKey = findKey(first, ['Stock', 'stock', 'Quantité', 'Quantite', 'quantity', 'Qte']);
      const priceKey = findKey(first, ['Prix de vente', 'Prix vente', 'Prix', 'prix', 'price', 'PVT']);
      const purchaseKey = findKey(first, ["Prix d'achat", 'Prix achat', 'PA', 'purchase_price', 'cost', 'Prix dachat', "Prix d achat"]);

      // Match price type columns by name (flexible matching)
      const ptKeyMap: { priceTypeId: string; key: string }[] = [];
      for (const pt of activePriceTypes) {
        const ptNameNorm = normalizeKey(pt.name);
        const candidates = [
          pt.name, `Prix ${pt.name}`, `Prix ${pt.name.toLowerCase()}`,
          `Prix de ${pt.name}`, `Prix de ${pt.name.toLowerCase()}`,
          `Prix ${pt.name} (FCFA)`, `${pt.name} (FCFA)`,
        ];
        let key = findKey(first, candidates);
        if (!key) {
          // Fallback: match any column whose normalized name contains the price type name
          key = Object.keys(first).find(k => {
            const nk = normalizeKey(k);
            return nk.includes(ptNameNorm) && !BASE_HEADERS.some(h => normalizeKey(h) === nk);
          }) ?? null;
        }
        if (key) ptKeyMap.push({ priceTypeId: pt.id, key });
      }

      if (!nameKey) {
        setError(`Colonne "Article" introuvable. Colonnes attendues : ${allHeaders.join(', ')}.`);
        return;
      }

      const toNum = (v: unknown): number => {
        if (typeof v === 'number') return v;
        if (typeof v === 'string') {
          const cleaned = v.replace(/\s/g, '').replace(',', '.').replace(/[^\d.-]/g, '');
          const n = parseFloat(cleaned);
          return isNaN(n) ? 0 : n;
        }
        return 0;
      };

      const parsed: ParsedRow[] = json
        .map(r => {
          const priceTypePrices: Record<string, number> = {};
          for (const ptm of ptKeyMap) {
            const val = toNum(r[ptm.key]);
            if (val > 0) priceTypePrices[ptm.priceTypeId] = val;
          }
          return {
            family: famKey ? String(r[famKey] ?? '').trim() : '',
            reference: refKey ? String(r[refKey] ?? '').trim() : '',
            name: String(r[nameKey] ?? '').trim(),
            stock: toNum(stockKey ? r[stockKey] : 0),
            price: toNum(priceKey ? r[priceKey] : 0),
            purchase_price: toNum(purchaseKey ? r[purchaseKey] : 0),
            priceTypePrices,
          };
        })
        .filter(r => r.name !== '');

      if (parsed.length === 0) {
        setError('Aucun article valide trouvé dans le fichier.');
        return;
      }
      setRows(parsed);
    } catch (e) {
      setError(e instanceof Error ? translateError(e.message) : 'Lecture du fichier impossible.');
    }
  }, [activePriceTypes, allHeaders]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const downloadTemplate = useCallback(() => {
    const exampleRow: (string | number)[] = ['Boissons', 'REF-001', 'Coca-Cola 1L', 24, 1000, 700];
    for (const pt of activePriceTypes) {
      exampleRow.push(pt.name.toLowerCase().includes('gros') ? 900 : 950);
    }
    const ws = XLSX.utils.aoa_to_sheet([allHeaders, exampleRow]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Articles');
    XLSX.writeFile(wb, 'modele_import_articles.xlsx');
  }, [activePriceTypes, allHeaders]);

  async function doImport() {
    if (rows.length === 0) return;
    setImporting(true);
    setError(null);
    setImportProgress(0);
    try {
      const res = await onImport(rows, targetLocationId, (current, total) => {
        setImportProgress(total > 0 ? Math.round((current / total) * 100) : 0);
      });
      setImportProgress(100);
      setResult(res);
      setRows([]);
    } catch (e) {
      setError(e instanceof Error ? translateError(e.message) : 'Erreur lors de l\'import.');
    } finally {
      setImporting(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-blue-600" />
            <h2 className="text-base font-semibold text-gray-900">Importer des articles</h2>
          </div>
          <button onClick={() => { reset(); onClose(); }} className="text-gray-400 hover:text-gray-700 text-xl leading-none">×</button>
        </div>

        <div className="overflow-y-auto px-6 py-5 space-y-5">
          {/* Success state */}
          {result && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold text-emerald-800">Import réussi</p>
                <p className="text-emerald-700 mt-1">
                  {result.created} article{result.created > 1 ? 's' : ''} créé{result.created > 1 ? 's' : ''},
                  {' '}{result.updated} mis à jour,
                  {' '}{result.familiesCreated} famille{result.familiesCreated > 1 ? 's' : ''} créée{result.familiesCreated > 1 ? 's' : ''}.
                </p>
              </div>
            </div>
          )}

          {/* Progress bar */}
          {importing && (
            <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 space-y-2">
              <div className="flex items-center justify-between text-sm font-semibold text-blue-800">
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Import des articles en cours…
                </div>
                <span className="tabular-nums">{importProgress}%</span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded-full bg-blue-100">
                <div
                  className="h-full rounded-full bg-blue-500 transition-all duration-300 ease-out"
                  style={{ width: `${importProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Step 1: Download template + upload zone */}
          {!result && (
            <>
              <div className="flex items-center gap-3 rounded-lg bg-blue-50 border border-blue-100 px-4 py-3">
                <Download className="h-4 w-4 text-blue-600 shrink-0" />
                <p className="text-xs text-blue-700 flex-1">
                  Pas de modèle ? Téléchargez le fichier Excel pré-formaté avec les bonnes colonnes.
                </p>
                <button onClick={downloadTemplate} className="text-xs font-semibold text-blue-700 hover:text-blue-900 underline shrink-0">
                  Télécharger le modèle
                </button>
              </div>

              <div
                onDrop={onDrop}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onClick={() => inputRef.current?.click()}
                className={`cursor-pointer rounded-xl border-2 border-dashed p-8 text-center transition ${
                  dragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-gray-50 hover:border-blue-400 hover:bg-blue-50/50'
                }`}
              >
                <input
                  ref={inputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
                />
                <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                {fileName ? (
                  <p className="text-sm font-medium text-gray-700">{fileName}</p>
                ) : (
                  <p className="text-sm text-gray-500">
                    Glissez votre fichier Excel ici, ou <span className="text-blue-600 font-medium">cliquez pour parcourir</span>
                  </p>
                )}
                <p className="text-xs text-gray-400 mt-1">Formats acceptés : .xlsx, .xls, .csv</p>
              </div>

              {/* Expected columns */}
              <div className="rounded-lg border border-gray-200 bg-gray-50 p-3">
                <p className="text-xs font-semibold text-gray-500 mb-2">Colonnes attendues :</p>
                <div className="flex flex-wrap gap-1.5">
                  {allHeaders.map(h => (
                    <span key={h} className="rounded-md bg-white px-2 py-1 text-xs font-medium text-gray-600 ring-1 ring-gray-200">{h}</span>
                  ))}
                </div>
                {activePriceTypes.length > 0 && (
                  <p className="mt-2 text-[11px] text-blue-600">
                    Les colonnes de types de prix (en bleu) sont optionnelles — si elles sont présentes, les prix seront enregistrés automatiquement.
                  </p>
                )}
              </div>

              {/* Error */}
              {error && (
                <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3 py-2.5">
                  <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-red-700">{error}</p>
                </div>
              )}

              {/* Preview */}
              {rows.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold text-gray-700">{rows.length} article{rows.length > 1 ? 's' : ''} à importer</p>
                    <button onClick={() => setRows([])} className="text-xs text-gray-400 hover:text-red-500">Effacer</button>
                  </div>
                  <div className="overflow-x-auto overflow-hidden rounded-xl border border-gray-200 max-h-64 overflow-y-auto">
                    <table className="w-full text-xs whitespace-nowrap">
                      <thead className="sticky top-0 bg-gray-50">
                        <tr className="border-b border-gray-200">
                          {allHeaders.map(h => {
                            const isPt = activePriceTypes.some(pt => pt.name === h);
                            return (
                              <th key={h} className={`px-3 py-2 text-left font-semibold ${isPt ? 'text-blue-600' : 'text-gray-500'}`}>{h}</th>
                            );
                          })}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {rows.slice(0, 100).map((r, i) => (
                          <tr key={i} className="bg-white">
                            <td className="px-3 py-2 text-gray-600">{r.family || '—'}</td>
                            <td className="px-3 py-2 text-gray-600">{r.reference || '—'}</td>
                            <td className="px-3 py-2 font-medium text-gray-800">{r.name}</td>
                            <td className="px-3 py-2 tabular-nums text-gray-600">{new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(r.stock)}</td>
                            <td className="px-3 py-2 tabular-nums text-gray-600">{r.price}</td>
                            <td className="px-3 py-2 tabular-nums text-gray-600">{r.purchase_price}</td>
                            {activePriceTypes.map(pt => (
                              <td key={pt.id} className="px-3 py-2 tabular-nums text-gray-600">
                                {r.priceTypePrices[pt.id] ?? '—'}
                              </td>
                            ))}
                          </tr>
                        ))}
                        {rows.length > 100 && (
                          <tr><td colSpan={allHeaders.length} className="px-3 py-2 text-center text-gray-400">… et {rows.length - 100} autres</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Target location */}
                  {locations.length > 0 && (
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1.5">
                        Boutique de destination <span className="text-gray-400">(pour le stock)</span>
                      </label>
                      <div className="flex items-center gap-2">
                        <select
                          value={targetLocationId ?? ''}
                          onChange={e => setTargetLocationId(e.target.value || null)}
                          className="flex-1 rounded-lg border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-500 focus:bg-white transition"
                        >
                          <option value="">— Sélectionner un point de vente —</option>
                          {locations.filter(l => l.active).map(l => (
                            <option key={l.id} value={l.id}>{l.name}</option>
                          ))}
                        </select>
                        {targetLocationId && (
                          <div className="flex items-center gap-1 text-xs text-blue-600 font-medium">
                            <ArrowRight className="h-3.5 w-3.5" />
                            {locations.find(l => l.id === targetLocationId)?.name}
                          </div>
                        )}
                      </div>
                      <p className="mt-1 text-[10px] text-gray-400">
                        Le stock indiqué sera ajouté à cette boutique. Les prix de vente et types de prix seront aussi appliqués à cette boutique.
                      </p>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-100 px-6 py-4 flex gap-3">
          <button
            onClick={() => { reset(); onClose(); }}
            className="flex-1 rounded-xl border border-gray-200 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50 transition"
          >
            {result ? 'Fermer' : 'Annuler'}
          </button>
          {!result && (
            <button
              onClick={doImport}
              disabled={importing || rows.length === 0 || !targetLocationId}
              className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50"
            >
              <Upload className="h-4 w-4" />
              {importing ? 'Import en cours…' : `Importer ${rows.length > 0 ? `(${rows.length})` : ''}`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
