import { useState, useMemo } from 'react';
import { Search, PlusCircle, Printer, Eye, Wallet, Loader2, Calendar, ShieldCheck, ShieldAlert, ShieldX, Users } from 'lucide-react';
import type { Invoice, InvoiceStatus, PaymentMethod } from '../types';
import { StatusBadge } from './StatusBadge';
import { STATUS_LABELS, ALL_PAYMENT_METHODS, METHOD_LABELS } from '../types';
import { Modal } from './Modal';
import type { Route } from '../App';
import { translateError } from '../lib/translateError';

interface InvoicesPageProps {
  invoices: Invoice[];
  onNavigate: (r: Route) => void;
  recordPayment: (payload: {
    customer_id: string;
    invoice_id: string | null;
    amount: number;
    method: PaymentMethod;
    payment_date: string;
    notes: string;
  }) => Promise<unknown>;
  refetchInvoices: () => Promise<void> | void;
  currency?: string;
}

const STATUSES: InvoiceStatus[] = ['brouillon', 'envoyee', 'payee', 'partielle', 'annulee'];

function fmt(n: number, currency = 'FCFA') {
  try {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);
  } catch {
    return `${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n)} ${currency}`;
  }
}

export function InvoicesPage({ invoices, onNavigate, recordPayment, refetchInvoices, currency }: InvoicesPageProps) {
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<InvoiceStatus | 'all'>('all');
  const [creatorFilter, setCreatorFilter] = useState<string>('all');
  const [periodPreset, setPeriodPreset] = useState<'all' | 'today' | 'week' | 'month' | 'year' | 'custom'>('today');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const [payTarget, setPayTarget] = useState<Invoice | null>(null);
  const [payForm, setPayForm] = useState({
    amount: '',
    method: 'especes' as PaymentMethod,
    payment_date: new Date().toISOString().slice(0, 10),
    notes: '',
  });
  const [paySaving, setPaySaving] = useState(false);
  const [payError, setPayError] = useState('');

  function presetRange(preset: typeof periodPreset): { from: string; to: string } {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const fmtDate = (d: Date) => d.toISOString().slice(0, 10);
    if (preset === 'today') return { from: fmtDate(today), to: fmtDate(today) };
    if (preset === 'week') {
      const from = new Date(today);
      from.setDate(today.getDate() - today.getDay() + 1);
      return { from: fmtDate(from), to: fmtDate(today) };
    }
    if (preset === 'month') return { from: fmtDate(new Date(now.getFullYear(), now.getMonth(), 1)), to: fmtDate(today) };
    if (preset === 'year') return { from: fmtDate(new Date(now.getFullYear(), 0, 1)), to: fmtDate(today) };
    return { from: '', to: '' };
  }

  const activeRange = periodPreset === 'custom' ? { from: dateFrom, to: dateTo } : presetRange(periodPreset);

  const creators = useMemo(() => {
    const map = new Map<string, string>();
    for (const inv of invoices) {
      if (inv.created_by && inv.creator?.full_name) {
        map.set(inv.created_by, inv.creator.full_name);
      }
    }
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }));
  }, [invoices]);

  const filtered = invoices.filter(inv => {
    const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
    const matchCreator = creatorFilter === 'all' || inv.created_by === creatorFilter;
    const matchQuery =
      inv.invoice_number.toLowerCase().includes(query.toLowerCase()) ||
      (inv.customer?.name ?? '').toLowerCase().includes(query.toLowerCase());
    const invDate = inv.date.slice(0, 10);
    const matchFrom = !activeRange.from || invDate >= activeRange.from;
    const matchTo = !activeRange.to || invDate <= activeRange.to;
    return matchStatus && matchCreator && matchQuery && matchFrom && matchTo;
  });

  const totalFiltered = filtered.reduce((s, i) => s + i.total, 0);
  const paidFiltered = filtered.reduce((s, i) => s + i.amount_paid, 0);

  function openPayModal(inv: Invoice) {
    setPayTarget(inv);
    setPayError('');
    setPayForm({
      amount: String(Number(inv.balance_due) > 0 ? Number(inv.balance_due) : Number(inv.total)),
      method: 'especes',
      payment_date: new Date().toISOString().slice(0, 10),
      notes: '',
    });
  }

  async function submitPayment(e: React.FormEvent) {
    e.preventDefault();
    if (!payTarget) return;
    const amount = Number(payForm.amount);
    if (!amount || amount <= 0) { setPayError('Montant invalide.'); return; }
    setPaySaving(true); setPayError('');
    try {
      await recordPayment({
        customer_id: payTarget.customer_id,
        invoice_id: payTarget.id,
        amount,
        method: payForm.method,
        payment_date: payForm.payment_date,
        notes: payForm.notes,
      });
      setPayTarget(null);
      await refetchInvoices();
    } catch (err) {
      setPayError(err instanceof Error ? translateError(err.message) : 'Erreur lors de l\'enregistrement.');
    } finally {
      setPaySaving(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-gray-900">Factures</h1>
          <p className="text-sm text-gray-400">{invoices.length} facture{invoices.length > 1 ? 's' : ''}</p>
        </div>
        <button
          onClick={() => onNavigate({ page: 'invoice-form' })}
          className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition active:scale-95"
        >
          <PlusCircle className="h-4 w-4" /> Nouvelle facture
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Numéro, client…"
            className="w-full rounded-lg border border-gray-300 bg-gray-100 py-2 pl-9 pr-4 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500"
          />
        </div>
        <div className="flex gap-1 rounded-lg border border-gray-300 bg-gray-100 p-1">
          <button
            onClick={() => setStatusFilter('all')}
            className={`rounded-md px-3 py-1 text-xs font-medium transition ${statusFilter === 'all' ? 'bg-gray-200 text-gray-900' : 'text-gray-500 hover:text-gray-800'}`}
          >
            Toutes
          </button>
          {STATUSES.map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`rounded-md px-3 py-1 text-xs font-medium transition ${statusFilter === s ? 'bg-gray-200 text-gray-900' : 'text-gray-500 hover:text-gray-800'}`}
            >
              {STATUS_LABELS[s]}
            </button>
          ))}
        </div>
        {creators.length > 0 && (
          <div className="relative">
            <Users className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <select
              value={creatorFilter}
              onChange={e => setCreatorFilter(e.target.value)}
              className="appearance-none rounded-lg border border-gray-300 bg-gray-100 py-2 pl-9 pr-8 text-sm text-gray-800 outline-none focus:border-blue-500"
            >
              <option value="all">Tous les créateurs</option>
              {creators.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Period filter */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-gray-500">
          <Calendar className="h-4 w-4" /> Période :
        </div>
        <div className="flex gap-1 rounded-lg border border-gray-300 bg-gray-100 p-1">
          {([['all','Toute'],['today','Aujourd\'hui'],['week','Semaine'],['month','Mois'],['year','Année'],['custom','Perso.']] as const).map(([val, label]) => (
            <button
              key={val}
              onClick={() => {
                setPeriodPreset(val);
                if (val !== 'custom') { setDateFrom(''); setDateTo(''); }
              }}
              className={`rounded-md px-3 py-1 text-xs font-medium transition ${periodPreset === val ? 'bg-blue-600 text-white' : 'text-gray-500 hover:text-gray-800'}`}
            >
              {label}
            </button>
          ))}
        </div>
        {periodPreset === 'custom' && (
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={dateFrom}
              onChange={e => setDateFrom(e.target.value)}
              className="rounded-lg border border-gray-300 bg-gray-100 px-3 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-500"
            />
            <span className="text-gray-400 text-xs">→</span>
            <input
              type="date"
              value={dateTo}
              onChange={e => setDateTo(e.target.value)}
              className="rounded-lg border border-gray-300 bg-gray-100 px-3 py-1.5 text-sm text-gray-800 outline-none focus:border-blue-500"
            />
          </div>
        )}
        {periodPreset !== 'all' && (
          <span className="text-xs text-gray-400">
            {activeRange.from && `Du ${new Date(activeRange.from).toLocaleDateString('fr-FR')}`}
            {activeRange.from && activeRange.to && ' au '}
            {activeRange.to && new Date(activeRange.to).toLocaleDateString('fr-FR')}
          </span>
        )}
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200">
        {filtered.length === 0 ? (
          <div className="py-14 text-center text-sm text-gray-400">
            {query || statusFilter !== 'all' || periodPreset !== 'all' ? 'Aucune facture correspondante.' : 'Aucune facture. Créez votre première facture.'}
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px] text-sm">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    {['Numéro', 'Client', 'Créé par', 'Date', 'Échéance', 'Total', 'Solde dû', 'FNE', 'Statut', ''].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 first:pl-5">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filtered.map(inv => {
                    const overdue = inv.status !== 'payee' && inv.status !== 'annulee' && inv.due_date && new Date(inv.due_date) < new Date();
                    const canPay = inv.status !== 'payee' && inv.status !== 'annulee' && Number(inv.balance_due) > 0;
                    return (
                      <tr key={inv.id} className="group bg-white hover:bg-gray-100">
                        <td className="px-4 py-3 pl-5 font-mono text-xs font-semibold text-blue-400">{inv.invoice_number}</td>
                        <td className="px-4 py-3 font-medium text-gray-800">{inv.customer?.name ?? '—'}</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{inv.creator?.full_name ?? '—'}</td>
                        <td className="px-4 py-3 tabular-nums text-gray-500">{new Date(inv.date).toLocaleDateString('fr-FR')}</td>
                        <td className={`px-4 py-3 tabular-nums text-sm ${overdue ? 'font-semibold text-red-400' : 'text-gray-500'}`}>
                          {inv.due_date ? new Date(inv.due_date).toLocaleDateString('fr-FR') : '—'}
                        </td>
                        <td className="px-4 py-3 tabular-nums font-semibold text-gray-900">{fmt(inv.total, currency ?? 'FCFA')}</td>
                        <td className={`px-4 py-3 tabular-nums font-semibold ${inv.balance_due > 0 ? 'text-amber-400' : 'text-gray-500'}`}>
                          {fmt(inv.balance_due, currency ?? 'FCFA')}
                        </td>
                        <td className="px-4 py-3">
                          {inv.fne_status === 'certified' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700" title={`Certifiée — Réf. ${inv.fne_reference ?? ''}`}>
                              <ShieldCheck className="h-3.5 w-3.5" /> Certifiée
                            </span>
                          ) : inv.fne_status === 'error' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-xs font-medium text-red-600" title={inv.fne_error ?? ''}>
                              <ShieldX className="h-3.5 w-3.5" /> Erreur
                            </span>
                          ) : inv.fne_status === 'pending' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-600">
                              <ShieldAlert className="h-3.5 w-3.5" /> En attente
                            </span>
                          ) : (
                            <span className="text-xs text-gray-300">—</span>
                          )}
                        </td>
                        <td className="px-4 py-3"><StatusBadge status={inv.status} /></td>
                        <td className="px-4 py-3 pr-4">
                          <div className="flex items-center gap-1 opacity-0 transition group-hover:opacity-100">
                            {canPay && (
                              <button
                                onClick={() => openPayModal(inv)}
                                className="flex items-center gap-1 rounded-md bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 transition"
                                title="Enregistrer un règlement"
                              >
                                <Wallet className="h-3.5 w-3.5" /> Régler
                              </button>
                            )}
                            <button
                              onClick={() => onNavigate({ page: 'invoice-detail', id: inv.id })}
                              className="rounded p-1.5 text-gray-500 hover:bg-gray-200 hover:text-gray-800"
                              title="Voir / imprimer"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => onNavigate({ page: 'invoice-detail', id: inv.id })}
                              className="rounded p-1.5 text-gray-500 hover:bg-gray-200 hover:text-gray-800"
                              title="Imprimer"
                            >
                              <Printer className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {/* Footer totals */}
            <div className="flex items-center justify-between border-t border-gray-200 bg-gray-50 px-5 py-3">
              <span className="text-xs text-gray-400">{filtered.length} facture{filtered.length > 1 ? 's' : ''}</span>
              <div className="flex gap-6 text-xs text-gray-500">
                <span>Total : <span className="font-semibold text-gray-900">{fmt(totalFiltered)}</span></span>
                <span>Encaissé : <span className="font-semibold text-emerald-400">{fmt(paidFiltered)}</span></span>
                <span>Solde : <span className="font-semibold text-amber-400">{fmt(totalFiltered - paidFiltered)}</span></span>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Quick payment modal */}
      {payTarget && (
        <Modal title={`Règlement — ${payTarget.invoice_number}`} onClose={() => setPayTarget(null)}>
          <form onSubmit={submitPayment} className="space-y-4 p-5">
            <div className="rounded-lg bg-gray-50 p-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Client</span>
                <span className="font-medium text-gray-900">{payTarget.customer?.name ?? '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Total facture</span>
                <span className="font-semibold text-gray-900">{fmt(Number(payTarget.total), currency ?? 'FCFA')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Déjà réglé</span>
                <span className="font-semibold text-emerald-600">{fmt(Number(payTarget.amount_paid), currency ?? 'FCFA')}</span>
              </div>
              <div className="flex justify-between border-t border-gray-200 pt-2 mt-2">
                <span className="text-gray-500">Solde dû</span>
                <span className="font-bold text-amber-600">{fmt(Number(payTarget.balance_due), currency ?? 'FCFA')}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Montant *</label>
                <input type="number" step="any" min="1" required value={payForm.amount}
                  onChange={e => setPayForm(f => ({ ...f, amount: e.target.value }))}
                  placeholder="0"
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm tabular-nums text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Mode</label>
                <select value={payForm.method} onChange={e => setPayForm(f => ({ ...f, method: e.target.value as PaymentMethod }))}
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500">
                  {ALL_PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-gray-500">Date</label>
              <input type="date" value={payForm.payment_date} onChange={e => setPayForm(f => ({ ...f, payment_date: e.target.value }))}
                className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-gray-500">Notes</label>
              <input type="text" value={payForm.notes} onChange={e => setPayForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="Référence, commentaire…"
                className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
            </div>
            {payError && <p className="text-xs text-red-500">{payError}</p>}
            <button type="submit" disabled={paySaving}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-500 disabled:opacity-50">
              {paySaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wallet className="h-4 w-4" />}
              {paySaving ? 'Enregistrement…' : 'Enregistrer le règlement'}
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
}
