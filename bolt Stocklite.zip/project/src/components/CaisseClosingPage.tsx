import { useState, useEffect, useCallback } from 'react';
import {
  Calculator, CheckCircle, Clock, ChevronDown, ChevronUp,
  AlertTriangle, TrendingUp, TrendingDown, Printer, ShoppingBag,
  RefreshCw, Package, Wallet, FileDown, Receipt, FileText, BarChart3,
  Coins, ArrowDownCircle, ArrowUpCircle, Scale, Trash2,
} from 'lucide-react';
import type { PaymentMethod, CompanySettings } from '../types';
import { ALL_PAYMENT_METHODS } from '../types';
import type { CaisseClosing, ProductSaleSummary, PosJournalEntry, InvoiceJournalEntry, PaymentSummaryEntry } from '../hooks/useCaisseClosing';
import { exportHtmlToPdf } from '../lib/pdf';
import { printDocument } from '../lib/printEngine';
import { translateError } from '../lib/translateError';

interface CaisseClosingPageProps {
  settings: CompanySettings | null;
  isAdmin: boolean;
  computeExpected: ReturnType<typeof import('../hooks/useCaisseClosing').useCaisseClosing>['computeExpected'];
  computeProductSales: ReturnType<typeof import('../hooks/useCaisseClosing').useCaisseClosing>['computeProductSales'];
  computePosJournal: ReturnType<typeof import('../hooks/useCaisseClosing').useCaisseClosing>['computePosJournal'];
  computeInvoiceJournal: ReturnType<typeof import('../hooks/useCaisseClosing').useCaisseClosing>['computeInvoiceJournal'];
  computePaymentSummary: ReturnType<typeof import('../hooks/useCaisseClosing').useCaisseClosing>['computePaymentSummary'];
  computeCashSummary: ReturnType<typeof import('../hooks/useCaisseClosing').useCaisseClosing>['computeCashSummary'];
  saveClosing: ReturnType<typeof import('../hooks/useCaisseClosing').useCaisseClosing>['saveClosing'];
  closings: CaisseClosing[];
  loading: boolean;
  fetchClosings: () => void;
  caisses: { id: string; opened_at: string; closed_at: string | null; status: string; opening_amount: number; user?: { full_name: string; email: string } | null }[];
  caisseId: string | null;
  onCaisseChange: (id: string | null) => void;
  onCloseCaisse?: (caisseId: string, input: { closing_amount?: number; notes?: string }) => Promise<void>;
  activeCaisseId?: string | null;
  onDeleteCaisse?: (caisseId: string) => Promise<void>;
}

/* ─── Helpers ──────────────────────────────────────────────────── */
function fmtN(n: number, currency = 'FCFA') {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n) + ' ' + currency;
}
function fmtQ(n: number) {
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 4 }).format(n);
}
function fmtDate(d: string) {
  return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}
function fmtDateTime(d: string) {
  return new Date(d).toLocaleString('fr-FR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}
function todayLocal() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function buildPeriod(dateStart: string, dateEnd: string) {
  const end = dateEnd || dateStart;
  return { start: `${dateStart}T00:00:00.000`, end: `${end}T23:59:59.999` };
}
function fmtPeriod(start: string, end: string) {
  const s = start.slice(0, 10);
  const e = end.slice(0, 10);
  return s === e ? fmtDate(s) : `${fmtDate(s)} → ${fmtDate(e)}`;
}

const METHOD_META: Record<string, { label: string; icon: string }> = Object.fromEntries(
  ALL_PAYMENT_METHODS.map(m => [m.value, { label: m.label, icon: m.icon }])
);

function DiffBadge({ diff }: { diff: number }) {
  if (Math.abs(diff) < 0.5) return <span className="text-sm text-gray-400">—</span>;
  const pos = diff > 0;
  return (
    <span className={`inline-flex items-center gap-1 text-sm font-semibold ${pos ? 'text-emerald-600' : 'text-red-500'}`}>
      {pos ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
      {pos ? '+' : ''}{fmtN(diff, '')}
    </span>
  );
}

/* ─── Products table ────────────────────────────────────────────── */
function ProductsTable({ products, currency }: { products: ProductSaleSummary[]; currency: string }) {
  const totalQty = products.reduce((s, p) => s + p.total_quantity, 0);
  const totalAmt = products.reduce((s, p) => s + p.total_amount, 0);
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-gray-50">
            <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Article</th>
            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Qté vendue</th>
            <th className="px-4 py-3 pr-5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Montant</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {products.map((p, i) => (
            <tr key={i} className="hover:bg-gray-50/60">
              <td className="px-5 py-3 font-medium text-gray-800">{p.description}</td>
              <td className="px-4 py-3 text-right tabular-nums text-gray-700">{fmtQ(p.total_quantity)}</td>
              <td className="px-4 py-3 pr-5 text-right tabular-nums font-semibold text-gray-900">{fmtN(p.total_amount, currency)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr className="border-t-2 border-gray-300 bg-gray-50">
            <td className="px-5 py-3 text-sm font-bold text-gray-700">TOTAL</td>
            <td className="px-4 py-3 text-right tabular-nums text-sm font-bold text-gray-700">{fmtQ(totalQty)} art.</td>
            <td className="px-4 py-3 pr-5 text-right tabular-nums text-sm font-bold text-blue-700">{fmtN(totalAmt, currency)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

/* ─── Print ─────────────────────────────────────────────────────── */
function buildClosingHtml(
  c: CaisseClosing,
  products: ProductSaleSummary[],
  settings: CompanySettings | null,
  currency: string
) {
  const f    = (n: number) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n);
  const fq   = (n: number) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 4 }).format(n);
  const cls  = c.lines ?? [];
  const totE = cls.reduce((s, l) => s + Number(l.expected_amount), 0);
  const totC = cls.reduce((s, l) => s + Number(l.counted_amount), 0);
  const diff = totC - totE;

  const linesHtml = cls.map(l => {
    const d    = Number(l.counted_amount) - Number(l.expected_amount);
    const meta = METHOD_META[l.method] ?? { label: l.method, icon: '' };
    return `<tr>
      <td>${meta.icon} ${meta.label}</td>
      <td class="r">${f(Number(l.expected_amount))}</td>
      <td class="r">${f(Number(l.counted_amount))}</td>
      <td class="r ${d > 0.5 ? 'surplus' : d < -0.5 ? 'manque' : ''}">${d > 0 ? '+' : ''}${f(d)}</td>
    </tr>`;
  }).join('');

  const productsHtml = products.map(p =>
    `<tr><td>${p.description}</td><td class="r">${fq(p.total_quantity)}</td><td class="r">${f(p.total_amount)}</td></tr>`
  ).join('');
  const totalProdAmt = products.reduce((s, p) => s + p.total_amount, 0);
  const totalProdQty = products.reduce((s, p) => s + p.total_quantity, 0);

  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<title>Point de caisse ${c.date}</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: 'Courier New', monospace; font-size: 11px; color:#111; }
  @media screen { html { background:#e8e8e8; } body { width:80mm; margin:20px auto; padding:6mm 5mm 12mm; background:#fff; box-shadow:0 4px 20px rgba(0,0,0,.18); } }
  @media print { @page { size:80mm auto; margin:0; } body { width:80mm; padding:3mm 4mm 8mm; } }
  h1 { font-size:14px; text-align:center; font-weight:900; text-transform:uppercase; }
  .c { text-align:center; font-size:10px; color:#555; margin-top:1px; }
  .sep { border:none; border-top:1px dashed #999; margin:5px 0; }
  .title { text-align:center; font-size:11.5px; font-weight:700; letter-spacing:2px; padding:2px 0; }
  table { width:100%; border-collapse:collapse; font-size:10px; }
  th { font-size:9px; text-transform:uppercase; font-weight:700; padding-bottom:2px; }
  td, th { padding:2px 1px; }
  .r { text-align:right; }
  .bold { font-weight:700; }
  .total td { font-weight:900; font-size:11px; border-top:1px solid #333; padding-top:3px; }
  .surplus { color:#2a7a2a; } .manque { color:#b00; }
  .footer { text-align:center; font-size:9px; color:#666; margin-top:4px; }
</style></head><body>
<h1>${settings?.name ?? 'POINT DE CAISSE'}</h1>
<div class="c">${fmtDate(c.date)}</div>
<hr class="sep">

${products.length > 0 ? `
<div class="title">ARTICLES VENDUS</div>
<hr class="sep">
<table>
  <tr><th>Article</th><th class="r">Qté</th><th class="r">Montant</th></tr>
  ${productsHtml}
  <tr class="total">
    <td>TOTAL</td>
    <td class="r">${fq(totalProdQty)}</td>
    <td class="r">${f(totalProdAmt)} ${currency}</td>
  </tr>
</table>
<hr class="sep">` : ''}

<div class="title">ENCAISSEMENTS</div>
<hr class="sep">
<table>
  <tr><th>Mode</th><th class="r">Attendu</th><th class="r">Compté</th><th class="r">Écart</th></tr>
  ${linesHtml}
  <tr class="total">
    <td>TOTAL</td>
    <td class="r">${f(totE)} ${currency}</td>
    <td class="r">${f(totC)} ${currency}</td>
    <td class="r ${diff > 0.5 ? 'surplus' : diff < -0.5 ? 'manque' : ''}">${diff > 0 ? '+' : ''}${f(diff)}</td>
  </tr>
</table>

${c.notes ? `<hr class="sep"><div class="c" style="text-align:left">${c.notes}</div>` : ''}
<hr class="sep">
<div class="footer">Statut : ${c.status === 'cloturee' ? 'CLÔTURÉ' : 'Brouillon'} — ${fmtDateTime(c.created_at)}</div>
</body></html>`;
}

function printClosing(
  c: CaisseClosing,
  products: ProductSaleSummary[],
  settings: CompanySettings | null,
  currency: string
) {
  printDocument(buildClosingHtml(c, products, settings, currency), { format: 'receipt', title: `Point de caisse — ${c.date}` });
}

async function exportClosingPdf(
  c: CaisseClosing,
  products: ProductSaleSummary[],
  settings: CompanySettings | null,
  currency: string
) {
  await exportHtmlToPdf(buildClosingHtml(c, products, settings, currency), `point_caisse_${c.date}.pdf`, 'receipt');
}

interface LiveReportData {
  dateStart: string;
  dateEnd: string;
  caisseLabel: string;
  cashSummary: { opening_amount: number; total_sales: number; total_expenses: number; expense_count: number; theoretical_balance: number } | null;
  productSales: ProductSaleSummary[];
  posJournal: PosJournalEntry[];
  invoiceJournal: InvoiceJournalEntry[];
  paymentSummary: PaymentSummaryEntry[];
  lines: { method: PaymentMethod; expected: number; counted: string }[];
  notes: string;
  settings: CompanySettings | null;
  currency: string;
}

function buildLiveReportHtml(d: LiveReportData): string {
  const f  = (n: number) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n);
  const fq = (n: number) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 4 }).format(n);
  const meta = (m: string) => METHOD_META[m] ?? { label: m, icon: '' };

  const periodLabel = d.dateStart === d.dateEnd
    ? new Date(d.dateStart).toLocaleDateString('fr-FR')
    : `${new Date(d.dateStart).toLocaleDateString('fr-FR')} → ${new Date(d.dateEnd).toLocaleDateString('fr-FR')}`;

  const totalExpected = d.lines.reduce((s, l) => s + l.expected, 0);
  const totalCounted  = d.lines.reduce((s, l) => s + (parseFloat(l.counted) || 0), 0);
  const totalDiff    = totalCounted - totalExpected;

  // Cash summary block
  const cashBlock = d.cashSummary ? `
    <div class="section-title">FOND DE CAISSE &amp; DÉPENSES</div>
    <table class="kpi-table">
      <tr>
        <td class="kpi"><span class="kpi-label">Fond d'ouverture</span><span class="kpi-val">${f(d.cashSummary.opening_amount)}</span></td>
        <td class="kpi"><span class="kpi-label">Ventes POS</span><span class="kpi-val green">${f(d.cashSummary.total_sales)}</span></td>
        <td class="kpi"><span class="kpi-label">Dépenses (${d.cashSummary.expense_count})</span><span class="kpi-val red">${f(d.cashSummary.total_expenses)}</span></td>
        <td class="kpi"><span class="kpi-label">Solde théorique</span><span class="kpi-val blue">${f(d.cashSummary.theoretical_balance)}</span></td>
      </tr>
    </table>` : '';

  // Products
  const productsHtml = d.productSales.map(p =>
    `<tr><td>${p.description}</td><td class="r">${fq(p.total_quantity)}</td><td class="r">${f(p.total_amount)}</td></tr>`
  ).join('');
  const totalProdAmt = d.productSales.reduce((s, p) => s + p.total_amount, 0);
  const totalProdQty = d.productSales.reduce((s, p) => s + p.total_quantity, 0);
  const productsBlock = d.productSales.length > 0 ? `
    <div class="section-title">ARTICLES VENDUS (${d.productSales.length} réf.)</div>
    <table>
      <tr><th>Article</th><th class="r">Qté</th><th class="r">Montant</th></tr>
      ${productsHtml}
      <tr class="total-row"><td>TOTAL</td><td class="r">${fq(totalProdQty)}</td><td class="r">${f(totalProdAmt)} ${d.currency}</td></tr>
    </table>` : '';

  // POS journal
  const posHtml = d.posJournal.map(s => `
    <tr>
      <td>${s.sale_number}</td>
      <td>${new Date(s.created_at).toLocaleString('fr-FR', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' })}</td>
      <td>${s.customer_name ?? 'Comptant'}</td>
      <td>${s.payment_methods}</td>
      <td class="r">${f(s.total)}</td>
    </tr>`).join('');
  const posBlock = d.posJournal.length > 0 ? `
    <div class="section-title">JOURNAL DES VENTES POS (${d.posJournal.length})</div>
    <table>
      <tr><th>N° Vente</th><th>Heure</th><th>Client</th><th>Règlement</th><th class="r">Montant</th></tr>
      ${posHtml}
      <tr class="total-row"><td colspan="4">TOTAL POS</td><td class="r">${f(d.posJournal.reduce((s,e)=>s+e.total,0))} ${d.currency}</td></tr>
    </table>` : '';

  // Invoice journal
  const invStatus: Record<string,string> = { brouillon:'Devis', envoyee:'Facture', payee:'Payée', partielle:'Partielle', annulee:'Annulée' };
  const invHtml = d.invoiceJournal.map(i => `
    <tr>
      <td>${i.invoice_number}</td>
      <td>${new Date(i.date).toLocaleDateString('fr-FR')}</td>
      <td>${i.customer_name ?? '—'}</td>
      <td>${invStatus[i.status] ?? i.status}</td>
      <td class="r">${f(i.total)}</td>
      <td class="r">${f(i.amount_paid)}</td>
    </tr>`).join('');
  const invBlock = d.invoiceJournal.length > 0 ? `
    <div class="section-title">JOURNAL DES FACTURES (${d.invoiceJournal.length})</div>
    <table>
      <tr><th>N° Facture</th><th>Date</th><th>Client</th><th>Statut</th><th class="r">Total</th><th class="r">Encaissé</th></tr>
      ${invHtml}
      <tr class="total-row"><td colspan="4">TOTAL FACTURES</td><td class="r">${f(d.invoiceJournal.reduce((s,e)=>s+e.total,0))}</td><td class="r">${f(d.invoiceJournal.reduce((s,e)=>s+e.amount_paid,0))} ${d.currency}</td></tr>
    </table>` : '';

  // Payment summary
  const payHtml = d.paymentSummary.map(p => {
    const m = meta(p.method);
    return `<tr>
      <td>${m.icon} ${m.label}</td>
      <td class="r">${p.count}</td>
      <td class="r">${p.pos_amount > 0 ? f(p.pos_amount) : '—'}</td>
      <td class="r">${p.invoice_amount > 0 ? f(p.invoice_amount) : '—'}</td>
      <td class="r bold">${f(p.total)}</td>
    </tr>`;
  }).join('');
  const payBlock = d.paymentSummary.length > 0 ? `
    <div class="section-title">SYNTHÈSE DES ENCAISSEMENTS PAR MODE</div>
    <table>
      <tr><th>Mode</th><th class="r">Nb</th><th class="r">POS</th><th class="r">Factures</th><th class="r">Total</th></tr>
      ${payHtml}
      <tr class="total-row"><td>TOTAL GÉNÉRAL</td><td class="r">${d.paymentSummary.reduce((s,p)=>s+p.count,0)}</td><td class="r">${f(d.paymentSummary.reduce((s,p)=>s+p.pos_amount,0))}</td><td class="r">${f(d.paymentSummary.reduce((s,p)=>s+p.invoice_amount,0))}</td><td class="r">${f(d.paymentSummary.reduce((s,p)=>s+p.total,0))} ${d.currency}</td></tr>
    </table>` : '';

  // Reconciliation
  const reconHtml = d.lines.map(l => {
    const m = meta(l.method);
    const counted = parseFloat(l.counted) || 0;
    const diff = counted - l.expected;
    return `<tr>
      <td>${m.icon} ${m.label}</td>
      <td class="r">${f(l.expected)}</td>
      <td class="r">${f(counted)}</td>
      <td class="r ${diff > 0.5 ? 'surplus' : diff < -0.5 ? 'manque' : ''}">${diff > 0 ? '+' : ''}${f(diff)}</td>
    </tr>`;
  }).join('');
  const reconBlock = d.lines.length > 0 ? `
    <div class="section-title">COMPTAGE DES ENCAISSEMENTS</div>
    <table>
      <tr><th>Mode</th><th class="r">Attendu</th><th class="r">Compté</th><th class="r">Écart</th></tr>
      ${reconHtml}
      <tr class="total-row"><td>TOTAL</td><td class="r">${f(totalExpected)}</td><td class="r">${f(totalCounted)}</td><td class="r ${totalDiff > 0.5 ? 'surplus' : totalDiff < -0.5 ? 'manque' : ''}">${totalDiff > 0 ? '+' : ''}${f(totalDiff)}</td></tr>
    </table>
    ${Math.abs(totalDiff) >= 0.5 ? `<div class="ecart-banner ${totalDiff > 0 ? 'exc' : 'manq'}">${totalDiff > 0 ? 'EXCÉDENT' : 'MANQUANT'} : ${totalDiff > 0 ? '+' : ''}${f(totalDiff)} ${d.currency}</div>` : ''}` : '';

  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<title>Point de caisse — ${periodLabel}</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 11px; color:#1a1a1a; padding: 16mm 14mm; }
  .header { text-align:center; border-bottom: 2px solid #1e40af; padding-bottom: 8px; margin-bottom: 12px; }
  .header h1 { font-size: 18px; font-weight: 800; color:#1e40af; text-transform:uppercase; letter-spacing:1px; }
  .header .sub { font-size: 11px; color:#666; margin-top: 3px; }
  .header .meta-line { font-size: 10px; color:#999; margin-top: 2px; }
  .section-title { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color:#1e40af; margin: 14px 0 5px; padding-bottom: 3px; }
  table { width: 100%; border-collapse: collapse; font-size: 10px; }
  th { font-size: 8.5px; text-transform: uppercase; font-weight: 700; color:#6b7280; padding: 4px 6px; text-align: left; }
  td { padding: 3.5px 6px; }
  .r { text-align: right; }
  .bold { font-weight: 700; }
  .total-row td { font-weight: 800; font-size: 10.5px; border-top: 2px solid #9ca3af; border-bottom: none; padding-top: 5px; color:#111; }
  .surplus { color:#16a34a; font-weight:700; } .manque { color:#dc2626; font-weight:700; }
  .kpi-table { margin-bottom: 4px; }
  .kpi-table td { border: 1px solid #e5e7eb; padding: 8px 10px; }
  .kpi { width: 25%; }
  .kpi-label { display:block; font-size: 8.5px; text-transform:uppercase; color:#9ca3af; font-weight:600; letter-spacing:0.5px; }
  .kpi-val { display:block; font-size: 15px; font-weight: 800; margin-top: 3px; color:#111; }
  .kpi-val.green { color:#16a34a; } .kpi-val.red { color:#dc2626; } .kpi-val.blue { color:#1e40af; }
  .ecart-banner { margin-top: 8px; padding: 8px 12px; border-radius: 6px; font-weight: 700; font-size: 11px; text-align: center; }
  .ecart-banner.exc { background:#f0fdf4; color:#16a34a; border:1px solid #bbf7d0; }
  .ecart-banner.manq { background:#fef2f2; color:#dc2626; border:1px solid #fecaca; }
  .notes-block { margin-top: 12px; padding: 8px 10px; background:#f9fafb; border:1px solid #e5e7eb; border-radius: 6px; font-size: 10px; color:#4b5563; }
  .footer { margin-top: 18px; text-align:center; font-size: 9px; color:#9ca3af; border-top: 1px solid #e5e7eb; padding-top: 8px; }
  @media print { @page { size: A4; margin: 10mm; } body { padding: 0; } }
</style></head><body>
  <div class="header">
    <h1>${d.settings?.name ?? 'POINT DE CAISSE'}</h1>
    <div class="sub">Rapport de point de caisse — ${periodLabel}</div>
    <div class="meta-line">${d.caisseLabel} · Édité le ${new Date().toLocaleString('fr-FR')}</div>
  </div>

  ${cashBlock}
  ${productsBlock}
  ${posBlock}
  ${invBlock}
  ${payBlock}
  ${reconBlock}

  ${d.notes ? `<div class="notes-block"><strong>Notes :</strong> ${d.notes}</div>` : ''}

  <div class="footer">Document généré par Stocklite — ${new Date().toLocaleString('fr-FR')}</div>
</body></html>`;
}

async function exportLiveReportPdf(d: LiveReportData) {
  const filename = `point_caisse_${d.dateStart}${d.dateEnd !== d.dateStart ? '_'+d.dateEnd : ''}.pdf`;
  await exportHtmlToPdf(buildLiveReportHtml(d), filename, 'a4');
}

/* ═══════════════════════════════════════════════════════════════ */
export function CaisseClosingPage({
  settings, isAdmin, computeExpected, computeProductSales,
  computePosJournal, computeInvoiceJournal, computePaymentSummary, computeCashSummary,
  saveClosing, closings, loading, fetchClosings,
  caisses, caisseId, onCaisseChange, onCloseCaisse, activeCaisseId, onDeleteCaisse,
}: CaisseClosingPageProps) {
  const currency = settings?.currency ?? 'FCFA';

  const [dateStart, setDateStart] = useState(todayLocal());
  const [dateEnd, setDateEnd]     = useState(todayLocal());
  const [computing, setComputing]   = useState(false);

  // When a caisse is selected, the period is derived from the caisse session itself
  const selectedCaisse = caisses.find(c => c.id === caisseId) ?? null;
  const caisseDriven = !!selectedCaisse;
  const effectiveStart = caisseDriven ? selectedCaisse!.opened_at : `${dateStart}T00:00:00.000`;
  const effectiveEnd = caisseDriven
    ? (selectedCaisse!.closed_at ?? new Date().toISOString())
    : `${dateEnd || dateStart}T23:59:59.999`;
  const [saving, setSaving]         = useState(false);
  const [pdfSaving, setPdfSaving]   = useState(false);

  const [lines, setLines]           = useState<{ method: PaymentMethod; expected: number; counted: string }[]>([]);
  const [productSales, setProductSales] = useState<ProductSaleSummary[]>([]);
  const [posJournal, setPosJournal] = useState<PosJournalEntry[]>([]);
  const [invoiceJournal, setInvoiceJournal] = useState<InvoiceJournalEntry[]>([]);
  const [paymentSummary, setPaymentSummary] = useState<PaymentSummaryEntry[]>([]);
  const [cashSummary, setCashSummary] = useState<{ opening_amount: number; total_sales: number; total_expenses: number; expense_count: number; theoretical_balance: number } | null>(null);
  const [notes, setNotes]           = useState('');
  const [computed, setComputed]     = useState(false);
  const [error, setError]           = useState<string | null>(null);

  // History
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [histProducts, setHistProducts] = useState<Record<string, ProductSaleSummary[]>>({});
  const [histLoading, setHistLoading]   = useState<Record<string, boolean>>({});

  useEffect(() => { fetchClosings(); }, [fetchClosings]);

  // Auto-load data when caisse or period changes
  const loadData = useCallback(async () => {
    setComputing(true);
    setError(null);
    try {
      const start = effectiveStart;
      const end = effectiveEnd;
      const cId = caisseId;
      const [expected, products, posJ, invJ, paySum, cashSum] = await Promise.all([
        computeExpected(start, end, cId),
        computeProductSales(start, end, cId),
        computePosJournal(start, end, cId),
        computeInvoiceJournal(start, end),
        computePaymentSummary(start, end, cId),
        computeCashSummary(start, end, cId),
      ]);
      setLines(expected.map(e => ({
        method: e.method,
        expected: e.expected_amount,
        counted: String(Math.round(e.expected_amount)),
      })));
      setProductSales(products);
      setPosJournal(posJ);
      setInvoiceJournal(invJ);
      setPaymentSummary(paySum);
      setCashSummary(cashSum);
      setComputed(true);
    } catch (e) {
      setError(e instanceof Error ? translateError(e.message) : 'Erreur lors du calcul');
      setComputed(true);
    } finally {
      setComputing(false);
    }
  }, [computeExpected, computeProductSales, computePosJournal, computeInvoiceJournal, computePaymentSummary, computeCashSummary, caisseId, effectiveStart, effectiveEnd]);

  useEffect(() => {
    if (computed) { setLines([]); setProductSales([]); setPosJournal([]); setInvoiceJournal([]); setPaymentSummary([]); setCashSummary(null); setComputed(false); }
    loadData();
  }, [loadData]);

  function setCounted(method: PaymentMethod, val: string) {
    setLines(prev => prev.map(l => l.method === method ? { ...l, counted: val } : l));
  }

  const totalExpected = lines.reduce((s, l) => s + l.expected, 0);
  const totalCounted  = lines.reduce((s, l) => s + (parseFloat(l.counted) || 0), 0);
  const totalDiff     = totalCounted - totalExpected;
  const nbSales       = productSales.length;
  const totalProdAmt  = productSales.reduce((s, p) => s + p.total_amount, 0);
  const totalProdQty  = productSales.reduce((s, p) => s + p.total_quantity, 0);
  const paySumTotal   = paymentSummary.reduce((s, p) => s + p.total, 0);
  const paySumCount   = paymentSummary.reduce((s, p) => s + p.count, 0);

  async function handleSave(status: 'brouillon' | 'cloturee') {
    if (lines.length === 0 && productSales.length === 0) return;
    setSaving(true);
    try {
      await saveClosing({
        period_start: effectiveStart,
        period_end: effectiveEnd,
        caisse_id: caisseId,
        lines: lines.map(l => ({
          method: l.method,
          expected_amount: l.expected,
          counted_amount: parseFloat(l.counted) || 0,
        })),
        notes,
        status,
      });

      if (status === 'cloturee' && onCloseCaisse) {
        const cId = caisseId ?? activeCaisseId;
        if (cId) await onCloseCaisse(cId, { closing_amount: totalCounted, notes });
      }
      setLines([]); setProductSales([]); setComputed(false); setNotes('');
      setDateStart(todayLocal()); setDateEnd(todayLocal());
    } catch (e) {
      alert(e instanceof Error ? translateError(e.message) : 'Erreur');
    } finally {
      setSaving(false);
    }
  }

  async function loadHistProducts(c: CaisseClosing) {
    if (histProducts[c.id]) return;
    setHistLoading(p => ({ ...p, [c.id]: true }));
    const products = await computeProductSales(c.period_start, c.period_end, c.caisse_id);
    setHistProducts(p => ({ ...p, [c.id]: products }));
    setHistLoading(p => ({ ...p, [c.id]: false }));
  }

  function toggleHistory(c: CaisseClosing) {
    const next = expandedId === c.id ? null : c.id;
    setExpandedId(next);
    if (next) loadHistProducts(c);
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-gray-900">Point de caisse</h1>
          <p className="text-sm text-gray-400">
            {caisseDriven
              ? `Session de caisse — ${fmtDateTime(selectedCaisse!.opened_at)} → ${selectedCaisse!.closed_at ? fmtDateTime(selectedCaisse!.closed_at) : 'en cours'}`
              : 'Synthèse par période — toutes caisses'}
          </p>
        </div>
        {!caisseDriven && (
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={dateStart}
              onChange={e => setDateStart(e.target.value)}
              className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-800 shadow-sm outline-none focus:border-blue-500"
            />
            <span className="text-gray-400 text-sm">→</span>
            <input
              type="date"
              value={dateEnd}
              onChange={e => setDateEnd(e.target.value)}
              className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-800 shadow-sm outline-none focus:border-blue-500"
            />
            <button
              onClick={() => loadData()}
              disabled={computing}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50 shadow-sm active:scale-95"
            >
              {computing
                ? <><RefreshCw className="h-4 w-4 animate-spin" /> Calcul…</>
                : <><Calculator className="h-4 w-4" /> Calculer</>
              }
            </button>
          </div>
        )}
      </div>

      {/* Caisse selector */}
      <div className="flex flex-wrap items-center gap-3 rounded-xl border border-gray-200 bg-white px-5 py-4 shadow-sm">
        <div className="flex items-center gap-2 text-sm font-semibold text-gray-700">
          <Wallet className="h-4 w-4 text-gray-400" />
          Caisse
        </div>
        <select
          value={caisseId ?? ''}
          onChange={e => onCaisseChange(e.target.value || null)}
          className="flex-1 min-w-[200px] rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 shadow-sm"
        >
          <option value="">Toutes les caisses (par période)</option>
          {caisses.map(c => (
            <option key={c.id} value={c.id}>
              {new Date(c.opened_at).toLocaleString('fr-FR')}
              {c.closed_at ? ' · clôturée' : ' · ouverte'}
              {c.user ? ` · ${c.user.full_name}` : ''}
            </option>
          ))}
        </select>
        {caisseDriven && (
          <>
            <button
              onClick={() => loadData()}
              disabled={computing}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition disabled:opacity-50 shadow-sm active:scale-95"
            >
              {computing
                ? <><RefreshCw className="h-4 w-4 animate-spin" /> Calcul…</>
                : <><RefreshCw className="h-4 w-4" /> Actualiser</>
              }
            </button>
            {onDeleteCaisse && (
              <button
                onClick={async () => {
                  if (!confirm('Supprimer cette caisse et toutes les ventes associées ? Cette action est irréversible.')) return;
                  try {
                    await onDeleteCaisse(caisseId!);
                    onCaisseChange(null);
                  } catch (e) {
                    alert(e instanceof Error ? e.message : 'Erreur');
                  }
                }}
                className="flex items-center gap-2 rounded-lg border border-red-200 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 transition shadow-sm active:scale-95"
              >
                <Trash2 className="h-4 w-4" />
                Supprimer
              </button>
            )}
          </>
        )}
      </div>

      {/* ── Main card ── */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">

        {/* Error state */}
        {error && (
          <div className="mx-5 my-4 flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">
            <AlertTriangle className="h-4 w-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* Empty state */}
        {computed && !error && productSales.length === 0 && totalExpected === 0 && (
          <div className="px-5 py-8 text-center text-sm text-gray-400">
            {caisseDriven
              ? 'Aucune vente enregistrée sur cette session de caisse.'
              : 'Aucune vente enregistrée pour cette période.'}
          </div>
        )}

        {/* Cash summary — fond de caisse, ventes, dépenses, solde théorique */}
        {computed && !error && cashSummary && (cashSummary.opening_amount > 0 || cashSummary.total_expenses > 0 || cashSummary.expense_count > 0) && (
          <div className="border-b border-gray-100">
            <div className="flex items-center gap-2 bg-amber-50/60 px-5 py-3">
              <Coins className="h-4 w-4 text-amber-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-amber-700">
                Fond de caisse & dépenses
              </span>
            </div>
            <div className="grid grid-cols-2 divide-x divide-y divide-gray-100 sm:grid-cols-4">
              <div className="px-5 py-4">
                <div className="flex items-center gap-1.5 text-xs text-gray-400">
                  <Coins className="h-3.5 w-3.5" /> Fond d'ouverture
                </div>
                <p className="mt-1 text-lg font-bold tabular-nums text-gray-900">{fmtN(cashSummary.opening_amount, currency)}</p>
              </div>
              <div className="px-5 py-4">
                <div className="flex items-center gap-1.5 text-xs text-gray-400">
                  <ArrowUpCircle className="h-3.5 w-3.5" /> Ventes POS
                </div>
                <p className="mt-1 text-lg font-bold tabular-nums text-emerald-600">{fmtN(cashSummary.total_sales, currency)}</p>
              </div>
              <div className="px-5 py-4">
                <div className="flex items-center gap-1.5 text-xs text-gray-400">
                  <ArrowDownCircle className="h-3.5 w-3.5" /> Dépenses
                  {cashSummary.expense_count > 0 && <span className="text-gray-300">({cashSummary.expense_count})</span>}
                </div>
                <p className="mt-1 text-lg font-bold tabular-nums text-red-600">{fmtN(cashSummary.total_expenses, currency)}</p>
              </div>
              <div className="px-5 py-4">
                <div className="flex items-center gap-1.5 text-xs text-gray-400">
                  <Scale className="h-3.5 w-3.5" /> Solde théorique
                </div>
                <p className="mt-1 text-lg font-bold tabular-nums text-blue-700">{fmtN(cashSummary.theoretical_balance, currency)}</p>
              </div>
            </div>
          </div>
        )}

        {/* KPI strip */}
        {computed && !error && (lines.length > 0 || productSales.length > 0) && (
          <div className="grid grid-cols-2 divide-x divide-y divide-gray-100 sm:grid-cols-4 border-b border-gray-100">
            {[
              { label: 'Articles distincts', value: String(nbSales), sub: 'références vendues' },
              { label: 'Quantité totale',    value: fmtQ(totalProdQty), sub: 'unités' },
              { label: 'CA période',          value: fmtN(totalProdAmt, currency), sub: 'total articles' },
              { label: 'Encaissements',      value: fmtN(totalExpected, currency), sub: 'attendu POS' },
            ].map(k => (
              <div key={k.label} className="px-5 py-4">
                <p className="text-xs text-gray-400">{k.label}</p>
                <p className="mt-1 text-lg font-bold tabular-nums text-gray-900">{k.value}</p>
                <p className="text-xs text-gray-400">{k.sub}</p>
              </div>
            ))}
          </div>
        )}

        {/* ── Section 1: Products sold ── */}
        {computed && productSales.length > 0 && (
          <div>
            <div className="flex items-center gap-2 border-b border-gray-100 bg-blue-50/60 px-5 py-3">
              <ShoppingBag className="h-4 w-4 text-blue-500" />
              <span className="text-xs font-bold uppercase tracking-wider text-blue-700">
                Synthèse des articles vendus
              </span>
              <span className="ml-auto rounded-full bg-blue-100 px-2 py-0.5 text-xs font-bold text-blue-700">
                {productSales.length} réf.
              </span>
            </div>
            <ProductsTable products={productSales} currency={currency} />
          </div>
        )}

        {/* No products but has lines */}
        {computed && !error && productSales.length === 0 && lines.length > 0 && (
          <div className="flex items-center gap-2 border-b border-gray-100 px-5 py-4 text-sm text-gray-400">
            <Package className="h-4 w-4" />
            Aucun article de caisse enregistré pour cette période.
          </div>
        )}

        {/* ── Section 1b: POS sales journal ── */}
        {computed && !error && posJournal.length > 0 && (
          <div className="border-t border-gray-100">
            <div className="flex items-center gap-2 border-b border-gray-100 bg-emerald-50/60 px-5 py-3">
              <Receipt className="h-4 w-4 text-emerald-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                Journal des ventes POS
              </span>
              <span className="ml-auto rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-700">
                {posJournal.length} vente{posJournal.length > 1 ? 's' : ''}
              </span>
            </div>
            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 z-10">
                  <tr className="bg-gray-50">
                    <th className="px-5 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">N° Vente</th>
                    <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Heure</th>
                    <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Client</th>
                    <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Règlement</th>
                    <th className="px-4 py-2.5 pr-5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Montant</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {posJournal.map(s => (
                    <tr key={s.id} className="hover:bg-gray-50/60">
                      <td className="px-5 py-2.5 font-medium text-gray-800">{s.sale_number}</td>
                      <td className="px-4 py-2.5 text-gray-500">{new Date(s.created_at).toLocaleString('fr-FR', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}</td>
                      <td className="px-4 py-2.5 text-gray-600">{s.customer_name ?? 'Comptant'}</td>
                      <td className="px-4 py-2.5 text-gray-500 text-xs">{s.payment_methods}</td>
                      <td className="px-4 py-2.5 pr-5 text-right tabular-nums font-semibold text-gray-900">{fmtN(s.total, currency)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="sticky bottom-0">
                  <tr className="border-t-2 border-gray-300 bg-gray-50">
                    <td className="px-5 py-2.5 text-sm font-bold text-gray-700" colSpan={4}>TOTAL POS</td>
                    <td className="px-4 py-2.5 pr-5 text-right tabular-nums text-sm font-bold text-emerald-700">{fmtN(posJournal.reduce((s, e) => s + e.total, 0), currency)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}

        {/* ── Section 1c: Invoice journal ── */}
        {computed && !error && invoiceJournal.length > 0 && (
          <div className="border-t border-gray-100">
            <div className="flex items-center gap-2 border-b border-gray-100 bg-blue-50/60 px-5 py-3">
              <FileText className="h-4 w-4 text-blue-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-blue-700">
                Journal des factures
              </span>
              <span className="ml-auto rounded-full bg-blue-100 px-2 py-0.5 text-xs font-bold text-blue-700">
                {invoiceJournal.length} facture{invoiceJournal.length > 1 ? 's' : ''}
              </span>
            </div>
            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 z-10">
                  <tr className="bg-gray-50">
                    <th className="px-5 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">N° Facture</th>
                    <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Date</th>
                    <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Client</th>
                    <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Statut</th>
                    <th className="px-4 py-2.5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Total</th>
                    <th className="px-4 py-2.5 pr-5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Encaissé</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {invoiceJournal.map(i => {
                    const statusLabels: Record<string, string> = { brouillon: 'Devis', envoyee: 'Facture', payee: 'Payée', partielle: 'Partielle', annulee: 'Annulée' };
                    const statusColors: Record<string, string> = { brouillon: 'text-gray-500', envoyee: 'text-blue-600', payee: 'text-emerald-600', partielle: 'text-amber-600', annulee: 'text-red-500' };
                    return (
                      <tr key={i.id} className="hover:bg-gray-50/60">
                        <td className="px-5 py-2.5 font-medium text-gray-800">{i.invoice_number}</td>
                        <td className="px-4 py-2.5 text-gray-500">{fmtDate(i.date)}</td>
                        <td className="px-4 py-2.5 text-gray-600">{i.customer_name ?? '—'}</td>
                        <td className={`px-4 py-2.5 text-xs font-semibold ${statusColors[i.status] ?? 'text-gray-500'}`}>{statusLabels[i.status] ?? i.status}</td>
                        <td className="px-4 py-2.5 text-right tabular-nums text-gray-700">{fmtN(i.total, currency)}</td>
                        <td className="px-4 py-2.5 pr-5 text-right tabular-nums font-semibold text-gray-900">{fmtN(i.amount_paid, currency)}</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="sticky bottom-0">
                  <tr className="border-t-2 border-gray-300 bg-gray-50">
                    <td className="px-5 py-2.5 text-sm font-bold text-gray-700" colSpan={4}>TOTAL FACTURES</td>
                    <td className="px-4 py-2.5 text-right tabular-nums text-sm font-bold text-gray-900">{fmtN(invoiceJournal.reduce((s, e) => s + e.total, 0), currency)}</td>
                    <td className="px-4 py-2.5 pr-5 text-right tabular-nums text-sm font-bold text-blue-700">{fmtN(invoiceJournal.reduce((s, e) => s + e.amount_paid, 0), currency)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}

        {/* ── Section 1d: Payment summary by method ── */}
        {computed && !error && paymentSummary.length > 0 && (
          <div className="border-t border-gray-100">
            <div className="flex items-center gap-2 border-b border-gray-100 bg-violet-50/60 px-5 py-3">
              <BarChart3 className="h-4 w-4 text-violet-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-violet-700">
                Synthèse des encaissements par mode de règlement
              </span>
              <span className="ml-auto rounded-full bg-violet-100 px-2 py-0.5 text-xs font-bold text-violet-700">
                {paySumCount} encaissement{paySumCount > 1 ? 's' : ''}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Mode de règlement</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Nb</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Ventes POS</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Factures</th>
                    <th className="px-4 py-3 pr-5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {paymentSummary.map(p => {
                    const meta = METHOD_META[p.method] ?? { label: p.method, icon: '' };
                    return (
                      <tr key={p.method} className="hover:bg-gray-50/60">
                        <td className="px-5 py-3 font-medium text-gray-800">
                          <span className="mr-1.5">{meta.icon}</span>{meta.label}
                        </td>
                        <td className="px-4 py-3 text-right tabular-nums text-gray-500">{p.count}</td>
                        <td className="px-4 py-3 text-right tabular-nums text-gray-600">{p.pos_amount > 0 ? fmtN(p.pos_amount, currency) : '—'}</td>
                        <td className="px-4 py-3 text-right tabular-nums text-gray-600">{p.invoice_amount > 0 ? fmtN(p.invoice_amount, currency) : '—'}</td>
                        <td className="px-4 py-3 pr-5 text-right tabular-nums font-bold text-gray-900">{fmtN(p.total, currency)}</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-gray-300 bg-gray-50 font-bold">
                    <td className="px-5 py-3 text-sm font-bold text-gray-700">TOTAL GÉNÉRAL</td>
                    <td className="px-4 py-3 text-right tabular-nums text-sm text-gray-700">{paySumCount}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-sm text-gray-700">{fmtN(paymentSummary.reduce((s, p) => s + p.pos_amount, 0), currency)}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-sm text-gray-700">{fmtN(paymentSummary.reduce((s, p) => s + p.invoice_amount, 0), currency)}</td>
                    <td className="px-4 py-3 pr-5 text-right tabular-nums text-sm font-bold text-violet-700">{fmtN(paySumTotal, currency)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}

        {/* ── Section 2: Payment reconciliation ── */}
        {computed && !error && lines.length > 0 && (
          <div className="border-t border-gray-200">
            <div className="flex items-center gap-2 border-b border-gray-100 bg-gray-50 px-5 py-3">
              <span className="text-xs font-bold uppercase tracking-wider text-gray-400">Comptage des encaissements</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr>
                    <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Mode de paiement</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Attendu (POS)</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Compté</th>
                    <th className="px-4 py-3 pr-5 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Écart</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {lines.map(l => {
                    const meta    = METHOD_META[l.method] ?? { label: l.method, icon: '' };
                    const counted = parseFloat(l.counted) || 0;
                    const diff    = counted - l.expected;
                    return (
                      <tr key={l.method} className="hover:bg-gray-50/60">
                        <td className="px-5 py-3 font-medium text-gray-800">
                          <span className="mr-1.5">{meta.icon}</span>{meta.label}
                        </td>
                        <td className="px-4 py-3 text-right tabular-nums text-gray-600">{fmtN(l.expected, currency)}</td>
                        <td className="px-4 py-3 text-right">
                          <input
                            type="number" step="any" min="0" value={l.counted}
                            onChange={e => setCounted(l.method, e.target.value)}
                            className="w-36 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-right text-sm tabular-nums text-gray-900 outline-none focus:border-blue-500 shadow-sm"
                          />
                        </td>
                        <td className="px-4 py-3 pr-5 text-right"><DiffBadge diff={diff} /></td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-gray-300 bg-gray-50 font-bold">
                    <td className="px-5 py-3 text-sm font-bold text-gray-700">TOTAL</td>
                    <td className="px-4 py-3 text-right tabular-nums text-gray-900">{fmtN(totalExpected, currency)}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-gray-900">{fmtN(totalCounted, currency)}</td>
                    <td className="px-4 py-3 pr-5 text-right"><DiffBadge diff={totalDiff} /></td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Écart banner */}
            {Math.abs(totalDiff) >= 0.5 && (
              <div className={`mx-5 my-3 flex items-center gap-2 rounded-lg px-4 py-3 text-sm font-semibold ${
                totalDiff > 0
                  ? 'bg-emerald-50 border border-emerald-200 text-emerald-700'
                  : 'bg-red-50 border border-red-200 text-red-600'
              }`}>
                <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                {totalDiff > 0
                  ? `Excédent de caisse : + ${fmtN(totalDiff, currency)}`
                  : `Manquant en caisse : ${fmtN(totalDiff, currency)}`}
              </div>
            )}
          </div>
        )}

        {/* ── Actions ── */}
        {computed && !error && (lines.length > 0 || productSales.length > 0) && (
          <div className="border-t border-gray-100 px-5 py-4 space-y-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-gray-500">Notes / observations</label>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                rows={2}
                placeholder="Observations sur la caisse…"
                className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 resize-none"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handleSave('brouillon')}
                disabled={saving}
                className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition shadow-sm disabled:opacity-50"
              >
                <Clock className="h-4 w-4" /> Enregistrer brouillon
              </button>
              <button
                onClick={async () => {
                  setPdfSaving(true);
                  try {
                    await exportLiveReportPdf({
                      dateStart: effectiveStart.slice(0, 10),
                      dateEnd: effectiveEnd.slice(0, 10),
                      caisseLabel: selectedCaisse
                        ? `${fmtDateTime(selectedCaisse.opened_at)} → ${selectedCaisse.closed_at ? fmtDateTime(selectedCaisse.closed_at) : 'en cours'}`
                        : 'Toutes les caisses',
                      cashSummary, productSales, posJournal, invoiceJournal,
                      paymentSummary, lines, notes, settings, currency,
                    });
                  } finally { setPdfSaving(false); }
                }}
                disabled={pdfSaving}
                className="flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-4 py-2.5 text-sm font-semibold text-blue-700 hover:bg-blue-100 transition shadow-sm disabled:opacity-50"
              >
                <FileDown className="h-4 w-4" /> {pdfSaving ? 'Génération…' : 'Télécharger PDF'}
              </button>
              <button
                onClick={() => handleSave('cloturee')}
                disabled={saving}
                className="flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-500 transition shadow-sm disabled:opacity-50"
              >
                <CheckCircle className="h-4 w-4" />
                {saving ? 'Enregistrement…' : 'Clôturer la caisse'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ── History ── */}
      <div>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-gray-400">Historique des clôtures</h2>
        {loading ? (
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => <div key={i} className="h-14 animate-pulse rounded-xl bg-gray-100" />)}
          </div>
        ) : closings.length === 0 ? (
          <div className="rounded-xl border border-gray-200 py-10 text-center text-sm text-gray-400">
            Aucune clôture enregistrée.
          </div>
        ) : (
          <div className="space-y-2">
            {closings.map(c => {
              const cls    = c.lines ?? [];
              const totE   = cls.reduce((s, l) => s + Number(l.expected_amount), 0);
              const totC   = cls.reduce((s, l) => s + Number(l.counted_amount), 0);
              const diff   = totC - totE;
              const isOpen = expandedId === c.id;
              const hProds = histProducts[c.id] ?? [];
              const hLoad  = histLoading[c.id] ?? false;
              return (
                <div key={c.id} className="rounded-xl border border-gray-200 bg-white overflow-hidden">
                  <button
                    className="flex w-full items-center gap-3 px-5 py-3.5 hover:bg-gray-50 transition text-left"
                    onClick={() => toggleHistory(c)}
                  >
                    <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                      c.status === 'cloturee' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-500'
                    }`}>
                      {c.status === 'cloturee' ? <CheckCircle className="h-4 w-4" /> : <Clock className="h-4 w-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-sm font-semibold text-gray-800">{fmtPeriod(c.period_start, c.period_end)}</p>
                        {isAdmin && c.user && (
                          <span className="inline-flex items-center rounded-full bg-blue-50 px-2 py-0.5 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-100">
                            {c.user.full_name || c.user.email}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-400">{fmtDateTime(c.period_start)} → {fmtDateTime(c.period_end)}</p>
                      {c.user && (
                        <p className="text-xs text-gray-400">Caissier : {c.user.full_name || c.user.email}</p>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold tabular-nums text-gray-900">{fmtN(totC, currency)}</p>
                      {Math.abs(diff) >= 0.5 && (
                        <p className={`text-xs font-semibold tabular-nums ${diff > 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                          {diff > 0 ? '+' : ''}{fmtN(diff, '')}
                        </p>
                      )}
                    </div>
                    {isOpen ? <ChevronUp className="h-4 w-4 text-gray-400 shrink-0" /> : <ChevronDown className="h-4 w-4 text-gray-400 shrink-0" />}
                  </button>

                  {isOpen && (
                    <div className="border-t border-gray-100">
                      {/* Products sub-section */}
                      {hLoad ? (
                        <div className="px-5 py-4 text-xs text-gray-400 animate-pulse">Chargement des articles…</div>
                      ) : hProds.length > 0 && (
                        <>
                          <div className="flex items-center gap-2 bg-blue-50/60 border-b border-gray-100 px-5 py-2">
                            <ShoppingBag className="h-3.5 w-3.5 text-blue-500" />
                            <span className="text-xs font-bold uppercase tracking-wider text-blue-700">Articles vendus</span>
                          </div>
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="bg-gray-50">
                                <th className="px-5 py-2 text-left font-semibold uppercase tracking-wider text-gray-400">Article</th>
                                <th className="px-4 py-2 text-right font-semibold uppercase tracking-wider text-gray-400">Qté</th>
                                <th className="px-4 py-2 text-right font-semibold uppercase tracking-wider text-gray-400">Montant</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {hProds.map((p, i) => (
                                <tr key={i} className="hover:bg-gray-50/60">
                                  <td className="px-5 py-2 font-medium text-gray-700">{p.description}</td>
                                  <td className="px-4 py-2 text-right tabular-nums text-gray-600">{fmtQ(p.total_quantity)}</td>
                                  <td className="px-4 py-2 text-right tabular-nums font-semibold text-gray-900">{fmtN(p.total_amount, currency)}</td>
                                </tr>
                              ))}
                            </tbody>
                            <tfoot>
                              <tr className="border-t border-gray-200 bg-gray-50 font-bold text-xs">
                                <td className="px-5 py-2 text-gray-700">Total</td>
                                <td className="px-4 py-2 text-right tabular-nums text-gray-700">
                                  {fmtQ(hProds.reduce((s, p) => s + p.total_quantity, 0))} art.
                                </td>
                                <td className="px-4 py-2 text-right tabular-nums text-blue-700">
                                  {fmtN(hProds.reduce((s, p) => s + p.total_amount, 0), currency)}
                                </td>
                              </tr>
                            </tfoot>
                          </table>
                        </>
                      )}

                      {/* Payment lines sub-section */}
                      {cls.length > 0 && (
                        <>
                          <div className="flex items-center gap-2 bg-gray-50 border-b border-gray-100 border-t border-gray-100 px-5 py-2">
                            <span className="text-xs font-bold uppercase tracking-wider text-gray-400">Encaissements</span>
                          </div>
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="bg-gray-50">
                                <th className="px-5 py-2 text-left font-semibold uppercase tracking-wider text-gray-400">Mode</th>
                                <th className="px-4 py-2 text-right font-semibold uppercase tracking-wider text-gray-400">Attendu</th>
                                <th className="px-4 py-2 text-right font-semibold uppercase tracking-wider text-gray-400">Compté</th>
                                <th className="px-4 py-2 pr-5 text-right font-semibold uppercase tracking-wider text-gray-400">Écart</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {cls.map((l, i) => {
                                const meta = METHOD_META[l.method] ?? { label: l.method, icon: '' };
                                return (
                                  <tr key={i} className="hover:bg-gray-50/60">
                                    <td className="px-5 py-2 font-medium text-gray-700">{meta.icon} {meta.label}</td>
                                    <td className="px-4 py-2 text-right tabular-nums text-gray-500">{fmtN(Number(l.expected_amount), '')}</td>
                                    <td className="px-4 py-2 text-right tabular-nums font-semibold text-gray-900">{fmtN(Number(l.counted_amount), '')}</td>
                                    <td className="px-4 py-2 pr-5 text-right"><DiffBadge diff={Number(l.difference)} /></td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </>
                      )}

                      {c.notes && (
                        <div className="border-t border-gray-100 px-5 py-2 text-xs text-gray-500 italic">{c.notes}</div>
                      )}
                      <div className="flex justify-end gap-2 border-t border-gray-100 px-5 py-2">
                        <button
                          onClick={() => printClosing(c, hProds, settings, currency)}
                          className="flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 transition"
                        >
                          <Printer className="h-3.5 w-3.5" /> Imprimer
                        </button>
                        <button
                          onClick={async () => {
                            setPdfSaving(true);
                            try { await exportClosingPdf(c, hProds, settings, currency); }
                            finally { setPdfSaving(false); }
                          }}
                          disabled={pdfSaving}
                          className="flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 transition disabled:opacity-50"
                        >
                          <FileDown className="h-3.5 w-3.5" /> {pdfSaving ? 'PDF…' : 'PDF'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
