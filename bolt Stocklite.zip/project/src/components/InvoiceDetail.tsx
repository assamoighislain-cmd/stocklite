import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Printer, Pencil, Send, ShieldCheck, Loader2, QrCode, Wallet, Plus, Trash2, Trash, Receipt, Ban, FileDown, FileType, Package, RotateCcw } from 'lucide-react';
import QRCode from 'qrcode';
import type { Invoice, CompanySettings, Payment, PaymentMethod, SalesContract } from '../types';
import { STATUS_LABELS, ALL_PAYMENT_METHODS, METHOD_LABELS } from '../types';
import { StatusBadge } from './StatusBadge';
import { useFne } from '../hooks/useFne';
import { supabase } from '../lib/supabase';
import type { Route } from '../App';
import { exportElementToPdf } from '../lib/pdf';
import { translateError } from '../lib/translateError';
import { amountToFrenchWords } from '../lib/format';
import { ReturnItemsModal } from './ReturnItemsModal';

interface InvoiceDetailProps {
  invoiceId: string;
  settings: CompanySettings | null;
  activeContract: SalesContract | null;
  fetchOne: (id: string) => Promise<Invoice | null>;
  onUpdateStatus: (id: string, input: { status: import('../types').InvoiceStatus }) => Promise<void>;
  onNavigate: (r: Route) => void;
  recordPayment: (payload: {
    customer_id: string;
    invoice_id: string | null;
    amount: number;
    method: PaymentMethod;
    payment_date: string;
    notes: string;
  }) => Promise<Payment>;
  onDelete?: (id: string) => Promise<void> | void;
  onCreateCreditNote?: (id: string) => Promise<void> | void;
  onReturnInvoiceItems?: (invoiceId: string, returns: { item_id: string; product_id: string | null; quantity: number }[], reason: string) => Promise<void>;
  refetchInvoices?: () => Promise<void> | void;
}

function fmtMoney(n: number, currency = 'FCFA') {
  try {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);
  } catch {
    return `${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n)} ${currency}`;
  }
}

function fmtDate(d: string | null | undefined) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
}

export function InvoiceDetail({ invoiceId, settings, activeContract, fetchOne, onUpdateStatus, onNavigate, recordPayment, onDelete, onCreateCreditNote, onReturnInvoiceItems, refetchInvoices }: InvoiceDetailProps) {
  const [deleting, setDeleting] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const { certify, certifying, error: fneError } = useFne();

  const [payments, setPayments] = useState<Payment[]>([]);
  const [marginInfo, setMarginInfo] = useState<{ cost: number; margin: number; pct: number } | null>(null);
  const [productRefs, setProductRefs] = useState<Record<string, string>>({});
  const [payForm, setPayForm] = useState({
    amount: '',
    method: 'especes' as PaymentMethod,
    payment_date: new Date().toISOString().slice(0, 10),
    notes: '',
  });
  const [paySaving, setPaySaving] = useState(false);
  const [payError, setPayError] = useState('');
  const [printMode, setPrintMode] = useState<'a4' | 'receipt' | 'delivery' | 'delivery-receipt'>('a4');
  const [pdfSaving, setPdfSaving] = useState(false);
  const [showReturn, setShowReturn] = useState(false);

  function exportWord() {
    const el = document.getElementById('invoice-print');
    if (!el) return;
    const clone = el.cloneNode(true) as HTMLElement;
    clone.querySelectorAll('.no-print, script').forEach(n => n.remove());

    // Collect all <style> blocks from the print template
    const styleBlocks = Array.from(clone.querySelectorAll('style')).map(s => s.textContent ?? '').join('\n');

    // Word doesn't support CSS grid — convert grid layouts to table-based equivalents
    // Replace display:grid with display:block and rely on existing table elements for tabular data
    const wordStyles = `
      @page { size: A4 portrait; margin: 1.5cm; }
      @page WordSection1 { size: A4 portrait; margin: 1.5cm; }
      div.WordSection1 { page: WordSection1; }
      body { font-family: Arial, Helvetica, sans-serif; font-size: 10pt; color: #111; line-height: 1.35; margin: 0; }
      ${styleBlocks}
      /* Word-compatible overrides: grid is not supported, use block fallbacks */
      .inv-header { display: block !important; overflow: hidden; }
      .inv-company { float: left; width: 60%; }
      .inv-logo-wrap { float: right; width: 35%; text-align: right; }
      .inv-parties { display: block !important; overflow: hidden; }
      .inv-party-box { float: left; width: 48%; box-sizing: border-box; margin-bottom: 4mm; }
      .inv-party-box:nth-child(2) { float: right; }
      .inv-summary { display: block !important; overflow: hidden; }
      .inv-summary > div { float: left; width: 20%; box-sizing: border-box; }
      .inv-meta-grid { display: block !important; }
      .inv-meta-grid > div { display: block; border-bottom: 1px solid #111; border-right: 0 !important; }
      .inv-meta-grid > div.contact-cell { border-bottom: 1px solid #111; }
      .c-parties { display: block !important; overflow: hidden; }
      .c-party { float: left; width: 48%; box-sizing: border-box; }
      .c-party:nth-child(2) { float: right; }
      .signs { display: block !important; overflow: hidden; }
      .sign-col { float: left; width: 48%; box-sizing: border-box; }
      .sign-col:nth-child(2) { float: right; }
      .inv-doc, .inv-contract { width: 100% !important; min-height: auto !important; margin: 0 !important; padding: 0 !important; }
      .inv-contract { page-break-before: always; }
      table { border-collapse: collapse; width: 100%; }
      td, th { border: 1px solid #111; padding: 2px 4px; font-size: 10pt; }
      h1, h2, h3 { margin: 0 0 4px; }
      img { max-width: 100%; }
    `;

    const html = `<!DOCTYPE html><html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Facture ${invoice.invoice_number}</title><!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom><w:DoNotOptimizeForBrowser/></w:WordDocument></xml><![endif]--><style>${wordStyles}</style></head><body><div class="WordSection1">${clone.innerHTML}</div></body></html>`;
    const blob = new Blob(['\ufeff' + html], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${invoice.invoice_number}.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  async function exportPdf(mode: 'a4' | 'receipt' | 'delivery' | 'delivery-receipt') {
    const id = mode === 'a4' ? 'invoice-print' : mode === 'receipt' ? 'receipt-print' : mode === 'delivery' ? 'delivery-print' : 'delivery-receipt-print';
    const el = document.getElementById(id);
    if (!el) return;
    setPdfSaving(true);
    const wasHidden = el.classList.contains('hidden');
    if (wasHidden) {
      el.classList.remove('hidden');
      el.style.position = 'fixed';
      el.style.left = '-9999px';
      el.style.top = '0';
      if (mode === 'receipt' || mode === 'delivery-receipt') {
        el.style.width = '302px';
        el.style.maxWidth = '302px';
      }
    }
    try {
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
      const pdfMode = mode === 'delivery-receipt' ? 'receipt' : mode;
      const suffix = mode === 'delivery' ? 'bon-livraison' : mode === 'delivery-receipt' ? 'bon-livraison-80mm' : mode;
      await exportElementToPdf(el, `${invoice.invoice_number}-${suffix}.pdf`, pdfMode);
    } finally {
      if (wasHidden) {
        el.classList.add('hidden');
        el.style.position = '';
        el.style.left = '';
        el.style.top = '';
        el.style.width = '';
        el.style.maxWidth = '';
      }
      setPdfSaving(false);
    }
  }

  const load = useCallback(async () => {
    setLoading(true);
    const inv = await fetchOne(invoiceId);
    setInvoice(inv);
    setLoading(false);
    if (inv) {
      const { data: payData } = await supabase.from('payments').select('*').eq('invoice_id', inv.id).order('payment_date', { ascending: false });
      setPayments((payData ?? []) as Payment[]);

      // Compute margin from product purchase prices
      const items = inv.items ?? [];
      const productIds = items.map(i => i.product_id).filter(Boolean) as string[];
      if (productIds.length > 0) {
        const { data: prods } = await supabase.from('products').select('id, purchase_price, reference').in('id', productIds);
        const prodMap = new Map((prods ?? []).map(p => [p.id, p.purchase_price ?? 0] as [string, number]));
        const refMap: Record<string, string> = {};
        for (const p of (prods ?? [])) {
          if (p.reference) refMap[p.id] = p.reference;
        }
        setProductRefs(refMap);
        const cost = items.reduce((s, it) => s + (Number(it.quantity) || 0) * (prodMap.get(it.product_id!) ?? 0), 0);
        const sub = Number(inv.subtotal) || 0;
        const m = sub - cost;
        setMarginInfo({ cost, margin: m, pct: sub > 0 ? (m / sub) * 100 : 0 });
      } else {
        setMarginInfo(null);
      }
    }
  }, [invoiceId, fetchOne]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const handler = () => {
      const el = document.getElementById('print-page-style');
      if (el) el.remove();
    };
    window.addEventListener('afterprint', handler);
    return () => window.removeEventListener('afterprint', handler);
  }, []);

  useEffect(() => {
    const token = invoice?.fne_token;
    if (!token) { setQrDataUrl(null); return; }
    let cancelled = false;
    QRCode.toDataURL(token, { width: 180, margin: 1 })
      .then(url => { if (!cancelled) setQrDataUrl(url); })
      .catch(() => { if (!cancelled) setQrDataUrl(null); });
    return () => { cancelled = true; };
  }, [invoice?.fne_token]);

  async function handleCertify() {
    if (!invoice) return;
    const invType = invoice.is_credit_note ? 'credit-note' : 'sale';
    const cert = await certify(invoice, invoice.items ?? [], settings, invoice.customer, invType);
    if (cert) {
      await load();
      if (refetchInvoices) await refetchInvoices();
    }
  }

  async function markAs(status: import('../types').InvoiceStatus) {
    if (!invoice) return;
    setUpdatingStatus(true);
    await onUpdateStatus(invoice.id, { status });
    await load();
    setUpdatingStatus(false);
  }

  if (loading) return <div className="h-96 animate-pulse rounded-xl bg-gray-100/40" />;
  if (!invoice) return <div className="py-20 text-center text-gray-400">Facture introuvable.</div>;

  const c = invoice.customer;
  const cur = settings?.currency ?? 'FCFA';

  async function handlePayment(e: React.FormEvent) {
    e.preventDefault();
    if (!invoice) return;
    const amount = Number(payForm.amount);
    if (!amount || amount <= 0) { setPayError('Montant invalide.'); return; }
    setPaySaving(true); setPayError('');
    try {
      await recordPayment({
        customer_id: invoice.customer_id,
        invoice_id: invoice.id,
        amount,
        method: payForm.method,
        payment_date: payForm.payment_date,
        notes: payForm.notes,
      });
      setPayForm(f => ({ ...f, amount: '', notes: '' }));
      await load();
    } catch (err) {
      setPayError(err instanceof Error ? translateError(err.message) : 'Erreur');
    } finally {
      setPaySaving(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="no-print flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigate({ page: 'invoices' })} className="rounded-lg p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-900 transition">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-gray-900">
              {invoice.is_credit_note && <span className="text-amber-600">AVOIR — </span>}
              {invoice.invoice_number}
            </h1>
            <div className="flex items-center gap-2">
              <StatusBadge status={invoice.status} />
              {invoice.is_credit_note && invoice.credit_note_of && (
                <span className="text-xs text-amber-600 font-medium">Annule {invoice.notes?.match(/facture (INV-\w+)/)?.[1] ?? 'la facture d\'origine'}</span>
              )}
              {invoice.due_date && new Date(invoice.due_date) < new Date() && invoice.status !== 'payee' && (
                <span className="text-xs font-semibold text-red-400">En retard</span>
              )}
            </div>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          {invoice.status === 'brouillon' && (
            <button
              onClick={() => markAs('envoyee')}
              disabled={updatingStatus}
              className="flex items-center gap-2 rounded-lg border border-blue-600 bg-blue-600 px-3.5 py-2 text-sm font-medium text-white hover:bg-blue-700 transition disabled:opacity-50"
            >
              <Send className="h-4 w-4" /> Convertir en facture
            </button>
          )}
          <button
            onClick={() => onNavigate({ page: 'invoice-form', editId: invoice.id })}
            className="flex items-center gap-2 rounded-lg border border-gray-300 bg-gray-100 px-3.5 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200 transition"
          >
            <Pencil className="h-4 w-4" /> Modifier
          </button>
          <button
            onClick={() => {
              setPrintMode('a4');
              const el = document.getElementById('print-page-style');
              if (el) el.remove();
              const prevTitle = document.title;
              document.title = `Facture ${invoice.invoice_number}`;
              const styleEl = document.createElement('style');
              styleEl.id = 'print-page-style';
              styleEl.textContent = '@media print { @page { size: A4; margin: 0; } }';
              document.head.appendChild(styleEl);
              const restore = () => { document.title = prevTitle; window.removeEventListener('afterprint', restore); };
              window.addEventListener('afterprint', restore);
              setTimeout(() => window.print(), 50);
            }}
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition"
          >
            <Printer className="h-4 w-4" /> Imprimer A4
          </button>
          <button
            onClick={() => exportPdf('a4')}
            disabled={pdfSaving}
            className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3.5 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
          >
            <FileDown className="h-4 w-4" /> {pdfSaving ? 'PDF…' : 'PDF A4'}
          </button>
          <button
            onClick={exportWord}
            className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3.5 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition"
          >
            <FileType className="h-4 w-4" /> Word
          </button>
          <button
            onClick={() => setPrintMode('receipt')}
            className="flex items-center gap-2 rounded-lg border border-emerald-600 bg-emerald-50 px-3.5 py-2 text-sm font-semibold text-emerald-700 hover:bg-emerald-100 transition"
          >
            <Receipt className="h-4 w-4" /> Reçu de caisse
          </button>
          <button
            onClick={() => setPrintMode('delivery')}
            className="flex items-center gap-2 rounded-lg border border-orange-600 bg-orange-50 px-3.5 py-2 text-sm font-semibold text-orange-700 hover:bg-orange-100 transition"
          >
            <Package className="h-4 w-4" /> Bon de livraison A4
          </button>
          <button
            onClick={() => setPrintMode('delivery-receipt')}
            className="flex items-center gap-2 rounded-lg border border-orange-400 bg-orange-50 px-3.5 py-2 text-sm font-semibold text-orange-600 hover:bg-orange-100 transition"
          >
            <Package className="h-3.5 w-3.5" /> Bon de livraison 80mm
          </button>
          {onDelete && (
            <button
              onClick={async () => {
                if (!confirm('Supprimer définitivement cette facture ? Cette action est irréversible.')) return;
                setDeleting(true);
                try { await onDelete(invoice.id); } catch { setDeleting(false); }
              }}
              disabled={deleting}
              className="flex items-center gap-2 rounded-lg border border-red-300 bg-red-50 px-3.5 py-2 text-sm font-medium text-red-600 hover:bg-red-100 transition disabled:opacity-50"
            >
              <Trash className="h-4 w-4" /> Supprimer
            </button>
          )}
          {onCreateCreditNote && invoice.status !== 'annulee' && !invoice.is_credit_note && (
            <button
              onClick={async () => {
                const msg = invoice.fne_status === 'certified'
                  ? 'Annuler cette facture certifiée DGI ? Un avoir sera créé et automatiquement envoyé à la DGI pour certification.'
                  : 'Annuler cette facture et créer une facture d\'avoir ? Cette action est irréversible.';
                if (!confirm(msg)) return;
                setCancelling(true);
                try { await onCreateCreditNote(invoice.id); } catch { setCancelling(false); }
              }}
              disabled={cancelling}
              className="flex items-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2 text-sm font-medium text-amber-700 hover:bg-amber-100 transition disabled:opacity-50"
            >
              <Ban className="h-4 w-4" /> {cancelling ? 'Annulation…' : 'Annuler (Avoir)'}
            </button>
          )}
          {onReturnInvoiceItems && invoice.status !== 'annulee' && !invoice.is_credit_note && (invoice.items ?? []).some(i => i.product_id) && (
            <button
              onClick={() => setShowReturn(true)}
              className="flex items-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2 text-sm font-medium text-amber-700 hover:bg-amber-100 transition"
            >
              <RotateCcw className="h-4 w-4" /> Retour en stock
            </button>
          )}
        </div>
      </div>

      {/* FNE Certification panel */}
      <div className={`rounded-xl border border-gray-200 bg-white p-5 print:hidden ${printMode !== 'a4' ? 'hidden' : ''}`}>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <ShieldCheck className={`h-6 w-6 ${invoice.fne_status === 'certified' ? 'text-emerald-600' : 'text-gray-400'}`} />
            <div>
              <h3 className="text-sm font-semibold text-gray-900">Certification FNE — DGI Côte d'Ivoire</h3>
              <p className="text-xs text-gray-500">
                {invoice.fne_status === 'certified'
                  ? `Facture certifiée — Réf. ${invoice.fne_reference}`
                  : invoice.fne_status === 'error'
                    ? `Échec de certification : ${invoice.fne_error ?? 'erreur inconnue'}`
                    : 'Cette facture n\'a pas encore été certifiée par la DGI.'}
              </p>
              {invoice.fne_status === 'certified' && invoice.fne_certified_at && (
                <p className="mt-0.5 text-[11px] text-gray-400">
                  Certifiée le {fmtDate(invoice.fne_certified_at)}
                  {invoice.fne_balance_sticker != null ? ` · Sticker n° ${invoice.fne_balance_sticker}` : ''}
                </p>
              )}
              {/* FNE info summary */}
              <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-gray-500">
                {settings?.fne_ncc && <span>NCC vendeur : <span className="font-semibold text-gray-700">{settings.fne_ncc}</span></span>}
                {settings?.fne_point_of_sale && <span>PV : <span className="font-semibold text-gray-700">{settings.fne_point_of_sale}</span></span>}
                {settings?.fne_establishment && <span>Étab. : <span className="font-semibold text-gray-700">{settings.fne_establishment}</span></span>}
                {c?.ncc && <span>NCC client : <span className="font-semibold text-gray-700">{c.ncc}</span></span>}
                {c?.type === 'entreprise' ? <span>Type : <span className="font-semibold text-gray-700">B2B</span></span> : <span>Type : <span className="font-semibold text-gray-700">B2C</span></span>}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {qrDataUrl && (
              <div className="text-center">
                <img src={qrDataUrl} alt="QR code FNE" className="h-24 w-24 rounded border border-gray-200" />
                <p className="mt-1 text-[10px] text-gray-400">QR de vérification DGI</p>
              </div>
            )}
            <button
              onClick={handleCertify}
              disabled={certifying}
              className="flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 transition disabled:opacity-50"
            >
              {certifying ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
              {certifying ? 'Certification…' : invoice.fne_status === 'certified' ? 'Re-certifier' : 'Certifier FNE'}
            </button>
          </div>
        </div>
        {invoice.fne_status === 'certified' && invoice.fne_warning && (
          <p className="mt-3 rounded-md bg-amber-50 px-3 py-2 text-xs text-amber-700">
            {invoice.fne_warning_message
              ? `Avertissement DGI : ${invoice.fne_warning_message}`
              : 'La DGI a émis un avertissement sur cette facture. Vérifiez sa conformité.'}
          </p>
        )}
        {fneError && (
          <p className="mt-3 rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{fneError}</p>
        )}
      </div>

      {/* Payment panel */}
      {invoice.status !== 'annulee' && (
        <div className={`rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden print:hidden ${printMode !== 'a4' ? 'hidden' : ''}`}>
          <div className="border-b border-gray-100 bg-gray-50 px-5 py-3 flex items-center gap-2">
            <Wallet className="h-4 w-4 text-gray-500" />
            <h2 className="text-sm font-semibold text-gray-700">Règlements</h2>
            <span className="ml-auto text-xs text-gray-400">
              Réglé : <span className="font-semibold text-emerald-600">{fmtMoney(Number(invoice.amount_paid), cur)}</span>
              {' · '}
              Solde dû : <span className={`font-semibold ${Number(invoice.balance_due) > 0 ? 'text-red-600' : 'text-emerald-600'}`}>{fmtMoney(Number(invoice.balance_due), cur)}</span>
            </span>
          </div>

          <div className="grid gap-5 p-5 lg:grid-cols-5">
            {/* Form */}
            <form onSubmit={handlePayment} className="lg:col-span-2 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Montant *</label>
                  <input type="number" step="any" min="1" required value={payForm.amount}
                    onChange={e => setPayForm(f => ({ ...f, amount: e.target.value }))}
                    placeholder="0"
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm tabular-nums text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-500">Mode</label>
                  <select value={payForm.method} onChange={e => setPayForm(f => ({ ...f, method: e.target.value as PaymentMethod }))}
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500">
                    {ALL_PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Date</label>
                <input type="date" value={payForm.payment_date} onChange={e => setPayForm(f => ({ ...f, payment_date: e.target.value }))}
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-500">Notes</label>
                <input type="text" value={payForm.notes} onChange={e => setPayForm(f => ({ ...f, notes: e.target.value }))}
                  placeholder="Référence, commentaire…"
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-500 focus:bg-white" />
              </div>
              {payError && <p className="text-xs text-red-500">{payError}</p>}
              <button type="submit" disabled={paySaving || !payForm.amount}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-500 disabled:opacity-50">
                <Plus className="h-4 w-4" />
                {paySaving ? 'Enregistrement…' : 'Enregistrer le règlement'}
              </button>
            </form>

            {/* List */}
            <div className="lg:col-span-3">
              {payments.length === 0 ? (
                <div className="flex h-full items-center justify-center text-sm text-gray-400">
                  Aucun règlement enregistré pour cette facture.
                </div>
              ) : (
                <div className="overflow-hidden rounded-lg border border-gray-100">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-100 bg-gray-50">
                        <th className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Date</th>
                        <th className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Mode</th>
                        <th className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wider text-gray-400">Notes</th>
                        <th className="px-3 py-2 text-right text-xs font-semibold uppercase tracking-wider text-gray-400">Montant</th>
                        <th className="px-3 py-2" />
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {payments.map(p => (
                        <tr key={p.id} className="group hover:bg-gray-50">
                          <td className="px-3 py-2.5 text-sm tabular-nums text-gray-500">{new Date(p.payment_date).toLocaleDateString('fr-FR')}</td>
                          <td className="px-3 py-2.5 text-sm text-gray-600">{METHOD_LABELS[p.method] ?? p.method}</td>
                          <td className="px-3 py-2.5 text-sm text-gray-500 max-w-[160px] truncate">{p.notes || '—'}</td>
                          <td className="px-3 py-2.5 text-right tabular-nums font-semibold text-sm text-emerald-600">+{fmtMoney(Number(p.amount), cur)}</td>
                          <td className="px-3 py-2.5 text-right">
                            <button
                              onClick={async () => {
                                if (!confirm('Supprimer ce règlement ?')) return;
                                await supabase.from('payments').delete().eq('id', p.id);
                                if (invoice) {
                                  const remaining = payments.filter(x => x.id !== p.id).reduce((s, x) => s + Number(x.amount), 0);
                                  const total = Number(invoice.total);
                                  const newPaid = Math.min(total, remaining);
                                  const newBal = Math.round((total - newPaid) * 100) / 100;
                                  const newStatus = newPaid >= total ? 'payee' : (newPaid > 0 ? 'partielle' : 'envoyee');
                                  const patch = { amount_paid: newPaid, balance_due: newBal, status: newStatus, updated_at: new Date().toISOString() };
                                  await supabase.from('invoices').update(patch).eq('id', invoice.id);
                                }
                                await load();
                              }}
                              className="rounded p-1 text-gray-300 opacity-0 transition group-hover:opacity-100 hover:bg-red-50 hover:text-red-500"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="border-t-2 border-gray-200 bg-gray-50">
                        <td colSpan={3} className="px-3 py-2.5 text-xs font-bold uppercase tracking-wider text-gray-500">Total réglé</td>
                        <td className="px-3 py-2.5 text-right tabular-nums text-sm font-bold text-emerald-600">{fmtMoney(payments.reduce((s, p) => s + Number(p.amount), 0), cur)}</td>
                        <td />
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Preview action bar (shown when viewing receipt or delivery) */}
      {printMode !== 'a4' && (
        <div className="sticky top-0 z-20 flex items-center justify-between gap-3 rounded-xl border border-gray-200 bg-white/95 px-4 py-3 shadow-sm backdrop-blur print:hidden">
          <button
            onClick={() => setPrintMode('a4')}
            className="flex items-center gap-2 rounded-lg border border-gray-300 bg-gray-100 px-3.5 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200 transition"
          >
            <ArrowLeft className="h-4 w-4" /> Retour à la facture
          </button>
          <span className="text-sm font-semibold text-gray-600">
            {printMode === 'receipt' ? 'Aperçu — Reçu de caisse' : printMode === 'delivery' ? 'Aperçu — Bon de livraison A4' : 'Aperçu — Bon de livraison 80mm'}
          </span>
          <div className="flex gap-2">
            <button
              onClick={() => {
                let el = document.getElementById('print-page-style');
                if (!el) {
                  el = document.createElement('style');
                  el.id = 'print-page-style';
                  el.textContent = printMode === 'delivery'
                    ? '@media print { @page { size: A4; margin: 10mm; } }'
                    : '@media print { @page { size: 80mm auto; margin: 2mm; } }';
                  if (printMode === 'delivery-receipt') {
                    el.textContent = '@media print { @page { size: 80mm auto; margin: 2mm; } }';
                  }
                  document.head.appendChild(el);
                }
                setTimeout(() => window.print(), 50);
              }}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition"
            >
              <Printer className="h-4 w-4" /> Imprimer
            </button>
            {printMode === 'receipt' && (
              <button
                onClick={() => exportPdf(printMode)}
                disabled={pdfSaving}
                className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3.5 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
              >
                <FileDown className="h-4 w-4" /> {pdfSaving ? 'PDF…' : 'PDF'}
              </button>
            )}
            {printMode === 'delivery' && (
              <button
                onClick={() => exportPdf('delivery')}
                disabled={pdfSaving}
                className="flex items-center gap-2 rounded-lg border border-orange-600 bg-white px-3.5 py-2 text-sm font-medium text-orange-700 hover:bg-orange-50 transition disabled:opacity-50"
              >
                <FileDown className="h-4 w-4" /> {pdfSaving ? 'PDF…' : 'PDF'}
              </button>
            )}
            {printMode === 'delivery-receipt' && (
              <button
                onClick={() => exportPdf('delivery-receipt')}
                disabled={pdfSaving}
                className="flex items-center gap-2 rounded-lg border border-orange-400 bg-white px-3.5 py-2 text-sm font-medium text-orange-600 hover:bg-orange-50 transition disabled:opacity-50"
              >
                <FileDown className="h-4 w-4" /> {pdfSaving ? 'PDF…' : 'PDF'}
              </button>
            )}

          </div>
        </div>
      )}

      {/* A4 Invoice — self-contained print template */}
      <div id="invoice-print" className={`${printMode === 'a4' ? '' : 'hidden print:hidden'} print-invoice`}>
        <style>{`
        .inv-doc {
          width: 210mm; min-height: 297mm; margin: 0 auto; padding: 12mm 14mm;
          background: #fff; color: #111; font-family: Arial, Helvetica, sans-serif;
          font-size: 10px; line-height: 1.35; box-sizing: border-box;
        }
        .inv-doc * { box-sizing: border-box; }

        /* ── Header ── */
        .inv-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4mm; }
        .inv-company h1 { font-size: 13px; font-weight: 700; margin: 0 0 1mm; text-transform: uppercase; letter-spacing: 0; }
        .inv-company p { margin: 0; font-size: 10px; color: #333; line-height: 1.3; }
        .inv-logo-wrap { width: 60mm; text-align: right; }
        .inv-logo-wrap img { max-width: 55mm; max-height: 22mm; object-fit: contain; }

        /* ── Document label ── */
        .inv-doc-label {
          display: inline-block; padding: 1.5mm 4mm; border: 1.5px solid #111;
          background: #e5e7eb; font-size: 11px; font-weight: 700; text-transform: uppercase;
          letter-spacing: 0.5px; margin-bottom: 2mm;
        }
        .inv-doc-label .num { font-size: 13px; }
        .inv-meta-grid { display: grid; grid-template-columns: 1fr 1fr; border: none; }
        .inv-meta-grid > div { padding: 1mm 1.5mm; border: none; font-size: 10px; min-height: 5mm; }
        .inv-meta-grid > div:nth-child(2n) { border: none; }
        .inv-meta-grid > div:last-child { border: none; }
        .inv-meta-grid > div b { font-weight: 600; color: #555; }
        .inv-meta-grid .contact-cell { grid-column: 1 / -1; font-size: 10px; min-height: 8mm; }
        .inv-meta-grid .contact-cell .lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #666; margin-bottom: 0.5mm; }
        .inv-meta-grid .contact-cell .name { font-weight: 700; font-size: 11px; }
        .inv-meta-grid .contact-cell p { margin: 0; line-height: 1.4; font-size: 10px; }

        /* ── Parties ── */
        .inv-parties { display: grid; grid-template-columns: 1fr 1fr; gap: 4mm; margin-bottom: 4mm; }
        .inv-party-box { border: 1px solid #111; padding: 2mm 2.5mm; min-height: 22mm; }
        .inv-party-box .lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #666; margin-bottom: 1mm; }
        .inv-party-box .name { font-size: 11px; font-weight: 700; margin-bottom: 0.5mm; }
        .inv-party-box p { margin: 0; font-size: 10px; color: #333; line-height: 1.3; }

        /* ── Table ── */
        .inv-table { width: 100%; border-collapse: collapse; margin-bottom: 4mm; }
        .inv-table th, .inv-table td { border: 1px solid #bbb; padding: 1.2mm 1.5mm; font-size: 10px; text-align: left; vertical-align: middle; }
        .inv-table th { background: #d1d5db; font-weight: 700; text-align: center; text-transform: uppercase; font-size: 10px; }
        .inv-table td.num, .inv-table th.num { text-align: right; }
        .inv-table td.qty, .inv-table th.qty { text-align: center; }
        .inv-empty-row td { height: 40mm; border: 1px solid #bbb; }

        /* ── In words ── */
        .inv-in-words { border: 1px solid #111; padding: 2mm 2.5mm; font-size: 10px; margin-bottom: 3mm; min-height: 7mm; }
        .inv-in-words b { font-weight: 700; }

        /* ── Summary grid (5 columns) ── */
        .inv-summary { display: grid; grid-template-columns: repeat(5, 1fr); border: 1px solid #111; margin-bottom: 3mm; }
        .inv-summary > div { border-right: 1px solid #111; text-align: center; min-height: 11mm; display: flex; flex-direction: column; }
        .inv-summary > div:last-child { border-right: 0; }
        .inv-summary > div .lbl { background: #d1d5db; border-bottom: 1px solid #111; padding: 1mm; font-size: 10px; font-weight: 700; text-transform: uppercase; }
        .inv-summary > div .val { padding: 1mm; font-size: 10px; flex: 1; display: flex; align-items: center; justify-content: center; }
        .inv-summary > div:last-child .val { font-weight: 700; }

        /* ── Payment mode + FNE ── */
        .inv-pay-mode { font-size: 10px; margin-bottom: 3mm; }
        .inv-fne-box { border: 1px solid #111; padding: 2mm 2.5mm; font-size: 10px; display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4mm; }
        .inv-fne-box .fne-info p { margin: 0; line-height: 1.4; }
        .inv-fne-box .fne-title { font-weight: 700; text-transform: uppercase; margin-bottom: 0.5mm; }
        .inv-fne-box img { width: 22mm; height: 22mm; border: 1px solid #ccc; padding: 0.5mm; background: #fff; }

        /* ── Footer ── */
        .inv-footer { border-top: 1px solid #111; padding-top: 1.5mm; margin-top: 8mm; text-align: center; font-size: 10px; color: #333; }

        /* ── Contract page (always page 2) ── */
        .inv-contract { display: block; page-break-before: always; break-before: page; padding-top: 4mm; width: 210mm; min-height: 297mm; margin: 0 auto; background: #fff; color: #111; font-family: Arial, Helvetica, sans-serif; font-size: 10px; line-height: 1.35; box-sizing: border-box; padding: 12mm 14mm; }
        .inv-contract h2 { text-align: center; font-size: 14px; font-weight: 700; margin: 0 0 1mm; }
        .inv-contract .sub { text-align: center; font-size: 10px; color: #555; margin-bottom: 4mm; }
        .inv-contract .c-parties { display: grid; grid-template-columns: 1fr 1fr; gap: 4mm; margin-bottom: 4mm; }
        .inv-contract .c-party { border: 1px solid #111; padding: 2mm 2.5mm; font-size: 10px; }
        .inv-contract .c-party .lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #666; margin-bottom: 0.5mm; }
        .inv-contract .c-party .name { font-weight: 700; font-size: 10px; margin-bottom: 0.5mm; }
        .inv-contract .c-party p { margin: 0; line-height: 1.3; color: #333; }
        .inv-contract .intro { font-size: 10px; line-height: 1.5; margin-bottom: 4mm; white-space: pre-line; }
        .inv-contract .terms-title { font-size: 10px; font-weight: 700; text-transform: uppercase; margin-bottom: 2mm; }
        .inv-contract ol { padding-left: 4mm; margin: 0 0 4mm; }
        .inv-contract ol li { font-size: 10px; line-height: 1.5; margin-bottom: 2mm; }
        .inv-contract .recap { border: 1px solid #111; padding: 2.5mm; font-size: 10px; margin-bottom: 6mm; }
        .inv-contract .recap .title { font-weight: 700; font-size: 10px; text-transform: uppercase; margin-bottom: 1.5mm; }
        .inv-contract .recap .row { display: flex; justify-content: space-between; padding: 0.5mm 0; }
        .inv-contract .signs { display: flex; justify-content: space-between; gap: 8mm; margin-top: 12mm; }
        .inv-contract .sign-col { flex: 1; text-align: center; }
        .inv-contract .sign-col .who { font-size: 10px; font-weight: 600; margin-bottom: 18mm; }
        .inv-contract .sign-col .line { border-top: 1px solid #111; }
        .inv-contract .sign-col .cap { font-size: 10px; color: #555; margin-top: 1mm; }
        `}</style>

        <div className="inv-doc">
          {/* ── Header ── */}
          <div className="inv-header">
            <div className="inv-company">
              <h1>{settings?.name ?? 'Mon Entreprise'}</h1>
              {settings?.address && <p>{settings.address}</p>}
              {settings?.city && <p>{settings.city}</p>}
              {settings?.phone && <p>Tél : {settings.phone}</p>}
              {settings?.email && <p>{settings.email}</p>}
              {settings?.tax_id && <p>NIF / SIRET : {settings.tax_id}</p>}
              {settings?.fne_ncc && <p>NCC : {settings.fne_ncc}</p>}
              {settings?.fne_tax_regime && <p>Régime d'imposition : {settings.fne_tax_regime}</p>}
              {settings?.fne_tax_center && <p>Centre des impôts : {settings.fne_tax_center}</p>}
              {settings?.fne_bank_reference && <p>Réf. bancaire : {settings.fne_bank_reference}</p>}
            </div>
            <div className="inv-logo-wrap">
              {settings?.logo_url && <img src={settings.logo_url} alt="Logo" />}
            </div>
          </div>

          {/* ── Document label + meta ── */}
          <div style={{ marginBottom: '4mm' }}>
            <div className="inv-doc-label">
              {invoice.is_credit_note ? 'AVOIR' : invoice.status === 'brouillon' ? 'DEVIS' : 'FACTURE'} <span className="num">{invoice.invoice_number}</span>
            </div>
            <div className="inv-meta-grid">
              <div><b>Date :</b> {fmtDate(invoice.date)}</div>
              <div><b>Statut :</b> {STATUS_LABELS[invoice.status]}</div>
              {invoice.due_date && <div><b>Échéance :</b> {fmtDate(invoice.due_date)}</div>}
              {invoice.order_number && <div><b>Commande :</b> {invoice.order_number}</div>}
              {invoice.delivery_delay && <div><b>Délai :</b> {invoice.delivery_delay}</div>}
              {invoice.payment_mode && <div><b>Règlement :</b> {invoice.payment_mode}</div>}
              {(invoice.airsi ?? 0) > 0 && <div><b>AIRSI :</b> {fmtMoney(invoice.airsi_amount ?? 0, cur)}</div>}
              {invoice.creator?.full_name && <div><b>Créé par :</b> {invoice.creator.full_name}</div>}
              {settings?.fne_point_of_sale && <div><b>PV :</b> {settings.fne_point_of_sale}</div>}
              {(invoice.contact_name || invoice.contact_phone || invoice.contact_email) && (
                <div className="contact-cell">
                  <div className="lbl">Interlocuteur</div>
                  {invoice.contact_name && <p className="name">{invoice.contact_name}</p>}
                  {invoice.contact_phone && <p>Tél : {invoice.contact_phone}</p>}
                  {invoice.contact_email && <p>Email : {invoice.contact_email}</p>}
                </div>
              )}
            </div>
          </div>

          {/* ── Parties ── */}
          <div className="inv-parties">
            <div className="inv-party-box">
              <div className="lbl">Facturer à</div>
              <div className="name">{c?.name ?? '—'}</div>
              {c?.address && <p>{c.address}</p>}
              {c?.city && <p>{c.city}</p>}
              {c?.phone && <p>Tél : {c.phone}</p>}
              {c?.email && <p>{c.email}</p>}
              {c?.ncc && <p>NCC : {c.ncc}</p>}
              {c?.type === 'entreprise' && <p>Entreprise (B2B)</p>}
            </div>
            {invoice.fne_status === 'certified' ? (
              <div className="inv-party-box" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div className="fne-info">
                  <div className="lbl">Certification FNE — DGI</div>
                  <p>Réf DGI : <b>{invoice.fne_reference ?? '—'}</b></p>
                  {invoice.fne_ncc && <p>NCC vendeur : {invoice.fne_ncc}</p>}
                  {c?.ncc && <p>NCC client : {c.ncc}</p>}
                  <p>Type : {c?.type === 'entreprise' ? 'B2B' : 'B2C'}</p>
                  {invoice.fne_certified_at && <p>Certifiée le : {fmtDate(invoice.fne_certified_at)}</p>}
                  {invoice.fne_balance_sticker != null && <p>Sticker n° {invoice.fne_balance_sticker}</p>}
                </div>
                {qrDataUrl && <img src={qrDataUrl} alt="QR FNE" style={{ width: '18mm', height: '18mm', border: '1px solid #ccc', padding: '0.5mm', background: '#fff' }} />}
              </div>
            ) : (
              <div className="inv-party-box" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#999' }}>
                <p style={{ fontSize: '10px', textAlign: 'center' }}>{invoice.notes ?? ''}</p>
              </div>
            )}
          </div>

          {/* ── Items table ── */}
          <table className="inv-table">
            <thead>
              <tr>
                <th style={{ width: '4%' }}>#</th>
                <th style={{ width: '21%' }}>Référence</th>
                <th style={{ width: '36%' }}>Désignation</th>
                <th className="qty" style={{ width: '8%' }}>Qté</th>
                <th className="num" style={{ width: '13%' }}>Prix U.</th>
                <th className="num" style={{ width: '8%' }}>Remise</th>
                <th className="num" style={{ width: '14%' }}>Total</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.items ?? []).map((item, i) => {
                const ref = item.product_id ? productRefs[item.product_id] : undefined;
                return (
                  <tr key={item.id}>
                    <td>{i + 1}</td>
                    <td style={{ fontFamily: 'monospace' }}>{ref ?? '—'}</td>
                    <td>{item.description}</td>
                    <td className="qty">{new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(item.quantity))}</td>
                    <td className="num">{fmtMoney(item.unit_price, cur)}</td>
                    <td className="num">{(item.discount ?? 0) > 0 ? `−${fmtMoney(item.discount, cur)}` : '—'}</td>
                    <td className="num" style={{ fontWeight: 700 }}>{fmtMoney(item.total, cur)}</td>
                  </tr>
                );
              })}
              <tr className="inv-empty-row"><td colSpan={7} /></tr>
            </tbody>
          </table>

          {/* ── In words ── */}
          <div className="inv-in-words">
            Arrêté la présente {invoice.is_credit_note ? 'facture d\'avoir' : 'facture'} à la somme de : <b>{amountToFrenchWords(Number(invoice.total), cur)}</b> ({fmtMoney(invoice.total, cur)})
          </div>

          {/* ── Summary 5 columns ── */}
          <div className="inv-summary">
            <div><div className="lbl">Total TTC</div><div className="val">{fmtMoney(invoice.total, cur)}</div></div>
            {invoice.tax_rate > 0 && <div><div className="lbl">TVA</div><div className="val">{fmtMoney(invoice.tax_amount, cur)}</div></div>}
            {(invoice.airsi ?? 0) > 0 && <div><div className="lbl">AIRSI</div><div className="val">{fmtMoney(invoice.airsi_amount ?? 0, cur)}</div></div>}
            <div><div className="lbl">Acompte</div><div className="val">{fmtMoney(invoice.order_advance ?? 0, cur)}</div></div>
            <div><div className="lbl">Net à payer</div><div className="val">{fmtMoney(invoice.total, cur)}</div></div>
          </div>

          {/* ── Payment mode ── */}
          <p className="inv-pay-mode">Mode de règlement : <b>{invoice.payment_mode ?? '—'}</b></p>

          {/* ── FNE detail ── */}
          {invoice.fne_status === 'certified' && (
            <div className="inv-fne-box">
              <div className="fne-info">
                <p className="fne-title">Certifiée FNE — DGI Côte d'Ivoire</p>
                <p>Réf DGI : {invoice.fne_reference ?? '—'}</p>
                {invoice.fne_ncc && <p>NCC vendeur : {invoice.fne_ncc}</p>}
                {settings?.fne_point_of_sale && <p>Point de vente : {settings.fne_point_of_sale}</p>}
                {settings?.fne_establishment && <p>Établissement : {settings.fne_establishment}</p>}
                {c?.ncc && <p>NCC client : {c.ncc}</p>}
                <p>Type facture : {c?.type === 'entreprise' ? 'B2B' : 'B2C'}</p>
                {settings?.fne_tax_regime && <p>Régime d'imposition : {settings.fne_tax_regime}</p>}
                {settings?.fne_tax_center && <p>Centre des impôts : {settings.fne_tax_center}</p>}
                {settings?.fne_bank_reference && <p>Réf. bancaire : {settings.fne_bank_reference}</p>}
                {invoice.fne_certified_at && <p>Certifiée le : {fmtDate(invoice.fne_certified_at)}</p>}
                {invoice.fne_balance_sticker != null && <p>Sticker n° {invoice.fne_balance_sticker}</p>}
                {invoice.fne_warning && <p style={{ fontWeight: 700 }}>Avertissement DGI émis sur cette facture.</p>}
              </div>
              {qrDataUrl && <img src={qrDataUrl} alt="QR FNE" />}
            </div>
          )}

          {/* ── Footer ── */}
          <div className="inv-footer">
            {settings?.invoice_footer && <p>{settings.invoice_footer}</p>}
          </div>
        </div>

        {/* ── Sales Conditions (page 2, after footer) ── */}
        {activeContract && (
          <div className="inv-contract">
            <h2>{activeContract.title}</h2>
              <p className="sub">Joint à la facture n° {invoice.invoice_number} du {fmtDate(invoice.date)}</p>

              <div className="c-parties">
                <div className="c-party">
                  <div className="lbl">Le vendeur</div>
                  <div className="name">{settings?.name ?? '—'}</div>
                  {settings?.address && <p>{settings.address}</p>}
                  {settings?.city && <p>{settings.city}</p>}
                  {settings?.tax_id && <p>NIF : {settings.tax_id}</p>}
                  {settings?.fne_ncc && <p>NCC : {settings.fne_ncc}</p>}
                  {settings?.fne_tax_regime && <p>Régime : {settings.fne_tax_regime}</p>}
                  {settings?.fne_tax_center && <p>Centre des impôts : {settings.fne_tax_center}</p>}
                  {settings?.fne_bank_reference && <p>Réf. bancaire : {settings.fne_bank_reference}</p>}
                </div>
                <div className="c-party">
                  <div className="lbl">L'acheteur</div>
                  <div className="name">{c?.name ?? '—'}</div>
                  {c?.address && <p>{c.address}</p>}
                  {c?.city && <p>{c.city}</p>}
                  {c?.ncc && <p>NCC : {c.ncc}</p>}
                </div>
              </div>

              {activeContract.intro_text && <p className="intro">{activeContract.intro_text}</p>}

              {activeContract.terms.length > 0 && (
                <>
                  <p className="terms-title">Conditions de vente</p>
                  <ol>
                    {activeContract.terms.map((term, i) => <li key={i}>{term}</li>)}
                  </ol>
                </>
              )}

              <div className="recap">
                <div className="title">Récapitulatif</div>
                <div className="row"><span>Total TTC</span><b>{fmtMoney(invoice.total, cur)}</b></div>
                {(invoice.order_advance ?? 0) > 0 && <div className="row"><span>Avance à la commande</span><b>{fmtMoney(Number(invoice.order_advance), cur)}</b></div>}
                {invoice.payment_mode && <div className="row"><span>Modalité de règlement</span><b>{invoice.payment_mode}</b></div>}
                {(invoice.airsi ?? 0) > 0 && <div className="row"><span>AIRSI</span><b>{fmtMoney(invoice.airsi_amount ?? 0, cur)}</b></div>}
                {invoice.delivery_delay && <div className="row"><span>Délai de livraison</span><b>{invoice.delivery_delay}</b></div>}
              </div>

              <div className="signs">
                <div className="sign-col">
                  <div className="who">{settings?.name ?? 'Le Vendeur'}</div>
                  <div className="line" />
                  <div className="cap">Signature & cachet</div>
                </div>
                <div className="sign-col">
                  <div className="who">{c?.name ?? "L'Acheteur"}</div>
                  <div className="line" />
                  <div className="cap">{activeContract.signature_label}</div>
                </div>
              </div>
            </div>
          )}
      </div>

      {/* Cash Receipt (thermal 80mm) */}
      <div id="receipt-print" className={`${printMode === 'receipt' ? 'mx-auto w-[302px] max-w-full' : 'hidden print:hidden'} rounded-xl border border-gray-300 bg-white shadow-xl print-receipt`}>
        <div className="px-4 py-5 text-gray-900 font-mono text-[11px] leading-relaxed">
          {/* Header */}
          <div className="text-center">
            {settings?.logo_url && (
              <img src={settings.logo_url} alt="Logo" className="mx-auto mb-2 h-14 w-14 object-contain" />
            )}
            <p className="font-bold text-[14px] uppercase tracking-wide text-gray-900">{settings?.name ?? 'Mon Entreprise'}</p>
            <div className="mt-1 text-[10px] text-gray-500 leading-snug">
              {settings?.address && <p>{settings.address}</p>}
              {settings?.city && <p>{settings.city}</p>}
            </div>
            <div className="mt-0.5 text-[10px] text-gray-500">
              {settings?.phone && <span>Tél : {settings.phone}</span>}
              {settings?.tax_id && <span> · NIF : {settings.tax_id}</span>}
            </div>
          </div>

          <div className="my-2.5 border-t border-dashed border-gray-300" />

          {/* Receipt meta */}
          <div className="space-y-1">
            <div className="flex justify-between items-baseline">
              <span className="text-gray-500 text-[10px] uppercase tracking-wide">Reçu N°</span>
              <span className="font-bold text-[14px] text-gray-900">{invoice.invoice_number}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 text-[10px] uppercase tracking-wide">Statut</span>
              <span className="font-bold uppercase text-[10px]">{STATUS_LABELS[invoice.status]}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 text-[10px] uppercase tracking-wide">Date</span>
              <span className="text-[11px]">{fmtDate(invoice.date)}</span>
            </div>
            {c?.name && (
              <div className="flex justify-between">
                <span className="text-gray-500 text-[10px] uppercase tracking-wide">Client</span>
                <span className="font-semibold text-[11px] text-right max-w-[60%] truncate">{c.name}</span>
              </div>
            )}
            {invoice.contact_name && (
              <div className="flex justify-between">
                <span className="text-gray-500 text-[10px] uppercase tracking-wide">Interloc.</span>
                <span className="font-semibold text-[11px] text-right max-w-[60%] truncate">{invoice.contact_name}</span>
              </div>
            )}
            {invoice.contact_phone && (
              <div className="flex justify-between">
                <span className="text-gray-500 text-[10px] uppercase tracking-wide">Tél interloc.</span>
                <span className="text-[11px]">{invoice.contact_phone}</span>
              </div>
            )}
          </div>

          <div className="my-2.5 border-t border-dashed border-gray-300" />

          {/* Items */}
          <table className="w-full">
            <thead>
              <tr className="text-gray-500 border-b border-gray-400">
                <th className="text-left pb-1 text-[9px] font-bold uppercase tracking-wide">Article</th>
                <th className="text-left pb-1 w-16 text-[9px] font-bold uppercase tracking-wide">Réf.</th>
                <th className="text-center pb-1 w-12 text-[9px] font-bold uppercase tracking-wide">Qté</th>
                <th className="text-right pb-1 w-20 pl-1 text-[9px] font-bold uppercase tracking-wide">Total</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.items ?? []).map((item, i) => (
                <tr key={item.id} className="align-top border-b border-dotted border-gray-200">
                  <td className="py-1 pr-1 text-[11px]">
                    <span className="text-gray-400 text-[8px] mr-1">{i + 1}.</span>
                    {item.description}
                  </td>
                  <td className="py-1 pr-1 text-[9px] font-mono text-gray-500">{item.product_id ? productRefs[item.product_id] ?? '—' : '—'}</td>
                  <td className="py-1 text-center tabular-nums font-semibold text-[11px]">{new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(Number(item.quantity))}</td>
                  <td className="py-1 pl-1 text-right tabular-nums font-semibold text-[11px]">{fmtMoney(item.total, cur)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="my-2.5 border-t border-dashed border-gray-300" />

          {/* Totals */}
          <div className="space-y-1">
            <div className="flex justify-between font-bold text-[14px] border-t-2 border-gray-900 pt-1.5 mt-1">
              <span>TOTAL TTC</span>
              <span className="tabular-nums">{fmtMoney(invoice.total, cur)}</span>
            </div>
            {invoice.tax_rate > 0 && (
              <div className="flex justify-between text-[11px]">
                <span className="text-gray-500">TVA</span>
                <span className="tabular-nums">{fmtMoney(invoice.tax_amount, cur)}</span>
              </div>
            )}
            {(invoice.airsi ?? 0) > 0 && (
              <div className="flex justify-between text-[11px]">
                <span className="text-gray-500">AIRSI</span>
                <span className="tabular-nums">{fmtMoney(invoice.airsi_amount ?? 0, cur)}</span>
              </div>
            )}
            {(invoice.remise ?? 0) > 0 && (
              <div className="flex justify-between text-[11px] text-red-500">
                <span>Remise</span>
                <span className="tabular-nums">−{fmtMoney(invoice.remise, cur)}</span>
              </div>
            )}
            {invoice.amount_paid > 0 && (
              <>
                <div className="flex justify-between text-[11px] text-emerald-700 mt-1">
                  <span>Réglé</span>
                  <span className="tabular-nums">− {fmtMoney(invoice.amount_paid, cur)}</span>
                </div>
                <div className={`flex justify-between font-bold text-[12px] border-t border-gray-300 pt-1 ${invoice.balance_due > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                  <span>{invoice.balance_due > 0 ? 'SOLDE DÛ' : 'SOLDÉ'}</span>
                  <span className="tabular-nums">{fmtMoney(invoice.balance_due, cur)}</span>
                </div>
              </>
            )}
          </div>

          {/* Payments breakdown */}
          {payments.length > 0 && (
            <>
              <div className="my-2.5 border-t border-dashed border-gray-300" />
              <div className="space-y-0.5">
                <p className="font-bold text-[9px] uppercase tracking-wide text-gray-500 border-b border-gray-300 pb-0.5 mb-1">Règlements</p>
                {payments.map(p => (
                  <div key={p.id} className="flex justify-between text-[11px]">
                    <span className="text-gray-700">{METHOD_LABELS[p.method] ?? p.method}{p.notes ? ` — ${p.notes}` : ''}</span>
                    <span className="tabular-nums font-semibold">{fmtMoney(Number(p.amount), cur)}</span>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* FNE info */}
          {invoice.fne_status === 'certified' && (
            <>
              <div className="my-2.5 border-t border-dashed border-gray-300" />
              <div className="rounded border border-emerald-200 bg-emerald-50/50 p-2 text-center space-y-1">
                <p className="font-bold text-[11px] text-emerald-700">FNE Certifiée — DGI</p>
                <p className="text-[11px]">Réf : <span className="font-mono font-bold text-[12px]">{invoice.fne_reference ?? '—'}</span></p>
                {invoice.fne_ncc && <p className="text-[10px] text-gray-600">NCC vendeur : {invoice.fne_ncc}</p>}
                {c?.ncc && <p className="text-[10px] text-gray-600">NCC client : {c.ncc}</p>}
                <p className="text-[10px] text-gray-600">Type : {c?.type === 'entreprise' ? 'B2B' : 'B2C'}</p>
                {qrDataUrl && (
                  <img src={qrDataUrl} alt="QR FNE" className="mx-auto h-28 w-28 rounded border border-emerald-200 bg-white p-1" />
                )}
              </div>
            </>
          )}

          <div className="my-2.5 border-t border-dashed border-gray-300" />

          {/* Footer */}
          <div className="text-center text-gray-500">
            {settings?.invoice_footer && <p className="text-[10px] leading-snug">{settings.invoice_footer}</p>}
            <p className="mt-1 text-[11px] font-semibold text-gray-700">Merci de votre visite !</p>
          </div>
        </div>
      </div>

      {/* Delivery note A4 — self-contained print template */}
      <div id="delivery-print" className={`${printMode === 'delivery' ? '' : 'hidden print:hidden'} print-invoice`}>
        <style>{`
        .bl-doc {
          width: 210mm; min-height: 297mm; margin: 0 auto; padding: 12mm 14mm;
          background: #fff; color: #111; font-family: Arial, Helvetica, sans-serif;
          font-size: 10px; line-height: 1.35; box-sizing: border-box;
        }
        .bl-doc * { box-sizing: border-box; }
        .bl-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4mm; }
        .bl-company h1 { font-size: 13px; font-weight: 700; margin: 0 0 1mm; text-transform: uppercase; letter-spacing: 0; }
        .bl-company p { margin: 0; font-size: 10px; color: #333; line-height: 1.3; }
        .bl-logo-wrap { width: 60mm; text-align: right; }
        .bl-logo-wrap img { max-width: 55mm; max-height: 22mm; object-fit: contain; }
        .bl-doc-label {
          display: inline-block; padding: 1.5mm 4mm; border: 1.5px solid #111;
          background: #e5e7eb; font-size: 11px; font-weight: 700; text-transform: uppercase;
          letter-spacing: 0.5px; margin-bottom: 2mm;
        }
        .bl-doc-label .num { font-size: 13px; }
        .bl-meta-grid { display: grid; grid-template-columns: 1fr 1fr; border: 1px solid #111; }
        .bl-meta-grid > div { padding: 1mm 1.5mm; border-right: 1px solid #111; border-bottom: 1px solid #111; font-size: 10px; min-height: 5mm; }
        .bl-meta-grid > div:nth-child(2n) { border-right: 0; }
        .bl-meta-grid > div:last-child { border-right: 0; border-bottom: 0; }
        .bl-meta-grid > div b { font-weight: 600; color: #555; }
        .bl-meta-grid .contact-cell { grid-column: 1 / -1; font-size: 10px; min-height: 8mm; }
        .bl-meta-grid .contact-cell .lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #666; margin-bottom: 0.5mm; }
        .bl-meta-grid .contact-cell .name { font-weight: 700; font-size: 11px; }
        .bl-meta-grid .contact-cell p { margin: 0; line-height: 1.4; font-size: 10px; }
        .bl-parties { display: grid; grid-template-columns: 1fr 1fr; gap: 4mm; margin-bottom: 4mm; }
        .bl-party-box { border: 1px solid #111; padding: 2mm 2.5mm; min-height: 22mm; }
        .bl-party-box .lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #666; margin-bottom: 1mm; }
        .bl-party-box .name { font-size: 11px; font-weight: 700; margin-bottom: 0.5mm; }
        .bl-party-box p { margin: 0; font-size: 10px; color: #333; line-height: 1.3; }
        .bl-table { width: 100%; border-collapse: collapse; margin-bottom: 4mm; }
        .bl-table th, .bl-table td { border: 1px solid #111; padding: 1.2mm 1.5mm; font-size: 10px; text-align: left; }
        .bl-table th { background: #d1d5db; font-weight: 700; text-align: center; text-transform: uppercase; font-size: 10px; }
        .bl-table td.qty, .bl-table th.qty { text-align: center; }
        .bl-empty-row td { height: 75mm; border: 1px solid #111; }
        .bl-total-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6mm; }
        .bl-total-row .articles { font-size: 10px; color: #555; }
        .bl-total-box { border: 1.5px solid #111; padding: 2mm 5mm; font-size: 11px; font-weight: 700; display: flex; gap: 4mm; }
        .bl-signs { display: flex; justify-content: space-between; gap: 8mm; margin-top: 18mm; }
        .bl-sign-col { flex: 1; text-align: center; }
        .bl-sign-col .who { font-size: 10px; font-weight: 600; margin-bottom: 20mm; }
        .bl-sign-col .line { border-top: 1px solid #111; }
        .bl-sign-col .cap { font-size: 10px; color: #555; margin-top: 1mm; }
        .bl-notice { border: 1px solid #111; background: #f3f4f6; padding: 2mm 2.5mm; margin-top: 3mm; font-size: 8.5px; line-height: 1.4; min-height: 6mm; }
        .bl-notice .lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #444; margin-bottom: 0.5mm; }
        .bl-footer { border-top: 1px solid #111; padding-top: 1.5mm; margin-top: 8mm; text-align: center; font-size: 10px; color: #333; }
        `}</style>

        <div className="bl-doc">
          {/* Header */}
          <div className="bl-header">
            <div className="bl-company">
              <h1>{settings?.name ?? 'Mon Entreprise'}</h1>
              {settings?.address && <p>{settings.address}</p>}
              {settings?.city && <p>{settings.city}</p>}
              {settings?.phone && <p>Tél : {settings.phone}</p>}
              {settings?.email && <p>{settings.email}</p>}
              {settings?.tax_id && <p>NIF / SIRET : {settings.tax_id}</p>}
            </div>
            <div className="bl-logo-wrap">
              {settings?.logo_url && <img src={settings.logo_url} alt="Logo" />}
            </div>
          </div>

          {/* Document label + meta */}
          <div style={{ marginBottom: '4mm' }}>
            <div className="bl-doc-label">BON DE LIVRAISON <span className="num">{invoice.invoice_number}</span></div>
            <div className="bl-meta-grid">
              <div><b>Date :</b> {fmtDate(invoice.date)}</div>
              {invoice.order_number && <div><b>Commande :</b> {invoice.order_number}</div>}
              {invoice.delivery_delay && <div><b>Délai :</b> {invoice.delivery_delay}</div>}
              {(invoice.airsi ?? 0) > 0 && <div><b>AIRSI :</b> {fmtMoney(invoice.airsi_amount ?? 0, cur)}</div>}
              {invoice.creator?.full_name && <div><b>Créé par :</b> {invoice.creator.full_name}</div>}
              {(invoice.contact_name || invoice.contact_phone || invoice.contact_email) && (
                <div className="contact-cell">
                  <div className="lbl">Interlocuteur</div>
                  {invoice.contact_name && <p className="name">{invoice.contact_name}</p>}
                  {invoice.contact_phone && <p>Tél : {invoice.contact_phone}</p>}
                  {invoice.contact_email && <p>Email : {invoice.contact_email}</p>}
                </div>
              )}
            </div>
          </div>

          {/* Parties */}
          <div className="bl-parties">
            <div className="bl-party-box">
              <div className="lbl">Livré à</div>
              <div className="name">{c?.name ?? '—'}</div>
              {c?.address && <p>{c.address}</p>}
              {c?.city && <p>{c.city}</p>}
              {c?.phone && <p>Tél : {c.phone}</p>}
              {c?.email && <p>{c.email}</p>}
              {c?.ncc && <p>NCC : {c.ncc}</p>}
            </div>
            {invoice.fne_status === 'certified' && (
              <div className="bl-party-box">
                <div className="lbl">Certification FNE — DGI</div>
                <p>Réf DGI : <b>{invoice.fne_reference ?? '—'}</b></p>
                {invoice.fne_ncc && <p>NCC : {invoice.fne_ncc}</p>}
                {qrDataUrl && <img src={qrDataUrl} alt="QR FNE" style={{ width: '18mm', height: '18mm', border: '1px solid #ccc', padding: '0.5mm', background: '#fff', marginTop: '1mm' }} />}
              </div>
            )}
          </div>

          {/* Items table */}
          <table className="bl-table">
            <thead>
              <tr>
                <th style={{ width: '4%' }}>#</th>
                <th style={{ width: '21%' }}>Référence</th>
                <th style={{ width: '55%' }}>Désignation</th>
                <th className="qty" style={{ width: '12%' }}>Qté</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.items ?? []).map((item, i) => {
                const ref = item.product_id ? productRefs[item.product_id] : undefined;
                return (
                  <tr key={item.id}>
                    <td>{i + 1}</td>
                    <td style={{ fontFamily: 'monospace' }}>{ref ?? '—'}</td>
                    <td>{item.description}</td>
                    <td className="qty">{new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(item.quantity))}</td>
                  </tr>
                );
              })}
              <tr className="bl-empty-row"><td colSpan={4} /></tr>
            </tbody>
          </table>

          {/* Total */}
          <div className="bl-total-row">
            <div className="articles">{(invoice.items ?? []).length} article{(invoice.items ?? []).length > 1 ? 's' : ''}</div>
            <div className="bl-total-box">
              <span>TOTAL QTÉ</span>
              <span>{new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format((invoice.items ?? []).reduce((s, it) => s + Number(it.quantity), 0))}</span>
            </div>
          </div>

          {/* Notification */}
          {settings?.delivery_notice && (
            <div className="bl-notice">
              <div className="lbl">Observations</div>
              <p>{settings.delivery_notice}</p>
            </div>
          )}

          {/* Signatures */}
          <div className="bl-signs">
            <div className="bl-sign-col">
              <div className="who">Livré par</div>
              <div className="line" />
              <div className="cap">Signature & cachet</div>
            </div>
            <div className="bl-sign-col">
              <div className="who">Reçu par</div>
              <div className="line" />
              <div className="cap">Signature & cachet</div>
            </div>
          </div>

          {/* Footer */}
          <div className="bl-footer">
            {settings?.invoice_footer && <p>{settings.invoice_footer}</p>}
          </div>
        </div>
      </div>

      {/* Delivery note 80mm thermal — self-contained */}
      <div id="delivery-receipt-print" className={`${printMode === 'delivery-receipt' ? 'mx-auto w-[302px] max-w-full' : 'hidden print:hidden'} print-receipt`}>
        <div className="px-4 py-5 text-gray-900 font-mono text-[11px] leading-relaxed">
          {/* Header */}
          <div className="text-center">
            {settings?.logo_url && (
              <img src={settings.logo_url} alt="Logo" className="mx-auto mb-2 h-14 w-14 object-contain" />
            )}
            <p className="font-bold text-[14px] uppercase tracking-wide text-gray-900">{settings?.name ?? 'Mon Entreprise'}</p>
            <div className="mt-1 text-[10px] text-gray-500 leading-snug">
              {settings?.address && <p>{settings.address}</p>}
              {settings?.city && <p>{settings.city}</p>}
            </div>
            <div className="mt-0.5 text-[10px] text-gray-500">
              {settings?.phone && <span>Tél : {settings.phone}</span>}
              {settings?.tax_id && <span> · NIF : {settings.tax_id}</span>}
            </div>
          </div>

          <div className="my-2.5 border-t border-dashed border-gray-300" />

          {/* Title */}
          <p className="text-center font-bold text-[13px] uppercase tracking-wide text-orange-700">Bon de Livraison</p>

          <div className="my-2 border-t border-dashed border-gray-300" />

          {/* Meta */}
          <div className="space-y-1">
            <div className="flex justify-between items-baseline">
              <span className="text-gray-500 text-[10px] uppercase tracking-wide">N°</span>
              <span className="font-bold text-[14px] text-gray-900">{invoice.invoice_number}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 text-[10px] uppercase tracking-wide">Date</span>
              <span className="text-[11px]">{fmtDate(invoice.date)}</span>
            </div>
            {invoice.order_number && (
              <div className="flex justify-between">
                <span className="text-gray-500 text-[10px] uppercase tracking-wide">Commande</span>
                <span className="text-[11px]">{invoice.order_number}</span>
              </div>
            )}
            {(invoice.airsi ?? 0) > 0 && (
              <div className="flex justify-between">
                <span className="text-gray-500 text-[10px] uppercase tracking-wide">AIRSI</span>
                <span className="text-[11px] tabular-nums">{fmtMoney(invoice.airsi_amount ?? 0, cur)}</span>
              </div>
            )}
            {c?.name && (
              <div className="flex justify-between">
                <span className="text-gray-500 text-[10px] uppercase tracking-wide">Client</span>
                <span className="font-semibold text-[11px] text-right max-w-[60%] truncate">{c.name}</span>
              </div>
            )}
            {invoice.contact_name && (
              <div className="flex justify-between">
                <span className="text-gray-500 text-[10px] uppercase tracking-wide">Interloc.</span>
                <span className="font-semibold text-[11px] text-right max-w-[60%] truncate">{invoice.contact_name}</span>
              </div>
            )}
            {invoice.contact_phone && (
              <div className="flex justify-between">
                <span className="text-gray-500 text-[10px] uppercase tracking-wide">Tél interloc.</span>
                <span className="text-[11px]">{invoice.contact_phone}</span>
              </div>
            )}
          </div>

          <div className="my-2.5 border-t border-dashed border-gray-300" />

          {/* Items */}
          <table className="w-full">
            <thead>
              <tr className="text-gray-500 border-b border-gray-400">
                <th className="text-left pb-1 text-[9px] font-bold uppercase tracking-wide">Article</th>
                <th className="text-center pb-1 w-12 text-[9px] font-bold uppercase tracking-wide">Qté</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.items ?? []).map((item, i) => (
                <tr key={item.id} className="align-top border-b border-dotted border-gray-200">
                  <td className="py-1 pr-1 text-[11px]">
                    <span className="text-gray-400 text-[8px] mr-1">{i + 1}.</span>
                    {item.description}
                  </td>
                  <td className="py-1 text-center tabular-nums font-semibold text-[11px]">{new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(Number(item.quantity))}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="my-2.5 border-t border-dashed border-gray-300" />

          {/* Total */}
          <div className="flex justify-between font-bold text-[14px] border-t-2 border-gray-900 pt-1.5">
            <span>TOTAL QTÉ</span>
            <span className="tabular-nums">{new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format((invoice.items ?? []).reduce((s, it) => s + Number(it.quantity), 0))}</span>
          </div>
          <div className="mt-1 text-right text-[10px] text-gray-500">
            {(invoice.items ?? []).length} article{(invoice.items ?? []).length > 1 ? 's' : ''}
          </div>

          {/* Notification */}
          {settings?.delivery_notice && (
            <div className="rounded border border-gray-300 bg-gray-50 p-2 mb-3">
              <p className="text-[8px] font-bold uppercase tracking-wide text-gray-500 mb-0.5">Observations</p>
              <p className="text-[10px] text-gray-700 leading-snug">{settings.delivery_notice}</p>
            </div>
          )}

          <div className="my-3 border-t border-dashed border-gray-300" />

          {/* FNE info */}
          {invoice.fne_status === 'certified' && (
            <div className="rounded border border-emerald-200 bg-emerald-50/50 p-2 text-center space-y-1 mb-3">
              <p className="font-bold text-[11px] text-emerald-700">FNE Certifiée — DGI</p>
              <p className="text-[11px]">Réf : <span className="font-mono font-bold text-[12px]">{invoice.fne_reference ?? '—'}</span></p>
              {qrDataUrl && (
                <img src={qrDataUrl} alt="QR FNE" className="mx-auto h-24 w-24 rounded border border-emerald-200 bg-white p-1" />
              )}
            </div>
          )}

          {/* Signatures */}
          <div className="mt-6 flex justify-between gap-4">
            <div className="flex-1 text-center">
              <p className="text-[10px] font-medium uppercase tracking-wide text-gray-500 mb-12">Livré par</p>
              <div className="border-t border-gray-400" />
              <p className="mt-1 text-[9px] text-gray-400">Signature</p>
            </div>
            <div className="flex-1 text-center">
              <p className="text-[10px] font-medium uppercase tracking-wide text-gray-500 mb-12">Reçu par</p>
              <div className="border-t border-gray-400" />
              <p className="mt-1 text-[9px] text-gray-400">Signature</p>
            </div>
          </div>

          <div className="my-2.5 border-t border-dashed border-gray-300" />

          {/* Footer */}
          <div className="text-center text-gray-500">
            {settings?.invoice_footer && <p className="text-[10px] leading-snug">{settings.invoice_footer}</p>}
            <p className="mt-1 text-[11px] font-semibold text-gray-700">Merci de votre confiance !</p>
          </div>
        </div>
      </div>

      {showReturn && invoice && onReturnInvoiceItems && (
        <ReturnItemsModal
          title={`Retour en stock — ${invoice.invoice_number}`}
          items={(invoice.items ?? []).map(i => ({ id: i.id, product_id: i.product_id, description: i.description, quantity: i.quantity, unit_price: i.unit_price }))}
          onSubmit={async (returns, reason) => {
            await onReturnInvoiceItems(invoice.id, returns, reason);
            await load();
          }}
          onClose={() => setShowReturn(false)}
        />
      )}
    </div>
  );
}
