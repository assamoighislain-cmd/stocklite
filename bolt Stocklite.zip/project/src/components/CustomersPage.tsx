import { useState } from 'react';
import { Search, PlusCircle, Pencil, ArrowRight, Trash2, Upload } from 'lucide-react';
import type { Customer, SalesLocation } from '../types';
import { Modal } from './Modal';
import { ImportDataModal } from './ImportDataModal';
import type { Route } from '../App';
import { translateError } from '../lib/translateError';

interface CustomersPageProps {
  customers: Customer[];
  invoiceSummary: Record<string, { total: number; paid: number; balance: number }>;
  onSave: (payload: Omit<Customer, 'id' | 'created_at'>, id?: string) => Promise<Customer>;
  onRemove: (id: string) => Promise<void>;
  onNavigate: (r: Route) => void;
  canDelete?: boolean;
  locationId?: string | null;
}

function fmt(n: number) {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XOF', maximumFractionDigits: 0 }).format(n);
}

interface CustomerFormProps {
  initial?: Customer;
  onSubmit: (d: Omit<Customer, 'id' | 'created_at'>) => Promise<void>;
  onClose: () => void;
  locations: SalesLocation[];
  defaultLocationId?: string | null;
}

function CustomerForm({ initial, onSubmit, onClose, locations, defaultLocationId }: CustomerFormProps) {
  const [form, setForm] = useState({
    code: initial?.code ?? '',
    name: initial?.name ?? '',
    email: initial?.email ?? '',
    phone: initial?.phone ?? '',
    address: initial?.address ?? '',
    city: initial?.city ?? '',
    notes: initial?.notes ?? '',
    location_id: initial?.location_id ?? defaultLocationId ?? null,
    type: (initial?.type ?? 'particulier') as 'particulier' | 'entreprise',
    ncc: initial?.ncc ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  function set(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); setSaved(false); }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setErr('Le nom est requis.'); return; }
    if (!form.location_id) { setErr('Le point de vente est requis.'); return; }
    if (form.type === 'entreprise' && !form.ncc.trim()) {
      setErr('Le NCC est requis pour un client entreprise (certification FNE).');
      return;
    }
    setSaving(true);
    try {
      await onSubmit({
        ...form,
        code: form.code.trim() || null,
        name: form.name.trim(),
        ncc: form.type === 'entreprise' ? form.ncc.trim() : null,
      });
      onClose();
    } catch (e) { setErr(e instanceof Error ? translateError(e.message) : 'Erreur'); setSaving(false); }
  }

  return (
    <form onSubmit={submit} className="space-y-4 p-5">
      <div className="grid grid-cols-3 gap-3">
        <div className="col-span-1">
          <label className="label">Code client</label>
          <input className="input font-mono" value={form.code} onChange={e => set('code', e.target.value)} placeholder="Auto" />
          <p className="mt-1 text-xs text-gray-400">Laisser vide pour générer automatiquement.</p>
        </div>
        <div className="col-span-2">
          <label className="label">Nom / Raison sociale *</label>
          <input className="input" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Nom complet" />
        </div>
      </div>
      <div>
        <label className="label">Type de client *</label>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => set('type', 'particulier')}
            className={`rounded-lg border px-3 py-2.5 text-sm font-medium transition ${form.type === 'particulier' ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-300 text-gray-600 hover:bg-gray-50'}`}
          >
            Particulier
          </button>
          <button
            type="button"
            onClick={() => set('type', 'entreprise')}
            className={`rounded-lg border px-3 py-2.5 text-sm font-medium transition ${form.type === 'entreprise' ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-300 text-gray-600 hover:bg-gray-50'}`}
          >
            Entreprise
          </button>
        </div>
      </div>
      {form.type === 'entreprise' && (
        <div>
          <label className="label">NCC (Numéro Compte Contribuable) *</label>
          <input className="input font-mono" value={form.ncc} onChange={e => set('ncc', e.target.value)} placeholder="Ex : 9606123E" />
          <p className="mt-1 text-xs text-gray-400">Requis pour la certification FNE des factures B2B.</p>
        </div>
      )}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">Téléphone</label>
          <input className="input" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+xxx" />
        </div>
        <div>
          <label className="label">Email</label>
          <input type="email" className="input" value={form.email} onChange={e => set('email', e.target.value)} placeholder="mail@example.com" />
        </div>
      </div>
      <div>
        <label className="label">Adresse</label>
        <input className="input" value={form.address} onChange={e => set('address', e.target.value)} placeholder="Rue, quartier…" />
      </div>
      <div>
        <label className="label">Ville</label>
        <input className="input" value={form.city} onChange={e => set('city', e.target.value)} placeholder="Ville" />
      </div>
      {locations.length > 0 && (
        <div>
          <label className="label">Point de vente *</label>
          <select
            className="input"
            value={form.location_id ?? ''}
            onChange={e => set('location_id', e.target.value || null)}
          >
            <option value="">Sélectionner un point de vente</option>
            {locations.map(l => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
          <p className="mt-1 text-xs text-gray-400">Le client doit être rattaché à un point de vente.</p>
        </div>
      )}
      <div>
        <label className="label">Notes internes</label>
        <textarea rows={2} className="input resize-none" value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="Optionnel" />
      </div>
      {err && <p className="text-xs text-red-400">{err}</p>}
      <div className="flex gap-2 pt-1">
        <button type="button" onClick={onClose} className="flex-1 rounded-lg border border-gray-300 py-2.5 text-sm text-gray-500 hover:bg-gray-100">Annuler</button>
        <button type="submit" disabled={saving} className="flex-1 rounded-lg bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50">
          {saving ? 'Enregistrement…' : 'Enregistrer'}
        </button>
      </div>
    </form>
  );
}

export function CustomersPage({ customers, invoiceSummary, onSave, onRemove, onNavigate, canDelete = true, locationId, locations = [] }: CustomersPageProps) {
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<Customer | null | 'new'>(null);
  const [confirm, setConfirm] = useState<string | null>(null);
  const [showImport, setShowImport] = useState(false);

  const filtered = customers.filter(c =>
    `${c.code ?? ''} ${c.name} ${c.email} ${c.phone} ${c.city}`.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-gray-900">Clients</h1>
          <p className="text-sm text-gray-400">{customers.length} client{customers.length > 1 ? 's' : ''} enregistré{customers.length > 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowImport(true)} className="flex items-center gap-2 rounded-lg border border-gray-300 px-3.5 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100 transition active:scale-95">
            <Upload className="h-4 w-4" /> Importer
          </button>
          <button onClick={() => setEditing('new')} className="flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-blue-500 transition active:scale-95">
            <PlusCircle className="h-4 w-4" /> Nouveau client
          </button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Rechercher un client…" className="w-full rounded-lg border border-gray-300 bg-white py-2.5 pl-9 pr-4 text-sm text-gray-800 placeholder-gray-400 outline-none focus:border-blue-500" />
      </div>

      <div className="overflow-x-auto rounded-xl border border-gray-200">
        {filtered.length === 0 ? (
          <div className="py-14 text-center text-sm text-gray-400">
            {query ? 'Aucun client trouvé.' : 'Aucun client. Ajoutez votre premier client.'}
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                {['Client', 'Point de vente', 'Contact', 'Facturé', 'Solde dû', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-400 first:pl-5">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filtered.map(c => {
                const s = invoiceSummary[c.id] ?? { total: 0, paid: 0, balance: 0 };
                return (
                  <tr key={c.id} onClick={() => onNavigate({ page: 'customer-detail', id: c.id })} className="group cursor-pointer bg-white hover:bg-gray-100">
                    <td className="px-4 py-3 pl-5">
                      <div className="flex items-center gap-2">
                        {c.code && <span className="rounded bg-gray-100 px-1.5 py-0.5 font-mono text-[11px] font-semibold text-gray-500">{c.code}</span>}
                        <p className="font-semibold text-gray-800">{c.name}</p>
                      </div>
                      {c.city && <p className="text-xs text-gray-400">{c.city}</p>}
                    </td>
                    <td className="px-4 py-3">
                      {c.location_id ? (
                        <span className="text-gray-500">{locations.find(l => l.id === c.location_id)?.name ?? '—'}</span>
                      ) : (
                        <span className="text-gray-300">Tous</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {c.phone && <p className="text-gray-500">{c.phone}</p>}
                      {c.email && <p className="text-xs text-gray-400">{c.email}</p>}
                    </td>
                    <td className="px-4 py-3 tabular-nums text-gray-700">{fmt(s.total)}</td>
                    <td className="px-4 py-3 tabular-nums">
                      <span className={`font-semibold ${s.balance > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                        {fmt(s.balance)}
                      </span>
                    </td>
                    <td className="px-4 py-3 pr-4">
                      <div className="flex items-center justify-end gap-1" onClick={e => e.stopPropagation()}>
                        <button onClick={() => setEditing(c)} className="rounded p-1.5 text-gray-500 hover:bg-gray-200 hover:text-gray-800" title="Modifier">
                          <Pencil className="h-4 w-4" />
                        </button>
                        {canDelete && (
                          <>
                            {confirm === c.id ? (
                              <div className="flex items-center gap-1">
                                <button onClick={() => onRemove(c.id).then(() => setConfirm(null))} className="rounded px-2 py-1 text-xs font-semibold text-red-400 ring-1 ring-red-800 hover:bg-red-950">Supprimer</button>
                                <button onClick={() => setConfirm(null)} className="text-xs text-gray-400 px-1">×</button>
                              </div>
                            ) : (
                              <button onClick={() => setConfirm(c.id)} className="rounded p-1.5 text-gray-500 hover:bg-red-950/60 hover:text-red-400" title="Supprimer">
                                <Trash2 className="h-4 w-4" />
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {editing !== null && (
        <Modal title={editing === 'new' ? 'Nouveau client' : 'Modifier le client'} onClose={() => setEditing(null)}>
          <CustomerForm
            initial={editing === 'new' ? undefined : editing}
            onSubmit={d => onSave(d, editing === 'new' ? undefined : editing.id).then(() => {})}
            onClose={() => setEditing(null)}
            locations={locations}
            defaultLocationId={locationId}
          />
        </Modal>
      )}

      <ImportDataModal
        open={showImport}
        onClose={() => setShowImport(false)}
        locationId={locationId}
        locations={locations}
      />
    </div>
  );
}
