/**
 * Generates PWA PNG icons using pure Node.js (no external deps).
 * Produces solid-color icons with a simple "S" lettermark.
 */
const fs   = require('fs');
const zlib = require('zlib');

// ── CRC32 ──────────────────────────────────────────────────────────
const crcTable = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[i] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return ((c ^ 0xFFFFFFFF) >>> 0);
}

function chunk(type, data) {
  const typeB = Buffer.from(type, 'ascii');
  const lenB  = Buffer.alloc(4);  lenB.writeUInt32BE(data.length);
  const crcB  = Buffer.alloc(4);  crcB.writeUInt32BE(crc32(Buffer.concat([typeB, data])));
  return Buffer.concat([lenB, typeB, data, crcB]);
}

// ── Draw a filled rectangle into a pixel buffer ────────────────────
function fillRect(pixels, W, x, y, w, h, r, g, b) {
  for (let py = y; py < y + h; py++) {
    for (let px = x; px < x + w; px++) {
      if (px < 0 || px >= W || py < 0) continue;
      const off = (py * W + px) * 3;
      pixels[off] = r; pixels[off+1] = g; pixels[off+2] = b;
    }
  }
}

// ── Create PNG from W×W pixel buffer (RGB) ────────────────────────
function makePng(W, pixels) {
  const sig    = Buffer.from([137,80,78,71,13,10,26,10]);
  const ihdrD  = Buffer.alloc(13);
  ihdrD.writeUInt32BE(W, 0); ihdrD.writeUInt32BE(W, 4);
  ihdrD[8]=8; ihdrD[9]=2; // 8-bit RGB truecolor
  const raw = Buffer.alloc((W*3+1)*W);
  for (let y = 0; y < W; y++) {
    raw[y*(W*3+1)] = 0; // filter: None
    for (let x = 0; x < W; x++) {
      const src = (y*W+x)*3, dst = y*(W*3+1)+1+x*3;
      raw[dst]=pixels[src]; raw[dst+1]=pixels[src+1]; raw[dst+2]=pixels[src+2];
    }
  }
  const compressed = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([sig, chunk('IHDR',ihdrD), chunk('IDAT',compressed), chunk('IEND',Buffer.alloc(0))]);
}

// ── Draw the app icon: blue bg + white lettermark ─────────────────
function drawIcon(W) {
  const pixels = Buffer.alloc(W * W * 3);
  const BG  = [29, 78, 216];   // blue-700
  const FG  = [255,255,255];   // white
  const ACC = [96, 165, 250];  // blue-400

  // Background
  for (let i = 0; i < W*W*3; i+=3) { pixels[i]=BG[0]; pixels[i+1]=BG[1]; pixels[i+2]=BG[2]; }

  // Rounded corner simulation: darken corners
  const radius = Math.round(W * 0.18);
  for (let y = 0; y < radius; y++) {
    for (let x = 0; x < radius; x++) {
      const dx = radius - x - 0.5, dy = radius - y - 0.5;
      if (dx*dx + dy*dy > radius*radius) {
        // corners: set to a slightly darker shade or transparent equivalent
        const corners = [[0,0],[W-radius,0],[0,W-radius],[W-radius,W-radius]];
        for (const [cx,cy] of corners) {
          const nx = cx === 0 ? x : W-1-x, ny = cy === 0 ? y : W-1-y;
          const off = (ny*W+nx)*3;
          pixels[off]=20; pixels[off+1]=55; pixels[off+2]=160;
        }
      }
    }
  }

  // Letter "S" made of rectangles scaled to W
  const u = Math.round(W / 8);  // unit size
  const ox = Math.round(W * 0.28), oy = Math.round(W * 0.20);
  const sw = Math.round(W * 0.44), sh = Math.round(W * 0.60);
  const t  = Math.max(1, Math.round(u * 0.85)); // stroke thickness

  // Top bar
  fillRect(pixels,W, ox, oy, sw, t, ...FG);
  // Middle bar
  fillRect(pixels,W, ox, oy + Math.round(sh/2) - Math.round(t/2), sw, t, ...ACC);
  // Bottom bar
  fillRect(pixels,W, ox, oy + sh - t, sw, t, ...FG);
  // Top-left vertical
  fillRect(pixels,W, ox, oy, t, Math.round(sh/2), ...FG);
  // Bottom-right vertical
  fillRect(pixels,W, ox + sw - t, oy + Math.round(sh/2), t, Math.round(sh/2), ...FG);

  return makePng(W, pixels);
}

// ── Output ─────────────────────────────────────────────────────────
fs.mkdirSync('public/icons', { recursive: true });

const sizes = [72, 96, 128, 144, 152, 180, 192, 384, 512];
for (const s of sizes) {
  fs.writeFileSync(`public/icons/icon-${s}x${s}.png`, drawIcon(s));
  console.log(`  icon-${s}x${s}.png`);
}

// Also write a small 32×32 favicon
fs.writeFileSync('public/favicon.png', drawIcon(32));
console.log('  favicon.png');
console.log('Done.');
