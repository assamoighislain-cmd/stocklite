import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.47.0";

function translateError(message: string): string {
  if (!message) return "Une erreur est survenue.";
  const map: [RegExp, string][] = [
    [/already been registered/i, "Un compte existe déjà avec cet email"],
    [/JWT expired/i, "Votre session a expiré. Reconnectez-vous."],
    [/Invalid login credentials/i, "Email ou mot de passe incorrect."],
    [/row-level security/i, "Action non autorisée. Vérifiez vos permissions."],
    [/foreign key/i, "Référence invalide. L'élément lié n'existe pas."],
    [/not-null constraint/i, "Un champ obligatoire est manquant."],
    [/duplicate key/i, "Cette valeur existe déjà."],
    [/rate limit/i, "Trop de requêtes. Patientez un instant."],
    [/network|fetch failed/i, "Problème de connexion. Vérifiez votre internet."],
  ];
  for (const [re, fr] of map) if (re.test(message)) return fr;
  return message;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Non autorise" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const anonClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user: caller } } = await anonClient.auth.getUser();
    if (!caller) {
      return new Response(JSON.stringify({ error: "Non autorise" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { data: callerProfile } = await adminClient
      .from("user_profiles")
      .select("role, tenant_id")
      .eq("id", caller.id)
      .maybeSingle();

    if (!callerProfile || (callerProfile.role !== "super_admin" && callerProfile.role !== "admin")) {
      return new Response(JSON.stringify({ error: "Acces refuse. Role admin requis." }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { email, password, full_name, role, tenant_id } = await req.json();

    if (!email || !password || !role) {
      return new Response(JSON.stringify({ error: "Champs requis: email, password, role" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Admins can only create users within their own tenant; super_admin can specify any tenant.
    const effectiveTenantId = callerProfile.role === "super_admin" ? tenant_id : (callerProfile.tenant_id ?? tenant_id);

    if (!effectiveTenantId) {
      return new Response(JSON.stringify({ error: "Aucune entreprise associee au compte." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check tenant exists and quota
    const { data: tenant } = await adminClient
      .from("tenants")
      .select("max_users, name")
      .eq("id", effectiveTenantId)
      .maybeSingle();

    if (!tenant) {
      return new Response(JSON.stringify({ error: "Entreprise introuvable" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { count } = await adminClient
      .from("user_profiles")
      .select("id", { count: "exact", head: true })
      .eq("tenant_id", effectiveTenantId);

    if (count !== null && count >= tenant.max_users) {
      return new Response(JSON.stringify({
        error: `Quota atteint: ${count}/${tenant.max_users} utilisateurs pour ${tenant.name}.`
      }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create auth user - do NOT pass tenant_id in metadata to avoid trigger issues
    const { data: newUser, error: createError } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: full_name || "", role },
    });

    if (createError) {
      const msg = createError.message.includes("already been registered")
        ? "Un compte existe deja avec cet email"
        : createError.message;
      return new Response(JSON.stringify({ error: msg }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Update the profile with full data (trigger created a basic row via ON CONFLICT DO NOTHING)
    const { error: profileError } = await adminClient
      .from("user_profiles")
      .update({
        email,
        full_name: full_name || "",
        role,
        status: "active",
        tenant_id: effectiveTenantId,
      })
      .eq("id", newUser.user.id);

    if (profileError) {
      await adminClient.auth.admin.deleteUser(newUser.user.id);
      return new Response(JSON.stringify({ error: "Erreur lors de la création du profil : " + translateError(profileError.message) }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({
      success: true,
      user: { id: newUser.user.id, email, full_name, role, tenant_id: effectiveTenantId }
    }), {
      status: 201,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err instanceof Error ? translateError(err.message) : "Erreur interne" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
