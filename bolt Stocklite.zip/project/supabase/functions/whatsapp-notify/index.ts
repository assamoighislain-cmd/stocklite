import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.47.0";

function translateError(message: string): string {
  if (!message) return "Une erreur est survenue.";
  const map: [RegExp, string][] = [
    [/network|fetch failed/i, "Problème de connexion. Vérifiez votre internet."],
    [/rate limit/i, "Trop de requêtes. Patientez un instant."],
  ];
  for (const [re, fr] of map) if (re.test(message)) return fr;
  return message;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SignupPayload {
  full_name?: string;
  email?: string;
  company_name?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Non autorise" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    if (!supabaseUrl || !anonKey) throw new Error("Configuration Supabase manquante");

    const client = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await client.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Non autorise" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const payload = await req.json() as SignupPayload;
    const recipient = Deno.env.get("WHATSAPP_ADMIN_PHONE");
    const accessToken = Deno.env.get("WHATSAPP_ACCESS_TOKEN");
    const phoneNumberId = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID");

    if (!recipient || !accessToken || !phoneNumberId) {
      return new Response(JSON.stringify({ sent: false, reason: "WhatsApp non configure" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const message = [
      "Nouvelle demande de compte Stocklite",
      `Nom : ${payload.full_name?.trim() || user.user_metadata?.full_name || "Non renseigne"}`,
      `Email : ${payload.email?.trim() || user.email || "Non renseigne"}`,
      `Entreprise : ${payload.company_name?.trim() || user.user_metadata?.company_name || "Non renseignee"}`,
      "Validation requise dans Stocklite.",
    ].join("\n");

    const response = await fetch(`https://graph.facebook.com/v20.0/${phoneNumberId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to: recipient,
        type: "text",
        text: { preview_url: false, body: message },
      }),
    });

    if (!response.ok) {
      console.error("WhatsApp provider rejected notification:", await response.text());
      return new Response(JSON.stringify({ sent: false, reason: "WhatsApp a refuse la notification" }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ sent: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err instanceof Error ? translateError(err.message) : "Erreur interne" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
