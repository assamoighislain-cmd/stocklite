import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.47.0";

function translateError(message: string): string {
  if (!message) return "Une erreur est survenue.";
  const map: [RegExp, string][] = [
    [/row-level security/i, "Action non autorisée."],
    [/rate limit/i, "Trop de requêtes. Patientez un instant."],
    [/network|fetch failed/i, "Problème de connexion."],
  ];
  for (const [re, fr] of map) if (re.test(message)) return fr;
  return message;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface PushPayload {
  title: string;
  body: string;
  url?: string;
  company_name?: string;
  target_role?: string;
  target_tenant_id?: string | null;
  target_user_ids?: string[];
}

function base64UrlToUint8Array(base64Url: string): Uint8Array {
  const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
  const pad = "=".repeat((4 - (base64.length % 4)) % 4);
  const raw = atob(base64 + pad);
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return arr;
}

async function importVapidKeys(
  publicKeyBase64: string,
  privateKeyBase64: string
) {
  const publicKeyBytes = base64UrlToUint8Array(publicKeyBase64);
  const privateKeyBytes = base64UrlToUint8Array(privateKeyBase64);

  const publicKey = await crypto.subtle.importKey(
    "raw",
    publicKeyBytes,
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    []
  );

  const privateKey = await crypto.subtle.importKey(
    "pkcs8",
    privateKeyBytes,
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign"]
  );

  return { publicKey, privateKey };
}

function uint8ArrayToBase64Url(arr: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < arr.length; i++) binary += String.fromCharCode(arr[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function createVapidJwt(
  audience: string,
  subject: string,
  privateKey: CryptoKey,
  publicKeyBase64: string
): Promise<string> {
  const header = { typ: "JWT", alg: "ES256" };
  const now = Math.floor(Date.now() / 1000);
  const payload = { aud: audience, exp: now + 12 * 3600, sub: subject };

  const encoder = new TextEncoder();
  const headerB64 = uint8ArrayToBase64Url(
    encoder.encode(JSON.stringify(header))
  );
  const payloadB64 = uint8ArrayToBase64Url(
    encoder.encode(JSON.stringify(payload))
  );
  const unsignedToken = `${headerB64}.${payloadB64}`;

  const signature = await crypto.subtle.sign(
    { name: "ECDSA", hash: "SHA-256" },
    privateKey,
    encoder.encode(unsignedToken)
  );

  const sigBytes = new Uint8Array(signature);
  const r = sigBytes.slice(0, 32);
  const s = sigBytes.slice(32, 64);
  const sigB64 = uint8ArrayToBase64Url(new Uint8Array([...r, ...s]));

  return `${unsignedToken}.${sigB64}`;
}

async function sendWebPush(
  subscription: { endpoint: string; p256dh: string; auth_key: string },
  payloadJson: string,
  vapidPublicKey: string,
  vapidPrivateKey: string,
  vapidSubject: string
): Promise<boolean> {
  try {
    const { publicKey: _pk, privateKey } = await importVapidKeys(
      vapidPublicKey,
      vapidPrivateKey
    );

    const endpointUrl = new URL(subscription.endpoint);
    const audience = `${endpointUrl.protocol}//${endpointUrl.host}`;

    const jwt = await createVapidJwt(
      audience,
      vapidSubject,
      privateKey,
      vapidPublicKey
    );

    const response = await fetch(subscription.endpoint, {
      method: "POST",
      headers: {
        Authorization: `vapid t=${jwt}, k=${vapidPublicKey}`,
        "Content-Type": "application/octet-stream",
        TTL: "86400",
      },
      body: new TextEncoder().encode(payloadJson),
    });

    if (response.status === 410 || response.status === 404) {
      return false;
    }

    return response.ok;
  } catch (err) {
    console.error("Push send failed:", err);
    return false;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const vapidPublicKey = Deno.env.get("VAPID_PUBLIC_KEY");
    const vapidPrivateKey = Deno.env.get("VAPID_PRIVATE_KEY");
    const vapidSubject = Deno.env.get("VAPID_SUBJECT") || "mailto:admin@stocklite.app";

    if (!vapidPublicKey || !vapidPrivateKey) {
      return new Response(
        JSON.stringify({ sent: false, reason: "VAPID keys not configured" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Non autorise" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const callerClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await callerClient.auth.getUser();
    if (!user) {
      return new Response(
        JSON.stringify({ error: "Non autorise" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const payload = (await req.json()) as PushPayload;
    const { title, body, url, target_role, target_tenant_id, target_user_ids, company_name } = payload;

    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    let query = adminClient.from("push_subscriptions").select("endpoint, p256dh, auth_key, user_id");

    if (target_user_ids && target_user_ids.length > 0) {
      query = query.in("user_id", target_user_ids);
    } else if (company_name) {
      // Resolve company name to tenant, then find admin or fallback to super_admins
      const { data: tenant } = await adminClient
        .from("tenants")
        .select("id")
        .ilike("name", company_name.trim())
        .maybeSingle();

      if (tenant) {
        // Existing company -> notify its admin(s)
        const { data: admins } = await adminClient
          .from("user_profiles")
          .select("id")
          .eq("tenant_id", tenant.id)
          .eq("role", "admin")
          .eq("status", "active");
        if (admins && admins.length > 0) {
          query = query.in("user_id", admins.map((a: { id: string }) => a.id));
        } else {
          return new Response(
            JSON.stringify({ sent: 0, total: 0 }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      } else {
        // New company -> notify super_admins
        const { data: superAdmins } = await adminClient
          .from("user_profiles")
          .select("id")
          .eq("role", "super_admin")
          .eq("status", "active");
        if (superAdmins && superAdmins.length > 0) {
          query = query.in("user_id", superAdmins.map((p: { id: string }) => p.id));
        } else {
          return new Response(
            JSON.stringify({ sent: 0, total: 0 }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
    } else if (target_tenant_id) {
      query = query.eq("tenant_id", target_tenant_id);
      if (target_role) {
        const { data: profiles } = await adminClient
          .from("user_profiles")
          .select("id")
          .eq("tenant_id", target_tenant_id)
          .eq("role", target_role);
        if (profiles && profiles.length > 0) {
          query = query.in("user_id", profiles.map((p: { id: string }) => p.id));
        } else {
          return new Response(
            JSON.stringify({ sent: 0, total: 0 }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
    } else if (target_role === "super_admin") {
      const { data: superAdmins } = await adminClient
        .from("user_profiles")
        .select("id")
        .eq("role", "super_admin");
      if (superAdmins && superAdmins.length > 0) {
        query = query.in("user_id", superAdmins.map((p: { id: string }) => p.id));
      } else {
        return new Response(
          JSON.stringify({ sent: 0, total: 0 }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    const { data: subscriptions, error: subErr } = await query;
    if (subErr) throw new Error(translateError(subErr.message));
    if (!subscriptions || subscriptions.length === 0) {
      return new Response(
        JSON.stringify({ sent: 0, total: 0 }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const pushPayload = JSON.stringify({ title, body, url: url || "/" });
    let sentCount = 0;
    const expiredEndpoints: string[] = [];

    for (const sub of subscriptions) {
      const ok = await sendWebPush(sub, pushPayload, vapidPublicKey, vapidPrivateKey, vapidSubject);
      if (ok) {
        sentCount++;
      } else {
        expiredEndpoints.push(sub.endpoint);
      }
    }

    if (expiredEndpoints.length > 0) {
      await adminClient
        .from("push_subscriptions")
        .delete()
        .in("endpoint", expiredEndpoints);
    }

    return new Response(
      JSON.stringify({ sent: sentCount, total: subscriptions.length }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? translateError(err.message) : "Erreur interne" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
