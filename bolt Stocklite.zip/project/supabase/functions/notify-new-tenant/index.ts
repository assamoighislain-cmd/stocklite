import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.47.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function base64UrlToUint8Array(base64Url: string): Uint8Array {
  const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
  const pad = "=".repeat((4 - (base64.length % 4)) % 4);
  const raw = atob(base64 + pad);
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return arr;
}

async function importVapidKeys(publicKeyBase64: string, privateKeyBase64: string) {
  const publicKeyBytes = base64UrlToUint8Array(publicKeyBase64);
  const privateKeyBytes = base64UrlToUint8Array(privateKeyBase64);
  const publicKey = await crypto.subtle.importKey("raw", publicKeyBytes, { name: "ECDSA", namedCurve: "P-256" }, true, []);
  const privateKey = await crypto.subtle.importKey("pkcs8", privateKeyBytes, { name: "ECDSA", namedCurve: "P-256" }, true, ["sign"]);
  return { publicKey, privateKey };
}

function uint8ArrayToBase64Url(arr: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < arr.length; i++) binary += String.fromCharCode(arr[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function createVapidJwt(audience: string, subject: string, privateKey: CryptoKey, publicKeyBase64: string): Promise<string> {
  const header = { typ: "JWT", alg: "ES256" };
  const now = Math.floor(Date.now() / 1000);
  const payload = { aud: audience, exp: now + 12 * 3600, sub: subject };
  const encoder = new TextEncoder();
  const headerB64 = uint8ArrayToBase64Url(encoder.encode(JSON.stringify(header)));
  const payloadB64 = uint8ArrayToBase64Url(encoder.encode(JSON.stringify(payload)));
  const unsignedToken = `${headerB64}.${payloadB64}`;
  const signature = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, privateKey, encoder.encode(unsignedToken));
  const sigBytes = new Uint8Array(signature);
  const r = sigBytes.slice(0, 32);
  const s = sigBytes.slice(32, 64);
  const sigB64 = uint8ArrayToBase64Url(new Uint8Array([...r, ...s]));
  return `${unsignedToken}.${sigB64}`;
}

async function sendWebPush(
  subscription: { endpoint: string; p256dh: string; auth_key: string },
  payloadJson: string,
  vapidPublicKey: string,
  vapidPrivateKey: string,
  vapidSubject: string,
): Promise<boolean> {
  try {
    const { privateKey } = await importVapidKeys(vapidPublicKey, vapidPrivateKey);
    const endpointUrl = new URL(subscription.endpoint);
    const audience = `${endpointUrl.protocol}//${endpointUrl.host}`;
    const jwt = await createVapidJwt(audience, vapidSubject, privateKey, vapidPublicKey);
    const response = await fetch(subscription.endpoint, {
      method: "POST",
      headers: {
        Authorization: `vapid t=${jwt}, k=${vapidPublicKey}`,
        "Content-Type": "application/octet-stream",
        TTL: "86400",
      },
      body: new TextEncoder().encode(payloadJson),
    });
    return response.ok;
  } catch {
    return false;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const vapidPublicKey = Deno.env.get("VAPID_PUBLIC_KEY");
    const vapidPrivateKey = Deno.env.get("VAPID_PRIVATE_KEY");
    const vapidSubject = Deno.env.get("VAPID_SUBJECT") || "mailto:admin@stocklite.app";

    if (!vapidPublicKey || !vapidPrivateKey) {
      return new Response(JSON.stringify({ sent: 0, reason: "VAPID not configured" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { tenant_name, tenant_id } = body as { tenant_name: string; tenant_id: string };

    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    // Insert admin_notifications for all active super_admins
    const { data: superAdmins } = await adminClient
      .from("user_profiles")
      .select("id")
      .eq("role", "super_admin")
      .eq("status", "active");

    if (superAdmins && superAdmins.length > 0) {
      const notifTitle = "Nouvelle entreprise inscrite";
      const notifBody = `L'entreprise "${tenant_name}" vient de s'inscrire sur Stocklite.`;

      // Insert in-app notifications
      await adminClient.from("admin_notifications").insert(
        superAdmins.map((sa: { id: string }) => ({
          type: "new_tenant",
          title: notifTitle,
          body: notifBody,
          tenant_id: tenant_id,
          recipient_user_id: sa.id,
        })),
      );

      // Send push notifications to super_admins who have subscriptions
      const { data: subs } = await adminClient
        .from("push_subscriptions")
        .select("endpoint, p256dh, auth_key")
        .in(
          "user_id",
          superAdmins.map((sa: { id: string }) => sa.id),
        );

      if (subs && subs.length > 0) {
        const pushPayload = JSON.stringify({ title: notifTitle, body: notifBody, url: "/tenants" });
        let sentCount = 0;
        const expired: string[] = [];

        for (const sub of subs) {
          const ok = await sendWebPush(sub, pushPayload, vapidPublicKey, vapidPrivateKey, vapidSubject);
          if (ok) sentCount++;
          else expired.push(sub.endpoint);
        }

        if (expired.length > 0) {
          await adminClient.from("push_subscriptions").delete().in("endpoint", expired);
        }

        return new Response(JSON.stringify({ sent: sentCount, total: subs.length }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    return new Response(JSON.stringify({ sent: 0, total: 0 }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Erreur interne" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
