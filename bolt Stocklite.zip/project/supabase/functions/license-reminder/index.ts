import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.47.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const DAYS_THRESHOLD = 29;

interface TenantRow {
  id: string;
  name: string;
  slug: string;
  license_expires_at: string;
  last_license_reminder_at: string | null;
}

interface SuperAdminRow {
  id: string;
  full_name: string | null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    const thresholdDate = new Date(Date.now() + DAYS_THRESHOLD * 24 * 60 * 60 * 1000).toISOString();

    const { data: tenants, error: tenantErr } = await adminClient
      .from("tenants")
      .select("id, name, slug, license_expires_at, last_license_reminder_at")
      .eq("active", true)
      .not("license_expires_at", "is", null)
      .lte("license_expires_at", thresholdDate)
      .gte("license_expires_at", new Date().toISOString());

    if (tenantErr) throw new Error(tenantErr.message);

    const expiringTenants = (tenants ?? []) as TenantRow[];
    if (expiringTenants.length === 0) {
      return new Response(
        JSON.stringify({ checked: 0, notified: 0, emails: 0 }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: superAdminsData } = await adminClient
      .from("user_profiles")
      .select("id, full_name")
      .eq("role", "super_admin")
      .eq("status", "active");
    const superAdmins = (superAdminsData ?? []) as SuperAdminRow[];

    const superAdminIds = superAdmins.map((s) => s.id);
    const superAdminEmails: string[] = [];
    for (const id of superAdminIds) {
      const { data: userData } = await adminClient.auth.admin.getUserById(id);
      if (userData?.user?.email) {
        superAdminEmails.push(userData.user.email);
      }
    }

    let notifiedCount = 0;
    let emailCount = 0;

    for (const tenant of expiringTenants) {
      const daysLeft = Math.ceil(
        (new Date(tenant.license_expires_at).getTime() - Date.now()) / (24 * 60 * 60 * 1000)
      );
      const expDate = new Date(tenant.license_expires_at).toLocaleDateString("fr-FR", {
        day: "2-digit",
        month: "long",
        year: "numeric",
      });

      const title = `Licence expirant dans ${daysLeft} jour${daysLeft > 1 ? "s" : ""}`;
      const body = `La licence de l'entreprise "${tenant.name}" expire le ${expDate}. Pensez à renouveler.`;

      const { error: notifErr } = await adminClient.from("admin_notifications").insert({
        type: "license_expiring",
        title,
        body,
        tenant_id: tenant.id,
        read: false,
      });
      if (notifErr) {
        console.error(`Failed to insert notification for ${tenant.name}:`, notifErr.message);
      } else {
        notifiedCount++;
      }

      const resendApiKey = Deno.env.get("RESEND_API_KEY");
      if (resendApiKey && superAdminEmails.length > 0) {
        const emailHtml = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px;">
            <h2 style="color: #dc2626; margin-bottom: 16px;">Rappel de renouvellement de licence</h2>
            <p style="font-size: 16px; color: #333; line-height: 1.6;">
              La licence de l'entreprise <strong>${tenant.name}</strong> expire dans
              <strong style="color: #dc2626;">${daysLeft} jour${daysLeft > 1 ? "s" : ""}</strong>,
              le <strong>${expDate}</strong>.
            </p>
            <p style="font-size: 14px; color: #666; margin-top: 24px;">
              Connectez-vous au tableau de bord pour renouveler la licence avant son expiration.
            </p>
          </div>
        `;

        try {
          const res = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${resendApiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              from: "StockLite <noreply@stocklite.app>",
              to: superAdminEmails,
              subject: title,
              html: emailHtml,
            }),
          });
          if (res.ok) {
            emailCount++;
          } else {
            const errText = await res.text();
            console.error("Resend email failed:", errText);
          }
        } catch (err) {
          console.error("Email send error:", err);
        }
      }

      await adminClient
        .from("tenants")
        .update({ last_license_reminder_at: new Date().toISOString() })
        .eq("id", tenant.id);
    }

    return new Response(
      JSON.stringify({
        checked: expiringTenants.length,
        notified: notifiedCount,
        emails: emailCount,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("License reminder error:", err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Erreur interne" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
