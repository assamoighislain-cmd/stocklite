import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

function translateError(message: string): string {
  if (!message) return "Une erreur est survenue.";
  const map: [RegExp, string][] = [
    [/User not found/i, "Utilisateur introuvable."],
    [/row-level security/i, "Action non autorisée."],
    [/rate limit/i, "Trop de requêtes. Patientez un instant."],
    [/network|fetch failed/i, "Problème de connexion."],
  ];
  for (const [re, fr] of map) if (re.test(message)) return fr;
  return message;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userErr } = await supabase.auth.getUser();
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Non authentifié" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { userId } = await req.json();
    if (!userId || typeof userId !== "string") {
      return new Response(JSON.stringify({ error: "userId manquant" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (userId === user.id) {
      return new Response(JSON.stringify({ error: "Vous ne pouvez pas supprimer votre propre compte" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: profile } = await supabase
      .from("user_profiles")
      .select("role, status, tenant_id")
      .eq("id", user.id)
      .maybeSingle();

    if (!profile || !["admin", "super_admin"].includes(profile.role) || profile.status !== "active") {
      return new Response(JSON.stringify({ error: "Accès refusé : administrateur requis" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (profile.role === "admin") {
      const { data: target } = await supabase
        .from("user_profiles")
        .select("tenant_id")
        .eq("id", userId)
        .maybeSingle();
      if (target && target.tenant_id && target.tenant_id !== profile.tenant_id) {
        return new Response(JSON.stringify({ error: "Accès refusé : utilisateur hors de votre entreprise" }), {
          status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Check if the user still exists in auth.users before attempting deletion
    const { data: existingUser, error: lookupErr } = await admin.auth.admin.getUserById(userId);
    if (lookupErr || !existingUser) {
      // User already deleted (e.g. by a previous cascade) — treat as success
      return new Response(JSON.stringify({ success: true, alreadyDeleted: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { error: delErr } = await admin.auth.admin.deleteUser(userId);
    if (delErr) {
      return new Response(JSON.stringify({ error: translateError(delErr.message) }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err instanceof Error ? translateError(err.message) : "Erreur" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
