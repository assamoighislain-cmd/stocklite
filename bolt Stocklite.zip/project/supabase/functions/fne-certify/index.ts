import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

function translateError(message: string): string {
  if (!message) return "Une erreur est survenue.";
  const map: [RegExp, string][] = [
    [/network|fetch failed/i, "Problème de connexion. Vérifiez votre internet."],
    [/rate limit/i, "Trop de requêtes. Patientez un instant."],
  ];
  for (const [re, fr] of map) if (re.test(message)) return fr;
  return message;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const DEFAULT_FNE_BASE_URL = "http://54.247.95.108/ws";
const UPSTREAM_TIMEOUT_MS = 30_000;

interface FneItem {
  reference?: string;
  description: string;
  quantity: number;
  amount: number;
  discount?: number;
  measurementUnit?: string;
  taxes: string[];
  customTaxes?: { name: string; amount: number }[];
}

interface RefundItem {
  id: string;
  quantity: number;
}

interface CertifyRequest {
  settingsId?: string;
  invoiceType: "sale" | "purchase" | "credit-note";
  paymentMethod: "cash" | "card" | "check" | "mobile-money" | "transfer" | "deferred";
  template: "B2B" | "B2C" | "B2G" | "B2F";
  isRne: boolean;
  rne?: string | null;
  clientNcc?: string;
  clientCompanyName: string;
  clientPhone: string;
  clientEmail: string;
  clientSellerName?: string;
  pointOfSale: string;
  establishment: string;
  commercialMessage?: string;
  footer?: string;
  foreignCurrency?: string;
  foreignCurrencyRate?: number;
  items: FneItem[];
  customTaxes?: { name: string; amount: number }[];
  discount?: number;
  mode?: "sign" | "refund";
  originalDgiInvoiceId?: string;
  originalFneReference?: string;
  refundItems?: RefundItem[];
}

async function loadSettings(settingsId?: string) {
  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return null;
  const supabase = createClient(url, serviceKey);
  let query = supabase
    .from("company_settings")
    .select("fne_api_key, fne_api_url, fne_rne, fne_tax_regime");
  if (settingsId) {
    query = query.eq("id", settingsId);
  }
  const { data, error } = await query.limit(1).maybeSingle();
  if (error || !data) return null;
  return {
    apiKey: (data.fne_api_key as string | null)?.trim() || null,
    apiUrl: (data.fne_api_url as string | null)?.trim() || null,
    rne: (data.fne_rne as string | null)?.trim() || null,
    taxRegime: (data.fne_tax_regime as string | null)?.trim() || null,
  };
}

function extractDgiInvoiceId(data: unknown): string | null {
  const obj = (data && typeof data === "object") ? data as Record<string, unknown> : {};
  const invoiceObj = (obj.invoice as Record<string, unknown> | undefined) ?? (obj.data as Record<string, unknown> | undefined)?.invoice ?? (obj.result as Record<string, unknown> | undefined)?.invoice;
  if (invoiceObj && typeof invoiceObj.id === "string") return invoiceObj.id;
  if (typeof obj.id === "string") return obj.id;
  return null;
}

function extractDgiItemIds(data: unknown): Record<string, string> {
  const result: Record<string, string> = {};
  const obj = (data && typeof data === "object") ? data as Record<string, unknown> : {};
  const invoiceObj = (obj.invoice as Record<string, unknown> | undefined) ?? (obj.data as Record<string, unknown> | undefined)?.invoice ?? (obj.result as Record<string, unknown> | undefined)?.invoice ?? obj;
  const items = invoiceObj?.items;
  if (!Array.isArray(items)) return result;
  for (const item of items) {
    if (item && typeof item === "object") {
      const it = item as Record<string, unknown>;
      const id = it.id;
      const reference = it.reference;
      if (typeof id === "string" && typeof reference === "string") {
        result[reference] = id;
      }
    }
  }
  return result;
}

async function fetchDgiInvoiceIdByReference(
  fneBaseUrl: string,
  apiKey: string,
  reference: string,
): Promise<{ dgiInvoiceId: string; dgiItemIds: Record<string, string> } | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);
  try {
    const resp = await fetch(`${fneBaseUrl}/external/invoices/${reference}`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const data = await resp.json().catch(() => null);
    if (!data || typeof data !== "object") return null;
    const dgiInvoiceId = extractDgiInvoiceId(data);
    const dgiItemIds = extractDgiItemIds(data);
    if (!dgiInvoiceId) return null;
    return { dgiInvoiceId, dgiItemIds };
  } catch {
    clearTimeout(timeout);
    return null;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Méthode non autorisée" }), {
        status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json() as CertifyRequest;
    const mode = body.mode ?? "sign";

    const settings = await loadSettings(body.settingsId);
    const apiKey = settings?.apiKey;
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "Clé API FNE non configurée. Ajoutez-la dans Paramètres." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const fneBaseUrl = settings?.apiUrl || DEFAULT_FNE_BASE_URL;

    let endpoint: string;
    let payload: unknown;
    let resolvedDgiInvoiceId: string | null = null;
    let resolvedDgiItemIds: Record<string, string> = {};

    if (mode === "refund") {
      if (!body.refundItems || !Array.isArray(body.refundItems) || body.refundItems.length === 0) {
        return new Response(JSON.stringify({ error: "Aucun article à rembourser." }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      let dgiInvoiceId = body.originalDgiInvoiceId ?? null;

      // Fallback: if no DGI invoice ID stored, try to resolve it via GET by reference
      if (!dgiInvoiceId && body.originalFneReference) {
        const resolved = await fetchDgiInvoiceIdByReference(fneBaseUrl, apiKey, body.originalFneReference);
        if (resolved) {
          dgiInvoiceId = resolved.dgiInvoiceId;
          resolvedDgiItemIds = resolved.dgiItemIds;
        }
      }

      if (!dgiInvoiceId) {
        return new Response(JSON.stringify({
          error: "ID facture DGI original introuvable. La facture originale a été certifiée avant une mise à jour du système. Re-certifiez la facture originale pour récupérer son ID DGI, ou contactez le support.",
        }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // If refund items don't have DGI item IDs, try to resolve them from the GET response
      let refundItems = body.refundItems;
      if (resolvedDgiItemIds && Object.keys(resolvedDgiItemIds).length > 0) {
        // Map by product_id reference if the refund items use product_id as id
        // This handles the case where the frontend sent product_ids instead of DGI item IDs
        refundItems = body.refundItems.map(ri => {
          if (resolvedDgiItemIds[ri.id]) {
            return { id: resolvedDgiItemIds[ri.id], quantity: ri.quantity };
          }
          return ri;
        });
      }

      endpoint = `${fneBaseUrl}/external/invoices/${dgiInvoiceId}/refund`;
      payload = { items: refundItems };
    } else {
      if (!body.items || !Array.isArray(body.items) || body.items.length === 0) {
        return new Response(JSON.stringify({ error: "Aucun article à certifier" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      endpoint = `${fneBaseUrl}/external/invoices/sign`;
      payload = {
        invoiceType: body.invoiceType,
        paymentMethod: body.paymentMethod,
        template: body.template,
        isRne: body.isRne,
        rne: body.rne ?? null,
        clientNcc: body.clientNcc ?? "",
        clientCompanyName: body.clientCompanyName,
        clientPhone: body.clientPhone,
        clientEmail: body.clientEmail,
        clientSellerName: body.clientSellerName ?? null,
        clientRccm: settings?.rne ?? body.rne ?? null,
        clientTaxRegime: settings?.taxRegime ?? null,
        pointOfSale: body.pointOfSale,
        establishment: body.establishment,
        commercialMessage: body.commercialMessage ?? "",
        footer: body.footer ?? null,
        foreignCurrency: body.foreignCurrency ?? "",
        foreignCurrencyRate: body.foreignCurrencyRate ?? 0,
        items: body.items,
        customTaxes: body.customTaxes ?? [],
        discount: body.discount ?? 0,
      };
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);

    let upstream: Response;
    try {
      upstream = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
    } catch (fetchErr) {
      clearTimeout(timeout);
      const msg = fetchErr instanceof DOMException && fetchErr.name === "AbortError"
        ? `La DGI n'a pas répondu dans les délais (${UPSTREAM_TIMEOUT_MS / 1000}s). Réessayez.`
        : "Impossible de joindre l'API DGI. Vérifiez l'URL FNE dans Paramètres.";
      return new Response(JSON.stringify({ error: msg }), {
        status: 504, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    clearTimeout(timeout);

    const text = await upstream.text();
    const ct = upstream.headers.get("content-type") ?? "";
    let data: unknown;
    try { data = JSON.parse(text); }
    catch {
      if (ct.includes("text/html") || text.trimStart().startsWith("<")) {
        return new Response(JSON.stringify({
          error: "L'URL FNE configurée pointe vers une page web, pas l'API DGI. Vérifiez l'URL dans Paramètres (elle doit contenir /ws).",
          details: { contentType: ct, preview: text.slice(0, 200) },
        }), {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      data = { raw: text };
    }

    if (!upstream.ok) {
      const errMsg =
        (data && typeof data === "object" && "message" in data && typeof (data as { message: unknown }).message === "string")
          ? (data as { message: string }).message
          : `Erreur DGI (${upstream.status})`;
      return new Response(JSON.stringify({ error: errMsg, statusCode: upstream.status, details: data }), {
        status: upstream.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Normalize: DGI may return reference/token at top level or nested under data/invoice/result
    const obj = (data && typeof data === "object") ? data as Record<string, unknown> : {};
    const ref = obj.reference ?? (obj.data as Record<string, unknown> | undefined)?.reference ?? (obj.invoice as Record<string, unknown> | undefined)?.reference ?? (obj.result as Record<string, unknown> | undefined)?.reference;
    const tok = obj.token ?? (obj.data as Record<string, unknown> | undefined)?.token ?? (obj.invoice as Record<string, unknown> | undefined)?.token ?? (obj.result as Record<string, unknown> | undefined)?.token;

    if (ref && tok) {
      const dgiInvoiceId = extractDgiInvoiceId(data);
      const dgiItemIds = extractDgiItemIds(data);
      // Extract warning flag and message from DGI response — try many field name variants
      const warnSources = [
        obj, (obj.data as Record<string, unknown> | undefined), (obj.invoice as Record<string, unknown> | undefined), (obj.result as Record<string, unknown> | undefined),
      ].filter(Boolean) as Record<string, unknown>[];
      const warningVal = warnSources.find(s => s.warning !== undefined)?.warning
        ?? warnSources.find(s => s.hasWarning !== undefined)?.hasWarning
        ?? warnSources.find(s => s.isWarning !== undefined)?.isWarning
        ?? warnSources.find(s => s.alert !== undefined)?.alert;
      // The DGI may return warning as a string (the message itself) or a boolean/number
      const warning =
        typeof warningVal === "string"
          ? warningVal.trim().length > 0 && warningVal.trim().toLowerCase() !== "false" && warningVal.trim() !== "0"
          : Boolean(warningVal);
      let warningMessage: string | null = null;
      // If warning is a string, it IS the message
      if (typeof warningVal === "string" && warningVal.trim() && warningVal.trim().toLowerCase() !== "false" && warningVal.trim() !== "0") {
        warningMessage = warningVal.trim();
      }
      const warningMsgVal = warnSources.find(s => typeof s.warningMessage === 'string')?.warningMessage
        ?? warnSources.find(s => typeof s.warning_message === 'string')?.warning_message
        ?? warnSources.find(s => typeof s.message === 'string')?.message
        ?? warnSources.find(s => typeof s.alertMessage === 'string')?.alertMessage
        ?? warnSources.find(s => Array.isArray(s.warnings))?.warnings
        ?? warnSources.find(s => Array.isArray(s.alerts))?.alerts;
      if (!warningMessage) {
        if (typeof warningMsgVal === "string") {
          warningMessage = warningMsgVal;
        } else if (Array.isArray(warningMsgVal) && warningMsgVal.length > 0) {
          warningMessage = warningMsgVal.map(w => typeof w === "string" ? w : (w as Record<string, unknown>)?.message ?? JSON.stringify(w)).join("; ");
        }
      }
      // If warning flag is true but no message found, check balance_funds for the cause
      if (warning && !warningMessage) {
        const balanceFunds = obj.balance_funds;
        if (typeof balanceFunds === "number" && balanceFunds < 0) {
          warningMessage = `Le solde de votre compte FNE est insuffisant (solde actuel : ${balanceFunds} FCFA). Rechargez votre solde sur la plateforme FNE de la DGI pour éviter les avertissements.`;
        } else {
          warningMessage = `Avertissement DGI sans message détaillé. Réponse complète: ${JSON.stringify(obj).slice(0, 500)}`;
        }
      }
      console.log("FNE certify response warning:", { warning, warningVal, warningMessage, rawKeys: Object.keys(obj) });
      const normalized = {
        ...obj,
        reference: String(ref),
        token: String(tok),
        warning,
        ...(warningMessage ? { warningMessage } : {}),
        ...(dgiInvoiceId ? { dgiInvoiceId } : {}),
        ...(Object.keys(dgiItemIds).length > 0 ? { dgiItemIds } : {}),
      };
      return new Response(JSON.stringify(normalized), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({
      error: "Réponse DGI invalide : référence ou token manquant.",
      details: data,
    }), {
      status: 502,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err instanceof Error ? translateError(err.message) : "Erreur interne" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
