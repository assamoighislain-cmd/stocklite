/*
# Remove the 103 products imported today for BES tenant

These were created during the partial import (only 103 of 207 rows succeeded
due to the old per-row insert logic). We delete them and their location_stock
entries so the user can re-import cleanly with the new batch import code.
*/

DELETE FROM location_stock
WHERE product_id IN (
  SELECT id FROM products
  WHERE tenant_id = '891af16f-e055-4658-a447-7c15952df795'
    AND created_at >= '2026-11-05'
);

DELETE FROM products
WHERE tenant_id = '891af16f-e055-4658-a447-7c15952df795'
  AND created_at >= '2026-11-05';
