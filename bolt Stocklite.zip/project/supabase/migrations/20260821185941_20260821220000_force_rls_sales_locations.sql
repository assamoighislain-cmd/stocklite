/*
# Force RLS on sales_locations

## Summary
sales_locations had RLS enabled but not FORCED, meaning the table owner
bypasses policies. This caused users from one tenant to see all locations
regardless of their tenant_id.

## Security
ALTER TABLE sales_locations FORCE ROW LEVEL SECURITY ensures even the
table owner is subject to the RLS policies.
*/

ALTER TABLE sales_locations FORCE ROW LEVEL SECURITY;
