-- Relax products SELECT policy: allow all authenticated users in the same tenant
-- to see the full product catalog. Per-location restrictions are enforced on
-- location_stock (already tenant-scoped). Product catalog rows (name, reference,
-- price) are not location-sensitive — only stock levels are — so hiding products
-- by location causes catalog items to disappear when they have no stock entry
-- for a given depot.

DROP POLICY IF EXISTS products_select_tenant ON products;

CREATE POLICY products_select_tenant ON products FOR SELECT
  TO authenticated
  USING (
    is_super_admin()
    OR tenant_id = get_user_tenant_id()
  );
