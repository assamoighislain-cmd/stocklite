-- product_families
CREATE TABLE IF NOT EXISTS product_families (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL,
  color      text NOT NULL DEFAULT '#6b7280',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- product_categories
CREATE TABLE IF NOT EXISTS product_categories (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id  uuid NOT NULL REFERENCES product_families(id) ON DELETE CASCADE,
  name       text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- link products to categories
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'category_id'
  ) THEN
    ALTER TABLE products ADD COLUMN category_id uuid REFERENCES product_categories(id) ON DELETE SET NULL;
  END IF;
END $$;

-- RLS
ALTER TABLE product_families   ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_categories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_pf" ON product_families;
DROP POLICY IF EXISTS "anon_insert_pf" ON product_families;
DROP POLICY IF EXISTS "anon_update_pf" ON product_families;
DROP POLICY IF EXISTS "anon_delete_pf" ON product_families;
CREATE POLICY "anon_select_pf" ON product_families FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_pf" ON product_families FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_pf" ON product_families FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_pf" ON product_families FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_pc" ON product_categories;
DROP POLICY IF EXISTS "anon_insert_pc" ON product_categories;
DROP POLICY IF EXISTS "anon_update_pc" ON product_categories;
DROP POLICY IF EXISTS "anon_delete_pc" ON product_categories;
CREATE POLICY "anon_select_pc" ON product_categories FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_pc" ON product_categories FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_pc" ON product_categories FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_pc" ON product_categories FOR DELETE TO anon, authenticated USING (true);
