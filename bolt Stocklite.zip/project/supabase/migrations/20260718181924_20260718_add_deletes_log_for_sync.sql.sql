/*
# Add deletes_log table for offline sync deletion propagation

## Purpose
When a record is deleted on the server (by another client or admin), the offline-first
sync engine needs to learn about it so it can remove the row from its local IndexedDB
cache. Previously, the pull phase only fetched rows where `updated_at > last_pull`, which
meant hard-deleted rows were never seen and stayed forever in local caches.

## Changes

1. New table `deletes_log`
   - `id` bigserial primary key — monotonically increasing, used as the pull watermark
   - `table_name` text — which syncable table the delete happened on
   - `record_id` uuid — the id of the deleted row
   - `deleted_at` timestamptz — when the delete occurred (defaults to now())

2. Triggers
   - An AFTER DELETE trigger function `log_delete_trigger()` that inserts into deletes_log.
   - One trigger per syncable table (22 tables total), each calling the shared function.

3. Security (RLS)
   - RLS enabled on deletes_log.
   - Authenticated users can read the log (needed for pull sync).
   - No direct INSERT/UPDATE/DELETE from clients — only the trigger function (SECURITY
     DEFINER) writes to it. This prevents clients from forging delete events.

4. Index
   - Index on `deletes_log(id)` for fast watermark-based pagination (covered by pk).

## Important notes
- The trigger function is SECURITY DEFINER so it can insert into deletes_log even though
  clients cannot.
- Old deletes_log rows can be periodically purged (e.g. delete where deleted_at < now() -
  interval '30 days') once all clients have synced. Not automated here.
- Tables without a uuid `id` column (none in this schema) would need a different approach.
*/

CREATE TABLE IF NOT EXISTS deletes_log (
  id bigserial PRIMARY KEY,
  table_name text NOT NULL,
  record_id uuid NOT NULL,
  deleted_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE deletes_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_deletes_log" ON deletes_log;
CREATE POLICY "read_deletes_log" ON deletes_log FOR SELECT
  TO authenticated USING (true);

-- Trigger function: logs a delete into deletes_log.
-- SECURITY DEFINER so it runs with the table owner's privileges regardless of the
-- calling user's role, allowing INSERT into deletes_log which is otherwise locked.
CREATE OR REPLACE FUNCTION log_delete_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO deletes_log (table_name, record_id)
  VALUES (TG_TABLE_NAME, OLD.id);
  RETURN OLD;
END;
$$;

-- Create AFTER DELETE triggers on every syncable table.
DO $$
DECLARE
  t text;
  trig_name text;
  tables text[] := ARRAY[
    'products','product_families','customers','invoices','invoice_items',
    'payments','stock_movements','pos_sales','pos_sale_items','pos_payments',
    'sales_locations','commerciaux','price_types','product_price_types',
    'stock_transfers','held_carts','company_settings','user_profiles',
    'location_stock','accounting_entries','caisse_closings','caisse_closing_lines'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    trig_name := 'log_delete_' || t;
    EXECUTE format('DROP TRIGGER IF EXISTS %I ON %I;', trig_name, t);
    EXECUTE format('CREATE TRIGGER %I AFTER DELETE ON %I FOR EACH ROW EXECUTE FUNCTION log_delete_trigger();', trig_name, t);
  END LOOP;
END;
$$;
