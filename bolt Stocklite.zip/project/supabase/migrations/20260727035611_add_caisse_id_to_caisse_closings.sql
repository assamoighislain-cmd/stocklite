/*
# Lier les points de caisse à une caisse spécifique

## Objectif
Une caissière peut ouvrir plusieurs caisses dans la même journée. Le point de
caisse (caisse_closings) était jusqu'ici calculé par plage de dates, ce qui
mélangeait les ventes et dépenses de plusieurs caisses ouvertes le même jour.
On ajoute une colonne `caisse_id` à `caisse_closings` pour rattacher chaque
clôture à une caisse précise.

## Modification de tables existantes
### `caisse_closings`
- Ajout de la colonne `caisse_id` (uuid, nullable) référençant `caisses(id)`
  avec `ON DELETE SET NULL`. Nullable pour ne pas casser les clôtures
  existantes (qui restent non rattachées à une caisse).
- Ajout d'un index sur `caisse_id` pour accélérer la recherche des clôtures
  d'une caisse donnée.

## Sécurité (RLS)
- Aucune modification des politiques existantes : `caisse_id` est simplement une
  nouvelle colonne nullable. Les politiques `USING (true)` / `WITH CHECK (true)`
  existantes s'appliquent toujours.
*/

ALTER TABLE caisse_closings
  ADD COLUMN IF NOT EXISTS caisse_id uuid REFERENCES caisses(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_caisse_closings_caisse ON caisse_closings(caisse_id);
