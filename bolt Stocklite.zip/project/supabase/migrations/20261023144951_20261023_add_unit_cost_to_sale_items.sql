/*
# Add unit_cost column to pos_sale_items and invoice_items

1. Purpose
   Freeze the purchase price (coût d'achat) at the moment of sale so that
   later changes to products.purchase_price do NOT retroactively alter the
   cost of goods sold (COGS) for past sales.

2. Changes
   - `pos_sale_items`: add `unit_cost` (numeric, NOT NULL, default 0)
   - `invoice_items`: add `unit_cost` (numeric, NOT NULL, default 0)
   - Backfill existing rows: set unit_cost from the linked product's
     current purchase_price (best available approximation for historical data).

3. Security
   - No new tables. No policy changes needed — existing RLS policies on
     pos_sale_items and invoice_items already cover the new column since
     it is part of the same table.
   - No new grants needed — existing grants cover all columns.
*/

ALTER TABLE pos_sale_items
  ADD COLUMN IF NOT EXISTS unit_cost numeric NOT NULL DEFAULT 0;

ALTER TABLE invoice_items
  ADD COLUMN IF NOT EXISTS unit_cost numeric NOT NULL DEFAULT 0;

-- Backfill from current product purchase_price for rows where unit_cost is still 0
UPDATE pos_sale_items psi
  SET unit_cost = COALESCE(p.purchase_price, 0)
  FROM products p
  WHERE psi.product_id = p.id
    AND psi.unit_cost = 0;

UPDATE invoice_items ii
  SET unit_cost = COALESCE(p.purchase_price, 0)
  FROM products p
  WHERE ii.product_id = p.id
    AND ii.unit_cost = 0;
