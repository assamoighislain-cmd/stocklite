/*
# Fix: is_super_admin() / is_admin() / get_user_tenant_id() RLS recursion

## Problem
user_profiles has FORCED RLS. Its SELECT policy calls is_super_admin(),
which queries user_profiles → RLS policy fires → calls is_super_admin() again
→ infinite recursion. PostgreSQL aborts with "infinite recursion detected in
policy for relation user_profiles".

This breaks every operation that checks is_super_admin() or is_admin(),
including: creating a tenant (INSERT policy on tenants checks is_super_admin()),
reading user_profiles, etc.

## Fix
The security functions must read from user_profiles but bypass RLS.
We use a SECURITY DEFINER function that sets row_security = off locally,
so the internal query is not subject to RLS policies. This is safe because:
1. The function only returns a boolean / uuid — no row data leaks.
2. The function is owned by postgres and has a fixed search_path.
3. Only the role/tenant_id of the calling user is checked.
*/

-- Helper: get the current user's role bypassing RLS
CREATE OR REPLACE FUNCTION public._get_current_user_role()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
DECLARE
  v_role text;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  BEGIN
    SET LOCAL row_security = off;
    SELECT role INTO v_role FROM public.user_profiles WHERE id = auth.uid();
    SET LOCAL row_security = on;
  EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
  END;

  RETURN v_role;
END;
$$;

-- Helper: get the current user's tenant_id bypassing RLS
CREATE OR REPLACE FUNCTION public._get_current_user_tenant_id()
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
DECLARE
  v_tenant_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  BEGIN
    SET LOCAL row_security = off;
    SELECT tenant_id INTO v_tenant_id FROM public.user_profiles WHERE id = auth.uid();
    SET LOCAL row_security = on;
  EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
  END;

  RETURN v_tenant_id;
END;
$$;

-- Rewrite is_super_admin() to use the helper (no recursion)
CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT COALESCE(public._get_current_user_role() = 'super_admin', false)
$$;

-- Rewrite is_admin() to use the helper (no recursion)
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT COALESCE(public._get_current_user_role() IN ('admin', 'super_admin'), false)
$$;

-- Rewrite get_user_tenant_id() to use the helper (no recursion)
CREATE OR REPLACE FUNCTION public.get_user_tenant_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT public._get_current_user_tenant_id()
$$;
