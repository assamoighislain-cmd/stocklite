/*
# Auto-create default sales location "PV 1" on new tenant

1. Purpose
   When a new company (tenant) is created, automatically create a default
   sales location (boutique) named "PV 1" linked to that tenant, so the
   tenant can start using the POS immediately without manual setup.

2. New Objects
   - Function `auto_create_default_sales_location()` — trigger function that
     inserts a row into `sales_locations` with name 'PV 1', active = true,
     and tenant_id = NEW.id.
   - Trigger `on_tenant_created_default_location` — fires AFTER INSERT on
     `tenants`, calls the function above.

3. Security
   - The trigger function runs with SECURITY DEFINER so it can insert into
     `sales_locations` regardless of the caller's role.
   - `search_path` is set to `public` to prevent search-path injection.
   - The insert respects the existing `tenant_id` FK on `sales_locations`.

4. Idempotency
   - Uses `CREATE OR REPLACE FUNCTION`.
   - Trigger uses `DROP TRIGGER IF EXISTS` before creation.
   - The function checks if a location already exists for the tenant before
     inserting, so re-running the migration or manual re-inserts are safe.
*/

CREATE OR REPLACE FUNCTION auto_create_default_sales_location()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only insert if no sales_location exists yet for this tenant
  IF NOT EXISTS (
    SELECT 1 FROM sales_locations WHERE tenant_id = NEW.id
  ) THEN
    INSERT INTO sales_locations (name, active, sort_order, tenant_id)
    VALUES ('PV 1', true, 0, NEW.id);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_tenant_created_default_location ON tenants;
CREATE TRIGGER on_tenant_created_default_location
  AFTER INSERT ON tenants
  FOR EACH ROW
  EXECUTE FUNCTION auto_create_default_sales_location();
