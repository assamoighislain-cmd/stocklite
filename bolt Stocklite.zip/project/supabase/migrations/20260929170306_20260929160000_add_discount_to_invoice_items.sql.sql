/*
# Add per-line discount to invoice_items

1. Modified Tables
- `invoice_items`: add `discount` column (numeric, default 0) — represents a discount amount applied to a single line item.
  This enables per-article remises on invoices. The `total` generated column is updated to `quantity * unit_price - discount`.

2. Important Notes
- The `total` column is a GENERATED ALWAYS column. To change its expression we must drop and recreate it.
- Existing rows get `discount = 0` by default, so current invoices are unchanged.
- No security changes needed — RLS policies on invoice_items remain unchanged.
*/

-- Add discount column
ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS discount numeric(12,2) NOT NULL DEFAULT 0 CHECK (discount >= 0);

-- Replace the generated total column to account for discount
ALTER TABLE invoice_items DROP COLUMN IF EXISTS total;
ALTER TABLE invoice_items ADD COLUMN total numeric(12,2) GENERATED ALWAYS AS (quantity * unit_price - discount) STORED;
