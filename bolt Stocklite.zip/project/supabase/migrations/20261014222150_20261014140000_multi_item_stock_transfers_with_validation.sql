/*
# Multi-item stock transfers with validation step

1. Changes to `stock_transfers`
- Add `status` column (text, default 'en_attente') — values: 'en_attente', 'valide', 'annule'
- Make `product_id` and `quantity` nullable (new multi-item transfers store articles in child table)
- Add `validated_by` (uuid, nullable) and `validated_at` (timestamptz, nullable)

2. New table: `stock_transfer_items`
- `id` uuid PK
- `transfer_id` uuid FK → stock_transfers(id) ON DELETE CASCADE
- `product_id` uuid FK → products(id) ON DELETE SET NULL
- `quantity` numeric NOT NULL
- `created_at` timestamptz default now()
- `tenant_id` uuid default get_user_tenant_id()

3. Security
- Enable RLS on `stock_transfer_items`
- Tenant-scoped CRUD policies (same pattern as stock_transfers)
- Add updated_at trigger for stock_transfer_items
*/

-- Add status column
ALTER TABLE stock_transfers
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'en_attente';

-- Add validation tracking columns
ALTER TABLE stock_transfers
  ADD COLUMN IF NOT EXISTS validated_by uuid,
  ADD COLUMN IF NOT EXISTS validated_at timestamptz;

-- Make product_id and quantity nullable for multi-item transfers
ALTER TABLE stock_transfers
  ALTER COLUMN product_id DROP NOT NULL,
  ALTER COLUMN quantity DROP NOT NULL;

-- Create stock_transfer_items table
CREATE TABLE IF NOT EXISTS stock_transfer_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id uuid NOT NULL REFERENCES stock_transfers(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  quantity numeric NOT NULL,
  tenant_id uuid DEFAULT get_user_tenant_id(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE stock_transfer_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "stock_transfer_items_select_tenant" ON stock_transfer_items;
CREATE POLICY "stock_transfer_items_select_tenant"
ON stock_transfer_items FOR SELECT
TO authenticated USING (is_super_admin() OR (tenant_id = get_user_tenant_id()));

DROP POLICY IF EXISTS "stock_transfer_items_insert_tenant" ON stock_transfer_items;
CREATE POLICY "stock_transfer_items_insert_tenant"
ON stock_transfer_items FOR INSERT
TO authenticated WITH CHECK (is_super_admin() OR (tenant_id = get_user_tenant_id()));

DROP POLICY IF EXISTS "stock_transfer_items_update_tenant" ON stock_transfer_items;
CREATE POLICY "stock_transfer_items_update_tenant"
ON stock_transfer_items FOR UPDATE
TO authenticated USING (is_super_admin() OR (tenant_id = get_user_tenant_id()))
WITH CHECK (is_super_admin() OR (tenant_id = get_user_tenant_id()));

DROP POLICY IF EXISTS "stock_transfer_items_delete_tenant" ON stock_transfer_items;
CREATE POLICY "stock_transfer_items_delete_tenant"
ON stock_transfer_items FOR DELETE
TO authenticated USING (is_super_admin() OR (tenant_id = get_user_tenant_id()));

-- Index for lookup by transfer
CREATE INDEX IF NOT EXISTS idx_stock_transfer_items_transfer_id ON stock_transfer_items(transfer_id);

-- updated_at trigger for stock_transfer_items
CREATE OR REPLACE FUNCTION trg_stock_transfer_items_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.created_at = COALESCE(NEW.created_at, now());
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS stock_transfer_items_set_timestamp ON stock_transfer_items;
CREATE TRIGGER stock_transfer_items_set_timestamp
BEFORE INSERT ON stock_transfer_items
FOR EACH ROW EXECUTE FUNCTION trg_stock_transfer_items_updated_at();
