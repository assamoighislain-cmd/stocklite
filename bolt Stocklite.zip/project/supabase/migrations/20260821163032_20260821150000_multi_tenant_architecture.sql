/*
# Multi-tenant architecture: tenants, subscriptions, tenant_id on all tables

1. New Tables
   - `tenants`
     - `id` (uuid, PK)
     - `name` (text) - company name
     - `slug` (text, unique) - URL-friendly identifier
     - `active` (boolean) - whether tenant is active
     - `license_expires_at` (timestamptz) - license expiration date
     - `created_at` (timestamptz)
   - `subscriptions`
     - `id` (uuid, PK)
     - `tenant_id` (uuid, FK to tenants)
     - `amount` (numeric) - payment amount
     - `currency` (text) - e.g. XOF
     - `payment_method` (text) - e.g. orange_money, wave
     - `payment_reference` (text) - external payment ref
     - `starts_at` (timestamptz)
     - `ends_at` (timestamptz)
     - `status` (text) - pending, active, expired, cancelled
     - `created_at` (timestamptz)

2. Modified Tables
   - `user_profiles` - add `tenant_id` (uuid, nullable FK to tenants)
   - `products` - add `tenant_id`
   - `customers` - add `tenant_id`
   - `invoices` - add `tenant_id`
   - `invoice_items` - add `tenant_id`
   - `payments` - add `tenant_id`
   - `stock_movements` - add `tenant_id`
   - `pos_sales` - add `tenant_id`
   - `pos_sale_items` - add `tenant_id`
   - `company_settings` - add `tenant_id`
   - `product_families` - add `tenant_id`
   - `sales_locations` - add `tenant_id`
   - `location_stock` - add `tenant_id`
   - `commerciaux` - add `tenant_id`
   - `held_carts` - add `tenant_id`
   - `price_types` - add `tenant_id`
   - `stock_transfers` - add `tenant_id`
   - `caisses` - add `tenant_id`
   - `caisse_closings` - add `tenant_id`
   - `accounting_entries` - add `tenant_id`
   - `services` - add `tenant_id`
   - `dotations` - add `tenant_id`
   - `dotation_items` - add `tenant_id`
   - `orders` - add `tenant_id`
   - `order_items` - add `tenant_id`
   - `suppliers` - add `tenant_id`
   - `delivery_notes` - add `tenant_id`
   - `delivery_note_items` - add `tenant_id`
   - `supplier_payments` - add `tenant_id`

3. New Functions
   - `get_user_tenant_id()` - returns the tenant_id for the current authenticated user (SECURITY DEFINER)

4. Security
   - RLS enabled on `tenants` and `subscriptions`
   - Policies: super_admin sees all tenants; regular users see only their own tenant
   - Helper function enables tenant-scoped RLS on all tables

5. Important Notes
   - Existing data gets NULL tenant_id (will be assigned by super_admin)
   - The `super_admin` role is added alongside existing roles
   - The helper function is STABLE + SECURITY DEFINER for efficient RLS evaluation
*/

-- 1. Create tenants table
CREATE TABLE IF NOT EXISTS tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  active boolean NOT NULL DEFAULT true,
  license_expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;

-- 2. Create subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  amount numeric NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'XOF',
  payment_method text NOT NULL DEFAULT 'autre',
  payment_reference text,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- 3. Add tenant_id to all existing tables
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_profiles' AND column_name='tenant_id') THEN
    ALTER TABLE user_profiles ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='products' AND column_name='tenant_id') THEN
    ALTER TABLE products ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='customers' AND column_name='tenant_id') THEN
    ALTER TABLE customers ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='invoices' AND column_name='tenant_id') THEN
    ALTER TABLE invoices ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='invoice_items' AND column_name='tenant_id') THEN
    ALTER TABLE invoice_items ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='payments' AND column_name='tenant_id') THEN
    ALTER TABLE payments ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='stock_movements' AND column_name='tenant_id') THEN
    ALTER TABLE stock_movements ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pos_sales' AND column_name='tenant_id') THEN
    ALTER TABLE pos_sales ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pos_sale_items' AND column_name='tenant_id') THEN
    ALTER TABLE pos_sale_items ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='company_settings' AND column_name='tenant_id') THEN
    ALTER TABLE company_settings ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='product_families' AND column_name='tenant_id') THEN
    ALTER TABLE product_families ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales_locations' AND column_name='tenant_id') THEN
    ALTER TABLE sales_locations ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='location_stock' AND column_name='tenant_id') THEN
    ALTER TABLE location_stock ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='commerciaux' AND column_name='tenant_id') THEN
    ALTER TABLE commerciaux ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='held_carts' AND column_name='tenant_id') THEN
    ALTER TABLE held_carts ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='price_types' AND column_name='tenant_id') THEN
    ALTER TABLE price_types ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='stock_transfers' AND column_name='tenant_id') THEN
    ALTER TABLE stock_transfers ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='caisses' AND column_name='tenant_id') THEN
    ALTER TABLE caisses ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='caisse_closings' AND column_name='tenant_id') THEN
    ALTER TABLE caisse_closings ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='accounting_entries' AND column_name='tenant_id') THEN
    ALTER TABLE accounting_entries ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='services' AND column_name='tenant_id') THEN
    ALTER TABLE services ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='dotations' AND column_name='tenant_id') THEN
    ALTER TABLE dotations ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='dotation_items' AND column_name='tenant_id') THEN
    ALTER TABLE dotation_items ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='tenant_id') THEN
    ALTER TABLE orders ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='order_items' AND column_name='tenant_id') THEN
    ALTER TABLE order_items ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='suppliers' AND column_name='tenant_id') THEN
    ALTER TABLE suppliers ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='delivery_notes' AND column_name='tenant_id') THEN
    ALTER TABLE delivery_notes ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='delivery_note_items' AND column_name='tenant_id') THEN
    ALTER TABLE delivery_note_items ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='supplier_payments' AND column_name='tenant_id') THEN
    ALTER TABLE supplier_payments ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
END $$;

-- 4. Create helper function to get user's tenant
CREATE OR REPLACE FUNCTION get_user_tenant_id() RETURNS uuid AS $$
  SELECT tenant_id FROM user_profiles WHERE id = auth.uid()
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- 5. Create helper function to check super_admin
CREATE OR REPLACE FUNCTION is_super_admin() RETURNS boolean AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'super_admin'
  )
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- 6. Policies for tenants table
DROP POLICY IF EXISTS "super_admin_select_tenants" ON tenants;
CREATE POLICY "super_admin_select_tenants" ON tenants FOR SELECT
  TO authenticated USING (is_super_admin() OR id = get_user_tenant_id());

DROP POLICY IF EXISTS "super_admin_insert_tenants" ON tenants;
CREATE POLICY "super_admin_insert_tenants" ON tenants FOR INSERT
  TO authenticated WITH CHECK (is_super_admin());

DROP POLICY IF EXISTS "super_admin_update_tenants" ON tenants;
CREATE POLICY "super_admin_update_tenants" ON tenants FOR UPDATE
  TO authenticated USING (is_super_admin()) WITH CHECK (is_super_admin());

DROP POLICY IF EXISTS "super_admin_delete_tenants" ON tenants;
CREATE POLICY "super_admin_delete_tenants" ON tenants FOR DELETE
  TO authenticated USING (is_super_admin());

-- 7. Policies for subscriptions table
DROP POLICY IF EXISTS "select_subscriptions" ON subscriptions;
CREATE POLICY "select_subscriptions" ON subscriptions FOR SELECT
  TO authenticated USING (is_super_admin() OR tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "insert_subscriptions" ON subscriptions;
CREATE POLICY "insert_subscriptions" ON subscriptions FOR INSERT
  TO authenticated WITH CHECK (is_super_admin());

DROP POLICY IF EXISTS "update_subscriptions" ON subscriptions;
CREATE POLICY "update_subscriptions" ON subscriptions FOR UPDATE
  TO authenticated USING (is_super_admin()) WITH CHECK (is_super_admin());

DROP POLICY IF EXISTS "delete_subscriptions" ON subscriptions;
CREATE POLICY "delete_subscriptions" ON subscriptions FOR DELETE
  TO authenticated USING (is_super_admin());

-- 8. Indexes for tenant_id on key tables
CREATE INDEX IF NOT EXISTS idx_user_profiles_tenant ON user_profiles(tenant_id);
CREATE INDEX IF NOT EXISTS idx_products_tenant ON products(tenant_id);
CREATE INDEX IF NOT EXISTS idx_customers_tenant ON customers(tenant_id);
CREATE INDEX IF NOT EXISTS idx_invoices_tenant ON invoices(tenant_id);
CREATE INDEX IF NOT EXISTS idx_pos_sales_tenant ON pos_sales(tenant_id);
CREATE INDEX IF NOT EXISTS idx_orders_tenant ON orders(tenant_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_tenant ON stock_movements(tenant_id);
CREATE INDEX IF NOT EXISTS idx_caisses_tenant ON caisses(tenant_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_tenant ON subscriptions(tenant_id);
