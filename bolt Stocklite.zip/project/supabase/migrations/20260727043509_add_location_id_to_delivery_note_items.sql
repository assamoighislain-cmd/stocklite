/*
# Lier les articles du bon de livraison au point de vente

## Objectif
Chaque ligne d'article d'un bon de livraison (delivery_note_items) doit être
explicitement rattachée à un point de vente (sales_locations). Jusqu'ici seul
l'en-tête du bon portait le `location_id` ; on l'ajoute aussi au niveau de la
ligne pour pouvoir cibler le stock par point de vente à la validation.

## Modifications
### `delivery_note_items`
- Ajout de la colonne `location_id` (uuid, nullable, FK vers sales_locations,
  ON DELETE SET NULL) — point de vente de réception de la ligne.
- Index sur `location_id` pour faciliter le filtrage par boutique.

## Sécurité
- Aucune modification de RLS : la table a déjà des politiques CRUD
  `TO authenticated`. La nouvelle colonne est couverte par les politiques
  existantes (USING/WITH CHECK true).
*/

ALTER TABLE delivery_note_items
  ADD COLUMN IF NOT EXISTS location_id UUID REFERENCES sales_locations(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_delivery_note_items_location
  ON delivery_note_items(location_id);
