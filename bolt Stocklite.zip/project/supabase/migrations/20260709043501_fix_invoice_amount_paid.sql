-- Fix invoices marked as paid but with amount_paid = 0
UPDATE invoices
SET amount_paid = total
WHERE status = 'payee' AND amount_paid = 0;
