/*
# Fix: Security functions return NULL, blocking all data access

## Problem
The previous fix used SET LOCAL row_security = off inside SECURITY DEFINER
functions. SET LOCAL only works inside an explicit transaction block, and
the EXCEPTION handler was swallowing errors and returning NULL. This made
is_super_admin() = false and get_user_tenant_id() = NULL for everyone,
so ALL RLS policies blocked ALL access — users see no data.

## Fix
1. Backfill auth.users.raw_user_meta_data with the correct role and
   tenant_id from user_profiles (sync the two).
2. Rewrite security functions to read from auth.users (no RLS, no recursion).
3. Add a trigger to keep auth.users metadata in sync when user_profiles changes.
*/

-- ── 1. Backfill auth.users metadata from user_profiles ──────────
UPDATE auth.users u
SET raw_user_meta_data = u.raw_user_meta_data
  || jsonb_build_object(
    'role', up.role,
    'tenant_id', up.tenant_id::text,
    'full_name', up.full_name
  )
FROM user_profiles up
WHERE up.id = u.id;

-- ── 2. Rewrite security functions to read from auth.users ────────
CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT COALESCE(
    auth.uid() IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM auth.users
      WHERE id = auth.uid()
        AND raw_user_meta_data->>'role' = 'super_admin'
    ),
    false
  )
$$;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT COALESCE(
    auth.uid() IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM auth.users
      WHERE id = auth.uid()
        AND raw_user_meta_data->>'role' IN ('admin', 'super_admin')
    ),
    false
  )
$$;

CREATE OR REPLACE FUNCTION public.get_user_tenant_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT NULLIF(
    (SELECT raw_user_meta_data->>'tenant_id' FROM auth.users WHERE id = auth.uid()),
    ''
  )::uuid
$$;

-- ── 3. Drop the broken helper functions ──────────────────────────
DROP FUNCTION IF EXISTS public._get_current_user_role();
DROP FUNCTION IF EXISTS public._get_current_user_tenant_id();

-- ── 4. Trigger: sync user_profiles changes back to auth.users ────
CREATE OR REPLACE FUNCTION public.sync_user_metadata_to_auth()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.role IS DISTINCT FROM OLD.role
     OR NEW.tenant_id IS DISTINCT FROM OLD.tenant_id
     OR NEW.full_name IS DISTINCT FROM OLD.full_name
  THEN
    UPDATE auth.users
    SET raw_user_meta_data = COALESCE(raw_user_meta_data, '{}'::jsonb)
      || jsonb_build_object(
        'role', NEW.role,
        'tenant_id', NEW.tenant_id::text,
        'full_name', NEW.full_name
      )
    WHERE id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_auth_metadata ON public.user_profiles;
CREATE TRIGGER trg_sync_auth_metadata
  AFTER UPDATE ON public.user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.sync_user_metadata_to_auth();
