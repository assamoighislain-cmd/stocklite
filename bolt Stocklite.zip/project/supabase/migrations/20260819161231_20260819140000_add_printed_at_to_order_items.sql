/*
# Add printed_at column to order_items

## Overview
Allows incremental printing of order items to kitchen/bar printers.
Each order item now has a `printed_at` timestamp. When the user prints
"new items", only items where `printed_at IS NULL` are sent to the
kitchen printers. After printing, those items are marked with the
current timestamp so they are not reprinted on subsequent prints.

## Modified Tables

### order_items
- `printed_at` (timestamptz, nullable) — set to now() when the item
  has been sent to a kitchen printer. NULL means "not yet printed".

## Security
- No policy changes. The existing CRUD policies on order_items already
  allow anon/authenticated to read and update all columns, so the new
  column is accessible without additional policies.

## Notes
1. The column is nullable so existing rows are unaffected (they remain
   NULL = "not yet printed"). The user can print them once, after which
   they are marked as printed.
2. The app's update logic will be changed to a diff-based approach so
   that editing an order no longer deletes and recreates all items
   (which would lose the printed_at state).
*/

ALTER TABLE order_items
  ADD COLUMN IF NOT EXISTS printed_at timestamptz;
