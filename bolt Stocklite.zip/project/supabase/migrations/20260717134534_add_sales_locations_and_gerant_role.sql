-- ── 1. sales_locations ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sales_locations (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL,
  address    text NOT NULL DEFAULT '',
  city       text NOT NULL DEFAULT '',
  phone      text NOT NULL DEFAULT '',
  active     boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sales_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_sl" ON sales_locations;
DROP POLICY IF EXISTS "auth_insert_sl" ON sales_locations;
DROP POLICY IF EXISTS "auth_update_sl" ON sales_locations;
DROP POLICY IF EXISTS "auth_delete_sl" ON sales_locations;
CREATE POLICY "auth_select_sl" ON sales_locations FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_sl" ON sales_locations FOR INSERT TO authenticated WITH CHECK (is_admin());
CREATE POLICY "auth_update_sl" ON sales_locations FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
CREATE POLICY "auth_delete_sl" ON sales_locations FOR DELETE TO authenticated USING (is_admin());

-- ── 2. Add location_id to user_profiles ─────────────────────────
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'location_id'
  ) THEN
    ALTER TABLE user_profiles
      ADD COLUMN location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ── 3. Update role constraint: add 'gerant', keep 'stock' compat ─
ALTER TABLE user_profiles DROP CONSTRAINT IF EXISTS user_profiles_role_check;
ALTER TABLE user_profiles
  ADD CONSTRAINT user_profiles_role_check
  CHECK (role IN ('admin', 'caissier', 'gerant', 'stock'));

-- Migrate existing 'stock' users to 'gerant'
UPDATE user_profiles SET role = 'gerant' WHERE role = 'stock';

-- Now tighten constraint to exclude 'stock'
ALTER TABLE user_profiles DROP CONSTRAINT IF EXISTS user_profiles_role_check;
ALTER TABLE user_profiles
  ADD CONSTRAINT user_profiles_role_check
  CHECK (role IN ('admin', 'caissier', 'gerant'));

-- ── 4. Update trigger to accept 'gerant' ────────────────────────
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role   text;
  v_status text;
  v_name   text;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'caissier');
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', '');

  IF v_role NOT IN ('admin', 'caissier', 'gerant') THEN
    v_role := 'caissier';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM user_profiles LIMIT 1) THEN
    v_role   := 'admin';
    v_status := 'active';
  ELSE
    v_status := 'pending';
  END IF;

  INSERT INTO user_profiles (id, email, full_name, role, status)
  VALUES (NEW.id, NEW.email, v_name, v_role, v_status);

  RETURN NEW;
END;
$$;
