/*
# Create orders and order_items tables

## Overview
Adds a new "Commande" (Order) feature for commerciaux (sales reps).
Orders are similar to invoices but have their own lifecycle:
  - `brouillon` (draft) — created by a commercial
  - `validee` (validated) — approved by admin/gerant
  - `convertie` (converted) — turned into an invoice
  - `annulee` (cancelled)

When an order is validated, it can be converted into an invoice.

## New Tables

### orders
- `id` — uuid primary key
- `order_number` — unique order number (CMD-XXXXX)
- `customer_id` — FK to customers
- `commercial_id` — FK to commerciaux (nullable)
- `location_id` — FK to sales_locations (nullable, for multi-boutique)
- `date` — order date
- `status` — brouillon | validee | convertie | annulee
- `subtotal`, `tax_rate`, `tax_amount`, `total` — computed totals
- `notes` — order notes
- `created_by` — user who created the order (nullable)
- `created_at`, `updated_at` — timestamps

### order_items
- `id` — uuid primary key
- `order_id` — FK to orders (CASCADE)
- `product_id` — FK to products (SET NULL)
- `description` — line description
- `quantity`, `unit_price`, `total` — line amounts
- `sort_order` — display order
- `created_at` — timestamp

## Security
- RLS enabled on both tables.
- Policies grant `anon, authenticated` full CRUD (same pattern as invoices —
  the app uses anon-key access with location-based filtering in the frontend).

## Sync
- `updated_at` column + trigger for incremental sync.
- AFTER DELETE trigger for deletes_log so local caches stay clean.
*/

-- Sequence for order numbers
CREATE SEQUENCE IF NOT EXISTS order_seq START 1;

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL DEFAULT 'CMD-' || LPAD(nextval('order_seq')::text, 5, '0'),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
  commercial_id uuid REFERENCES commerciaux(id) ON DELETE SET NULL,
  location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL,
  date date NOT NULL DEFAULT current_date,
  status text NOT NULL DEFAULT 'brouillon'
    CHECK (status IN ('brouillon','validee','convertie','annulee')),
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  tax_rate numeric(5,2) NOT NULL DEFAULT 0,
  tax_amount numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  notes text NOT NULL DEFAULT '',
  created_by uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,4) NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price numeric(12,2) NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
  total numeric(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_commercial ON orders(commercial_id);
CREATE INDEX IF NOT EXISTS idx_orders_location ON orders(location_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);

-- RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

-- Orders policies
DROP POLICY IF EXISTS "anon_select_orders" ON orders;
CREATE POLICY "anon_select_orders" ON orders FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_orders" ON orders;
CREATE POLICY "anon_insert_orders" ON orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_orders" ON orders;
CREATE POLICY "anon_update_orders" ON orders FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_orders" ON orders;
CREATE POLICY "anon_delete_orders" ON orders FOR DELETE
  TO anon, authenticated USING (true);

-- Order items policies
DROP POLICY IF EXISTS "anon_select_order_items" ON order_items;
CREATE POLICY "anon_select_order_items" ON order_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_order_items" ON order_items;
CREATE POLICY "anon_insert_order_items" ON order_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_order_items" ON order_items;
CREATE POLICY "anon_update_order_items" ON order_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_order_items" ON order_items;
CREATE POLICY "anon_delete_order_items" ON order_items FOR DELETE
  TO anon, authenticated USING (true);

-- Sync triggers: updated_at
DROP TRIGGER IF EXISTS trg_set_updated_at ON orders;
CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_set_updated_at ON order_items;
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON order_items
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Sync triggers: deletes_log
DROP TRIGGER IF EXISTS log_delete_orders ON orders;
CREATE TRIGGER log_delete_orders AFTER DELETE ON orders
  FOR EACH ROW EXECUTE FUNCTION log_delete_trigger();

DROP TRIGGER IF EXISTS log_delete_order_items ON order_items;
CREATE TRIGGER log_delete_order_items AFTER DELETE ON order_items
  FOR EACH ROW EXECUTE FUNCTION log_delete_trigger();
