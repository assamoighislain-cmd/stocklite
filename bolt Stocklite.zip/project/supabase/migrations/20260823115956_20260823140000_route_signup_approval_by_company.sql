/*
# Route new signup approvals by company

1. Purpose
- Capture the company name supplied during public registration.
- Attach a new user to an existing company when the name matches.
- Keep new-company registrations unassigned so a super administrator can review them.
- Create an in-app notification for the appropriate approver.

2. Modified tables
- `admin_notifications`
  - Add `recipient_user_id` to target a company administrator when a matching company exists.
  - Keep it nullable so existing super-admin notifications remain valid.

3. Modified function
- `handle_new_user()` now reads `company_name` from auth metadata.
- Existing company names are matched case-insensitively after trimming whitespace.
- Matching-company users receive the matching `tenant_id` and remain `pending`.
- New-company users remain without a tenant and remain `pending`.
- The first existing profile bootstrap behavior is preserved only when no company name is supplied.
- A notification is created for every new signup: company administrators for a match, otherwise all super administrators.

4. Security
- Company administrators can read and update only notifications addressed to their own user ID.
- Super administrators retain access to all notifications.
- No client-side insert policy is added; the SECURITY DEFINER trigger writes notifications.

5. Important notes
- WhatsApp delivery is intentionally handled by a server-side edge function, not by this database trigger, so provider credentials are never exposed to the browser.
- Existing rows and existing notification behavior are preserved.
*/

ALTER TABLE admin_notifications
  ADD COLUMN IF NOT EXISTS recipient_user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_admin_notifications_recipient
  ON admin_notifications(recipient_user_id, read, created_at DESC);

DROP POLICY IF EXISTS "admin_read_own_notifications" ON admin_notifications;
CREATE POLICY "admin_read_own_notifications"
ON admin_notifications FOR SELECT
TO authenticated
USING (
  recipient_user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
      AND user_profiles.role = 'admin'
      AND user_profiles.status = 'active'
  )
);

DROP POLICY IF EXISTS "admin_update_own_notifications" ON admin_notifications;
CREATE POLICY "admin_update_own_notifications"
ON admin_notifications FOR UPDATE
TO authenticated
USING (
  recipient_user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
      AND user_profiles.role = 'admin'
      AND user_profiles.status = 'active'
  )
)
WITH CHECK (
  recipient_user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
      AND user_profiles.role = 'admin'
      AND user_profiles.status = 'active'
  )
);

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
  v_status text;
  v_name text;
  v_company_name text;
  v_tenant_id uuid;
  v_admin_id uuid;
  v_notification_title text;
  v_notification_body text;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'caissier');
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', '');
  v_company_name := NULLIF(trim(NEW.raw_user_meta_data->>'company_name'), '');

  IF v_role NOT IN ('admin', 'caissier', 'gerant', 'commercial') THEN
    v_role := 'caissier';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM user_profiles LIMIT 1) AND v_company_name IS NULL THEN
    v_role := 'admin';
    v_status := 'active';
  ELSE
    v_status := 'pending';
  END IF;

  IF v_company_name IS NOT NULL THEN
    SELECT id INTO v_tenant_id
    FROM tenants
    WHERE lower(trim(name)) = lower(v_company_name)
    LIMIT 1;
  END IF;

  INSERT INTO user_profiles (id, email, full_name, role, status, tenant_id)
  VALUES (NEW.id, NEW.email, v_name, v_role, v_status, v_tenant_id)
  ON CONFLICT (id) DO UPDATE SET
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    status = EXCLUDED.status,
    tenant_id = EXCLUDED.tenant_id,
    updated_at = now();

  IF v_status = 'pending' THEN
    IF v_tenant_id IS NOT NULL THEN
      SELECT id INTO v_admin_id
      FROM user_profiles
      WHERE tenant_id = v_tenant_id
        AND role = 'admin'
        AND status = 'active'
      ORDER BY created_at ASC
      LIMIT 1;

      v_notification_title := 'Nouvelle demande d’accès';
      v_notification_body := format('%s (%s) demande à rejoindre votre entreprise %s.', COALESCE(v_name, ''), COALESCE(NEW.email, ''), v_company_name);

      IF v_admin_id IS NOT NULL THEN
        INSERT INTO admin_notifications (type, title, body, tenant_id, recipient_user_id)
        VALUES ('signup_request', v_notification_title, v_notification_body, v_tenant_id, v_admin_id);
      END IF;
    ELSE
      v_notification_title := 'Nouvelle inscription à valider';
      v_notification_body := format('%s (%s) demande un compte pour l’entreprise %s.', COALESCE(v_name, ''), COALESCE(NEW.email, ''), COALESCE(v_company_name, 'non renseignée'));

      INSERT INTO admin_notifications (type, title, body)
      SELECT 'signup_request', v_notification_title, v_notification_body
      FROM user_profiles
      WHERE role = 'super_admin'
        AND status = 'active';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;