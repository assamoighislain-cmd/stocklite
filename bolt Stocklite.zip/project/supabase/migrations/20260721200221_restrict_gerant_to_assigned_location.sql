/*
# Restrict gérant role to assigned boutique only

## Summary
Currently all RLS policies use `USING (true)` for authenticated users, meaning a gérant
can read/write data from ANY boutique at the database level. The frontend filters
client-side by activeLocationId, but that is not security-enforced.

This migration tightens RLS so that:
- **admin** users keep full access to all boutiques (unrestricted)
- **gérant** and **caissier** users can only SELECT/INSERT/UPDATE/DELETE rows where
  `location_id` matches their assigned boutique (from `user_profiles.location_id`)
- Shared tables (`products`, `product_families`, `price_types`, `company_settings`,
  `sales_locations`) remain accessible to all authenticated users — they are global
  catalog/config, not boutique-scoped transactional data

## New helper function
- `user_location_id()` — SECURITY DEFINER, returns the caller's `location_id` from
  `user_profiles`. Returns NULL for admins (meaning "no restriction") and for users
  with no assigned location.

## Modified tables (RLS policies replaced)
1. `invoices` — location_id filter
2. `pos_sales` — location_id filter
3. `pos_sale_items` — filtered via parent pos_sales.location_id
4. `pos_payments` — filtered via parent pos_sales.location_id
5. `invoice_items` — filtered via parent invoices.location_id
6. `payments` — filtered via parent invoices.location_id
7. `stock_movements` — location_id filter
8. `location_stock` — location_id filter
9. `location_product_price_types` — location_id filter
10. `customers` — location_id filter (NULL location_id = shared/global customer)
11. `caisses` — location_id filter
12. `caisse_closings` — location_id filter
13. `accounting_entries` — location_id filter
14. `commerciaux` — location_id filter
15. `held_carts` — location_id filter
16. `services` — location_id filter
17. `dotations` — location_id filter

## Security model
- For each table, SELECT uses: `is_admin() OR location_id = user_location_id()`
- INSERT uses: `is_admin() OR location_id = user_location_id()` (WITH CHECK)
- UPDATE uses same predicate for USING and WITH CHECK
- DELETE uses same predicate for USING
- Child tables (pos_sale_items, pos_payments, invoice_items) use EXISTS subquery
  on parent table's location_id
- Customers with NULL location_id are visible to all (global/shared customers)

## Important notes
1. Admins are completely unrestricted — they see all boutiques.
2. A gérant with no assigned location_id sees nothing on scoped tables (fails safe).
3. The frontend already sets location_id on all inserts, so no client changes needed.
4. `products`, `product_families`, `price_types`, `company_settings`,
   `sales_locations` keep `USING (true)` — shared catalog data.
*/

-- ── Helper: user_location_id() ──────────────────────────────────
-- Returns the caller's assigned location_id from user_profiles.
-- Returns NULL for admins (no restriction) or users without assignment.
CREATE OR REPLACE FUNCTION user_location_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT location_id FROM user_profiles WHERE id = auth.uid();
$$;

-- ── 1. invoices ──────────────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_invoices" ON invoices;
CREATE POLICY "auth_select_invoices" ON invoices FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_invoices" ON invoices;
CREATE POLICY "auth_insert_invoices" ON invoices FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_invoices" ON invoices;
CREATE POLICY "auth_update_invoices" ON invoices FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_invoices" ON invoices;
CREATE POLICY "auth_delete_invoices" ON invoices FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 2. pos_sales ─────────────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_pos_sales" ON pos_sales;
CREATE POLICY "auth_select_pos_sales" ON pos_sales FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_pos_sales" ON pos_sales;
CREATE POLICY "auth_insert_pos_sales" ON pos_sales FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_pos_sales" ON pos_sales;
CREATE POLICY "auth_update_pos_sales" ON pos_sales FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_pos_sales" ON pos_sales;
CREATE POLICY "auth_delete_pos_sales" ON pos_sales FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 3. pos_sale_items (via parent pos_sales) ─────────────────────
DROP POLICY IF EXISTS "auth_select_pos_sale_items" ON pos_sale_items;
CREATE POLICY "auth_select_pos_sale_items" ON pos_sale_items FOR SELECT
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_sale_items.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_insert_pos_sale_items" ON pos_sale_items;
CREATE POLICY "auth_insert_pos_sale_items" ON pos_sale_items FOR INSERT
  TO authenticated WITH CHECK (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_sale_items.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_update_pos_sale_items" ON pos_sale_items;
CREATE POLICY "auth_update_pos_sale_items" ON pos_sale_items FOR UPDATE
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_sale_items.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  ) WITH CHECK (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_sale_items.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_delete_pos_sale_items" ON pos_sale_items;
CREATE POLICY "auth_delete_pos_sale_items" ON pos_sale_items FOR DELETE
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_sale_items.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  );

-- ── 4. pos_payments (via parent pos_sales) ───────────────────────
DROP POLICY IF EXISTS "auth_select_pos_payments" ON pos_payments;
CREATE POLICY "auth_select_pos_payments" ON pos_payments FOR SELECT
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_payments.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_insert_pos_payments" ON pos_payments;
CREATE POLICY "auth_insert_pos_payments" ON pos_payments FOR INSERT
  TO authenticated WITH CHECK (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_payments.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_update_pos_payments" ON pos_payments;
CREATE POLICY "auth_update_pos_payments" ON pos_payments FOR UPDATE
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_payments.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  ) WITH CHECK (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_payments.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_delete_pos_payments" ON pos_payments;
CREATE POLICY "auth_delete_pos_payments" ON pos_payments FOR DELETE
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM pos_sales WHERE pos_sales.id = pos_payments.sale_id
      AND pos_sales.location_id = user_location_id()
    )
  );

-- ── 5. invoice_items (via parent invoices) ───────────────────────
DROP POLICY IF EXISTS "auth_select_invoice_items" ON invoice_items;
CREATE POLICY "auth_select_invoice_items" ON invoice_items FOR SELECT
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = invoice_items.invoice_id
      AND invoices.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_insert_invoice_items" ON invoice_items;
CREATE POLICY "auth_insert_invoice_items" ON invoice_items FOR INSERT
  TO authenticated WITH CHECK (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = invoice_items.invoice_id
      AND invoices.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_update_invoice_items" ON invoice_items;
CREATE POLICY "auth_update_invoice_items" ON invoice_items FOR UPDATE
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = invoice_items.invoice_id
      AND invoices.location_id = user_location_id()
    )
  ) WITH CHECK (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = invoice_items.invoice_id
      AND invoices.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_delete_invoice_items" ON invoice_items;
CREATE POLICY "auth_delete_invoice_items" ON invoice_items FOR DELETE
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = invoice_items.invoice_id
      AND invoices.location_id = user_location_id()
    )
  );

-- ── 6. payments (via parent invoices) ─────────────────────────────
DROP POLICY IF EXISTS "auth_select_payments" ON payments;
CREATE POLICY "auth_select_payments" ON payments FOR SELECT
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = payments.invoice_id
      AND invoices.location_id = user_location_id()
    ) OR payments.invoice_id IS NULL
  );

DROP POLICY IF EXISTS "auth_insert_payments" ON payments;
CREATE POLICY "auth_insert_payments" ON payments FOR INSERT
  TO authenticated WITH CHECK (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = payments.invoice_id
      AND invoices.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_update_payments" ON payments;
CREATE POLICY "auth_update_payments" ON payments FOR UPDATE
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = payments.invoice_id
      AND invoices.location_id = user_location_id()
    )
  ) WITH CHECK (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = payments.invoice_id
      AND invoices.location_id = user_location_id()
    )
  );

DROP POLICY IF EXISTS "auth_delete_payments" ON payments;
CREATE POLICY "auth_delete_payments" ON payments FOR DELETE
  TO authenticated USING (
    is_admin() OR EXISTS (
      SELECT 1 FROM invoices WHERE invoices.id = payments.invoice_id
      AND invoices.location_id = user_location_id()
    )
  );

-- ── 7. stock_movements ───────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_stock_movements" ON stock_movements;
CREATE POLICY "auth_select_stock_movements" ON stock_movements FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_stock_movements" ON stock_movements;
CREATE POLICY "auth_insert_stock_movements" ON stock_movements FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_stock_movements" ON stock_movements;
CREATE POLICY "auth_update_stock_movements" ON stock_movements FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_stock_movements" ON stock_movements;
CREATE POLICY "auth_delete_stock_movements" ON stock_movements FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 8. location_stock ───────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_ls" ON location_stock;
CREATE POLICY "auth_select_ls" ON location_stock FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_ls" ON location_stock;
CREATE POLICY "auth_insert_ls" ON location_stock FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_ls" ON location_stock;
CREATE POLICY "auth_update_ls" ON location_stock FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_ls" ON location_stock;
CREATE POLICY "auth_delete_ls" ON location_stock FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 9. location_product_price_types ──────────────────────────────
DROP POLICY IF EXISTS "auth_select_lppt" ON location_product_price_types;
CREATE POLICY "auth_select_lppt" ON location_product_price_types FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_lppt" ON location_product_price_types;
CREATE POLICY "auth_insert_lppt" ON location_product_price_types FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_lppt" ON location_product_price_types;
CREATE POLICY "auth_update_lppt" ON location_product_price_types FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_lppt" ON location_product_price_types;
CREATE POLICY "auth_delete_lppt" ON location_product_price_types FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 10. customers ────────────────────────────────────────────────
-- Customers with NULL location_id are shared/global — visible to all.
DROP POLICY IF EXISTS "auth_select_customers" ON customers;
CREATE POLICY "auth_select_customers" ON customers FOR SELECT
  TO authenticated USING (is_admin() OR location_id IS NULL OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_customers" ON customers;
CREATE POLICY "auth_insert_customers" ON customers FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id IS NULL OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_customers" ON customers;
CREATE POLICY "auth_update_customers" ON customers FOR UPDATE
  TO authenticated USING (is_admin() OR location_id IS NULL OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id IS NULL OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_customers" ON customers;
CREATE POLICY "auth_delete_customers" ON customers FOR DELETE
  TO authenticated USING (is_admin() OR location_id IS NULL OR location_id = user_location_id());

-- ── 11. caisses ──────────────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_caisses" ON caisses;
CREATE POLICY "auth_select_caisses" ON caisses FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_caisses" ON caisses;
CREATE POLICY "auth_insert_caisses" ON caisses FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_caisses" ON caisses;
CREATE POLICY "auth_update_caisses" ON caisses FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_caisses" ON caisses;
CREATE POLICY "auth_delete_caisses" ON caisses FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 12. caisse_closings ───────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_caisse_closings" ON caisse_closings;
CREATE POLICY "auth_select_caisse_closings" ON caisse_closings FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_caisse_closings" ON caisse_closings;
CREATE POLICY "auth_insert_caisse_closings" ON caisse_closings FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_caisse_closings" ON caisse_closings;
CREATE POLICY "auth_update_caisse_closings" ON caisse_closings FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_caisse_closings" ON caisse_closings;
CREATE POLICY "auth_delete_caisse_closings" ON caisse_closings FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 13. accounting_entries ───────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_accounting_entries" ON accounting_entries;
CREATE POLICY "auth_select_accounting_entries" ON accounting_entries FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_accounting_entries" ON accounting_entries;
CREATE POLICY "auth_insert_accounting_entries" ON accounting_entries FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_accounting_entries" ON accounting_entries;
CREATE POLICY "auth_update_accounting_entries" ON accounting_entries FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_accounting_entries" ON accounting_entries;
CREATE POLICY "auth_delete_accounting_entries" ON accounting_entries FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 14. commerciaux ──────────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_commerciaux" ON commerciaux;
CREATE POLICY "auth_select_commerciaux" ON commerciaux FOR SELECT
  TO authenticated USING (is_admin() OR location_id IS NULL OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_commerciaux" ON commerciaux;
CREATE POLICY "auth_insert_commerciaux" ON commerciaux FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id IS NULL OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_commerciaux" ON commerciaux;
CREATE POLICY "auth_update_commerciaux" ON commerciaux FOR UPDATE
  TO authenticated USING (is_admin() OR location_id IS NULL OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id IS NULL OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_commerciaux" ON commerciaux;
CREATE POLICY "auth_delete_commerciaux" ON commerciaux FOR DELETE
  TO authenticated USING (is_admin() OR location_id IS NULL OR location_id = user_location_id());

-- ── 15. held_carts ────────────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_held_carts" ON held_carts;
CREATE POLICY "auth_select_held_carts" ON held_carts FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_held_carts" ON held_carts;
CREATE POLICY "auth_insert_held_carts" ON held_carts FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_held_carts" ON held_carts;
CREATE POLICY "auth_update_held_carts" ON held_carts FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_held_carts" ON held_carts;
CREATE POLICY "auth_delete_held_carts" ON held_carts FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 16. services ─────────────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_services" ON services;
CREATE POLICY "auth_select_services" ON services FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_services" ON services;
CREATE POLICY "auth_insert_services" ON services FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_services" ON services;
CREATE POLICY "auth_update_services" ON services FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_services" ON services;
CREATE POLICY "auth_delete_services" ON services FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());

-- ── 17. dotations ─────────────────────────────────────────────────
DROP POLICY IF EXISTS "auth_select_dotations" ON dotations;
CREATE POLICY "auth_select_dotations" ON dotations FOR SELECT
  TO authenticated USING (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_insert_dotations" ON dotations;
CREATE POLICY "auth_insert_dotations" ON dotations FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_update_dotations" ON dotations;
CREATE POLICY "auth_update_dotations" ON dotations FOR UPDATE
  TO authenticated USING (is_admin() OR location_id = user_location_id())
  WITH CHECK (is_admin() OR location_id = user_location_id());

DROP POLICY IF EXISTS "auth_delete_dotations" ON dotations;
CREATE POLICY "auth_delete_dotations" ON dotations FOR DELETE
  TO authenticated USING (is_admin() OR location_id = user_location_id());