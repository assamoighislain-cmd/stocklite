/*
# Change AIRSI from text to numeric rate + add airsi_amount

1. Modified Tables
- `invoices`: 
  - Changes `airsi` column type from text to numeric (nullable, default 0) — stores the AIRSI rate percentage.
  - Adds `airsi_amount` numeric column (nullable, default 0) — stores the computed AIRSI amount.
2. Security
- No policy changes — columns inherit existing invoices RLS policies.
3. Notes
- Existing `airsi` text values are converted to 0 (they were free-text placeholders, not rates).
- Both columns are nullable so existing invoices remain valid.
*/

DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'airsi') THEN
    ALTER TABLE invoices ALTER COLUMN airsi TYPE numeric(10,2) USING 0;
    ALTER TABLE invoices ALTER COLUMN airsi SET DEFAULT 0;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'airsi_amount') THEN
    ALTER TABLE invoices ADD COLUMN airsi_amount numeric(12,2) DEFAULT 0;
  END IF;
END $$;
