DROP POLICY IF EXISTS location_stock_select_tenant ON location_stock;
CREATE POLICY location_stock_select_tenant ON location_stock
  FOR SELECT TO authenticated
  USING (is_super_admin() OR (tenant_id = get_user_tenant_id()));
