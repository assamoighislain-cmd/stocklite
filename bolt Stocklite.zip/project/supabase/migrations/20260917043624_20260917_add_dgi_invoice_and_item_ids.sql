-- Add columns to store DGI internal IDs for refund/avoir flow
ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS fne_dgi_invoice_id text;
ALTER TABLE public.invoice_items ADD COLUMN IF NOT EXISTS fne_dgi_item_id text;

COMMENT ON COLUMN public.invoices.fne_dgi_invoice_id IS 'DGI internal invoice ID from certification response, used for refund endpoint';
COMMENT ON COLUMN public.invoice_items.fne_dgi_item_id IS 'DGI internal item ID from certification response, used for refund endpoint';
