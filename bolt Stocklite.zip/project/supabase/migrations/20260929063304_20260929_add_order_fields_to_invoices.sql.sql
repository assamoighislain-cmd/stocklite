/*
# Add order-related fields to invoices

1. Modified Tables
- `invoices`
  - `order_number` (text, nullable) — Numéro de commande client
  - `order_advance` (numeric, default 0) — Avance versée à la commande
  - `delivery_delay` (text, nullable) — Délai de livraison (libre: "3 jours", "2 semaines", etc.)
  - `payment_mode` (text, nullable) — Mode de paiement convenu (espèces, virement, chèque, etc.)

2. Notes
- All columns are nullable / have safe defaults so existing invoices are unaffected.
- No RLS changes needed — existing policies cover the new columns automatically.
*/

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'order_number') THEN
    ALTER TABLE invoices ADD COLUMN order_number text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'order_advance') THEN
    ALTER TABLE invoices ADD COLUMN order_advance numeric(14,2) DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'delivery_delay') THEN
    ALTER TABLE invoices ADD COLUMN delivery_delay text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'payment_mode') THEN
    ALTER TABLE invoices ADD COLUMN payment_mode text;
  END IF;
END $$;