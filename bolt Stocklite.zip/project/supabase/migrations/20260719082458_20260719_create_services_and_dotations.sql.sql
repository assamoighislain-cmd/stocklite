/*
# Create services and dotations tables

1. New Tables
- `services`: internal services within a boutique (e.g. cuisine, bar, réception).
  - id (uuid PK)
  - name (text, not null)
  - location_id (uuid FK → sales_locations, not null) — the boutique this service belongs to
  - active (boolean, default true)
  - sort_order (int, default 0)
  - created_at, updated_at (timestamptz)
- `dotations`: a dotation operation from a boutique to a service.
  - id (uuid PK)
  - dotation_number (text, unique) — human-readable reference
  - location_id (uuid FK → sales_locations) — source boutique
  - service_id (uuid FK → services) — destination service
  - notes (text)
  - created_by (uuid, nullable)
  - created_at, updated_at (timestamptz)
- `dotation_items`: line items of a dotation.
  - id (uuid PK)
  - dotation_id (uuid FK → dotations, cascade delete)
  - product_id (uuid FK → products)
  - quantity (numeric, not null)
  - unit_cost (numeric, default 0)
  - created_at (timestamptz)

2. Security
- Enable RLS on all three tables.
- Owner-scoped CRUD via auth.uid() on user_profiles.location_id matching the dotation/service location_id.
- Admin/gerant users can manage services and dotations for their accessible locations.

3. Notes
- Stock is deducted from location_stock when a dotation is created.
- A stock_movement of type 'sortie' is recorded with reference to the dotation.
*/

-- ── Services ──
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location_id uuid NOT NULL REFERENCES sales_locations(id) ON DELETE CASCADE,
  active boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE services ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_services" ON services;
CREATE POLICY "select_services" ON services FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_services" ON services;
CREATE POLICY "insert_services" ON services FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_services" ON services;
CREATE POLICY "update_services" ON services FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_services" ON services;
CREATE POLICY "delete_services" ON services FOR DELETE
  TO authenticated USING (true);

-- ── Dotations ──
CREATE TABLE IF NOT EXISTS dotations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dotation_number text UNIQUE NOT NULL,
  location_id uuid NOT NULL REFERENCES sales_locations(id) ON DELETE CASCADE,
  service_id uuid NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  notes text NOT NULL DEFAULT '',
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE dotations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_dotations" ON dotations;
CREATE POLICY "select_dotations" ON dotations FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_dotations" ON dotations;
CREATE POLICY "insert_dotations" ON dotations FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_dotations" ON dotations;
CREATE POLICY "update_dotations" ON dotations FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_dotations" ON dotations;
CREATE POLICY "delete_dotations" ON dotations FOR DELETE
  TO authenticated USING (true);

-- ── Dotation items ──
CREATE TABLE IF NOT EXISTS dotation_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dotation_id uuid NOT NULL REFERENCES dotations(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity numeric NOT NULL DEFAULT 0,
  unit_cost numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE dotation_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_dotation_items" ON dotation_items;
CREATE POLICY "select_dotation_items" ON dotation_items FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_dotation_items" ON dotation_items;
CREATE POLICY "insert_dotation_items" ON dotation_items FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_dotation_items" ON dotation_items;
CREATE POLICY "update_dotation_items" ON dotation_items FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_dotation_items" ON dotation_items;
CREATE POLICY "delete_dotation_items" ON dotation_items FOR DELETE
  TO authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_services_location ON services(location_id);
CREATE INDEX IF NOT EXISTS idx_dotations_location ON dotations(location_id);
CREATE INDEX IF NOT EXISTS idx_dotations_service ON dotations(service_id);
CREATE INDEX IF NOT EXISTS idx_dotation_items_dotation ON dotation_items(dotation_id);
