/*
# Stocklite — Initial Schema

## Overview
Creates the two core tables for Stocklite: `holdings` (portfolio positions) and `watchlist` (symbols to track).

## Tables

### holdings
Stores each portfolio position the user is tracking.
- `id` — primary key (uuid)
- `symbol` — stock ticker symbol (e.g. AAPL), stored uppercase
- `company_name` — human-readable company name
- `shares` — number of shares held (decimal to support fractional shares)
- `purchase_price` — average cost per share in USD
- `created_at` — timestamp of when the holding was added

### watchlist
Stores symbols the user wants to monitor without owning.
- `id` — primary key (uuid)
- `symbol` — stock ticker symbol, stored uppercase
- `company_name` — human-readable company name
- `created_at` — timestamp

## Security
- RLS enabled on both tables.
- Single-tenant app (no sign-in), so all policies grant `anon, authenticated` full CRUD.
- `USING (true)` is intentional here — the data is device-local, not multi-user.
*/

CREATE TABLE IF NOT EXISTS holdings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol text NOT NULL,
  company_name text NOT NULL DEFAULT '',
  shares numeric(20, 8) NOT NULL CHECK (shares > 0),
  purchase_price numeric(20, 2) NOT NULL CHECK (purchase_price > 0),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS watchlist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol text NOT NULL,
  company_name text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE holdings ENABLE ROW LEVEL SECURITY;
ALTER TABLE watchlist ENABLE ROW LEVEL SECURITY;

-- Holdings policies
DROP POLICY IF EXISTS "anon_select_holdings" ON holdings;
CREATE POLICY "anon_select_holdings" ON holdings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_holdings" ON holdings;
CREATE POLICY "anon_insert_holdings" ON holdings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_holdings" ON holdings;
CREATE POLICY "anon_update_holdings" ON holdings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_holdings" ON holdings;
CREATE POLICY "anon_delete_holdings" ON holdings FOR DELETE
  TO anon, authenticated USING (true);

-- Watchlist policies
DROP POLICY IF EXISTS "anon_select_watchlist" ON watchlist;
CREATE POLICY "anon_select_watchlist" ON watchlist FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_watchlist" ON watchlist;
CREATE POLICY "anon_insert_watchlist" ON watchlist FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_watchlist" ON watchlist;
CREATE POLICY "anon_update_watchlist" ON watchlist FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_watchlist" ON watchlist;
CREATE POLICY "anon_delete_watchlist" ON watchlist FOR DELETE
  TO anon, authenticated USING (true);
