/*
# Add printer_name to product_families

1. Changes
- Add `printer_name` text column to `product_families` (nullable).
  Stores an optional label identifying which physical printer
  should handle receipts for items in this family (e.g. "Cuisine", "Bar").
  When null, items print on the default receipt printer.

2. Security
- No RLS policy changes. Existing policies remain intact.
*/

ALTER TABLE product_families
  ADD COLUMN IF NOT EXISTS printer_name text;
