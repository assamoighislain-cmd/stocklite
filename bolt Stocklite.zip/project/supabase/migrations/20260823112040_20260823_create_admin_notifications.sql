/*
# Create admin_notifications table for license renewal alerts

1. Purpose
   Stores in-app notifications for super admins. When a license payment
   succeeds (via the GeniusPay webhook), a notification row is inserted
   so the super admin sees a badge on the Entreprises page.

2. New Tables
   - `admin_notifications`
     - `id` (uuid, primary key)
     - `type` (text, not null) — 'license_payment' | 'license_expiring' | etc.
     - `title` (text, not null) — short headline
     - `body` (text, nullable) — longer description
     - `tenant_id` (uuid, nullable, references tenants) — related tenant
     - `payment_id` (uuid, nullable, references license_payments) — related payment
     - `read` (boolean, default false) — whether the admin has dismissed it
     - `created_at` (timestamptz, default now())

3. Security
   - RLS enabled.
   - Only super_admins can read notifications.
   - Only the service role (edge functions) can insert — no client INSERT policy.
   - Super admins can mark as read (UPDATE).

4. Notes
   - Index on `read` for efficient unread queries.
*/

CREATE TABLE IF NOT EXISTS admin_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  title text NOT NULL,
  body text,
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  payment_id uuid REFERENCES license_payments(id) ON DELETE CASCADE,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_admin_notifications_read ON admin_notifications(read);
CREATE INDEX IF NOT EXISTS idx_admin_notifications_created_at ON admin_notifications(created_at DESC);

ALTER TABLE admin_notifications ENABLE ROW LEVEL SECURITY;

-- Super admins can read all notifications
DROP POLICY IF EXISTS "super_admin_read_notifications" ON admin_notifications;
CREATE POLICY "super_admin_read_notifications"
ON admin_notifications FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
    AND user_profiles.role = 'super_admin'
  )
);

-- Super admins can mark notifications as read
DROP POLICY IF EXISTS "super_admin_update_notifications" ON admin_notifications;
CREATE POLICY "super_admin_update_notifications"
ON admin_notifications FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
    AND user_profiles.role = 'super_admin'
  )
) WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
    AND user_profiles.role = 'super_admin'
  )
);

-- No INSERT or DELETE from the client; edge functions use the service role key.
