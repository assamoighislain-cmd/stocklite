/*
# Fix sync infrastructure for custom_units and supplier_payments

## Problem
Two syncable tables were missing the infrastructure required by the
incremental sync engine, causing every sync cycle to fail:

1. `custom_units` — missing `updated_at` column AND missing the
   `log_delete` trigger. The sync pull queries `updated_at` with
   `.gt('updated_at', lastPull)` and `.order('updated_at')`, so a
   missing column causes a PostgREST error on every sync.

2. `supplier_payments` — has `updated_at` but is missing the
   `log_delete` trigger, so server-side deletes never propagate to
   local caches.

## Changes

1. Add `updated_at` column to `custom_units` (timestamptz, default now()).
2. Add the `trg_set_updated_at` BEFORE UPDATE trigger to `custom_units`
   so the column is auto-maintained.
3. Add the `log_delete_custom_units` AFTER DELETE trigger to `custom_units`.
4. Add the `log_delete_supplier_payments` AFTER DELETE trigger to
   `supplier_payments`.

## Security
No RLS or policy changes — both tables already have RLS enabled with
existing policies. This migration only adds columns and triggers.

## Notes
- The `set_updated_at()` and `log_delete_trigger()` functions already
  exist from earlier migrations and are reused here.
- All statements are idempotent (IF NOT EXISTS / DROP IF EXISTS).
*/

-- 1. Add updated_at to custom_units
ALTER TABLE custom_units
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

-- 2. Add updated_at trigger to custom_units
DROP TRIGGER IF EXISTS trg_set_updated_at ON custom_units;
CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON custom_units
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- 3. Add delete log trigger to custom_units
DROP TRIGGER IF EXISTS log_delete_custom_units ON custom_units;
CREATE TRIGGER log_delete_custom_units AFTER DELETE ON custom_units
  FOR EACH ROW EXECUTE FUNCTION log_delete_trigger();

-- 4. Add delete log trigger to supplier_payments
DROP TRIGGER IF EXISTS log_delete_supplier_payments ON supplier_payments;
CREATE TRIGGER log_delete_supplier_payments AFTER DELETE ON supplier_payments
  FOR EACH ROW EXECUTE FUNCTION log_delete_trigger();