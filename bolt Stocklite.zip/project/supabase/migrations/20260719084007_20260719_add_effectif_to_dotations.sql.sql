-- Add "effectif" column to dotations table
-- Tracks the number of people in the service at the time of dotation
ALTER TABLE dotations
  ADD COLUMN IF NOT EXISTS effectif integer NOT NULL DEFAULT 0;

COMMENT ON COLUMN dotations.effectif IS 'Nombre de personnes dans le service au moment de la dotation';
