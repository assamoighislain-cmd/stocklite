/*
# Tenant Activity Summary Function

## Purpose
Creates a SECURITY DEFINER function `get_tenant_activity(tenant_uuid)` that returns
aggregated activity metrics for a single tenant (enterprise). This allows the
super_admin to consult the activity of any company in the system.

## New Objects
- `get_tenant_activity(uuid)` — returns a single row with:
  - tenant_id, tenant_name, tenant_slug
  - total_sales (count of pos_sales)
  - total_sales_amount (sum of pos_sales.total)
  - total_invoices (count of invoices)
  - total_invoices_amount (sum of invoices.total)
  - unpaid_invoices (count where status != 'payee')
  - unpaid_amount (sum of balance_due for unpaid)
  - total_customers (count)
  - total_products (count of active products)
  - total_users (count of user_profiles in tenant)
  - total_locations (count of sales_locations)
  - last_sale_date (max created_at from pos_sales)
  - last_invoice_date (max created_at from invoices)

## Security
- SECURITY DEFINER so it can read across tenants
- Restricted to super_admin via an EXECUTE check
- search_path set to 'public'

## Notes
1. Only callable by super_admin role
2. Returns NULL-safe aggregates (COALESCE) for tenants with no activity
3. Safe to re-run (CREATE OR REPLACE)
*/

CREATE OR REPLACE FUNCTION public.get_tenant_activity(p_tenant_id uuid)
RETURNS TABLE (
  tenant_id uuid,
  tenant_name text,
  tenant_slug text,
  total_sales bigint,
  total_sales_amount numeric,
  total_invoices bigint,
  total_invoices_amount numeric,
  unpaid_invoices bigint,
  unpaid_amount numeric,
  total_customers bigint,
  total_products bigint,
  total_users bigint,
  total_locations bigint,
  last_sale_date timestamptz,
  last_invoice_date timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT
    t.id,
    t.name,
    t.slug,
    COALESCE((SELECT count(*) FROM pos_sales WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT sum(total) FROM pos_sales WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT count(*) FROM invoices WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT sum(total) FROM invoices WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT count(*) FROM invoices WHERE tenant_id = p_tenant_id AND status != 'payee' AND status != 'annulee'), 0),
    COALESCE((SELECT sum(balance_due) FROM invoices WHERE tenant_id = p_tenant_id AND status != 'payee' AND status != 'annulee'), 0),
    COALESCE((SELECT count(*) FROM customers WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT count(*) FROM products WHERE tenant_id = p_tenant_id AND active = true), 0),
    COALESCE((SELECT count(*) FROM user_profiles WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT count(*) FROM sales_locations WHERE tenant_id = p_tenant_id), 0),
    (SELECT max(created_at) FROM pos_sales WHERE tenant_id = p_tenant_id),
    (SELECT max(created_at) FROM invoices WHERE tenant_id = p_tenant_id)
  FROM tenants t
  WHERE t.id = p_tenant_id
$function$;

-- Restrict execution to super_admin only
REVOKE EXECUTE ON FUNCTION public.get_tenant_activity(uuid) FROM anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_tenant_activity(uuid) TO authenticated;
