/*
# Create customer_contacts table

1. New Tables
- `customer_contacts` — stores multiple contact persons (interlocuteurs) for a customer, especially for enterprise customers.
  - `id` (uuid PK)
  - `customer_id` (uuid FK → customers, CASCADE on delete)
  - `name` (text, not null) — contact person full name
  - `title` (text, nullable) — job title / function (e.g. "Directeur Achats")
  - `phone` (text, default '')
  - `email` (text, default '')
  - `is_default` (boolean, default false) — marks the primary contact
  - `notes` (text, default '')
  - `tenant_id` (uuid, default get_user_tenant_id())
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

2. Security
- Enable RLS on `customer_contacts`.
- Tenant-scoped CRUD: all four verbs restricted to same-tenant authenticated users.
- Index on `customer_id` for efficient lookups.
*/

CREATE TABLE IF NOT EXISTS customer_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  name text NOT NULL,
  title text,
  phone text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  is_default boolean NOT NULL DEFAULT false,
  notes text NOT NULL DEFAULT '',
  tenant_id uuid DEFAULT get_user_tenant_id(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_customer_contacts_customer_id ON customer_contacts(customer_id);

ALTER TABLE customer_contacts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "customer_contacts_select_tenant" ON customer_contacts;
CREATE POLICY customer_contacts_select_tenant ON customer_contacts FOR SELECT
  TO authenticated
  USING (is_super_admin() OR (tenant_id = get_user_tenant_id()));

DROP POLICY IF EXISTS "customer_contacts_insert_tenant" ON customer_contacts;
CREATE POLICY customer_contacts_insert_tenant ON customer_contacts FOR INSERT
  TO authenticated
  WITH CHECK (is_super_admin() OR (tenant_id = get_user_tenant_id()));

DROP POLICY IF EXISTS "customer_contacts_update_tenant" ON customer_contacts;
CREATE POLICY customer_contacts_update_tenant ON customer_contacts FOR UPDATE
  TO authenticated
  USING (is_super_admin() OR (tenant_id = get_user_tenant_id()))
  WITH CHECK (is_super_admin() OR (tenant_id = get_user_tenant_id()));

DROP POLICY IF EXISTS "customer_contacts_delete_tenant" ON customer_contacts;
CREATE POLICY customer_contacts_delete_tenant ON customer_contacts FOR DELETE
  TO authenticated
  USING (is_super_admin() OR (tenant_id = get_user_tenant_id()));