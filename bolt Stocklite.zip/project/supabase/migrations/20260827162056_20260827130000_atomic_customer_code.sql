-- Generate customer codes atomically using a Postgres sequence.
-- Fixes race condition where concurrent inserts produced duplicate codes.

CREATE SEQUENCE IF NOT EXISTS customer_code_seq;

-- Sync the sequence with the highest existing code number
DO $$
DECLARE
  max_num int;
BEGIN
  SELECT COALESCE(MAX(CAST(SUBSTRING(code FROM 5) AS int)), 0)
  INTO max_num
  FROM customers
  WHERE code ~ '^CLI-\d+$';
  PERFORM setval('customer_code_seq', GREATEST(max_num, 0));
END $$;

CREATE OR REPLACE FUNCTION next_customer_code()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 'CLI-' || lpad(nextval('customer_code_seq')::text, 4, '0');
$$;

GRANT EXECUTE ON FUNCTION next_customer_code() TO authenticated, anon;