/*
# Allow commercial role to access all locations

## Problem
The function `user_can_access_all_locations()` only returns true for `admin` role
or when the tenant has `access_all_locations = true`. The `commercial` role is
excluded, which means:

1. A commercial without an assigned location sees zero products (the RLS policy
   on `products` requires `EXISTS (location_stock WHERE location_id = user_location_id())`
   but `user_location_id()` returns NULL).
2. A commercial with an assigned location can only see products in that specific
   location, not the full tenant catalog — even though they need to create orders
   and invoices with any product.

## Fix
Add the `commercial` role to the `user_can_access_all_locations()` function so
that commercials can see all products within their tenant, regardless of
location assignment. This matches the existing UI behavior where commercials
already have access to the Articles page.

## Security
No new tables or columns. The function remains SECURITY DEFINER. Commercials
are still scoped to their own tenant via `get_user_tenant_id()` in all RLS
policies — they cannot see data from other tenants. The change only lifts the
per-location restriction for the commercial role.
*/

CREATE OR REPLACE FUNCTION public.user_can_access_all_locations()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    is_super_admin()
    OR EXISTS (
      SELECT 1
      FROM user_profiles up
      JOIN tenants t ON t.id = up.tenant_id
      WHERE up.id = auth.uid()
      AND up.role IN ('admin', 'commercial')
    )
    OR EXISTS (
      SELECT 1
      FROM user_profiles up
      JOIN tenants t ON t.id = up.tenant_id
      WHERE up.id = auth.uid()
      AND t.access_all_locations = true
    ),
    false
  )
$$;