-- Revoke public execute on internal helper functions
REVOKE EXECUTE ON FUNCTION public._get_current_user_role() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public._get_current_user_tenant_id() FROM anon, authenticated;
