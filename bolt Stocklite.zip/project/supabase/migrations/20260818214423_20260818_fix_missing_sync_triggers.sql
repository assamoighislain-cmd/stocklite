-- Fix sync triggers missing on 8 tables that were added after the initial
-- trigger-creation migrations. Without these:
--   1. updated_at never changes on UPDATE → incremental pull never sees the row again
--   2. no AFTER DELETE trigger → deletes_log never records the deletion →
--      local caches keep the ghost row forever

-- 1. Add updated_at column where missing
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE delivery_note_items ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

-- 2. Ensure the set_updated_at trigger exists on all 8 tables
-- (the function already exists from the earlier migration)
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'caisses','delivery_note_items','delivery_notes','dotation_items',
    'dotations','location_product_price_types','services','suppliers'
  ])
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_set_updated_at ON public.%I;', t);
    EXECUTE format('CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION set_updated_at();', t);
  END LOOP;
END $$;

-- 3. Add AFTER DELETE triggers for deletes_log on all 8 tables
-- The log_delete_trigger() function already exists (SECURITY DEFINER).
DO $$
DECLARE t text;
  trig_name text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'caisses','delivery_note_items','delivery_notes','dotation_items',
    'dotations','location_product_price_types','services','suppliers'
  ])
  LOOP
    trig_name := 'log_delete_' || t;
    EXECUTE format('DROP TRIGGER IF EXISTS %I ON %I;', trig_name, t);
    EXECUTE format('CREATE TRIGGER %I AFTER DELETE ON %I FOR EACH ROW EXECUTE FUNCTION log_delete_trigger();', trig_name, t);
  END LOOP;
END $$;

-- 4. Fix deletes_log.record_id type: it is currently uuid, but location_stock
-- and location_product_price_types use text IDs. Cast in the trigger function
-- so text-ID tables don't crash on delete.
CREATE OR REPLACE FUNCTION log_delete_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO deletes_log (table_name, record_id)
  VALUES (TG_TABLE_NAME, OLD.id::text::uuid);
  RETURN OLD;
END;
$$;
