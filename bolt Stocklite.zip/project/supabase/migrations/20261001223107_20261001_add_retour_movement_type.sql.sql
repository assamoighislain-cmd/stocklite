/*
# Add 'retour' movement type to stock_movements

1. Changes
- Alter the CHECK constraint on stock_movements.type to include 'retour'
- This allows recording stock returns from POS sales and invoices
2. Security
- No RLS changes — existing tenant-scoped policies already cover all movement types
*/

ALTER TABLE stock_movements DROP CONSTRAINT IF EXISTS stock_movements_type_check;
ALTER TABLE stock_movements ADD CONSTRAINT stock_movements_type_check
  CHECK (type IN ('entree','sortie','ajustement','vente','retour'));
