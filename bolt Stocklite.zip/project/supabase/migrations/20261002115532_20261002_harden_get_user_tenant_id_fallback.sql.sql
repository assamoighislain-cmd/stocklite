/*
# Harden get_user_tenant_id with user_profiles fallback

## Problem
The function `get_user_tenant_id()` reads tenant_id exclusively from `auth.users.raw_user_meta_data`.
When a user is created without the tenant_id metadata being set (observed for 3 caissier users in
the BES tenant and 1 in agasoft), the function returns NULL, causing all RLS policies that depend
on it to match zero rows — the user sees no products, no invoices, no data at all.

## Fix
Update `get_user_tenant_id()` to fall back to `user_profiles.tenant_id` when the auth metadata
is missing or empty. This makes the function resilient to incomplete auth metadata and prevents
the "no data visible" bug from recurring for any user.

## Security
No policy changes. No new tables or columns. The function already had SECURITY DEFINER scope;
the fallback reads from `user_profiles` which is already protected by RLS and only accessible
to the user themselves. No new attack surface is introduced.
*/

CREATE OR REPLACE FUNCTION public.get_user_tenant_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    NULLIF(
      (SELECT raw_user_meta_data->>'tenant_id' FROM auth.users WHERE id = auth.uid()),
      ''
    )::uuid,
    (SELECT tenant_id FROM user_profiles WHERE id = auth.uid())
  )
$$;