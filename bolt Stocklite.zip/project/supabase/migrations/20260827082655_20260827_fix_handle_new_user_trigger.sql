/*
# Fix handle_new_user trigger

## Problem
The handle_new_user() trigger was overwritten by the controleur role migration
(20260826101007) with a simplified version that:
1. Lost the signup-routing-by-company logic from 20260823115956.
2. Declares v_tenant_id as text but inserts into a uuid column — works when
   NULL but fails when a tenant_id value is present (text→uuid cast error),
   causing "Database error creating new user" from the auth API.
3. Lost notification creation for signup approvals.

## Fix
Restore the full trigger with:
- Proper uuid cast for tenant_id.
- controleur included in role validation.
- Company-name routing and admin/super_admin notifications.
- ON CONFLICT DO UPDATE so re-triggers (e.g. retried createUser) update
  the existing profile instead of silently doing nothing.
*/

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role          text;
  v_status        text;
  v_name          text;
  v_company_name  text;
  v_tenant_id     uuid;
  v_admin_id      uuid;
  v_notif_title   text;
  v_notif_body    text;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'caissier');
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', '');
  v_company_name := NULLIF(trim(NEW.raw_user_meta_data->>'company_name'), '');

  IF v_role NOT IN ('admin', 'caissier', 'gerant', 'commercial', 'controleur') THEN
    v_role := 'caissier';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM user_profiles LIMIT 1) AND v_company_name IS NULL THEN
    v_role := 'admin';
    v_status := 'active';
  ELSE
    v_status := 'pending';
  END IF;

  IF v_company_name IS NOT NULL THEN
    SELECT id INTO v_tenant_id
    FROM tenants
    WHERE lower(trim(name)) = lower(v_company_name)
    LIMIT 1;
  END IF;

  INSERT INTO user_profiles (id, email, full_name, role, status, tenant_id)
  VALUES (NEW.id, NEW.email, v_name, v_role, v_status, v_tenant_id)
  ON CONFLICT (id) DO UPDATE SET
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    status = EXCLUDED.status,
    tenant_id = EXCLUDED.tenant_id,
    updated_at = now();

  IF v_status = 'pending' THEN
    IF v_tenant_id IS NOT NULL THEN
      SELECT id INTO v_admin_id
      FROM user_profiles
      WHERE tenant_id = v_tenant_id
        AND role = 'admin'
        AND status = 'active'
      ORDER BY created_at ASC
      LIMIT 1;

      v_notif_title := 'Nouvelle demande d''accès';
      v_notif_body := format('%s (%s) demande à rejoindre votre entreprise %s.', COALESCE(v_name, ''), COALESCE(NEW.email, ''), v_company_name);

      IF v_admin_id IS NOT NULL THEN
        INSERT INTO admin_notifications (type, title, body, tenant_id, recipient_user_id)
        VALUES ('signup_request', v_notif_title, v_notif_body, v_tenant_id, v_admin_id);
      END IF;
    ELSE
      v_notif_title := 'Nouvelle inscription à valider';
      v_notif_body := format('%s (%s) demande un compte pour l''entreprise %s.', COALESCE(v_name, ''), COALESCE(NEW.email, ''), COALESCE(v_company_name, 'non renseignée'));

      INSERT INTO admin_notifications (type, title, body)
      SELECT 'signup_request', v_notif_title, v_notif_body
      FROM user_profiles
      WHERE role = 'super_admin'
        AND status = 'active';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;
