-- Add updated_at to all synced tables for incremental pull sync
-- Uses a single trigger function applied to each table

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END $$;

DO $$
DECLARE t text;
BEGIN
  FOR t IN
    SELECT table_name FROM information_schema.tables
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
    AND table_name NOT IN ('location_stock') -- already has updated_at
  LOOP
    BEGIN
      EXECUTE format('ALTER TABLE public.%I ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();', t);
      EXECUTE format('DROP TRIGGER IF EXISTS trg_set_updated_at ON public.%I;', t);
      EXECUTE format('CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION set_updated_at();', t);
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
END $$;

-- Ensure location_stock also has the trigger
DROP TRIGGER IF EXISTS trg_set_updated_at ON location_stock;
CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON location_stock
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();