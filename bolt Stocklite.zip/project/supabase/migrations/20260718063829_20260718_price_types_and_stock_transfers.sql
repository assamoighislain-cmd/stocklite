/*
# Types de prix multiples + Transferts de stock inter-boutiques

## Description
Deux nouvelles fonctionnalités :
1. **Types de prix** : chaque article peut avoir plusieurs tarifs nommés (ex : Détail, Gros, Demi-gros).
   Le caissier choisit le type de prix au moment de la vente en caisse.
2. **Transferts de stock** : permet de déplacer une quantité d'un article d'une boutique vers une autre,
   avec traçabilité complète (historique des transferts).

## Nouvelles tables

### 1. `price_types`
Définit les types de prix disponibles dans l'application.
- `id` : identifiant unique
- `name` : libellé du type (ex : "Détail", "Gros")
- `color` : couleur hexadécimale pour l'affichage UI
- `sort_order` : ordre d'affichage
- `active` : actif/inactif
- `is_default` : marque le type de prix par défaut (un seul à la fois)
- `created_at` : date de création

### 2. `product_price_types`
Associe un prix spécifique à chaque couple (article, type de prix).
- `id` : identifiant unique
- `product_id` : article concerné (FK → products)
- `price_type_id` : type de prix (FK → price_types)
- `price` : montant pour ce type de prix
- `created_at` : date de création
- Contrainte UNIQUE sur (product_id, price_type_id) : un seul prix par article/type

### 3. `stock_transfers`
Enregistre chaque transfert de stock entre boutiques.
- `id` : identifiant unique
- `product_id` : article transféré (FK → products)
- `from_location_id` : boutique source (FK → sales_locations)
- `to_location_id` : boutique destination (FK → sales_locations)
- `quantity` : quantité transférée (> 0)
- `notes` : remarques libres
- `created_by` : utilisateur ayant effectué le transfert (FK → auth.users)
- `created_at` : date/heure du transfert

## Sécurité
- RLS activé sur toutes les tables.
- Tous les utilisateurs authentifiés peuvent lire, créer, modifier et supprimer (contexte multi-utilisateurs mais données partagées).

## Notes importantes
- Les transferts sont des écritures comptables immuables — la suppression est autorisée en RLS mais doit être réservée aux admins côté application.
- `product_price_types.price` peut être 0 (article offert dans ce canal) mais pas NULL.
*/

-- ── price_types ──────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS price_types (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL,
  color      text NOT NULL DEFAULT '#3b82f6',
  sort_order integer NOT NULL DEFAULT 0,
  active     boolean NOT NULL DEFAULT true,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE price_types ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "pt_select" ON price_types;
CREATE POLICY "pt_select" ON price_types FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "pt_insert" ON price_types;
CREATE POLICY "pt_insert" ON price_types FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "pt_update" ON price_types;
CREATE POLICY "pt_update" ON price_types FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "pt_delete" ON price_types;
CREATE POLICY "pt_delete" ON price_types FOR DELETE TO authenticated USING (true);

-- ── product_price_types ───────────────────────────────────────────

CREATE TABLE IF NOT EXISTS product_price_types (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id    uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  price_type_id uuid NOT NULL REFERENCES price_types(id) ON DELETE CASCADE,
  price         numeric(12,2) NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE(product_id, price_type_id)
);

ALTER TABLE product_price_types ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ppt_select" ON product_price_types;
CREATE POLICY "ppt_select" ON product_price_types FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "ppt_insert" ON product_price_types;
CREATE POLICY "ppt_insert" ON product_price_types FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "ppt_update" ON product_price_types;
CREATE POLICY "ppt_update" ON product_price_types FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "ppt_delete" ON product_price_types;
CREATE POLICY "ppt_delete" ON product_price_types FOR DELETE TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_ppt_product ON product_price_types(product_id);
CREATE INDEX IF NOT EXISTS idx_ppt_type    ON product_price_types(price_type_id);

-- ── stock_transfers ───────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS stock_transfers (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id       uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  from_location_id uuid NOT NULL REFERENCES sales_locations(id) ON DELETE RESTRICT,
  to_location_id   uuid NOT NULL REFERENCES sales_locations(id) ON DELETE RESTRICT,
  quantity         numeric(12,4) NOT NULL CHECK (quantity > 0),
  notes            text NOT NULL DEFAULT '',
  created_by       uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid(),
  created_at       timestamptz NOT NULL DEFAULT now(),
  CHECK (from_location_id <> to_location_id)
);

ALTER TABLE stock_transfers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "st_select" ON stock_transfers;
CREATE POLICY "st_select" ON stock_transfers FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "st_insert" ON stock_transfers;
CREATE POLICY "st_insert" ON stock_transfers FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "st_update" ON stock_transfers;
CREATE POLICY "st_update" ON stock_transfers FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "st_delete" ON stock_transfers;
CREATE POLICY "st_delete" ON stock_transfers FOR DELETE TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_st_product  ON stock_transfers(product_id);
CREATE INDEX IF NOT EXISTS idx_st_from_loc ON stock_transfers(from_location_id);
CREATE INDEX IF NOT EXISTS idx_st_to_loc   ON stock_transfers(to_location_id);
CREATE INDEX IF NOT EXISTS idx_st_date     ON stock_transfers(created_at);
