-- ── 1. Clients par boutique ──────────────────────────────────────
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name='customers' AND column_name='location_id'
  ) THEN
    ALTER TABLE customers ADD COLUMN location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_customers_location ON customers(location_id);

-- ── 2. Prix de vente par boutique ────────────────────────────────
-- NULL = utiliser le prix global du produit
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name='location_stock' AND column_name='price'
  ) THEN
    ALTER TABLE location_stock ADD COLUMN price numeric(12,4) DEFAULT NULL;
  END IF;
END $$;
