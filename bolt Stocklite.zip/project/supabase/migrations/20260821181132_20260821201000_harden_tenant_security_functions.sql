/*
# Harden tenant security helper functions

## Summary
Set an explicit search path on authorization helper functions so their database
lookups cannot be redirected by a mutable session search path.

## Modified functions
- `get_user_tenant_id()` resolves profile data from `public` only.
- `is_super_admin()` resolves profile data from `public` only.
- `is_admin()` resolves profile data from `public` only.
- `user_location_id()` resolves profile data from `public` only.

## Security
These functions are used by row-level security policies and remain
SECURITY DEFINER where already configured. Their behavior is unchanged; only
the lookup path is fixed to prevent search-path manipulation.
*/

ALTER FUNCTION public.get_user_tenant_id() SET search_path = public;
ALTER FUNCTION public.is_super_admin() SET search_path = public;
ALTER FUNCTION public.is_admin() SET search_path = public;
ALTER FUNCTION public.user_location_id() SET search_path = public;
