/*
# Add global discount (remise) to invoices

1. Modified Tables
   - `invoices`
     - `remise` (numeric, default 0) — global discount amount applied to the invoice total

2. Notes
   - The remise is stored as an absolute amount (not a percentage).
   - The total and balance_due should be recalculated on the frontend taking remise into account.
*/

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'invoices' AND column_name = 'remise'
  ) THEN
    ALTER TABLE invoices ADD COLUMN remise numeric NOT NULL DEFAULT 0;
  END IF;
END $$;
