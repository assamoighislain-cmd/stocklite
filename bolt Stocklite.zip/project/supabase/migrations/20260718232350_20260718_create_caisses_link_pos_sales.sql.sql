/*
# Création de la table `caisses` et liaison avec `pos_sales`

## Objectif
Une "caisse" représente une session de travail ouverte par un utilisateur
(le caissier connecté). Elle peut s'étendre sur plusieurs jours (date
d'ouverture + date de clôture). Chaque vente de caisse (`pos_sales`) est
rattachée à une caisse, ce qui permet de calculer le fond de caisse attendu
par période et par utilisateur.

## Nouvelle table

### `caisses`
- `id` (uuid, PK) — identifiant unique
- `user_id` (uuid, NOT NULL, DEFAULT auth.uid()) — identifiant du caissier
  qui a ouvert la caisse. FK vers `user_profiles(id)`.
- `location_id` (uuid, nullable) — point de vente associé. FK vers
  `sales_locations(id)`.
- `status` (text, NOT NULL, DEFAULT 'ouverte') — statut de la caisse :
  `ouverte` ou `cloturee`.
- `opened_at` (timestamptz, NOT NULL, DEFAULT now()) — date/heure
  d'ouverture de la caisse.
- `closed_at` (timestamptz, nullable) — date/heure de clôture. NULL tant
  que la caisse est ouverte.
- `opening_amount` (numeric(12,2), DEFAULT 0) — montant de fond de caisse
  initial déclaré à l'ouverture.
- `closing_amount` (numeric(12,2), nullable) — montant total compté à la
  clôture.
- `notes` (text, DEFAULT '') — notes libres du caissier.
- `created_at` (timestamptz, DEFAULT now())
- `updated_at` (timestamptz, DEFAULT now()) — colonne utilisée par la
  synchronisation incrémentale côté client.

## Modification de tables existantes

### `pos_sales`
- Ajout de la colonne `caisse_id` (uuid, nullable) référençant `caisses(id)`
  avec `ON DELETE SET NULL`. Nullable pour ne pas casser les ventes
  existantes ; les nouvelles ventes seront rattachées à la caisse
  actuellement ouverte pour l'utilisateur.
- Ajout d'un index sur `caisse_id` pour accélérer le calcul du fond de
  caisse par caisse.

## Sécurité (RLS)
- RLS activé sur `caisses`.
- Politiques owner-scoped `TO authenticated` :
  - SELECT : `user_id = auth.uid() OR is_admin()` (un caissier ne voit que
    ses caisses ; un admin voit tout).
  - INSERT : `user_id = auth.uid()` (avec `DEFAULT auth.uid()` sur la
    colonne, un simple `.insert({...})` fonctionne).
  - UPDATE : `user_id = auth.uid() OR is_admin()` (le caissier peut
    clôturer sa caisse ; un admin peut modifier).
  - DELETE : `user_id = auth.uid() OR is_admin()`.
- `pos_sales` : la politique SELECT existante (`ps_select`) est étendue
  pour continuer à autoriser la lecture via `user_id = auth.uid() OR
  is_admin()`. Aucune autre politique n'est modifiée ; `caisse_id` est
  simplement une nouvelle colonne nullable.

## Notes importantes
1. La colonne `user_id` de `caisses` a `DEFAULT auth.uid()` : le client
   peut insérer sans préciser `user_id`, l'identifiant du caissier
   connecté sera utilisé automatiquement.
2. `closed_at` reste NULL tant que la caisse est ouverte. Le passage à
   `cloturee` positionne `closed_at = now()` (géré côté application).
3. Les ventes existantes ont `caisse_id = NULL` ; elles restent visibles
   et ne sont pas affectées.
4. La table est ajoutée à la liste des tables synchronisables côté
   client (Dexie) dans une étape ultérieure.
*/

-- ── Table `caisses` ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS caisses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES user_profiles(id) ON DELETE SET NULL,
  location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'ouverte'
    CHECK (status IN ('ouverte', 'cloturee')),
  opened_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  opening_amount numeric(12,2) NOT NULL DEFAULT 0 CHECK (opening_amount >= 0),
  closing_amount numeric(12,2) CHECK (closing_amount IS NULL OR closing_amount >= 0),
  notes text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_caisses_user     ON caisses(user_id);
CREATE INDEX IF NOT EXISTS idx_caisses_location ON caisses(location_id);
CREATE INDEX IF NOT EXISTS idx_caisses_status   ON caisses(status);
CREATE INDEX IF NOT EXISTS idx_caisses_opened   ON caisses(opened_at);

-- ── RLS sur `caisses` ───────────────────────────────────────────
ALTER TABLE caisses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "caisses_select_own" ON caisses;
CREATE POLICY "caisses_select_own" ON caisses FOR SELECT
  TO authenticated USING (user_id = auth.uid() OR is_admin());

DROP POLICY IF EXISTS "caisses_insert_own" ON caisses;
CREATE POLICY "caisses_insert_own" ON caisses FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "caisses_update_own" ON caisses;
CREATE POLICY "caisses_update_own" ON caisses FOR UPDATE
  TO authenticated USING (user_id = auth.uid() OR is_admin())
  WITH CHECK (user_id = auth.uid() OR is_admin());

DROP POLICY IF EXISTS "caisses_delete_own" ON caisses;
CREATE POLICY "caisses_delete_own" ON caisses FOR DELETE
  TO authenticated USING (user_id = auth.uid() OR is_admin());

-- ── Liaison `pos_sales` → `caisses` ─────────────────────────────
ALTER TABLE pos_sales
  ADD COLUMN IF NOT EXISTS caisse_id uuid REFERENCES caisses(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_pos_sales_caisse ON pos_sales(caisse_id);

-- ── Trigger `updated_at` ────────────────────────────────────────
-- Maintient updated_at automatiquement (utilisé par la sync incrémentale).
CREATE OR REPLACE FUNCTION trg_set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS caisses_updated_at ON caisses;
CREATE TRIGGER caisses_updated_at BEFORE UPDATE ON caisses
  FOR EACH ROW EXECUTE FUNCTION trg_set_updated_at();
