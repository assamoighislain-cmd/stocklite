/*
# Stocklite POS — Module Stock & Caisse

## Vue d'ensemble
Étend le schéma POS avec la gestion des stocks, les ventes en caisse,
les règlements multi-modes (dont Mobile Money) et les paramètres de devise.

## Modifications

### products
Ajout de champs pour la gestion des stocks :
- `purchase_price` — prix d'achat unitaire (pour la valorisation du stock)
- `stock_quantity` — quantité actuelle en stock
- `stock_min` — seuil d'alerte de réapprovisionnement
- `track_stock` — active le suivi de stock pour cet article

### company_settings
- `currency` — devise d'affichage (ex. FCFA, MAD, EUR, USD…)

## Nouvelles tables

### stock_movements
Historique de tous les mouvements de stock.
- `product_id` — article concerné
- `type` — entree / sortie / ajustement / vente
- `quantity` — quantité (toujours positive, le type indique le sens)
- `unit_cost` — coût unitaire au moment du mouvement
- `reference` — référence externe (numéro BL, facture fournisseur…)
- `notes` — commentaire libre

### pos_sales
Ventes en caisse (tickets de caisse), séparées des factures B2B.
- `sale_number` — numéro auto-séquentiel (VNT-00001…)
- `customer_id` — client facultatif (vente comptant possible)
- `subtotal`, `discount_amount`, `discount_pct`, `tax_rate`, `tax_amount`, `total`

### pos_sale_items
Lignes des tickets de caisse.
- Total généré automatiquement (quantity × unit_price)

### pos_payments
Règlements d'un ticket de caisse — supporte les règlements fractionnés.
- `method` — tous les modes de paiement supportés
- `reference` — numéro de transaction mobile money, chèque…

## Modes de paiement (payments + pos_payments)
especes, carte, virement, cheque, orange_money, wave, mtn_money,
moov_money, avoir, autre

## Sécurité
RLS activé sur toutes les nouvelles tables.
App mono-utilisateur : politiques TO anon, authenticated USING (true).
*/

-- ── company_settings : ajout devise ────────────────────────────
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='company_settings' AND column_name='currency') THEN
    ALTER TABLE company_settings ADD COLUMN currency text NOT NULL DEFAULT 'FCFA';
  END IF;
END $$;

-- ── products : ajout champs stock ───────────────────────────────
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='products' AND column_name='purchase_price') THEN
    ALTER TABLE products
      ADD COLUMN purchase_price numeric(12,2) NOT NULL DEFAULT 0,
      ADD COLUMN stock_quantity numeric(12,4) NOT NULL DEFAULT 0,
      ADD COLUMN stock_min      numeric(12,4) NOT NULL DEFAULT 0,
      ADD COLUMN track_stock    boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- ── Mise à jour contrainte payments.method ──────────────────────
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_method_check;
ALTER TABLE payments
  ADD CONSTRAINT payments_method_check
  CHECK (method IN (
    'especes','carte','virement','cheque',
    'orange_money','wave','mtn_money','moov_money',
    'avoir','autre'
  ));

-- ── stock_movements ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stock_movements (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id  uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  type        text NOT NULL CHECK (type IN ('entree','sortie','ajustement','vente')),
  quantity    numeric(12,4) NOT NULL CHECK (quantity > 0),
  unit_cost   numeric(12,2) NOT NULL DEFAULT 0,
  reference   text NOT NULL DEFAULT '',
  notes       text NOT NULL DEFAULT '',
  created_at  timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_stock_movements_product ON stock_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_date    ON stock_movements(created_at);

-- ── pos_sales ───────────────────────────────────────────────────
CREATE SEQUENCE IF NOT EXISTS pos_sale_seq START 1;

CREATE TABLE IF NOT EXISTS pos_sales (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_number     text UNIQUE NOT NULL
                    DEFAULT 'VNT-' || LPAD(nextval('pos_sale_seq')::text, 5, '0'),
  customer_id     uuid REFERENCES customers(id) ON DELETE SET NULL,
  subtotal        numeric(12,2) NOT NULL DEFAULT 0,
  discount_pct    numeric(5,2)  NOT NULL DEFAULT 0,
  discount_amount numeric(12,2) NOT NULL DEFAULT 0,
  tax_rate        numeric(5,2)  NOT NULL DEFAULT 0,
  tax_amount      numeric(12,2) NOT NULL DEFAULT 0,
  total           numeric(12,2) NOT NULL DEFAULT 0,
  notes           text NOT NULL DEFAULT '',
  created_at      timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pos_sales_customer ON pos_sales(customer_id);
CREATE INDEX IF NOT EXISTS idx_pos_sales_date     ON pos_sales(created_at);

-- ── pos_sale_items ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pos_sale_items (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_id     uuid NOT NULL REFERENCES pos_sales(id) ON DELETE CASCADE,
  product_id  uuid REFERENCES products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity    numeric(12,4) NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price  numeric(12,2) NOT NULL DEFAULT 0,
  total       numeric(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
  created_at  timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pos_items_sale ON pos_sale_items(sale_id);

-- ── pos_payments ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pos_payments (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_id    uuid NOT NULL REFERENCES pos_sales(id) ON DELETE CASCADE,
  method     text NOT NULL CHECK (method IN (
               'especes','carte','virement','cheque',
               'orange_money','wave','mtn_money','moov_money',
               'avoir','autre'
             )),
  amount     numeric(12,2) NOT NULL CHECK (amount > 0),
  reference  text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pos_payments_sale ON pos_payments(sale_id);

-- ── RLS ─────────────────────────────────────────────────────────
ALTER TABLE stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE pos_sales       ENABLE ROW LEVEL SECURITY;
ALTER TABLE pos_sale_items  ENABLE ROW LEVEL SECURITY;
ALTER TABLE pos_payments    ENABLE ROW LEVEL SECURITY;

-- stock_movements
DROP POLICY IF EXISTS "anon_select_sm"  ON stock_movements;
DROP POLICY IF EXISTS "anon_insert_sm"  ON stock_movements;
DROP POLICY IF EXISTS "anon_update_sm"  ON stock_movements;
DROP POLICY IF EXISTS "anon_delete_sm"  ON stock_movements;
CREATE POLICY "anon_select_sm" ON stock_movements FOR SELECT TO anon,authenticated USING (true);
CREATE POLICY "anon_insert_sm" ON stock_movements FOR INSERT TO anon,authenticated WITH CHECK (true);
CREATE POLICY "anon_update_sm" ON stock_movements FOR UPDATE TO anon,authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_sm" ON stock_movements FOR DELETE TO anon,authenticated USING (true);

-- pos_sales
DROP POLICY IF EXISTS "anon_select_ps"  ON pos_sales;
DROP POLICY IF EXISTS "anon_insert_ps"  ON pos_sales;
DROP POLICY IF EXISTS "anon_update_ps"  ON pos_sales;
DROP POLICY IF EXISTS "anon_delete_ps"  ON pos_sales;
CREATE POLICY "anon_select_ps" ON pos_sales FOR SELECT TO anon,authenticated USING (true);
CREATE POLICY "anon_insert_ps" ON pos_sales FOR INSERT TO anon,authenticated WITH CHECK (true);
CREATE POLICY "anon_update_ps" ON pos_sales FOR UPDATE TO anon,authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_ps" ON pos_sales FOR DELETE TO anon,authenticated USING (true);

-- pos_sale_items
DROP POLICY IF EXISTS "anon_select_psi" ON pos_sale_items;
DROP POLICY IF EXISTS "anon_insert_psi" ON pos_sale_items;
DROP POLICY IF EXISTS "anon_update_psi" ON pos_sale_items;
DROP POLICY IF EXISTS "anon_delete_psi" ON pos_sale_items;
CREATE POLICY "anon_select_psi" ON pos_sale_items FOR SELECT TO anon,authenticated USING (true);
CREATE POLICY "anon_insert_psi" ON pos_sale_items FOR INSERT TO anon,authenticated WITH CHECK (true);
CREATE POLICY "anon_update_psi" ON pos_sale_items FOR UPDATE TO anon,authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_psi" ON pos_sale_items FOR DELETE TO anon,authenticated USING (true);

-- pos_payments
DROP POLICY IF EXISTS "anon_select_pp"  ON pos_payments;
DROP POLICY IF EXISTS "anon_insert_pp"  ON pos_payments;
DROP POLICY IF EXISTS "anon_update_pp"  ON pos_payments;
DROP POLICY IF EXISTS "anon_delete_pp"  ON pos_payments;
CREATE POLICY "anon_select_pp" ON pos_payments FOR SELECT TO anon,authenticated USING (true);
CREATE POLICY "anon_insert_pp" ON pos_payments FOR INSERT TO anon,authenticated WITH CHECK (true);
CREATE POLICY "anon_update_pp" ON pos_payments FOR UPDATE TO anon,authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_pp" ON pos_payments FOR DELETE TO anon,authenticated USING (true);
