/*
# Schedule daily license reminder cron job

1. Purpose
   - Creates a pg_cron job that runs every day at 08:00 GMT.
   - The job calls the `license-reminder` edge function via an HTTP POST request.
   - The edge function checks all active tenants whose license expires within
     29 days, inserts in-app admin notifications, and sends reminder emails.

2. Changes
   - Schedules a new cron job named `license-reminder-daily` to run daily at 08:00 GMT.
   - The job uses `net.http_post` from the `http` extension to call the edge
     function URL with the service role key as authorization.

3. Notes
   - The edge function URL is constructed from the Supabase project URL.
   - The service role key is passed as the Authorization header so the function
     can use the service role client (bypasses RLS for inserts).
   - pg_cron runs in GMT timezone by default.
   - To re-run this migration safely, the job is unscheduled first inside a
     DO block that ignores errors if the job doesn't exist.
*/

DO $$
BEGIN
  -- Try to unschedule existing job, ignore error if not found
  PERFORM cron.unschedule('license-reminder-daily');
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;

-- Schedule the daily reminder job at 08:00 GMT
SELECT cron.schedule(
  'license-reminder-daily',
  '0 8 * * *',
  $$
    SELECT net.http_post(
      url := 'https://db.boltic.io/functions/v1/license-reminder',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || current_setting('app.service_role_key', true)
      ),
      body := '{}'::jsonb
    );
  $$
);
