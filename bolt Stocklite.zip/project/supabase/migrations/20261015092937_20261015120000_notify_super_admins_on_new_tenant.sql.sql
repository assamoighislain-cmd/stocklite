/*
# Notify super admins when a new company (tenant) is created

## Purpose
When a new tenant is inserted into the `tenants` table (either by the
handle_new_user() trigger during signup, or manually by a super admin),
this trigger calls the `notify-new-tenant` edge function which:
1. Inserts an in-app admin_notification for all active super_admins.
2. Sends a Web Push notification to super_admins who have push subscriptions.

This ensures super admins are alerted even when the application is closed,
as long as they have granted push notification permission.

## Changes
1. Create a SECURITY DEFINER function `notify_new_tenant()` that uses
   the `http` extension to POST to the edge function URL.
   - The function is SECURITY DEFINER so it can use the service role key
     stored in a Postgres variable (set via supabase secrets).
   - Actually, the edge function uses the service role key from its own
     env, so the trigger just needs to call the endpoint. We use the
     anon key for the call -- the edge function itself uses the service
     role internally.
2. Create an AFTER INSERT trigger on `tenants` that calls this function.

## Security
- The trigger function is SECURITY DEFINER with `search_path = public`.
- It only fires on INSERT, so existing tenants are unaffected.
- The HTTP call is non-blocking (the trigger returns NEW regardless of
  the HTTP response status).
- The edge function has `verify_jwt = false` so it can be called from
  the database trigger without a JWT.
*/

-- Ensure http extension is available
CREATE EXTENSION IF NOT EXISTS http;

CREATE OR REPLACE FUNCTION notify_new_tenant()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_url     text;
  v_payload jsonb;
  v_resp    text;
BEGIN
  -- Only notify for newly created tenants (not updates)
  -- Build the edge function URL
  v_url := current_setting('app.supabase_url', true) || '/functions/v1/notify-new-tenant';

  v_payload := jsonb_build_object(
    'tenant_id', NEW.id,
    'tenant_name', NEW.name
  );

  -- Fire and forget -- we don't care about the response
  BEGIN
    SELECT content INTO v_resp
    FROM http_post(
      v_url,
      v_payload::text,
      'application/json'
    );
  EXCEPTION WHEN OTHERS THEN
    -- Network errors should not block tenant creation
    NULL;
  END;

  RETURN NEW;
END;
$$;

-- Drop existing trigger if re-running
DROP TRIGGER IF EXISTS trg_notify_new_tenant ON tenants;

CREATE TRIGGER trg_notify_new_tenant
AFTER INSERT ON tenants
FOR EACH ROW
EXECUTE FUNCTION notify_new_tenant();
