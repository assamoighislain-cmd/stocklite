/*
# Add 'controleur' (Contrôleur de caisse) role

## Purpose
Adds a new user role "controleur" (Contrôleur de caisse) so company administrators
can create accounts for cash-control supervisors. These users can access the
dashboard, point of sale, cash closing, cash operations, invoices and customers
but cannot manage settings, stock, products, or other users.

## Changes
1. user_profiles.role CHECK constraint: add 'controleur' to the allowed values.
2. handle_new_user() trigger: accept 'controleur' as a valid role on signup.

## Security
- No new tables.
- No RLS policy changes (existing policies already cover the new role value).
*/

-- ── 1. Update role CHECK constraint ────────────────────────────
ALTER TABLE user_profiles
  DROP CONSTRAINT IF EXISTS user_profiles_role_check;

ALTER TABLE user_profiles
  ADD CONSTRAINT user_profiles_role_check
  CHECK (role IN ('admin', 'caissier', 'gerant', 'commercial', 'controleur', 'super_admin'));

-- ── 2. Update handle_new_user trigger to accept 'controleur' ──
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role      text;
  v_name      text;
  v_status    text;
  v_tenant_id text;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'caissier');
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', '');

  -- Validate role; fall back to caissier if unexpected value
  IF v_role NOT IN ('admin', 'caissier', 'gerant', 'commercial', 'controleur') THEN
    v_role := 'caissier';
  END IF;

  -- super_admin signups become active immediately; everyone else pending
  IF v_role = 'admin' THEN
    v_status := 'active';
  ELSE
    v_status := 'pending';
  END IF;

  -- Extract tenant_id if provided (e.g. from edge function admin.createUser)
  v_tenant_id := NEW.raw_user_meta_data->>'tenant_id';

  INSERT INTO user_profiles (id, email, full_name, role, status, tenant_id)
  VALUES (NEW.id, NEW.email, v_name, v_role, v_status, v_tenant_id)
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;
