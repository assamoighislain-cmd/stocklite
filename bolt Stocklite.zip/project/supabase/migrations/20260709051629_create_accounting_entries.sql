CREATE TABLE IF NOT EXISTS accounting_entries (
  id              UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  date            DATE         NOT NULL DEFAULT CURRENT_DATE,
  type            TEXT         NOT NULL CHECK (type IN ('recette', 'charge')),
  category        TEXT         NOT NULL DEFAULT 'autre',
  description     TEXT         NOT NULL DEFAULT '',
  amount          NUMERIC(12,2) NOT NULL CHECK (amount > 0),
  payment_method  TEXT         NOT NULL DEFAULT 'especes',
  reference       TEXT         NOT NULL DEFAULT '',
  notes           TEXT         NOT NULL DEFAULT '',
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_acc_entries_date ON accounting_entries(date);
CREATE INDEX IF NOT EXISTS idx_acc_entries_type ON accounting_entries(type);

ALTER TABLE accounting_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_accounting" ON accounting_entries FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_accounting" ON accounting_entries FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_accounting" ON accounting_entries FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_accounting" ON accounting_entries FOR DELETE TO authenticated USING (true);
