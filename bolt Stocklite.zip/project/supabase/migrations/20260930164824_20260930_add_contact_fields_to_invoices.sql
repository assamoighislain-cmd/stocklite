/*
# Add interlocuteur fields to invoices

1. Changes
- Add `contact_name` (text, nullable) — name of the contact/interlocuteur for this invoice.
- Add `contact_email` (text, nullable) — email of the contact.
- Add `contact_phone` (text, nullable) — phone number of the contact.
2. Security
- No RLS changes — invoices already has existing policies.
3. Notes
- Idempotent via DO $$ ... IF NOT EXISTS ... END $$.
*/

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'contact_name') THEN
    ALTER TABLE invoices ADD COLUMN contact_name text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'contact_email') THEN
    ALTER TABLE invoices ADD COLUMN contact_email text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'contact_phone') THEN
    ALTER TABLE invoices ADD COLUMN contact_phone text;
  END IF;
END $$;