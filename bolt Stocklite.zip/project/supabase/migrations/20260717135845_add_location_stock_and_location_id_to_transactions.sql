-- ── 1. location_stock : stock par boutique ──────────────────────
CREATE TABLE IF NOT EXISTS location_stock (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id     uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  location_id    uuid NOT NULL REFERENCES sales_locations(id) ON DELETE CASCADE,
  stock_quantity numeric(12,4) NOT NULL DEFAULT 0,
  stock_min      numeric(12,4) NOT NULL DEFAULT 0,
  updated_at     timestamptz DEFAULT now(),
  UNIQUE(product_id, location_id)
);

ALTER TABLE location_stock ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_ls" ON location_stock;
DROP POLICY IF EXISTS "auth_insert_ls" ON location_stock;
DROP POLICY IF EXISTS "auth_update_ls" ON location_stock;
DROP POLICY IF EXISTS "auth_delete_ls" ON location_stock;
CREATE POLICY "auth_select_ls" ON location_stock FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_ls" ON location_stock FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_ls" ON location_stock FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_ls" ON location_stock FOR DELETE TO authenticated USING (true);

-- Pré-remplir location_stock depuis products pour chaque boutique existante
INSERT INTO location_stock (product_id, location_id, stock_quantity, stock_min)
SELECT p.id, sl.id, p.stock_quantity, p.stock_min
FROM products p
CROSS JOIN sales_locations sl
WHERE p.track_stock = true
ON CONFLICT (product_id, location_id) DO NOTHING;

-- ── 2. Ajouter location_id aux tables de transactions ────────────
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pos_sales' AND column_name='location_id') THEN
    ALTER TABLE pos_sales ADD COLUMN location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='invoices' AND column_name='location_id') THEN
    ALTER TABLE invoices ADD COLUMN location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='caisse_closings' AND column_name='location_id') THEN
    ALTER TABLE caisse_closings ADD COLUMN location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='accounting_entries' AND column_name='location_id') THEN
    ALTER TABLE accounting_entries ADD COLUMN location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='stock_movements' AND column_name='location_id') THEN
    ALTER TABLE stock_movements ADD COLUMN location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Index sur location_id pour les requêtes de filtrage
CREATE INDEX IF NOT EXISTS idx_pos_sales_location      ON pos_sales(location_id);
CREATE INDEX IF NOT EXISTS idx_invoices_location       ON invoices(location_id);
CREATE INDEX IF NOT EXISTS idx_caisse_closings_location ON caisse_closings(location_id);
CREATE INDEX IF NOT EXISTS idx_accounting_location     ON accounting_entries(location_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_location ON stock_movements(location_id);
CREATE INDEX IF NOT EXISTS idx_location_stock_location  ON location_stock(location_id);
