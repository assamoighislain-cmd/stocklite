/*
# Fix notify_new_tenant: hardcode edge function URL

The previous migration relied on current_setting('app.supabase_url') which
is not set by default. This update hardcodes the project URL so the
trigger works without any extra configuration.
*/

CREATE OR REPLACE FUNCTION notify_new_tenant()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_url     text;
  v_payload jsonb;
  v_resp    text;
BEGIN
  v_url := 'https://sttwaijylxdyvsghlebj.supabase.co/functions/v1/notify-new-tenant';

  v_payload := jsonb_build_object(
    'tenant_id', NEW.id,
    'tenant_name', NEW.name
  );

  BEGIN
    SELECT content INTO v_resp
    FROM http_post(
      v_url,
      v_payload::text,
      'application/json'
    );
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_new_tenant ON tenants;
CREATE TRIGGER trg_notify_new_tenant
AFTER INSERT ON tenants
FOR EACH ROW
EXECUTE FUNCTION notify_new_tenant();
