/*
# Backfill unit_cost for sale items missing a purchase price

1. Purpose
   The initial backfill in migration 20261023144951 ran once and set unit_cost
   from the linked product's purchase_price for rows where unit_cost = 0.
   However, sales recorded AFTER the column was added but BEFORE the frontend
   code started populating unit_cost have slipped through with unit_cost = 0.
   This migration re-runs the backfill to catch any remaining rows where the
   linked product has a non-zero purchase_price.

2. Changes
   - `pos_sale_items`: UPDATE unit_cost = product.purchase_price for rows where
     unit_cost = 0 AND the linked product has a non-zero purchase_price.
   - `invoice_items`: same backfill.

3. Safety
   - No schema changes, no new tables, no policy changes.
   - Only updates rows where unit_cost is still 0, so previously-correct rows
     are untouched.
   - Rows without a linked product or whose product has purchase_price = 0
     remain at 0 (correct behaviour — no cost to freeze).
*/

UPDATE pos_sale_items psi
  SET unit_cost = p.purchase_price
  FROM products p
  WHERE psi.product_id = p.id
    AND psi.unit_cost = 0
    AND p.purchase_price > 0;

UPDATE invoice_items ii
  SET unit_cost = p.purchase_price
  FROM products p
  WHERE ii.product_id = p.id
    AND ii.unit_cost = 0
    AND p.purchase_price > 0;
