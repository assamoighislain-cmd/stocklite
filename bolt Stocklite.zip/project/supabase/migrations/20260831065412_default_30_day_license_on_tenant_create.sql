/*
# Default 30-day trial license on tenant creation

1. Changes
- Sets a column DEFAULT on `tenants.license_expires_at` so that newly created
  companies automatically receive a 30-day trial license starting from the
  moment they are created.
- The default is computed as `now() + interval '30 days'`, expressed as a
  stable expression via a generated column default.
- Existing tenants with a NULL `license_expires_at` are backfilled to
  `now() + interval '30 days'` so they also get a trial period.

2. Notes
- This does NOT change the data type of the column (still timestamptz).
- This does NOT affect tenants that already have a license date set.
- The frontend `createTenant` function also defaults to 30 days when no
  explicit date is passed, so both paths are covered.
*/

-- Backfill existing tenants that have no license date
UPDATE tenants
SET license_expires_at = now() + interval '30 days'
WHERE license_expires_at IS NULL;

-- Set the column default to 30 days from creation time
ALTER TABLE tenants
  ALTER COLUMN license_expires_at
  SET DEFAULT (now() + interval '30 days');
