/*
# Create custom_units table

## Purpose
Allows company administrators to manage the list of units available when creating
or editing a product ("fiche article"). Admins can add custom units (beyond the
built-in defaults) and remove units they no longer use.

## New Table
- `custom_units`
  - `id` (uuid, primary key)
  - `name` (text, not null) — the unit label, e.g. "pcs", "kg", "carton"
  - `tenant_id` (uuid, references tenants) — scopes units to a company
  - `created_at` (timestamptz)

## Security
- RLS enabled.
- Only authenticated users within the same tenant can manage their units.
- Standard 4 CRUD policies scoped by tenant_id via the helper function.
*/

CREATE TABLE IF NOT EXISTS custom_units (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE custom_units ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_custom_units" ON custom_units;
CREATE POLICY "select_own_custom_units" ON custom_units FOR SELECT
  TO authenticated USING (
    tenant_id IS NULL OR tenant_id = (
      SELECT tenant_id FROM user_profiles WHERE id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "insert_own_custom_units" ON custom_units;
CREATE POLICY "insert_own_custom_units" ON custom_units FOR INSERT
  TO authenticated WITH CHECK (
    tenant_id = (
      SELECT tenant_id FROM user_profiles WHERE id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "update_own_custom_units" ON custom_units;
CREATE POLICY "update_own_custom_units" ON custom_units FOR UPDATE
  TO authenticated USING (
    tenant_id = (
      SELECT tenant_id FROM user_profiles WHERE id = auth.uid()
    )
  ) WITH CHECK (
    tenant_id = (
      SELECT tenant_id FROM user_profiles WHERE id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "delete_own_custom_units" ON custom_units;
CREATE POLICY "delete_own_custom_units" ON custom_units FOR DELETE
  TO authenticated USING (
    tenant_id = (
      SELECT tenant_id FROM user_profiles WHERE id = auth.uid()
    )
  );

CREATE INDEX IF NOT EXISTS idx_custom_units_tenant_id ON custom_units(tenant_id);
