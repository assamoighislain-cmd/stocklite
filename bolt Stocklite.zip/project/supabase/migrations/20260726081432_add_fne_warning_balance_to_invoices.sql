/*
# Add FNE warning and balance sticker columns to invoices

## Purpose
The DGI FNE API returns two extra fields on certification — `warning` (boolean
indicating the invoice has a compliance warning) and `balance_sticker`
(numeric sticker used for verification). These were previously discarded
after certification. This migration persists them so the UI can display them.

## Changes
1. Modified table: `invoices`
   - Add `fne_warning` boolean, default false, nullable
   - Add `fne_balance_sticker` integer, nullable
2. Security
   - No RLS policy changes — `invoices` already has owner-scoped policies.
*/

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS fne_warning boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS fne_balance_sticker integer;
