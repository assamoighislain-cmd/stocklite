/*
# Tenant-scoped deletes_log for proper cross-tenant sync isolation

## Problem
1. `deletes_log` had no `tenant_id` column — the AFTER DELETE trigger
   only recorded `table_name` and `record_id`, with no way to know which
   tenant the deleted row belonged to.
2. `deletes_log` RLS policy was `is_super_admin()` only, so regular
   authenticated users (admins, caissiers, etc.) could NOT read any
   entries. The background sync's `pullDeletes()` function silently
   received zero rows, meaning server-side deletions never propagated
   to local caches.
3. This created a cross-tenant data leak: when user A (tenant X) deletes
   a row, the delete trigger inserts into deletes_log. When user B
   (tenant Y) syncs, they'd see that delete entry and could try to
   delete a local row — but more importantly, without tenant_id there
   was no way to filter deletes per tenant.

## Changes

### 1. Add tenant_id column to deletes_log
- New column `tenant_id uuid REFERENCES tenants(id)`.
- Backfilled from existing data where possible (joins to the original
  table to find the tenant of the deleted record — but since the row
  is already deleted, we can't backfill; existing rows get NULL and
  are invisible to non-super-admins, which is the safe default).

### 2. Update log_delete_trigger() to capture tenant_id
- The trigger now reads `OLD.tenant_id` and stores it in the new column.
  For tables that have a tenant_id column (all data tables), this works
  directly. For tables without tenant_id (none in the current schema),
  it falls back to NULL.

### 3. Replace RLS policy: tenant-scoped instead of super_admin-only
- SELECT: `is_super_admin() OR tenant_id = get_user_tenant_id()`
- This means each user only sees deletion log entries for their own
  tenant, so sync only deletes local rows that belonged to their tenant.

### 4. Add index on tenant_id for efficient filtering

## Security
- RLS remains enabled and forced on deletes_log.
- Non-super-admin users can now only read deletes_log entries for their
  own tenant, preventing cross-tenant information leakage.
*/

-- 1. Add tenant_id column
ALTER TABLE deletes_log ADD COLUMN IF NOT EXISTS tenant_id uuid REFERENCES tenants(id);

-- 2. Update the trigger function to capture tenant_id from the deleted row
CREATE OR REPLACE FUNCTION log_delete_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO deletes_log (table_name, record_id, tenant_id)
  VALUES (TG_TABLE_NAME, OLD.id::text, OLD.tenant_id);
  RETURN OLD;
END;
$$;

-- 3. Replace the RLS policy: drop super_admin-only, create tenant-scoped
DROP POLICY IF EXISTS "deletes_log_select" ON deletes_log;
DROP POLICY IF EXISTS "read_deletes_log" ON deletes_log;

CREATE POLICY "deletes_log_select_tenant" ON deletes_log FOR SELECT
  TO authenticated
  USING (is_super_admin() OR tenant_id = get_user_tenant_id());

-- 4. Index for efficient tenant filtering
CREATE INDEX IF NOT EXISTS idx_deletes_log_tenant ON deletes_log(tenant_id);
