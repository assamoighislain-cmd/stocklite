/*
# Add credit note fields to invoices

1. Modified Tables
   - `invoices`
     - `is_credit_note` (boolean, default false) - marks this invoice as a credit note (avoir)
     - `credit_note_of` (uuid, nullable) - references the original invoice this avoir cancels

2. Important Notes
   - A credit note (avoir) is created when a certified invoice is cancelled.
   - The original invoice status becomes 'annulee' and the avoir references it.
*/

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='invoices' AND column_name='is_credit_note') THEN
    ALTER TABLE invoices ADD COLUMN is_credit_note boolean NOT NULL DEFAULT false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='invoices' AND column_name='credit_note_of') THEN
    ALTER TABLE invoices ADD COLUMN credit_note_of uuid REFERENCES invoices(id);
  END IF;
END $$;
