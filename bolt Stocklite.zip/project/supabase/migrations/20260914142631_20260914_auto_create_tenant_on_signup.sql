/*
# Auto-create tenant on signup when company name doesn't match

## Problem
When a new user signs up with a company_name that doesn't match any existing
tenant, the handle_new_user() trigger leaves tenant_id = NULL. The user appears
in the super admin's "unassigned users" list but their company never appears
in the tenants list. The super admin has no way to see the company name and
must manually create the tenant, then assign the user.

## Fix
Update handle_new_user() so that when company_name is provided but no matching
tenant is found, a new tenant is automatically created with:
- name = the provided company_name
- slug = slugified version of the company_name
- active = true
- license_expires_at = now + 30 days (default)
- max_users = 5 (default)

The new user is then assigned to this tenant with status 'pending', so the
super admin can still approve/reject the account, but the company now appears
in the tenants list immediately.

## Security
- The trigger is SECURITY DEFINER, so it can insert into tenants regardless
  of RLS.
- The new tenant is created with default values; the super admin can edit
  it later.
- No changes to existing RLS policies.
- The ON CONFLICT DO UPDATE on user_profiles is preserved.

## Backfill
Manually create the tenant for the existing user LOUKOU konan Paul
(email: lpuniversgroupp@gmail.com) and assign them to it.
*/

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role          text;
  v_status        text;
  v_name          text;
  v_company_name  text;
  v_tenant_id     uuid;
  v_admin_id      uuid;
  v_notif_title   text;
  v_notif_body    text;
  v_slug          text;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'caissier');
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', '');
  v_company_name := NULLIF(trim(NEW.raw_user_meta_data->>'company_name'), '');

  IF v_role NOT IN ('admin', 'caissier', 'gerant', 'commercial', 'controleur') THEN
    v_role := 'caissier';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM user_profiles LIMIT 1) AND v_company_name IS NULL THEN
    v_role := 'admin';
    v_status := 'active';
  ELSE
    v_status := 'pending';
  END IF;

  IF v_company_name IS NOT NULL THEN
    SELECT id INTO v_tenant_id
    FROM tenants
    WHERE lower(trim(name)) = lower(v_company_name)
    LIMIT 1;

    -- No matching tenant found: create one automatically
    IF v_tenant_id IS NULL THEN
      v_slug := lower(trim(v_company_name));
      v_slug := regexp_replace(v_slug, '[^a-z0-9]+', '-', 'g');
      v_slug := regexp_replace(v_slug, '^-+|-+$', '', 'g');
      IF v_slug = '' THEN
        v_slug := 'tenant-' || substr(replace(gen_random_uuid()::text, '-', ''), 1, 8);
      END IF;

      INSERT INTO tenants (name, slug, active)
      VALUES (v_company_name, v_slug, true)
      RETURNING id INTO v_tenant_id;
    END IF;
  END IF;

  INSERT INTO user_profiles (id, email, full_name, role, status, tenant_id)
  VALUES (NEW.id, NEW.email, v_name, v_role, v_status, v_tenant_id)
  ON CONFLICT (id) DO UPDATE SET
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    status = EXCLUDED.status,
    tenant_id = EXCLUDED.tenant_id,
    updated_at = now();

  IF v_status = 'pending' THEN
    IF v_tenant_id IS NOT NULL THEN
      SELECT id INTO v_admin_id
      FROM user_profiles
      WHERE tenant_id = v_tenant_id
        AND role = 'admin'
        AND status = 'active'
      ORDER BY created_at ASC
      LIMIT 1;

      v_notif_title := 'Nouvelle demande d''accès';
      v_notif_body := format('%s (%s) demande à rejoindre votre entreprise %s.', COALESCE(v_name, ''), COALESCE(NEW.email, ''), v_company_name);

      IF v_admin_id IS NOT NULL THEN
        INSERT INTO admin_notifications (type, title, body, tenant_id, recipient_user_id)
        VALUES ('signup_request', v_notif_title, v_notif_body, v_tenant_id, v_admin_id);
      END IF;
    ELSE
      v_notif_title := 'Nouvelle inscription à valider';
      v_notif_body := format('%s (%s) demande un compte pour l''entreprise %s.', COALESCE(v_name, ''), COALESCE(NEW.email, ''), COALESCE(v_company_name, 'non renseignée'));

      INSERT INTO admin_notifications (type, title, body)
      SELECT 'signup_request', v_notif_title, v_notif_body
      FROM user_profiles
      WHERE role = 'super_admin'
        AND status = 'active';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- Backfill: create tenant for LOUKOU konan Paul and assign him
DO $$
DECLARE
  v_tenant_id uuid;
  v_company_name text := 'Lp univers  group et compagnie';
  v_slug text;
BEGIN
  -- Check if tenant already exists (case-insensitive)
  SELECT id INTO v_tenant_id
  FROM tenants
  WHERE lower(trim(name)) = lower(v_company_name)
  LIMIT 1;

  IF v_tenant_id IS NULL THEN
    v_slug := lower(trim(v_company_name));
    v_slug := regexp_replace(v_slug, '[^a-z0-9]+', '-', 'g');
    v_slug := regexp_replace(v_slug, '^-+|-+$', '', 'g');

    INSERT INTO tenants (name, slug, active)
    VALUES (v_company_name, v_slug, true)
    RETURNING id INTO v_tenant_id;
  END IF;

  -- Assign Paul to this tenant
  UPDATE user_profiles
  SET tenant_id = v_tenant_id, updated_at = now()
  WHERE email = 'lpuniversgroupp@gmail.com' AND tenant_id IS NULL;
END $$;
