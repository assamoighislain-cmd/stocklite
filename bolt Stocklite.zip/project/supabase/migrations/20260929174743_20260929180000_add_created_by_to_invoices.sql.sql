/*
# Add created_by column to invoices

1. Changes
- Adds `created_by` (uuid, nullable) to `invoices` to track which user created the invoice.
- Adds a foreign key to `auth.users(id)` with `ON DELETE SET NULL`.
- Backfills existing rows: sets `created_by` to `tenant_id`-matched owner if possible, otherwise leaves NULL.

2. Security
- No RLS policy changes. The column is informational; existing tenant-scoped RLS on `invoices` already controls access.
*/

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;
