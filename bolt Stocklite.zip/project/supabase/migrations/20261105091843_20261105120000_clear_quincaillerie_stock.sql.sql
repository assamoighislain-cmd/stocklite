/*
# Remove all stock items from QUINCALLERIE location for BES tenant

1. Purpose
   The user requested deletion of all articles (stock entries) from the
   "QUINCALLERIE" sales location belonging to tenant BES.

2. Changes
   - Delete all rows in `location_stock` for the QUINCALLERIE location.
   - No other tables are affected (no sales, movements, or invoices reference
     this location).

3. Safety
   - Verified beforehand: 0 stock_movements, 0 pos_sales, 0 invoices for this
     location, so no historical data is lost.
   - The sales_location itself is NOT deleted — only its stock entries.
*/

DELETE FROM location_stock
WHERE location_id = '7349b6ff-9fce-4c6b-89c0-ab3bae412939';
