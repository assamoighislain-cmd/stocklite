
/*
# Add multi-user authentication with role-based access control

## Summary
Adds a user_profiles table linked to auth.users, with role (admin/caissier/stock) and
status (pending/active/suspended) fields. A trigger auto-creates a profile on signup.
The first user ever to sign up becomes admin (active). Subsequent users start as pending
and must be approved by an admin. A SECURITY DEFINER helper bypasses RLS for admin checks.
All existing table policies are updated to require authenticated sessions.

## New Objects
1. `user_profiles` table — stores role + status per auth user
2. `is_admin()` function — SECURITY DEFINER, returns true if caller is an active admin
3. `handle_new_user()` trigger — fires on auth.users INSERT, creates profile row
4. RLS policies on user_profiles
5. Updated policies on all existing tables: require authenticated (not anon)

## Roles
- admin: full access to everything + user management
- caissier: POS only
- stock: stock + products

## Status lifecycle
- pending: created, awaiting admin approval
- active: approved, can log in
- suspended: revoked access
*/

-- ── 1. user_profiles ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_profiles (
  id         uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email      text NOT NULL,
  full_name  text NOT NULL DEFAULT '',
  role       text NOT NULL DEFAULT 'caissier'
               CHECK (role IN ('admin', 'caissier', 'stock')),
  status     text NOT NULL DEFAULT 'pending'
               CHECK (status IN ('pending', 'active', 'suspended')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- ── 2. is_admin() helper ─────────────────────────────────────────
-- SECURITY DEFINER: runs as owner, bypasses caller's RLS
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_profiles
    WHERE id = auth.uid()
      AND role = 'admin'
      AND status = 'active'
  );
$$;

-- ── 3. Trigger: auto-create profile on signup ────────────────────
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role   text;
  v_status text;
  v_name   text;
BEGIN
  -- Read desired role from user metadata (set during signUp)
  v_role   := COALESCE(NEW.raw_user_meta_data->>'role',      'caissier');
  v_name   := COALESCE(NEW.raw_user_meta_data->>'full_name', '');

  -- Validate role; fall back to caissier if unexpected value
  IF v_role NOT IN ('admin', 'caissier', 'stock') THEN
    v_role := 'caissier';
  END IF;

  -- First user ever → auto-approve as admin
  IF NOT EXISTS (SELECT 1 FROM user_profiles LIMIT 1) THEN
    v_role   := 'admin';
    v_status := 'active';
  ELSE
    v_status := 'pending';
  END IF;

  INSERT INTO user_profiles (id, email, full_name, role, status)
  VALUES (NEW.id, NEW.email, v_name, v_role, v_status);

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ── 4. RLS policies on user_profiles ────────────────────────────
-- Users can read their own profile
DROP POLICY IF EXISTS "profile_select_own" ON user_profiles;
CREATE POLICY "profile_select_own" ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id OR is_admin());

-- Admins can update any profile (for approval/role change)
DROP POLICY IF EXISTS "profile_update_admin" ON user_profiles;
CREATE POLICY "profile_update_admin" ON user_profiles FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

-- No direct INSERT/DELETE from client (handled by trigger / admin)
DROP POLICY IF EXISTS "profile_insert_none" ON user_profiles;
CREATE POLICY "profile_insert_none" ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (false);

DROP POLICY IF EXISTS "profile_delete_none" ON user_profiles;
CREATE POLICY "profile_delete_none" ON user_profiles FOR DELETE
  TO authenticated
  USING (false);

-- ── 5. Lock existing tables to authenticated only ────────────────
-- company_settings
DROP POLICY IF EXISTS "anon_select_settings" ON company_settings;
DROP POLICY IF EXISTS "anon_insert_settings" ON company_settings;
DROP POLICY IF EXISTS "anon_update_settings" ON company_settings;
DROP POLICY IF EXISTS "anon_delete_settings" ON company_settings;
DROP POLICY IF EXISTS "auth_select_settings" ON company_settings;
DROP POLICY IF EXISTS "auth_insert_settings" ON company_settings;
DROP POLICY IF EXISTS "auth_update_settings" ON company_settings;
DROP POLICY IF EXISTS "auth_delete_settings" ON company_settings;

CREATE POLICY "auth_select_settings" ON company_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_settings" ON company_settings FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_settings" ON company_settings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_settings" ON company_settings FOR DELETE TO authenticated USING (true);

-- products
DROP POLICY IF EXISTS "anon_select_products" ON products;
DROP POLICY IF EXISTS "anon_insert_products" ON products;
DROP POLICY IF EXISTS "anon_update_products" ON products;
DROP POLICY IF EXISTS "anon_delete_products" ON products;
DROP POLICY IF EXISTS "auth_select_products" ON products;
DROP POLICY IF EXISTS "auth_insert_products" ON products;
DROP POLICY IF EXISTS "auth_update_products" ON products;
DROP POLICY IF EXISTS "auth_delete_products" ON products;

CREATE POLICY "auth_select_products" ON products FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_products" ON products FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_products" ON products FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_products" ON products FOR DELETE TO authenticated USING (true);

-- customers
DROP POLICY IF EXISTS "anon_select_customers" ON customers;
DROP POLICY IF EXISTS "anon_insert_customers" ON customers;
DROP POLICY IF EXISTS "anon_update_customers" ON customers;
DROP POLICY IF EXISTS "anon_delete_customers" ON customers;
DROP POLICY IF EXISTS "auth_select_customers" ON customers;
DROP POLICY IF EXISTS "auth_insert_customers" ON customers;
DROP POLICY IF EXISTS "auth_update_customers" ON customers;
DROP POLICY IF EXISTS "auth_delete_customers" ON customers;

CREATE POLICY "auth_select_customers" ON customers FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_customers" ON customers FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_customers" ON customers FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_customers" ON customers FOR DELETE TO authenticated USING (true);

-- invoices
DROP POLICY IF EXISTS "anon_select_invoices" ON invoices;
DROP POLICY IF EXISTS "anon_insert_invoices" ON invoices;
DROP POLICY IF EXISTS "anon_update_invoices" ON invoices;
DROP POLICY IF EXISTS "anon_delete_invoices" ON invoices;
DROP POLICY IF EXISTS "auth_select_invoices" ON invoices;
DROP POLICY IF EXISTS "auth_insert_invoices" ON invoices;
DROP POLICY IF EXISTS "auth_update_invoices" ON invoices;
DROP POLICY IF EXISTS "auth_delete_invoices" ON invoices;

CREATE POLICY "auth_select_invoices" ON invoices FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_invoices" ON invoices FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_invoices" ON invoices FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_invoices" ON invoices FOR DELETE TO authenticated USING (true);

-- invoice_items
DROP POLICY IF EXISTS "anon_select_invoice_items" ON invoice_items;
DROP POLICY IF EXISTS "anon_insert_invoice_items" ON invoice_items;
DROP POLICY IF EXISTS "anon_update_invoice_items" ON invoice_items;
DROP POLICY IF EXISTS "anon_delete_invoice_items" ON invoice_items;
DROP POLICY IF EXISTS "auth_select_invoice_items" ON invoice_items;
DROP POLICY IF EXISTS "auth_insert_invoice_items" ON invoice_items;
DROP POLICY IF EXISTS "auth_update_invoice_items" ON invoice_items;
DROP POLICY IF EXISTS "auth_delete_invoice_items" ON invoice_items;

CREATE POLICY "auth_select_invoice_items" ON invoice_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_invoice_items" ON invoice_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_invoice_items" ON invoice_items FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_invoice_items" ON invoice_items FOR DELETE TO authenticated USING (true);

-- payments
DROP POLICY IF EXISTS "anon_select_payments" ON payments;
DROP POLICY IF EXISTS "anon_insert_payments" ON payments;
DROP POLICY IF EXISTS "anon_update_payments" ON payments;
DROP POLICY IF EXISTS "anon_delete_payments" ON payments;
DROP POLICY IF EXISTS "auth_select_payments" ON payments;
DROP POLICY IF EXISTS "auth_insert_payments" ON payments;
DROP POLICY IF EXISTS "auth_update_payments" ON payments;
DROP POLICY IF EXISTS "auth_delete_payments" ON payments;

CREATE POLICY "auth_select_payments" ON payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_payments" ON payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_payments" ON payments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_payments" ON payments FOR DELETE TO authenticated USING (true);

-- stock_movements
DROP POLICY IF EXISTS "anon_select_stock_movements" ON stock_movements;
DROP POLICY IF EXISTS "anon_insert_stock_movements" ON stock_movements;
DROP POLICY IF EXISTS "anon_update_stock_movements" ON stock_movements;
DROP POLICY IF EXISTS "anon_delete_stock_movements" ON stock_movements;
DROP POLICY IF EXISTS "auth_select_stock_movements" ON stock_movements;
DROP POLICY IF EXISTS "auth_insert_stock_movements" ON stock_movements;
DROP POLICY IF EXISTS "auth_update_stock_movements" ON stock_movements;
DROP POLICY IF EXISTS "auth_delete_stock_movements" ON stock_movements;

CREATE POLICY "auth_select_stock_movements" ON stock_movements FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_stock_movements" ON stock_movements FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_stock_movements" ON stock_movements FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_stock_movements" ON stock_movements FOR DELETE TO authenticated USING (true);

-- pos_sales
DROP POLICY IF EXISTS "anon_select_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "anon_insert_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "anon_update_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "anon_delete_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "auth_select_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "auth_insert_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "auth_update_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "auth_delete_pos_sales" ON pos_sales;

CREATE POLICY "auth_select_pos_sales" ON pos_sales FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_pos_sales" ON pos_sales FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_pos_sales" ON pos_sales FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_pos_sales" ON pos_sales FOR DELETE TO authenticated USING (true);

-- pos_sale_items
DROP POLICY IF EXISTS "anon_select_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "anon_insert_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "anon_update_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "anon_delete_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "auth_select_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "auth_insert_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "auth_update_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "auth_delete_pos_sale_items" ON pos_sale_items;

CREATE POLICY "auth_select_pos_sale_items" ON pos_sale_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_pos_sale_items" ON pos_sale_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_pos_sale_items" ON pos_sale_items FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_pos_sale_items" ON pos_sale_items FOR DELETE TO authenticated USING (true);

-- pos_payments
DROP POLICY IF EXISTS "anon_select_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "anon_insert_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "anon_update_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "anon_delete_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "auth_select_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "auth_insert_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "auth_update_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "auth_delete_pos_payments" ON pos_payments;

CREATE POLICY "auth_select_pos_payments" ON pos_payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_pos_payments" ON pos_payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_pos_payments" ON pos_payments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_pos_payments" ON pos_payments FOR DELETE TO authenticated USING (true);
