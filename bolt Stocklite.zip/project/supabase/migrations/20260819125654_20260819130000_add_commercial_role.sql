/*
# Add 'commercial' role + commercial_id link on user_profiles

## Changes
- Drop the existing role CHECK constraint and recreate it to include 'commercial'.
- Add `commercial_id` column (nullable FK to commerciaux) so an admin can link
  a user account to a commercial record.
- RLS already allows anon/authenticated full CRUD on user_profiles, so no
  policy changes are needed.
*/

ALTER TABLE user_profiles
  DROP CONSTRAINT IF EXISTS user_profiles_role_check;

ALTER TABLE user_profiles
  ADD CONSTRAINT user_profiles_role_check
  CHECK (role IN ('admin', 'caissier', 'gerant', 'commercial'));

ALTER TABLE user_profiles
  ADD COLUMN IF NOT EXISTS commercial_id uuid REFERENCES commerciaux(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_user_profiles_commercial_id ON user_profiles(commercial_id);
