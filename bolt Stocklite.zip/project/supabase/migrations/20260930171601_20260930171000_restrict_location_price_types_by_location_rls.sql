/*
# Restrict location_product_price_types SELECT by assigned location
*/
DROP POLICY IF EXISTS location_product_price_types_select_tenant ON location_product_price_types;

CREATE POLICY location_product_price_types_select_tenant ON location_product_price_types FOR SELECT
  TO authenticated
  USING (
    is_super_admin()
    OR (
      tenant_id = get_user_tenant_id()
      AND (
        user_can_access_all_locations()
        OR location_id = user_location_id()
      )
    )
  );