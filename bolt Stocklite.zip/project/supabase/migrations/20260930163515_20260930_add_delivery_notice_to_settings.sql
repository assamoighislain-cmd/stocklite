/*
# Add delivery_notice to company_settings

1. Changes
- Add `delivery_notice` (text, nullable) column to `company_settings`.
  Stores a configurable observation/notice printed at the foot of delivery notes.
2. Security
- No RLS changes — company_settings already has existing policies.
3. Notes
- Idempotent: uses DO $$ ... IF NOT EXISTS ... END $$ so re-runs are safe.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'company_settings' AND column_name = 'delivery_notice'
  ) THEN
    ALTER TABLE company_settings ADD COLUMN delivery_notice text;
  END IF;
END $$;