/*
# Create sales_contracts table

1. New Tables
- `sales_contracts` — stores configurable sales contract templates that print as the second page of an invoice.
  - `id` (uuid PK)
  - `title` (text) — display name for the contract template
  - `intro_text` (text) — introductory paragraph shown at the top of the contract page
  - `terms` (text[]) — array of clause/term lines, each rendered as a numbered bullet
  - `signature_label` (text) — label above the signature area (e.g. "Le Vendeur", "Le Client")
  - `is_active` (boolean) — whether this contract template is currently in use
  - `tenant_id` (uuid) — multi-tenant isolation, auto-set on insert
  - `created_at`, `updated_at` (timestamptz)

2. Security
- Enable RLS on `sales_contracts`.
- Tenant-scoped CRUD using `get_user_tenant_id()` matching the pattern used across the schema.
*/

CREATE TABLE IF NOT EXISTS sales_contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Conditions de vente',
  intro_text text NOT NULL DEFAULT '',
  terms text[] NOT NULL DEFAULT '{}',
  signature_label text NOT NULL DEFAULT 'Signature',
  is_active boolean NOT NULL DEFAULT true,
  tenant_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE sales_contracts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_sales_contracts" ON sales_contracts;
CREATE POLICY "select_own_sales_contracts" ON sales_contracts FOR SELECT
  TO authenticated USING (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "insert_own_sales_contracts" ON sales_contracts;
CREATE POLICY "insert_own_sales_contracts" ON sales_contracts FOR INSERT
  TO authenticated WITH CHECK (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "update_own_sales_contracts" ON sales_contracts;
CREATE POLICY "update_own_sales_contracts" ON sales_contracts FOR UPDATE
  TO authenticated USING (tenant_id = get_user_tenant_id())
  WITH CHECK (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "delete_own_sales_contracts" ON sales_contracts;
CREATE POLICY "delete_own_sales_contracts" ON sales_contracts FOR DELETE
  TO authenticated USING (tenant_id = get_user_tenant_id());
