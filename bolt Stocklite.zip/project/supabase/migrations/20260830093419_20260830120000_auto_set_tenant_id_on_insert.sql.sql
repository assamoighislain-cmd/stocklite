/*
# Auto-populate tenant_id on insert for all tenant-scoped tables

## Problem
The multi-tenant migration added `tenant_id` columns and RLS policies requiring
`tenant_id = get_user_tenant_id()` on every tenant-scoped table. However, no database
trigger auto-populates `tenant_id` on insert, and the application code does not set it
either. As a result, new records (POS sales, invoices, etc.) are created with
`tenant_id = null`, which fails the RLS check `tenant_id = get_user_tenant_id()` —
making them invisible to the user who created them.

## Fix
1. Create a trigger function `set_tenant_id_on_insert()` that sets `NEW.tenant_id`
   to the current user's tenant ID (via `get_user_tenant_id()`) when it is null.
2. Attach a BEFORE INSERT trigger to every tenant-scoped table so all future inserts
   get the correct `tenant_id` automatically — regardless of whether the application
   code passes it.
3. Backfill existing rows with `tenant_id = null`:
   a. Tables with `location_id` → infer from `sales_locations.tenant_id`.
   b. Tables with `user_id` → infer from `user_profiles.tenant_id`.
   c. Child tables (no location/user) → infer from their parent row's `tenant_id`.
   d. Standalone tables → infer from `company_settings.tenant_id`.

## Security
No RLS policy changes — existing policies remain. The trigger only fills in the
`tenant_id` that the RLS policies already require, making inserts work correctly.
*/

-- ── 1. Trigger function ──────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.set_tenant_id_on_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.tenant_id IS NULL THEN
    NEW.tenant_id := public.get_user_tenant_id();
  END IF;
  RETURN NEW;
END;
$$;

-- ── 2. Attach trigger to every tenant-scoped table ───────────────
DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'accounting_entries','admin_notifications','caisse_closing_lines',
    'caisse_closings','caisses','commerciaux','company_settings',
    'custom_units','customers','deletes_log','delivery_note_items',
    'delivery_notes','dotation_items','dotations','held_carts',
    'invoice_items','invoices','license_payments',
    'location_product_price_types','location_stock','order_items',
    'orders','payments','pos_payments','pos_sale_items','pos_sales',
    'price_types','product_families','product_price_types','products',
    'push_subscriptions','sales_locations','services','stock_movements',
    'stock_transfers','subscriptions','supplier_payments','suppliers'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trg_set_tenant_id ON %I; '
      'CREATE TRIGGER trg_set_tenant_id BEFORE INSERT ON %I '
      'FOR EACH ROW EXECUTE FUNCTION public.set_tenant_id_on_insert();',
      t, t
    );
  END LOOP;
END;
$$;

-- ── 3a. Backfill: tables with location_id ────────────────────────
DO $$
DECLARE
  t text;
  loc_tables text[] := ARRAY[
    'pos_sales','invoices','stock_movements','location_stock',
    'location_product_price_types','held_carts','dotations',
    'caisses','caisse_closings','delivery_notes','delivery_note_items',
    'orders','commerciaux','services','accounting_entries',
    'customers','suppliers','supplier_payments'
  ];
BEGIN
  FOREACH t IN ARRAY loc_tables LOOP
    EXECUTE format(
      'UPDATE %I SET tenant_id = sl.tenant_id '
      'FROM sales_locations sl '
      'WHERE %I.tenant_id IS NULL '
      'AND %I.location_id IS NOT NULL '
      'AND sl.id = %I.location_id;',
      t, t, t, t
    );
  END LOOP;
END;
$$;

-- ── 3b. Backfill: tables with user_id ────────────────────────────
UPDATE push_subscriptions SET tenant_id = up.tenant_id
  FROM user_profiles up
  WHERE push_subscriptions.tenant_id IS NULL
    AND up.id = push_subscriptions.user_id;

-- ── 3c. Backfill: child tables via parent ─────────────────────────
UPDATE pos_sale_items psi SET tenant_id = ps.tenant_id
  FROM pos_sales ps
  WHERE psi.tenant_id IS NULL AND ps.id = psi.sale_id;

UPDATE pos_payments pp SET tenant_id = ps.tenant_id
  FROM pos_sales ps
  WHERE pp.tenant_id IS NULL AND ps.id = pp.sale_id;

UPDATE invoice_items ii SET tenant_id = i.tenant_id
  FROM invoices i
  WHERE ii.tenant_id IS NULL AND i.id = ii.invoice_id;

UPDATE order_items oi SET tenant_id = o.tenant_id
  FROM orders o
  WHERE oi.tenant_id IS NULL AND o.id = oi.order_id;

UPDATE dotation_items di SET tenant_id = d.tenant_id
  FROM dotations d
  WHERE di.tenant_id IS NULL AND d.id = di.dotation_id;

UPDATE caisse_closing_lines ccl SET tenant_id = cc.tenant_id
  FROM caisse_closings cc
  WHERE ccl.tenant_id IS NULL AND cc.id = ccl.closing_id;

UPDATE stock_transfers SET tenant_id = sl.tenant_id
  FROM sales_locations sl
  WHERE stock_transfers.tenant_id IS NULL
    AND stock_transfers.from_location_id IS NOT NULL
    AND sl.id = stock_transfers.from_location_id;

UPDATE payments SET tenant_id = c.tenant_id
  FROM customers c
  WHERE payments.tenant_id IS NULL
    AND payments.customer_id IS NOT NULL
    AND c.id = payments.customer_id;

-- ── 3d. Backfill: standalone tables ─────────────────────────────
UPDATE products SET tenant_id = ls.tenant_id
  FROM location_stock ls
  WHERE products.tenant_id IS NULL
    AND ls.product_id = products.id
    AND ls.tenant_id IS NOT NULL;

UPDATE product_families SET tenant_id = p.tenant_id
  FROM products p
  WHERE product_families.tenant_id IS NULL
    AND p.family_id = product_families.id
    AND p.tenant_id IS NOT NULL;

UPDATE product_price_types SET tenant_id = p.tenant_id
  FROM products p
  WHERE product_price_types.tenant_id IS NULL
    AND p.id = product_price_types.product_id
    AND p.tenant_id IS NOT NULL;

-- company_settings: infer from any admin user's tenant_id
UPDATE company_settings cs SET tenant_id = sub.tenant_id
  FROM (
    SELECT up.tenant_id
    FROM user_profiles up
    WHERE up.role = 'admin' AND up.tenant_id IS NOT NULL
    ORDER BY up.tenant_id
    LIMIT 1
  ) sub
  WHERE cs.tenant_id IS NULL;

-- price_types, custom_units: infer from company_settings
UPDATE price_types SET tenant_id = cs.tenant_id
  FROM company_settings cs
  WHERE price_types.tenant_id IS NULL
    AND cs.tenant_id IS NOT NULL;

UPDATE custom_units SET tenant_id = cs.tenant_id
  FROM company_settings cs
  WHERE custom_units.tenant_id IS NULL
    AND cs.tenant_id IS NOT NULL;

-- subscriptions, license_payments: infer from tenants table
UPDATE subscriptions SET tenant_id = t.id
  FROM tenants t
  WHERE subscriptions.tenant_id IS NULL;

UPDATE license_payments SET tenant_id = t.id
  FROM tenants t
  WHERE license_payments.tenant_id IS NULL
    AND t.id IS NOT NULL;
