-- Transfer existing category→family links to direct family_id on products
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'family_id'
  ) THEN
    ALTER TABLE products ADD COLUMN family_id uuid REFERENCES product_families(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Backfill from category_id
UPDATE products p
SET family_id = pc.family_id
FROM product_categories pc
WHERE p.category_id = pc.id
  AND p.family_id IS NULL;

-- Drop category_id and product_categories
ALTER TABLE products DROP COLUMN IF EXISTS category_id;
DROP TABLE IF EXISTS product_categories CASCADE;
