/*
# Product-Supplier junction table

1. New Table
- `product_suppliers` — many-to-many between products and suppliers
  - product_id (uuid, FK to products ON DELETE CASCADE)
  - supplier_id (uuid, FK to suppliers ON DELETE CASCADE)
  - is_default (bool, default false) — marks the preferred supplier
  - supply_price (numeric, nullable) — purchase price from this specific supplier
  - supply_unit (text, nullable) — unit the supplier uses
  - created_at (timestamptz, default now())
  - Primary key: (product_id, supplier_id)

2. RLS — scoped through products.tenant_id = get_user_tenant_id() (same pattern as other child tables)
*/

CREATE TABLE IF NOT EXISTS product_suppliers (
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  supplier_id uuid NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  is_default boolean NOT NULL DEFAULT false,
  supply_price numeric(14,2),
  supply_unit text,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (product_id, supplier_id)
);

ALTER TABLE product_suppliers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_tenant_product_suppliers" ON product_suppliers FOR SELECT
  TO authenticated USING (
    is_super_admin() OR product_id IN (
      SELECT id FROM products WHERE tenant_id = get_user_tenant_id()
    )
  );

CREATE POLICY "insert_tenant_product_suppliers" ON product_suppliers FOR INSERT
  TO authenticated WITH CHECK (
    is_super_admin() OR product_id IN (
      SELECT id FROM products WHERE tenant_id = get_user_tenant_id()
    )
  );

CREATE POLICY "update_tenant_product_suppliers" ON product_suppliers FOR UPDATE
  TO authenticated USING (
    is_super_admin() OR product_id IN (
      SELECT id FROM products WHERE tenant_id = get_user_tenant_id()
    )
  ) WITH CHECK (
    is_super_admin() OR product_id IN (
      SELECT id FROM products WHERE tenant_id = get_user_tenant_id()
    )
  );

CREATE POLICY "delete_tenant_product_suppliers" ON product_suppliers FOR DELETE
  TO authenticated USING (
    is_super_admin() OR product_id IN (
      SELECT id FROM products WHERE tenant_id = get_user_tenant_id()
    )
  );