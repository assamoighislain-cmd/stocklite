/*
# Prix par type de prix et par boutique

## Description
Permet à chaque article d'avoir des prix spécifiques par type de prix (Détail, Gros, etc.)
**et par boutique**. Jusqu'ici les types de prix étaient globaux (un seul prix par type
pour l'article, identique dans toutes les boutiques). Désormais on peut configurer un
prix différent pour chaque couple (article, boutique, type de prix).

## Nouvelle table
### `location_product_price_types`
- `id` : identifiant unique (text, composite key `product_location_type`)
- `product_id` : article (FK → products)
- `location_id` : boutique (FK → sales_locations)
- `price_type_id` : type de prix (FK → price_types)
- `price` : montant pour ce type de prix dans cette boutique
- `created_at` : date de création
- `updated_at` : date de mise à jour
- Contrainte UNIQUE sur (product_id, location_id, price_type_id)

## Logique de priorité des prix
1. Si un prix existe dans `location_product_price_types` pour (article, boutique, type) → utiliser ce prix.
2. Sinon, si un prix existe dans `product_price_types` pour (article, type) → utiliser ce prix global.
3. Sinon, si `location_stock.price` est défini pour (article, boutique) → utiliser ce prix.
4. Sinon, utiliser `product.price` (prix standard global).

## Sécurité
- RLS activé sur `location_product_price_types`.
- Tous les utilisateurs authentifiés peuvent lire, créer, modifier et supprimer
  (contexte multi-utilisateurs, données partagées).

## Notes importantes
1. Cette table est optionnelle : si aucune ligne n'existe pour un article/boutique/type,
   le système retombe sur le prix global du type (`product_price_types`), puis sur
   `location_stock.price`, puis sur `product.price`.
2. Les suppressions sont logiques (soft delete) côté application pour la synchronisation.
*/

-- ── location_product_price_types ───────────────────────────────────

CREATE TABLE IF NOT EXISTS location_product_price_types (
  id            text PRIMARY KEY,
  product_id    uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  location_id   uuid NOT NULL REFERENCES sales_locations(id) ON DELETE CASCADE,
  price_type_id uuid NOT NULL REFERENCES price_types(id) ON DELETE CASCADE,
  price         numeric(12,2) NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE(product_id, location_id, price_type_id)
);

ALTER TABLE location_product_price_types ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "lppt_select" ON location_product_price_types;
CREATE POLICY "lppt_select" ON location_product_price_types FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "lppt_insert" ON location_product_price_types;
CREATE POLICY "lppt_insert" ON location_product_price_types FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "lppt_update" ON location_product_price_types;
CREATE POLICY "lppt_update" ON location_product_price_types FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "lppt_delete" ON location_product_price_types;
CREATE POLICY "lppt_delete" ON location_product_price_types FOR DELETE
  TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_lppt_product  ON location_product_price_types(product_id);
CREATE INDEX IF NOT EXISTS idx_lppt_location ON location_product_price_types(location_id);
CREATE INDEX IF NOT EXISTS idx_lppt_type     ON location_product_price_types(price_type_id);
