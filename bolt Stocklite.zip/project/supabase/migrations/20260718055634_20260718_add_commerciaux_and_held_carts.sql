/*
# Commerciaux et Paniers en attente

## Description
Ajout de deux nouvelles tables pour gérer les commerciaux et les paniers mis en attente de règlement à la caisse.

## Nouvelles tables

### 1. `commerciaux`
Représente les vendeurs/commerciaux assignables à une vente POS.
- `id` : identifiant unique (uuid)
- `name` : nom complet du commercial (obligatoire)
- `phone` : numéro de téléphone (optionnel)
- `active` : actif/inactif (défaut true)
- `location_id` : boutique d'appartenance (optionnel, FK vers sales_locations)
- `created_at` : date de création

### 2. `held_carts`
Paniers sauvegardés temporairement en attente de règlement.
- `id` : identifiant unique (uuid)
- `label` : étiquette optionnelle (ex : "Table 3", "Client VIP")
- `commercial_id` : commercial assigné (optionnel, FK vers commerciaux)
- `customer_id` : client associé (optionnel, FK vers customers)
- `items` : lignes du panier au format JSONB (tableau d'objets {product_id, description, unit_price, quantity})
- `discount_pct` : pourcentage de remise (défaut 0)
- `tax_rate` : taux de TVA (défaut 0)
- `notes` : notes libres
- `location_id` : boutique (optionnel, FK vers sales_locations)
- `created_by` : utilisateur qui a mis en attente (FK vers auth.users)
- `created_at` : date de création

## Sécurité
- RLS activé sur les deux tables.
- Tous les utilisateurs authentifiés peuvent lire, créer, modifier et supprimer les paniers en attente (contexte POS partagé).
- Idem pour les commerciaux.
*/

-- ── commerciaux ──────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS commerciaux (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL,
  phone       text NOT NULL DEFAULT '',
  active      boolean NOT NULL DEFAULT true,
  location_id uuid REFERENCES sales_locations(id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE commerciaux ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "commerciaux_select" ON commerciaux;
CREATE POLICY "commerciaux_select" ON commerciaux FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "commerciaux_insert" ON commerciaux;
CREATE POLICY "commerciaux_insert" ON commerciaux FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "commerciaux_update" ON commerciaux;
CREATE POLICY "commerciaux_update" ON commerciaux FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "commerciaux_delete" ON commerciaux;
CREATE POLICY "commerciaux_delete" ON commerciaux FOR DELETE
  TO authenticated USING (true);

-- ── held_carts ────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS held_carts (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label         text NOT NULL DEFAULT '',
  commercial_id uuid REFERENCES commerciaux(id) ON DELETE SET NULL,
  customer_id   uuid REFERENCES customers(id) ON DELETE SET NULL,
  items         jsonb NOT NULL DEFAULT '[]'::jsonb,
  discount_pct  numeric NOT NULL DEFAULT 0,
  tax_rate      numeric NOT NULL DEFAULT 0,
  notes         text NOT NULL DEFAULT '',
  location_id   uuid REFERENCES sales_locations(id) ON DELETE SET NULL,
  created_by    uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE held_carts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "held_carts_select" ON held_carts;
CREATE POLICY "held_carts_select" ON held_carts FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "held_carts_insert" ON held_carts;
CREATE POLICY "held_carts_insert" ON held_carts FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "held_carts_update" ON held_carts;
CREATE POLICY "held_carts_update" ON held_carts FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "held_carts_delete" ON held_carts;
CREATE POLICY "held_carts_delete" ON held_carts FOR DELETE
  TO authenticated USING (true);

-- Index utiles
CREATE INDEX IF NOT EXISTS held_carts_location_idx ON held_carts(location_id);
CREATE INDEX IF NOT EXISTS commerciaux_location_idx ON commerciaux(location_id);
