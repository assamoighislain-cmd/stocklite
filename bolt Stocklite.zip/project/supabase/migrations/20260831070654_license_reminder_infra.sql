/*
# License reminder infrastructure

1. Purpose
   - Enables the `pg_cron` and `http` extensions so the database can run a
     scheduled job every day that calls a license-reminder edge function.
   - Adds a `last_license_reminder_at` column to `tenants` so we can track the
     last time a reminder was sent and avoid duplicate notifications.

2. Changes
   - `CREATE EXTENSION IF NOT EXISTS pg_cron;`
   - `CREATE EXTENSION IF NOT EXISTS http;`
   - `ALTER TABLE tenants ADD COLUMN last_license_reminder_at timestamptz;`

3. Notes
   - pg_cron jobs run in the GMT timezone by default.
   - The `http` extension allows `net.http_post` calls from pg_cron.
*/

CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS http;

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS last_license_reminder_at timestamptz;
