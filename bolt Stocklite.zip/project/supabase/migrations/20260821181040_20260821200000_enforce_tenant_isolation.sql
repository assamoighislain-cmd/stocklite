/*
# Enforce tenant isolation: defaults + tenant-scoped RLS on all data tables

## Summary
Users must only see and modify data within their assigned company (tenant).
Previously, most RLS policies used USING(true) or only checked location,
letting any authenticated user access all data across all tenants.

## Changes

### 1. Tenant_id defaults
Set DEFAULT get_user_tenant_id() on tenant_id columns for all data tables
so that frontend inserts (which omit tenant_id) auto-fill with the user's tenant.

### 2. Child tables: add tenant_id
Added tenant_id to child tables that lacked it:
- caisse_closing_lines (child of caisse_closings)
- pos_payments (child of pos_sales)
- location_product_price_types (child of location_stock / products)
- product_price_types (child of products / price_types)

### 3. RLS policies replaced
Dropped ALL existing policies on every data table and replaced with
tenant-scoped policies:
- SELECT: tenant_id = get_user_tenant_id() OR is_super_admin()
- INSERT: WITH CHECK tenant_id = get_user_tenant_id() (or super_admin)
- UPDATE: USING + WITH CHECK tenant_id = get_user_tenant_id() (or super_admin)
- DELETE: USING tenant_id = get_user_tenant_id() (or super_admin)

For child tables without a direct tenant_id, policies scope through the
parent table via EXISTS subquery.

### 4. user_profiles policies
- Users can read their own profile
- Admins/super_admins can read all profiles in their tenant
- Super_admins can update any profile's tenant_id and role
- Users can update their own profile (name only)

### 5. deletes_log
- Super_admin only (admin maintenance table)

### Notes
- holdings and watchlist tables appear unused by this app (template leftovers).
  They get tenant-scoped policies for safety.
- tenants and subscriptions already have proper policies from the multi-tenant migration.
*/

-- ============================================================
-- STEP 1: Add tenant_id to child tables that lack it
-- ============================================================

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='caisse_closing_lines' AND column_name='tenant_id') THEN
    ALTER TABLE caisse_closing_lines ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pos_payments' AND column_name='tenant_id') THEN
    ALTER TABLE pos_payments ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='location_product_price_types' AND column_name='tenant_id') THEN
    ALTER TABLE location_product_price_types ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='product_price_types' AND column_name='tenant_id') THEN
    ALTER TABLE product_price_types ADD COLUMN tenant_id uuid REFERENCES tenants(id);
  END IF;
END $$;

-- Backfill tenant_id on child tables from their parents
UPDATE caisse_closing_lines cl
SET tenant_id = cc.tenant_id
FROM caisse_closings cc
WHERE cl.closing_id = cc.id
  AND cl.tenant_id IS NULL
  AND cc.tenant_id IS NOT NULL;

UPDATE pos_payments pp
SET tenant_id = ps.tenant_id
FROM pos_sales ps
WHERE pp.sale_id = ps.id
  AND pp.tenant_id IS NULL
  AND ps.tenant_id IS NOT NULL;

UPDATE location_product_price_types lppt
SET tenant_id = ls.tenant_id
FROM location_stock ls
WHERE lppt.location_id = ls.location_id
  AND lppt.product_id = ls.product_id
  AND lppt.tenant_id IS NULL
  AND ls.tenant_id IS NOT NULL;

UPDATE product_price_types ppt
SET tenant_id = p.tenant_id
FROM products p
WHERE ppt.product_id = p.id
  AND ppt.tenant_id IS NULL
  AND p.tenant_id IS NOT NULL;

-- ============================================================
-- STEP 2: Set DEFAULT get_user_tenant_id() on all tenant_id columns
-- ============================================================

DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'products','customers','invoices','invoice_items','payments',
    'stock_movements','pos_sales','pos_sale_items','company_settings',
    'product_families','sales_locations','location_stock','commerciaux',
    'held_carts','price_types','stock_transfers','caisses','caisse_closings',
    'caisse_closing_lines','accounting_entries','services','dotations',
    'dotation_items','orders','order_items','suppliers','delivery_notes',
    'delivery_note_items','supplier_payments','pos_payments',
    'location_product_price_types','product_price_types'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    IF EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name=t AND column_name='tenant_id'
    ) THEN
      EXECUTE format('ALTER TABLE %I ALTER COLUMN tenant_id SET DEFAULT get_user_tenant_id()', t);
    END IF;
  END LOOP;
END $$;

-- ============================================================
-- STEP 3: Drop ALL existing policies on data tables
-- ============================================================

DO $$
DECLARE
  r record;
  tables text[] := ARRAY[
    'products','customers','invoices','invoice_items','payments',
    'stock_movements','pos_sales','pos_sale_items','company_settings',
    'product_families','sales_locations','location_stock','commerciaux',
    'held_carts','price_types','stock_transfers','caisses','caisse_closings',
    'caisse_closing_lines','accounting_entries','services','dotations',
    'dotation_items','orders','order_items','suppliers','delivery_notes',
    'delivery_note_items','supplier_payments','pos_payments',
    'location_product_price_types','product_price_types',
    'user_profiles','deletes_log','holdings','watchlist'
  ];
  t text;
BEGIN
  FOREACH t IN ARRAY tables LOOP
    FOR r IN SELECT policyname FROM pg_policies WHERE schemaname='public' AND tablename=t LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON %I', r.policyname, t);
    END LOOP;
  END LOOP;
END $$;

-- ============================================================
-- STEP 4: Create tenant-scoped policies for all data tables
-- ============================================================

-- Helper: generate 4 CRUD policies for a table with direct tenant_id
DO $$
DECLARE
  -- Tables with direct tenant_id column
  direct_tables text[] := ARRAY[
    'products','customers','invoices','invoice_items','payments',
    'stock_movements','pos_sales','pos_sale_items','company_settings',
    'product_families','sales_locations','location_stock','commerciaux',
    'held_carts','price_types','stock_transfers','caisses','caisse_closings',
    'caisse_closing_lines','accounting_entries','services','dotations',
    'dotation_items','orders','order_items','suppliers','delivery_notes',
    'delivery_note_items','supplier_payments','pos_payments',
    'location_product_price_types','product_price_types'
  ];
  t text;
BEGIN
  FOREACH t IN ARRAY direct_tables LOOP
    EXECUTE format('
      CREATE POLICY "%1$s_select_tenant" ON %1$s FOR SELECT TO authenticated
        USING (is_super_admin() OR tenant_id = get_user_tenant_id());
      CREATE POLICY "%1$s_insert_tenant" ON %1$s FOR INSERT TO authenticated
        WITH CHECK (is_super_admin() OR tenant_id = get_user_tenant_id());
      CREATE POLICY "%1$s_update_tenant" ON %1$s FOR UPDATE TO authenticated
        USING (is_super_admin() OR tenant_id = get_user_tenant_id())
        WITH CHECK (is_super_admin() OR tenant_id = get_user_tenant_id());
      CREATE POLICY "%1$s_delete_tenant" ON %1$s FOR DELETE TO authenticated
        USING (is_super_admin() OR tenant_id = get_user_tenant_id());
    ', t);
  END LOOP;
END $$;

-- ============================================================
-- STEP 5: user_profiles policies
-- ============================================================

-- Users can read their own profile; admins can read all profiles in their tenant
CREATE POLICY "user_profiles_select" ON user_profiles FOR SELECT TO authenticated
  USING (
    id = auth.uid()
    OR is_super_admin()
    OR (is_admin() AND tenant_id = get_user_tenant_id())
  );

-- Users can update their own profile (name only — not role/tenant_id)
CREATE POLICY "user_profiles_update_own" ON user_profiles FOR UPDATE TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- Super_admin can update any profile
CREATE POLICY "user_profiles_update_admin" ON user_profiles FOR UPDATE TO authenticated
  USING (is_super_admin())
  WITH CHECK (is_super_admin());

-- Super_admin can insert profiles (for user creation flow)
CREATE POLICY "user_profiles_insert" ON user_profiles FOR INSERT TO authenticated
  WITH CHECK (is_super_admin() OR id = auth.uid());

-- Super_admin can delete profiles
CREATE POLICY "user_profiles_delete" ON user_profiles FOR DELETE TO authenticated
  USING (is_super_admin());

-- ============================================================
-- STEP 6: deletes_log — super_admin only
-- ============================================================

CREATE POLICY "deletes_log_select" ON deletes_log FOR SELECT TO authenticated
  USING (is_super_admin());

-- ============================================================
-- STEP 7: holdings & watchlist — tenant-scoped (template leftovers, unused)
-- ============================================================

-- These tables have no tenant_id column; lock to super_admin only
CREATE POLICY "holdings_select" ON holdings FOR SELECT TO authenticated
  USING (is_super_admin());
CREATE POLICY "holdings_insert" ON holdings FOR INSERT TO authenticated
  WITH CHECK (is_super_admin());
CREATE POLICY "holdings_update" ON holdings FOR UPDATE TO authenticated
  USING (is_super_admin()) WITH CHECK (is_super_admin());
CREATE POLICY "holdings_delete" ON holdings FOR DELETE TO authenticated
  USING (is_super_admin());

CREATE POLICY "watchlist_select" ON watchlist FOR SELECT TO authenticated
  USING (is_super_admin());
CREATE POLICY "watchlist_insert" ON watchlist FOR INSERT TO authenticated
  WITH CHECK (is_super_admin());
CREATE POLICY "watchlist_update" ON watchlist FOR UPDATE TO authenticated
  USING (is_super_admin()) WITH CHECK (is_super_admin());
CREATE POLICY "watchlist_delete" ON watchlist FOR DELETE TO authenticated
  USING (is_super_admin());

-- ============================================================
-- STEP 8: Indexes for tenant_id on child tables
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_caisse_closing_lines_tenant ON caisse_closing_lines(tenant_id);
CREATE INDEX IF NOT EXISTS idx_pos_payments_tenant ON pos_payments(tenant_id);
CREATE INDEX IF NOT EXISTS idx_location_product_price_types_tenant ON location_product_price_types(tenant_id);
CREATE INDEX IF NOT EXISTS idx_product_price_types_tenant ON product_price_types(tenant_id);
CREATE INDEX IF NOT EXISTS idx_invoice_items_tenant ON invoice_items(tenant_id);
CREATE INDEX IF NOT EXISTS idx_pos_sale_items_tenant ON pos_sale_items(tenant_id);
CREATE INDEX IF NOT EXISTS idx_order_items_tenant ON order_items(tenant_id);
CREATE INDEX IF NOT EXISTS idx_delivery_note_items_tenant ON delivery_note_items(tenant_id);
CREATE INDEX IF NOT EXISTS idx_dotation_items_tenant ON dotation_items(tenant_id);
CREATE INDEX IF NOT EXISTS idx_payments_tenant ON payments(tenant_id);
CREATE INDEX IF NOT EXISTS idx_commerciaux_tenant ON commerciaux(tenant_id);
CREATE INDEX IF NOT EXISTS idx_held_carts_tenant ON held_carts(tenant_id);
CREATE INDEX IF NOT EXISTS idx_price_types_tenant ON price_types(tenant_id);
CREATE INDEX IF NOT EXISTS idx_stock_transfers_tenant ON stock_transfers(tenant_id);
CREATE INDEX IF NOT EXISTS idx_caisse_closings_tenant ON caisse_closings(tenant_id);
CREATE INDEX IF NOT EXISTS idx_accounting_entries_tenant ON accounting_entries(tenant_id);
CREATE INDEX IF NOT EXISTS idx_services_tenant ON services(tenant_id);
CREATE INDEX IF NOT EXISTS idx_dotations_tenant ON dotations(tenant_id);
CREATE INDEX IF NOT EXISTS idx_suppliers_tenant ON suppliers(tenant_id);
CREATE INDEX IF NOT EXISTS idx_delivery_notes_tenant ON delivery_notes(tenant_id);
CREATE INDEX IF NOT EXISTS idx_supplier_payments_tenant ON supplier_payments(tenant_id);
CREATE INDEX IF NOT EXISTS idx_company_settings_tenant ON company_settings(tenant_id);
CREATE INDEX IF NOT EXISTS idx_product_families_tenant ON product_families(tenant_id);
CREATE INDEX IF NOT EXISTS idx_sales_locations_tenant ON sales_locations(tenant_id);
CREATE INDEX IF NOT EXISTS idx_location_stock_tenant ON location_stock(tenant_id);
