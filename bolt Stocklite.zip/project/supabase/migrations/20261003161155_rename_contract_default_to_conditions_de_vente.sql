/*
# Rename default sales contract title to "Conditions de vente"

1. Changes
- Updates the column default on `sales_contracts.title` from 'Contrat de vente' to 'Conditions de vente'.
- Does NOT update existing rows — only affects future inserts that omit the title.
2. Notes
- No RLS or policy changes.
- Existing records keep their current title values.
*/

ALTER TABLE sales_contracts ALTER COLUMN title SET DEFAULT 'Conditions de vente';
