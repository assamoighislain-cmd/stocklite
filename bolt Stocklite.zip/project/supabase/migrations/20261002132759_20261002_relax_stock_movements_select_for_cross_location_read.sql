/*
# Allow cross-location stock movement reads (tenant-wide)

## Purpose
Commercial, caissier, and gerant roles need to **consult** stock levels
and movement history of ALL points of sale within their tenant, not just
their own assigned location. The previous policy restricted SELECT on
`stock_movements` to `location_id = user_location_id()`, which blocked
reading movements from other boutiques even though the user belongs to
the same tenant.

## Changes
1. Replace the SELECT policy on `stock_movements` with a tenant-scoped
   predicate: any authenticated user in the same tenant can read all
   movement rows. Super admins keep access via `is_super_admin()`.
2. INSERT/UPDATE/DELETE policies remain unchanged — writes are still
   restricted to the user's own location (or admin).

## Security
- SELECT: `is_super_admin() OR tenant_id = get_user_tenant_id()`
- No change to write policies — non-admins can still only write to
  their own `location_id`.
*/

DROP POLICY IF EXISTS "auth_select_stock_movements" ON stock_movements;
DROP POLICY IF EXISTS "stock_movements_select_tenant" ON stock_movements;

CREATE POLICY "stock_movements_select_tenant" ON stock_movements FOR SELECT
  TO authenticated
  USING (is_super_admin() OR (tenant_id = get_user_tenant_id()));