/*
# Fix: is_super_admin() / is_admin() infinite RLS recursion

## Problem
user_profiles has FORCED RLS. Its SELECT policy calls is_super_admin(),
which queries user_profiles → RLS policy fires → calls is_super_admin() again
→ infinite recursion. PostgreSQL aborts with "infinite recursion detected in
policy for relation user_profiles".

This breaks every operation that checks is_super_admin() or is_admin(),
including: creating a tenant (INSERT policy on tenants checks is_super_admin()),
reading user_profiles, etc.

## Fix
Rewrite is_super_admin() and is_admin() to read the role from
auth.users.raw_user_meta_data->>'role' instead of querying user_profiles.
auth.users is not subject to our RLS policies, so there is no recursion.

get_user_tenant_id() is also rewritten to read tenant_id from
auth.users.raw_user_meta_data, avoiding the same recursion on user_profiles.
*/

CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT COALESCE(
    (auth.uid() IS NOT NULL
     AND EXISTS (
       SELECT 1 FROM auth.users
       WHERE id = auth.uid()
         AND raw_user_meta_data->>'role' = 'super_admin'
     )),
    false
  )
$$;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT COALESCE(
    (auth.uid() IS NOT NULL
     AND EXISTS (
       SELECT 1 FROM auth.users
       WHERE id = auth.uid()
         AND raw_user_meta_data->>'role' IN ('admin', 'super_admin')
     )),
    false
  )
$$;

CREATE OR REPLACE FUNCTION public.get_user_tenant_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
STABLE
AS $$
  SELECT (
    SELECT NULLIF(raw_user_meta_data->>'tenant_id', '')::uuid
    FROM auth.users
    WHERE id = auth.uid()
  )
$$;
