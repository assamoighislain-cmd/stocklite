/*
# License Plans — automatic license management

1. New Tables
- `license_plans`: stores predefined subscription plans (monthly, annual, etc.)
  - `id` (uuid, PK)
  - `name` (text) — display name, e.g. "Mensuel", "Annuel"
  - `duration_days` (integer) — how many days the license is extended when this plan is purchased
  - `price` (integer) — price in XOF
  - `currency` (text, default 'XOF')
  - `active` (boolean, default true)
  - `sort_order` (integer, default 0)
  - `created_at` / `updated_at` (timestamptz)

2. Modified Tables
- `subscriptions`: adds `plan_id` (uuid, nullable FK → license_plans.id ON DELETE SET NULL)
  so each payment can reference the plan that was chosen.

3. Security (RLS)
- `license_plans`: RLS enabled. Super admin can do all CRUD.
  Regular authenticated users can read plans (they need to see pricing).
- `subscriptions` policies updated to allow super_admin insert/update/delete
  (already the case — no policy changes needed since plan_id is just a column).

4. Seed Data
- Inserts 3 default plans: Essentiel (30 days), Business (365 days), Essai (15 days free).

5. Important Notes
- The frontend will fetch plans and display them as selectable cards in the
  subscription modal. When a plan is chosen, the amount and duration are
  auto-filled. The createSubscription function calculates starts_at from today
  and ends_at = starts_at + duration_days, extending the tenant's license.
*/

CREATE TABLE IF NOT EXISTS license_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  duration_days integer NOT NULL CHECK (duration_days > 0),
  price integer NOT NULL DEFAULT 0 CHECK (price >= 0),
  currency text NOT NULL DEFAULT 'XOF',
  active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE license_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_license_plans" ON license_plans;
CREATE POLICY "read_license_plans"
  ON license_plans FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_license_plans" ON license_plans;
CREATE POLICY "insert_license_plans"
  ON license_plans FOR INSERT
  TO authenticated WITH CHECK (is_super_admin());

DROP POLICY IF EXISTS "update_license_plans" ON license_plans;
CREATE POLICY "update_license_plans"
  ON license_plans FOR UPDATE
  TO authenticated USING (is_super_admin()) WITH CHECK (is_super_admin());

DROP POLICY IF EXISTS "delete_license_plans" ON license_plans;
CREATE POLICY "delete_license_plans"
  ON license_plans FOR DELETE
  TO authenticated USING (is_super_admin());

-- Add plan_id column to subscriptions
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'plan_id'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN plan_id uuid REFERENCES license_plans(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Seed default plans (idempotent)
INSERT INTO license_plans (name, duration_days, price, currency, active, sort_order)
SELECT * FROM (VALUES
  ('Essai gratuit', 15, 0, 'XOF', true, 0),
  ('Mensuel', 30, 15000, 'XOF', true, 1),
  ('Annuel', 365, 150000, 'XOF', true, 2)
) AS v(name, duration_days, price, currency, active, sort_order)
WHERE NOT EXISTS (SELECT 1 FROM license_plans);
