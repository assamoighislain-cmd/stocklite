/*
# Add RNE field and warning message to FNE

1. Modified Tables
- `company_settings`: add `fne_rne` (text, nullable) — Registre du Commerce / RNE, distinct du NCC
- `invoices`: add `fne_warning_message` (text, nullable) — message d'avertissement détaillé renvoyé par la DGI

2. Security
- No RLS changes — these columns inherit existing policies.
- Additive only, no destructive operations.
*/

ALTER TABLE company_settings
  ADD COLUMN IF NOT EXISTS fne_rne text;

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS fne_warning_message text;
