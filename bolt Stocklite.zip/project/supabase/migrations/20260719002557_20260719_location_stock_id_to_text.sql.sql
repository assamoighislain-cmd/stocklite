-- Change location_stock.id from uuid to text so client-generated
-- composite IDs (productId_locationId) work as primary keys.
-- Existing UUID values are preserved as text strings (no data loss).

-- Drop the default first (gen_random_uuid() is not valid for text)
ALTER TABLE location_stock ALTER COLUMN id DROP DEFAULT;

-- Change the column type from uuid to text
ALTER TABLE location_stock ALTER COLUMN id TYPE text USING id::text;

-- The UNIQUE(product_id, location_id) constraint is kept as-is.
-- The composite id is now the natural key used by the client.
