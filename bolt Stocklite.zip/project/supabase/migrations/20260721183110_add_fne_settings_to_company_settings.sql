/*
# Add FNE configuration fields to company_settings

## Context
Interfacing with the DGI Côte d'Ivoire FNE platform. The company needs to
store its FNE credentials and default emission parameters so that invoices
can be certified without re-entering these values each time.

## Changes to existing table `company_settings`
- `fne_ncc` (text): The company's NCC contributor identifier (e.g. "9606123E").
- `fne_api_key` (text): Bearer token / API key from the FNE espace.
- `fne_point_of_sale` (text): Default point of sale name/number.
- `fne_establishment` (text): Default establishment name.
- `fne_api_url` (text): Override the default DGI API base URL (test vs prod).

All columns are nullable and default NULL so existing rows are unaffected.

## Security
- No new tables; RLS already enabled on `company_settings`. No policy changes.
- The API key is stored in company_settings; it is readable by the anon client
  because this app uses anon/authenticated shared policies (single-tenant mode).
  In a future hardening pass, the key could be moved to an edge function secret.
*/

ALTER TABLE company_settings
  ADD COLUMN IF NOT EXISTS fne_ncc text,
  ADD COLUMN IF NOT EXISTS fne_api_key text,
  ADD COLUMN IF NOT EXISTS fne_point_of_sale text,
  ADD COLUMN IF NOT EXISTS fne_establishment text,
  ADD COLUMN IF NOT EXISTS fne_api_url text;
