/*
# Add status to dotations and quantite_reelle to dotation_items

1. Modified Tables
- `dotations`
  - Add `status` text column, NOT NULL DEFAULT 'valide' — values: 'brouillon' (draft, stock not yet deducted) or 'valide' (validated, stock deducted).
  - Existing rows default to 'valide' so historical dotations remain treated as already deducted.
- `dotation_items`
  - Add `quantite_reelle` numeric column, nullable — the actual quantity issued at validation time.
  - When null, the planned `quantity` is used as the actual issued quantity.

2. Security
- No new tables; existing RLS policies on dotations and dotation_items already allow authenticated CRUD. No policy changes needed.

3. Notes
- A dotation created as 'brouillon' does NOT deduct stock. Stock is deducted only when the dotation is validated ('valide'), using quantite_reelle (falling back to quantity).
- A CHECK constraint on dotations.status restricts values to 'brouillon' or 'valide'.
*/

ALTER TABLE dotations
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'valide';

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'dotations_status_check'
  ) THEN
    ALTER TABLE dotations
      ADD CONSTRAINT dotations_status_check CHECK (status IN ('brouillon', 'valide'));
  END IF;
END $$;

ALTER TABLE dotation_items
  ADD COLUMN IF NOT EXISTS quantite_reelle numeric;
