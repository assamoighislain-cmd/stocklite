/*
# Add photo to products

1. Schema change
- Add `photo_url` (text, nullable) to `products` — stores the public URL of the product image.

2. Storage bucket: product-photos
- Public bucket for storing product images.
- Files scoped by tenant: each tenant uploads to a folder named after their tenant_id.
- RLS policies enforce tenant-scoped writes, public reads (same pattern as company-logos).

3. Security
- No changes to products table RLS — existing policies already cover the new column.
- Storage policies: tenant-scoped CRUD, public read.
*/

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'photo_url') THEN
    ALTER TABLE products ADD COLUMN photo_url text;
  END IF;
END $$;

INSERT INTO storage.buckets (id, name, public)
VALUES ('product-photos', 'product-photos', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "product_photos_read" ON storage.objects;
CREATE POLICY "product_photos_read" ON storage.objects FOR SELECT
  USING (bucket_id = 'product-photos');

DROP POLICY IF EXISTS "product_photos_insert" ON storage.objects;
CREATE POLICY "product_photos_insert" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'product-photos'
    AND (storage.foldername(name))[1] = get_user_tenant_id()::text
  );

DROP POLICY IF EXISTS "product_photos_update" ON storage.objects;
CREATE POLICY "product_photos_update" ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'product-photos'
    AND (storage.foldername(name))[1] = get_user_tenant_id()::text
  )
  WITH CHECK (
    bucket_id = 'product-photos'
    AND (storage.foldername(name))[1] = get_user_tenant_id()::text
  );

DROP POLICY IF EXISTS "product_photos_delete" ON storage.objects;
CREATE POLICY "product_photos_delete" ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'product-photos'
    AND (storage.foldername(name))[1] = get_user_tenant_id()::text
  );