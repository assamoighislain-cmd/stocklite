/*
# Allow super_admin role in user_profiles

1. Modified Tables
   - `user_profiles`: update check constraint on `role` column to include 'super_admin'

2. Changes
   - Drop old check constraint `user_profiles_role_check`
   - Add new check constraint that includes 'super_admin' in allowed values
   - Update first admin user to super_admin role

3. Notes
   - This enables the super-admin dashboard for tenant/license management
*/

-- Drop old constraint and add updated one
ALTER TABLE user_profiles DROP CONSTRAINT IF EXISTS user_profiles_role_check;
ALTER TABLE user_profiles ADD CONSTRAINT user_profiles_role_check
  CHECK (role IN ('super_admin', 'admin', 'caissier', 'gerant', 'commercial'));

-- Promote the primary admin to super_admin
UPDATE user_profiles
SET role = 'super_admin', updated_at = now()
WHERE email = 'assamoighislain@gmail.com';
