/*
# Ajout du commercial_id sur pos_sales

Ajoute la colonne `commercial_id` sur la table `pos_sales` pour tracer le commercial
associé à chaque vente POS.

## Modifications
- `pos_sales` : ajout de `commercial_id uuid REFERENCES commerciaux(id) ON DELETE SET NULL`
*/

ALTER TABLE pos_sales
  ADD COLUMN IF NOT EXISTS commercial_id uuid REFERENCES commerciaux(id) ON DELETE SET NULL;
