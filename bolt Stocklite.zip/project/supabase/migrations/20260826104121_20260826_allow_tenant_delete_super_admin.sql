/*
# Allow super_admin to delete a tenant

## Purpose
Adds a DELETE RLS policy on the tenants table so the super_admin role can
remove an entire company. All related data is removed via ON DELETE CASCADE
on the foreign keys (user_profiles, products, invoices, etc.).

## Security
- Only the super_admin role can delete tenants. Regular admins within a
  tenant cannot delete their own company.
- The policy checks that the requesting user's profile has role = 'super_admin'.
*/

DROP POLICY IF EXISTS "delete_tenant_super_admin" ON tenants;

CREATE POLICY "delete_tenant_super_admin" ON tenants FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE id = auth.uid() AND role = 'super_admin'
    )
  );
