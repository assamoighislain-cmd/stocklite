/*
# Simplify handle_new_user trigger to avoid database errors

1. Modified Functions
   - `handle_new_user()`: Removed tenant_id handling from the trigger.
     The trigger now only creates a basic profile with role and status.
     The edge function handles tenant_id assignment via upsert after creation.

2. Changes
   - Removed tenant_id extraction from raw_user_meta_data (was causing "Database error creating new user")
   - Kept ON CONFLICT DO UPDATE for safety
   - Set search_path explicitly to avoid resolution issues

3. Notes
   - The "Database error creating new user" was caused by the trigger trying to cast
     tenant_id from user_metadata during the auth.users INSERT transaction.
   - Now the trigger is minimal and safe; the edge function handles the full profile update.
*/

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role   text;
  v_status text;
  v_name   text;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'caissier');
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', '');

  IF v_role NOT IN ('admin', 'caissier', 'gerant', 'commercial') THEN
    v_role := 'caissier';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM user_profiles LIMIT 1) THEN
    v_role   := 'admin';
    v_status := 'active';
  ELSE
    v_status := 'pending';
  END IF;

  INSERT INTO user_profiles (id, email, full_name, role, status)
  VALUES (NEW.id, NEW.email, v_name, v_role, v_status)
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;
