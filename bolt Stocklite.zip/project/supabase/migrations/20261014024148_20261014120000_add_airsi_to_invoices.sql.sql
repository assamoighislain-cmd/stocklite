/*
# Add AIRSI field to invoices

1. Modified Tables
- `invoices`: adds `airsi` text column (nullable) to store the AIRSI reference for each invoice.
2. Security
- No policy changes — the column inherits the existing invoices RLS policies.
3. Notes
- The column is optional (nullable) so existing invoices remain valid.
*/

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'invoices' AND column_name = 'airsi') THEN
    ALTER TABLE invoices ADD COLUMN airsi text;
  END IF;
END $$;
