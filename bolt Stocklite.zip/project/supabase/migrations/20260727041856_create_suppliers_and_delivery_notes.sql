/*
# Approvisionnement : fournisseurs et bons de livraison

## Objectif
Permettre d'enregistrer les bons de livraison (BL) reçus de chaque fournisseur.
À la validation d'un bon, le stock des produits concernés est automatiquement
movementé (entrée de stock).

## Nouvelles tables

### `suppliers` — répertoire des fournisseurs
- `id` (uuid, PK)
- `name` (text, not null) — nom du fournisseur
- `phone` (text) — téléphone
- `email` (text) — email
- `address` (text) — adresse
- `active` (boolean, default true)
- `location_id` (uuid, nullable) — boutique rattachée (null = toutes)
- `created_at` (timestamptz)

### `delivery_notes` — bons de livraison
- `id` (uuid, PK)
- `note_number` (text, not null) — numéro du BL (ex: BL-2026-001)
- `supplier_id` (uuid, not null, FK suppliers) — fournisseur
- `location_id` (uuid, nullable) — boutique de réception
- `note_date` (date, not null) — date du bon
- `status` (text, default 'brouillon') — 'brouillon' | 'valide'
- `total_amount` (numeric, default 0) — montant total
- `notes` (text) — remarques
- `created_by` (uuid, nullable) — utilisateur créateur
- `created_at` / `updated_at` (timestamptz)

### `delivery_note_items` — lignes du bon
- `id` (uuid, PK)
- `delivery_note_id` (uuid, not null, FK delivery_notes ON DELETE CASCADE)
- `product_id` (uuid, not null) — produit concerné
- `quantity` (numeric, not null) — quantité reçue
- `unit_cost` (numeric, not null default 0) — coût unitaire d'achat
- `total` (numeric, not null default 0) — total de la ligne
- `created_at` (timestamptz)

## Sécurité (RLS)
- RLS activée sur les trois tables.
- Politiques `TO authenticated` avec `USING (true)` / `WITH CHECK (true)`,
  cohérentes avec les politiques existantes du projet (caisse_closings,
  accounting_entries, etc.).
*/

CREATE TABLE IF NOT EXISTS suppliers (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  phone       TEXT NOT NULL DEFAULT '',
  email       TEXT NOT NULL DEFAULT '',
  address     TEXT NOT NULL DEFAULT '',
  active      BOOLEAN NOT NULL DEFAULT true,
  location_id UUID REFERENCES sales_locations(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS delivery_notes (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  note_number TEXT NOT NULL,
  supplier_id UUID NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  location_id UUID REFERENCES sales_locations(id) ON DELETE SET NULL,
  note_date   DATE NOT NULL DEFAULT CURRENT_DATE,
  status      TEXT NOT NULL DEFAULT 'brouillon' CHECK (status IN ('brouillon', 'valide')),
  total_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  notes       TEXT NOT NULL DEFAULT '',
  created_by  UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS delivery_note_items (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_note_id  UUID NOT NULL REFERENCES delivery_notes(id) ON DELETE CASCADE,
  product_id        UUID NOT NULL,
  quantity          NUMERIC(14,2) NOT NULL DEFAULT 0,
  unit_cost         NUMERIC(14,2) NOT NULL DEFAULT 0,
  total             NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_note_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_suppliers" ON suppliers;
CREATE POLICY "select_suppliers" ON suppliers FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_suppliers" ON suppliers;
CREATE POLICY "insert_suppliers" ON suppliers FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_suppliers" ON suppliers;
CREATE POLICY "update_suppliers" ON suppliers FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_suppliers" ON suppliers;
CREATE POLICY "delete_suppliers" ON suppliers FOR DELETE TO authenticated USING (true);

DROP POLICY IF EXISTS "select_delivery_notes" ON delivery_notes;
CREATE POLICY "select_delivery_notes" ON delivery_notes FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_delivery_notes" ON delivery_notes;
CREATE POLICY "insert_delivery_notes" ON delivery_notes FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_delivery_notes" ON delivery_notes;
CREATE POLICY "update_delivery_notes" ON delivery_notes FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_delivery_notes" ON delivery_notes;
CREATE POLICY "delete_delivery_notes" ON delivery_notes FOR DELETE TO authenticated USING (true);

DROP POLICY IF EXISTS "select_delivery_note_items" ON delivery_note_items;
CREATE POLICY "select_delivery_note_items" ON delivery_note_items FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_delivery_note_items" ON delivery_note_items;
CREATE POLICY "insert_delivery_note_items" ON delivery_note_items FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_delivery_note_items" ON delivery_note_items;
CREATE POLICY "update_delivery_note_items" ON delivery_note_items FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_delivery_note_items" ON delivery_note_items;
CREATE POLICY "delete_delivery_note_items" ON delivery_note_items FOR DELETE TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_delivery_notes_supplier ON delivery_notes(supplier_id);
CREATE INDEX IF NOT EXISTS idx_delivery_notes_location ON delivery_notes(location_id);
CREATE INDEX IF NOT EXISTS idx_delivery_note_items_note ON delivery_note_items(delivery_note_id);
