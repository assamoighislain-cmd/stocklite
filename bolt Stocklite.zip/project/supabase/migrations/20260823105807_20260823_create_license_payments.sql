/*
# Create license_payments table for GeniusPay integration

1. Purpose
   Tracks online license payments initiated through GeniusPay checkout.
   Each row represents a payment attempt for a tenant's annual license.
   When payment succeeds (confirmed via webhook), the tenant's license_expires_at
   is extended and a subscription record is created.

2. New Tables
   - `license_payments`
     - `id` (uuid, primary key)
     - `tenant_id` (uuid, references tenants, not null) — which company is paying
     - `amount` (integer, not null) — amount in FCFA
     - `currency` (text, default 'XOF')
     - `plan` (text, not null) — 'annual' (future: 'monthly', etc.)
     - `duration_days` (integer, default 365) — license duration in days
     - `geniuspay_reference` (text, unique) — GeniusPay payment reference/session ID
     - `status` (text, default 'pending') — 'pending' | 'paid' | 'failed' | 'cancelled'
     - `payment_method` (text, nullable) — e.g. 'orange_money', 'wave', 'mtn_money'
     - `payment_url` (text, nullable) — GeniusPay checkout URL to redirect the user
     - `created_by` (uuid, nullable) — user who initiated the payment
     - `paid_at` (timestamptz, nullable) — when payment was confirmed
     - `created_at` (timestamptz, default now())
     - `updated_at` (timestamptz, default now())

3. Security
   - RLS enabled on license_payments.
   - Super admins (role check via user_profiles) can read all and insert.
   - The edge function (service role) handles updates on webhook.
   - Authenticated users belonging to the tenant can read their own tenant's payments.

4. Notes
   - The geniuspay_reference column has a unique constraint to prevent duplicate webhook processing.
   - An index on tenant_id for efficient lookups.
*/

CREATE TABLE IF NOT EXISTS license_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  currency text NOT NULL DEFAULT 'XOF',
  plan text NOT NULL DEFAULT 'annual',
  duration_days integer NOT NULL DEFAULT 365,
  geniuspay_reference text UNIQUE,
  status text NOT NULL DEFAULT 'pending',
  payment_method text,
  payment_url text,
  created_by uuid,
  paid_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_license_payments_tenant_id ON license_payments(tenant_id);
CREATE INDEX IF NOT EXISTS idx_license_payments_status ON license_payments(status);

ALTER TABLE license_payments ENABLE ROW LEVEL SECURITY;

-- Super admins can read all license payments
DROP POLICY IF EXISTS "super_admin_read_license_payments" ON license_payments;
CREATE POLICY "super_admin_read_license_payments"
ON license_payments FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
    AND user_profiles.role = 'super_admin'
  )
);

-- Super admins can insert license payments
DROP POLICY IF EXISTS "super_admin_insert_license_payments" ON license_payments;
CREATE POLICY "super_admin_insert_license_payments"
ON license_payments FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
    AND user_profiles.role = 'super_admin'
  )
);

-- Users belonging to a tenant can read their own tenant's payments
DROP POLICY IF EXISTS "tenant_user_read_license_payments" ON license_payments;
CREATE POLICY "tenant_user_read_license_payments"
ON license_payments FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM user_profiles
    WHERE user_profiles.id = auth.uid()
    AND user_profiles.tenant_id = license_payments.tenant_id
  )
);

-- No UPDATE/DELETE policies from the client side;
-- all updates are done by the edge function using the service role key.
