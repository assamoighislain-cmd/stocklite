/*
# Add FNE company fields to company_settings

1. Modified Tables
- `company_settings`: add three new nullable text columns for DGI/FNE compliance:
  - `fne_bank_reference` — référence bancaire (RIB / compte bancaire)
  - `fne_tax_regime` — régime d'imposition (ex: réel, simplifié, forfait)
  - `fne_tax_center` — centre des impôts de rattachement

2. Security
- No changes to RLS — these columns inherit the existing company_settings policies.
- No destructive operations — purely additive ALTER TABLE.
*/

ALTER TABLE company_settings
  ADD COLUMN IF NOT EXISTS fne_bank_reference text,
  ADD COLUMN IF NOT EXISTS fne_tax_regime text,
  ADD COLUMN IF NOT EXISTS fne_tax_center text;
