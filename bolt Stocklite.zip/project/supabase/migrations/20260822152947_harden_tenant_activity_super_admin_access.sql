/*
# Harden Tenant Activity Access

## Purpose
Ensures the tenant activity summary can only return data to a super_admin.

## Modified Object
- `get_tenant_activity(uuid)` — adds an internal `is_super_admin()` guard.

## Security
- Authenticated users may technically call the function, but non-super_admin users receive no rows.
- The check is enforced in the database function and cannot be bypassed by the frontend.
- No tenant activity data is exposed to regular administrators or other roles.

## Important Notes
1. The existing function signature is preserved.
2. No existing tables or user data are modified.
3. The function remains available to the authenticated role for RPC compatibility.
*/

CREATE OR REPLACE FUNCTION public.get_tenant_activity(p_tenant_id uuid)
RETURNS TABLE (
  tenant_id uuid,
  tenant_name text,
  tenant_slug text,
  total_sales bigint,
  total_sales_amount numeric,
  total_invoices bigint,
  total_invoices_amount numeric,
  unpaid_invoices bigint,
  unpaid_amount numeric,
  total_customers bigint,
  total_products bigint,
  total_users bigint,
  total_locations bigint,
  last_sale_date timestamptz,
  last_invoice_date timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT
    t.id,
    t.name,
    t.slug,
    COALESCE((SELECT count(*) FROM pos_sales WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT sum(total) FROM pos_sales WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT count(*) FROM invoices WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT sum(total) FROM invoices WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT count(*) FROM invoices WHERE tenant_id = p_tenant_id AND status != 'payee' AND status != 'annulee'), 0),
    COALESCE((SELECT sum(balance_due) FROM invoices WHERE tenant_id = p_tenant_id AND status != 'payee' AND status != 'annulee'), 0),
    COALESCE((SELECT count(*) FROM customers WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT count(*) FROM products WHERE tenant_id = p_tenant_id AND active = true), 0),
    COALESCE((SELECT count(*) FROM user_profiles WHERE tenant_id = p_tenant_id), 0),
    COALESCE((SELECT count(*) FROM sales_locations WHERE tenant_id = p_tenant_id), 0),
    (SELECT max(created_at) FROM pos_sales WHERE tenant_id = p_tenant_id),
    (SELECT max(created_at) FROM invoices WHERE tenant_id = p_tenant_id)
  FROM tenants t
  WHERE t.id = p_tenant_id
    AND is_super_admin()
$function$;

REVOKE EXECUTE ON FUNCTION public.get_tenant_activity(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.get_tenant_activity(uuid) TO authenticated;
