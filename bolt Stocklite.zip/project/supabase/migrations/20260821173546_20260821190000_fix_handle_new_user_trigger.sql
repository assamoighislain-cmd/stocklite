/*
# Fix handle_new_user trigger to support all roles and tenant_id

1. Modified Functions
   - `handle_new_user()`: Updated to accept all valid roles (admin, caissier, gerant, commercial)
     and to read tenant_id from user_metadata when passed during admin user creation.

2. Changes
   - Expanded role validation to include 'commercial'
   - Added tenant_id extraction from raw_user_meta_data
   - Profile created with tenant_id if provided

3. Notes
   - This fixes the issue where the edge function creates users with tenant_id but the trigger
     was creating profiles first without it, causing a conflict on the subsequent upsert.
   - The edge function now uses upsert to handle the race condition gracefully.
*/

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  v_role   text;
  v_status text;
  v_name   text;
  v_tenant_id uuid;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'caissier');
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', '');

  IF v_role NOT IN ('admin', 'caissier', 'gerant', 'commercial') THEN
    v_role := 'caissier';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM user_profiles LIMIT 1) THEN
    v_role   := 'admin';
    v_status := 'active';
  ELSE
    v_status := 'pending';
  END IF;

  -- Extract tenant_id if provided (e.g. from edge function admin.createUser)
  IF NEW.raw_user_meta_data->>'tenant_id' IS NOT NULL THEN
    v_tenant_id := (NEW.raw_user_meta_data->>'tenant_id')::uuid;
    v_status := 'active';
  ELSE
    v_tenant_id := NULL;
  END IF;

  INSERT INTO user_profiles (id, email, full_name, role, status, tenant_id)
  VALUES (NEW.id, NEW.email, v_name, v_role, v_status, v_tenant_id)
  ON CONFLICT (id) DO UPDATE SET
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    status = EXCLUDED.status,
    tenant_id = EXCLUDED.tenant_id,
    updated_at = now();

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
