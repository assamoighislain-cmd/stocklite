-- 1. Ajouter user_id à pos_sales avec FK vers user_profiles (pour join PostgREST)
ALTER TABLE pos_sales
  ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_pos_sales_user ON pos_sales(user_id);

-- 2. Corriger la FK de caisse_closings pour référencer user_profiles (join PostgREST)
ALTER TABLE caisse_closings DROP CONSTRAINT IF EXISTS caisse_closings_user_id_fkey;
ALTER TABLE caisse_closings
  ADD CONSTRAINT caisse_closings_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES user_profiles(id) ON DELETE SET NULL;

-- 3. Remplacer les politiques pos_sales par des politiques user-scoped
DROP POLICY IF EXISTS "auth_select_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "auth_insert_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "auth_update_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "auth_delete_pos_sales" ON pos_sales;
DROP POLICY IF EXISTS "anon_select_ps"         ON pos_sales;
DROP POLICY IF EXISTS "anon_insert_ps"         ON pos_sales;
DROP POLICY IF EXISTS "anon_update_ps"         ON pos_sales;
DROP POLICY IF EXISTS "anon_delete_ps"         ON pos_sales;

CREATE POLICY "ps_select" ON pos_sales FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR is_admin());
CREATE POLICY "ps_insert" ON pos_sales FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "ps_update" ON pos_sales FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR is_admin())
  WITH CHECK (user_id = auth.uid() OR is_admin());
CREATE POLICY "ps_delete" ON pos_sales FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR is_admin());

-- 4. Remplacer les politiques pos_sale_items (lecture filtrée via vente parente)
DROP POLICY IF EXISTS "auth_select_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "auth_insert_pos_sale_items" ON pos_sale_items;
DROP POLICY IF EXISTS "anon_select_psi"             ON pos_sale_items;
DROP POLICY IF EXISTS "anon_insert_psi"             ON pos_sale_items;

CREATE POLICY "psi_select" ON pos_sale_items FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM pos_sales s
    WHERE s.id = sale_id AND (s.user_id = auth.uid() OR is_admin())
  ));
CREATE POLICY "psi_insert" ON pos_sale_items FOR INSERT TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM pos_sales s
    WHERE s.id = sale_id AND s.user_id = auth.uid()
  ));

-- 5. Remplacer les politiques pos_payments
DROP POLICY IF EXISTS "auth_select_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "auth_insert_pos_payments" ON pos_payments;
DROP POLICY IF EXISTS "anon_select_pp"            ON pos_payments;
DROP POLICY IF EXISTS "anon_insert_pp"            ON pos_payments;

CREATE POLICY "pp_select" ON pos_payments FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM pos_sales s
    WHERE s.id = sale_id AND (s.user_id = auth.uid() OR is_admin())
  ));
CREATE POLICY "pp_insert" ON pos_payments FOR INSERT TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM pos_sales s
    WHERE s.id = sale_id AND s.user_id = auth.uid()
  ));

-- 6. Remplacer les politiques caisse_closings
DROP POLICY IF EXISTS "select_closings" ON caisse_closings;
DROP POLICY IF EXISTS "insert_closings" ON caisse_closings;
DROP POLICY IF EXISTS "update_closings" ON caisse_closings;
DROP POLICY IF EXISTS "delete_closings" ON caisse_closings;

CREATE POLICY "cc_select" ON caisse_closings FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR is_admin());
CREATE POLICY "cc_insert" ON caisse_closings FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "cc_update" ON caisse_closings FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR is_admin())
  WITH CHECK (user_id = auth.uid() OR is_admin());
CREATE POLICY "cc_delete" ON caisse_closings FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR is_admin());

-- 7. Remplacer les politiques caisse_closing_lines
DROP POLICY IF EXISTS "select_closing_lines" ON caisse_closing_lines;
DROP POLICY IF EXISTS "insert_closing_lines" ON caisse_closing_lines;

CREATE POLICY "ccl_select" ON caisse_closing_lines FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM caisse_closings c
    WHERE c.id = closing_id AND (c.user_id = auth.uid() OR is_admin())
  ));
CREATE POLICY "ccl_insert" ON caisse_closing_lines FOR INSERT TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM caisse_closings c
    WHERE c.id = closing_id AND c.user_id = auth.uid()
  ));
