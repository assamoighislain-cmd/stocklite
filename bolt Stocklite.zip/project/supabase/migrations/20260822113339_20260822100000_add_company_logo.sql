/*
# Add company logo support

## Summary
Adds a `logo_url` column to `company_settings` so each tenant (entreprise)
can upload a logo image that appears on invoices and receipts.

## Changes

### 1. company_settings table
- New column `logo_url text` (nullable) — stores the public URL of the
  uploaded logo image in Supabase Storage.

### 2. Storage bucket: company-logos
- Public bucket for storing logo images.
- Files are scoped by tenant: each tenant uploads to a folder named
  after their tenant_id, so RLS policies can enforce isolation.

### 3. Storage policies (tenant-scoped)
- SELECT (read): public — anyone can read logos (they appear on printed
  invoices that may be shared externally).
- INSERT: authenticated users can only upload to their own tenant folder.
- UPDATE: authenticated users can only update files in their own tenant folder.
- DELETE: authenticated users can only delete files in their own tenant folder.

## Security
- Logos are public-readable (needed for invoice printing/sharing).
- Logos are tenant-scoped for writes: a user can only upload/modify/delete
  logos in a folder matching their own tenant_id.
*/

-- 1. Add logo_url column
ALTER TABLE company_settings ADD COLUMN IF NOT EXISTS logo_url text;

-- 2. Create storage bucket for company logos
INSERT INTO storage.buckets (id, name, public)
VALUES ('company-logos', 'company-logos', true)
ON CONFLICT (id) DO NOTHING;

-- 3. Storage policies: tenant-scoped writes, public reads
DROP POLICY IF EXISTS "company_logos_read" ON storage.objects;
CREATE POLICY "company_logos_read" ON storage.objects FOR SELECT
  USING (bucket_id = 'company-logos');

DROP POLICY IF EXISTS "company_logos_insert" ON storage.objects;
CREATE POLICY "company_logos_insert" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'company-logos'
    AND (storage.foldername(name))[1] = get_user_tenant_id()::text
  );

DROP POLICY IF EXISTS "company_logos_update" ON storage.objects;
CREATE POLICY "company_logos_update" ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'company-logos'
    AND (storage.foldername(name))[1] = get_user_tenant_id()::text
  )
  WITH CHECK (
    bucket_id = 'company-logos'
    AND (storage.foldername(name))[1] = get_user_tenant_id()::text
  );

DROP POLICY IF EXISTS "company_logos_delete" ON storage.objects;
CREATE POLICY "company_logos_delete" ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'company-logos'
    AND (storage.foldername(name))[1] = get_user_tenant_id()::text
  );
