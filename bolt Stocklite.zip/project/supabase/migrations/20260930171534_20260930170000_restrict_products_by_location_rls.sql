/*
# Restrict product visibility by assigned location for non-admin users

Users with a location_id (gérant, caissier, commercial, controleur) should only
see products that have a location_stock entry for their assigned sales location.
Admins and super_admins, or tenants with access_all_locations=true, can see all
tenant products.

## Changes
1. Add helper function user_can_access_all_locations()
2. Replace products SELECT policy to restrict by location for non-admin users
3. Add location_stock SELECT policy restriction for non-admin users

## Security
- Uses auth.uid() for the caller identity (never a parameter)
- Uses existing user_location_id() helper
- Falls back to tenant-wide access for admins / super_admins / access_all_locations
*/

-- Helper: can the current user access all locations within their tenant?
CREATE OR REPLACE FUNCTION user_can_access_all_locations()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER SET search_path = public
AS $$
  SELECT COALESCE(
    is_super_admin()
    OR EXISTS (
      SELECT 1
      FROM user_profiles up
      JOIN tenants t ON t.id = up.tenant_id
      WHERE up.id = auth.uid()
        AND up.role = 'admin'
    )
    OR EXISTS (
      SELECT 1
      FROM user_profiles up
      JOIN tenants t ON t.id = up.tenant_id
      WHERE up.id = auth.uid()
        AND t.access_all_locations = true
    ),
    false
  );
$$;

REVOKE EXECUTE ON FUNCTION user_can_access_all_locations FROM anon;
GRANT EXECUTE ON FUNCTION user_can_access_all_locations TO authenticated;

-- Replace products SELECT policy: restrict to assigned location for non-admin users
DROP POLICY IF EXISTS products_select_tenant ON products;

CREATE POLICY products_select_tenant ON products FOR SELECT
  TO authenticated
  USING (
    is_super_admin()
    OR (
      tenant_id = get_user_tenant_id()
      AND (
        user_can_access_all_locations()
        OR EXISTS (
          SELECT 1
          FROM location_stock ls
          WHERE ls.product_id = products.id
            AND ls.location_id = user_location_id()
        )
      )
    )
  );

-- Replace location_stock SELECT policy: restrict to assigned location for non-admin users
DROP POLICY IF EXISTS location_stock_select_tenant ON location_stock;

CREATE POLICY location_stock_select_tenant ON location_stock FOR SELECT
  TO authenticated
  USING (
    is_super_admin()
    OR (
      tenant_id = get_user_tenant_id()
      AND (
        user_can_access_all_locations()
        OR location_id = user_location_id()
      )
    )
  );