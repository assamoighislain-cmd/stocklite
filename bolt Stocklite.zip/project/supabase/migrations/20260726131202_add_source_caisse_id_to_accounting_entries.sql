/*
# Add source and caisse_id columns to accounting_entries

## Purpose
Distinguish cash-register expenses (dépenses de caisse) from manual
accounting entries, and optionally link them to the caisse session they
were recorded against. This lets the "Opérations de caisse" page record
expenses that automatically feed into the P&L (they are already charges
in accounting_entries) while being filterable by origin.

## Changes
1. Modified table: `accounting_entries`
   - Add `source` text, default 'manual', CHECK IN ('manual','caisse')
   - Add `caisse_id` uuid, nullable, references caisses(id) ON DELETE SET NULL
2. Indexes
   - idx_accounting_source on source
   - idx_accounting_caisse_id on caisse_id
3. Security
   - No RLS policy changes — existing policies already allow authenticated CRUD.
*/

ALTER TABLE accounting_entries
  ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'manual'
    CHECK (source IN ('manual', 'caisse')),
  ADD COLUMN IF NOT EXISTS caisse_id uuid REFERENCES caisses(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_accounting_source ON accounting_entries(source);
CREATE INDEX IF NOT EXISTS idx_accounting_caisse_id ON accounting_entries(caisse_id);
