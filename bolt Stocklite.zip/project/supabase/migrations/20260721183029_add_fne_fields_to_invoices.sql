/*
# Add FNE (Facture Normalisée Électronique) fields to invoices

## Context
Interfacing with the DGI Côte d'Ivoire FNE platform (fne.dgi.gouv.ci).
Each invoice can be certified by the DGI to obtain a normalized reference
and a QR code verification token.

## Changes to existing table `invoices`
- `fne_reference` (text): Normalized invoice number returned by DGI (e.g. "9606123E25000000019").
- `fne_token` (text): Verification URL/token from DGI, to be encoded as QR code.
- `fne_ncc` (text): Contributor identifier (NCC) returned by DGI.
- `fne_status` (text): Local tracking of certification status — 'pending', 'certified', 'error'.
- `fne_error` (text): Last error message from DGI API, if any.
- `fne_certified_at` (timestamptz): When certification was obtained.

All columns are nullable and default NULL so existing invoices are unaffected.

## Security
- No new tables; RLS already enabled on `invoices`. No policy changes needed.
*/

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS fne_reference text,
  ADD COLUMN IF NOT EXISTS fne_token text,
  ADD COLUMN IF NOT EXISTS fne_ncc text,
  ADD COLUMN IF NOT EXISTS fne_status text,
  ADD COLUMN IF NOT EXISTS fne_error text,
  ADD COLUMN IF NOT EXISTS fne_certified_at timestamptz;
