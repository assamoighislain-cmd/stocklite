-- Fix: deletes_log.record_id is uuid, but location_stock and
-- location_product_price_types use text composite IDs (e.g.
-- "productId_locationId"). The AFTER DELETE trigger casts OLD.id::text::uuid
-- which crashes for non-UUID text values, causing the entire DELETE to fail
-- and roll back — so rows on these tables can never be deleted from the
-- server. The client sees the delete succeed locally, but the server row
-- persists and comes back on the next pull.

-- 1. Change record_id from uuid to text so it can hold any ID format.
ALTER TABLE deletes_log ALTER COLUMN record_id TYPE text USING record_id::text;

-- 2. Fix the trigger function: cast OLD.id to text directly (no uuid cast).
CREATE OR REPLACE FUNCTION log_delete_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO deletes_log (table_name, record_id)
  VALUES (TG_TABLE_NAME, OLD.id::text);
  RETURN OLD;
END;
$$;
