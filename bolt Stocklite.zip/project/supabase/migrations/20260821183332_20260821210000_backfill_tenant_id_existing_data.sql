/*
# Backfill tenant_id for existing sales_locations and user_profiles

## Summary
After enabling tenant-scoped RLS, existing sales_locations and user_profiles
rows had NULL tenant_id, making them invisible to authenticated users
(whose own tenant_id may also be NULL). This migration assigns all
existing rows to the single tenant "AGASOFT" (521cfde5-9635-4f43-a4d7-443346f0e6c1).

## Data changes
- Set tenant_id on all sales_locations rows that have NULL tenant_id.
- Set tenant_id on all user_profiles rows (except super_admin) that have NULL tenant_id.
- Super_admin profiles keep tenant_id NULL so they can see all tenants.

## Security
No schema or policy changes. Data-only migration to fix visibility.
*/

UPDATE sales_locations
SET tenant_id = '521cfde5-9635-4f43-a4d7-443346f0e6c1'
WHERE tenant_id IS NULL;

UPDATE user_profiles
SET tenant_id = '521cfde5-9635-4f43-a4d7-443346f0e6c1'
WHERE tenant_id IS NULL
  AND role != 'super_admin';
