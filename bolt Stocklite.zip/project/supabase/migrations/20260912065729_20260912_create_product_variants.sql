/*
# Create product variants system

1. New Tables
- `product_variants`: Stores variants for a product (e.g. Carton, Bouteille, Canette).
  - `id` (uuid, primary key)
  - `product_id` (uuid, FK to products, ON DELETE CASCADE)
  - `name` (text, not null) — e.g. "Carton", "Bouteille"
  - `sku` (text, nullable) — optional variant-specific reference
  - `price` (numeric, not null, default 0) — selling price for this variant
  - `purchase_price` (numeric, not null, default 0) — purchase cost
  - `stock_quantity` (numeric, not null, default 0) — global stock for this variant
  - `stock_min` (numeric, not null, default 0) — low-stock threshold
  - `track_stock` (boolean, not null, default true) — whether to track stock
  - `sort_order` (integer, not null, default 0)
  - `active` (boolean, not null, default true)
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())
  - `tenant_id` (uuid, default get_user_tenant_id())

- `location_stock_variants`: Per-location stock for a specific variant.
  - `id` (text, primary key) — composite key `${variant_id}_${location_id}`
  - `variant_id` (uuid, FK to product_variants, ON DELETE CASCADE)
  - `location_id` (uuid, FK to sales_locations, ON DELETE CASCADE)
  - `stock_quantity` (numeric, not null, default 0)
  - `stock_min` (numeric, not null, default 0)
  - `price` (numeric, nullable) — optional location-specific price override
  - `updated_at` (timestamptz, default now())
  - `tenant_id` (uuid, default get_user_tenant_id())

2. Modified Tables
- `stock_movements`: Add nullable `variant_id` column (uuid, FK to product_variants ON DELETE SET NULL).

3. Security
- Enable RLS on both new tables.
- Tenant-scoped CRUD policies (TO authenticated, using tenant_id = get_user_tenant_id()).

4. Important Notes
- The `unit` column on `products` remains for backward compatibility but is hidden in the UI when variants exist.
- Products without variants continue to work exactly as before.
*/

-- ── product_variants ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS product_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name text NOT NULL,
  sku text,
  price numeric NOT NULL DEFAULT 0,
  purchase_price numeric NOT NULL DEFAULT 0,
  stock_quantity numeric NOT NULL DEFAULT 0,
  stock_min numeric NOT NULL DEFAULT 0,
  track_stock boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  tenant_id uuid DEFAULT get_user_tenant_id()
);

ALTER TABLE product_variants ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "product_variants_select_tenant" ON product_variants;
CREATE POLICY "product_variants_select_tenant" ON product_variants FOR SELECT
  TO authenticated USING (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "product_variants_insert_tenant" ON product_variants;
CREATE POLICY "product_variants_insert_tenant" ON product_variants FOR INSERT
  TO authenticated WITH CHECK (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "product_variants_update_tenant" ON product_variants;
CREATE POLICY "product_variants_update_tenant" ON product_variants FOR UPDATE
  TO authenticated USING (tenant_id = get_user_tenant_id()) WITH CHECK (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "product_variants_delete_tenant" ON product_variants;
CREATE POLICY "product_variants_delete_tenant" ON product_variants FOR DELETE
  TO authenticated USING (tenant_id = get_user_tenant_id());

CREATE INDEX IF NOT EXISTS idx_product_variants_product_id ON product_variants(product_id);
CREATE INDEX IF NOT EXISTS idx_product_variants_tenant_id ON product_variants(tenant_id);

-- ── location_stock_variants ───────────────────────────────
CREATE TABLE IF NOT EXISTS location_stock_variants (
  id text PRIMARY KEY,
  variant_id uuid NOT NULL REFERENCES product_variants(id) ON DELETE CASCADE,
  location_id uuid NOT NULL REFERENCES sales_locations(id) ON DELETE CASCADE,
  stock_quantity numeric NOT NULL DEFAULT 0,
  stock_min numeric NOT NULL DEFAULT 0,
  price numeric,
  updated_at timestamptz DEFAULT now(),
  tenant_id uuid DEFAULT get_user_tenant_id()
);

ALTER TABLE location_stock_variants ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "location_stock_variants_select_tenant" ON location_stock_variants;
CREATE POLICY "location_stock_variants_select_tenant" ON location_stock_variants FOR SELECT
  TO authenticated USING (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "location_stock_variants_insert_tenant" ON location_stock_variants;
CREATE POLICY "location_stock_variants_insert_tenant" ON location_stock_variants FOR INSERT
  TO authenticated WITH CHECK (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "location_stock_variants_update_tenant" ON location_stock_variants;
CREATE POLICY "location_stock_variants_update_tenant" ON location_stock_variants FOR UPDATE
  TO authenticated USING (tenant_id = get_user_tenant_id()) WITH CHECK (tenant_id = get_user_tenant_id());

DROP POLICY IF EXISTS "location_stock_variants_delete_tenant" ON location_stock_variants;
CREATE POLICY "location_stock_variants_delete_tenant" ON location_stock_variants FOR DELETE
  TO authenticated USING (tenant_id = get_user_tenant_id());

CREATE INDEX IF NOT EXISTS idx_location_stock_variants_variant_id ON location_stock_variants(variant_id);
CREATE INDEX IF NOT EXISTS idx_location_stock_variants_tenant_id ON location_stock_variants(tenant_id);

-- ── stock_movements: add variant_id ───────────────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'stock_movements' AND column_name = 'variant_id'
  ) THEN
    ALTER TABLE stock_movements ADD COLUMN variant_id uuid REFERENCES product_variants(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ── updated_at triggers ───────────────────────────────────
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_product_variants_updated_at') THEN
    CREATE TRIGGER trg_product_variants_updated_at
      BEFORE UPDATE ON product_variants
      FOR EACH ROW EXECUTE FUNCTION set_updated_at();
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_location_stock_variants_updated_at') THEN
    CREATE TRIGGER trg_location_stock_variants_updated_at
      BEFORE UPDATE ON location_stock_variants
      FOR EACH ROW EXECUTE FUNCTION set_updated_at();
  END IF;
END $$;
