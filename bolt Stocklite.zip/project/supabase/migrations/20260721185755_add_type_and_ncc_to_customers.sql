/*
# Add client type and NCC fields to customers

## Context
The FNE DGI certification requires a NCC (Numéro Compte Contribuable) only
for business clients (B2B/B2G templates). Individual consumers (B2C) do not
need one. We add a `type` column to distinguish client categories and an
`ncc` column to store the contributor identifier when applicable.

## Changes to existing table `customers`
- `type` (text): Client category — 'particulier' (individual) or 'entreprise'
  (business). Defaults to 'particulier' so existing rows are treated as
  individuals (no NCC required).
- `ncc` (text): NCC identifier for business clients. Nullable.

## Security
- No new tables; RLS already enabled on `customers`. No policy changes.
*/

ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS type text NOT NULL DEFAULT 'particulier',
  ADD COLUMN IF NOT EXISTS ncc text;
