-- Add updated_at column to dotation_items for sync support
ALTER TABLE dotation_items
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_dotation_items_updated_at ON dotation_items(updated_at);
