/*
# Restrict tenant security helper execution

## Summary
Authorization helper functions are used internally by row-level security and
must not be callable by unauthenticated API clients.

## Security changes
- Revoke EXECUTE from `public` and `anon` on tenant and authorization helpers.
- Grant EXECUTE only to `authenticated`, which is the role used by signed-in app users.
- The functions remain available to RLS evaluation and database triggers.
*/

REVOKE EXECUTE ON FUNCTION public.get_user_tenant_id() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_super_admin() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_admin() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.user_location_id() FROM PUBLIC, anon;

GRANT EXECUTE ON FUNCTION public.get_user_tenant_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_super_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.user_location_id() TO authenticated;
