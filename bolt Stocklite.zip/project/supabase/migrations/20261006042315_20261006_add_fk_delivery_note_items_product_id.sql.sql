/*
# Add missing foreign key: delivery_note_items.product_id -> products.id

## Problem
The delivery_note_items table has a product_id column but NO foreign key constraint
to products.id. PostgREST (the Supabase REST API) relies on foreign key constraints
to resolve nested resource embeddings like `select('*, product:products(id, name, unit)')`.
Without the FK, the nested join silently fails and returns no product data — which
means the items in delivery notes appear empty in the Approvisionnement page.

## Changes
1. Add FK constraint `delivery_note_items_product_id_fkey` referencing `products(id)`
   with ON DELETE CASCADE (if a product is deleted, its delivery note items go too).

## Security
- No RLS or policy changes. This is a pure schema integrity fix.
*/

ALTER TABLE delivery_note_items
  ADD CONSTRAINT delivery_note_items_product_id_fkey
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE;