/*
# Create deconditioning table

## Purpose
Allows converting stock from a "pack" product (carton/pack) into its "detail" product (unit).
When you decondition a carton, the carton's stock decreases and the unit's stock increases.
This is the reverse of selling a conditioned product — you break open packs to sell units.

## New Table
- `deconditionings`
  - `id` (uuid, primary key)
  - `pack_product_id` (uuid, references products) — the carton/pack product whose stock decreases
  - `detail_product_id` (uuid, references products) — the unit product whose stock increases
  - `pack_quantity` (numeric) — how many packs were broken open
  - `units_per_pack` (numeric) — how many units are in one pack (e.g. 12)
  - `detail_quantity` (numeric, generated = pack_quantity × units_per_pack) — total units produced
  - `location_id` (uuid, references sales_locations, nullable) — which shop this applies to
  - `notes` (text) — optional comment
  - `created_by` (uuid, references auth.users, nullable)
  - `created_at` (timestamptz)

## Security
- RLS enabled.
- Standard 4 CRUD policies scoped by tenant_id via the helper function (same pattern as other tables).
*/

CREATE TABLE IF NOT EXISTS deconditionings (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pack_product_id   uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  detail_product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  pack_quantity     numeric(12,4) NOT NULL DEFAULT 1 CHECK (pack_quantity > 0),
  units_per_pack    numeric(12,4) NOT NULL DEFAULT 1 CHECK (units_per_pack > 0),
  detail_quantity   numeric(12,4) GENERATED ALWAYS AS (pack_quantity * units_per_pack) STORED,
  location_id       uuid REFERENCES sales_locations(id) ON DELETE SET NULL,
  notes             text NOT NULL DEFAULT '',
  created_by        uuid,
  created_at        timestamptz DEFAULT now(),
  updated_at        timestamptz DEFAULT now()
);

ALTER TABLE deconditionings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_deconditionings" ON deconditionings;
CREATE POLICY "select_own_deconditionings" ON deconditionings FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM products p
      WHERE p.id = deconditionings.pack_product_id
      AND p.tenant_id = (SELECT tenant_id FROM user_profiles WHERE id = auth.uid())
    )
  );

DROP POLICY IF EXISTS "insert_own_deconditionings" ON deconditionings;
CREATE POLICY "insert_own_deconditionings" ON deconditionings FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM products p
      WHERE p.id = deconditionings.pack_product_id
      AND p.tenant_id = (SELECT tenant_id FROM user_profiles WHERE id = auth.uid())
    )
  );

DROP POLICY IF EXISTS "update_own_deconditionings" ON deconditionings;
CREATE POLICY "update_own_deconditionings" ON deconditionings FOR UPDATE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM products p
      WHERE p.id = deconditionings.pack_product_id
      AND p.tenant_id = (SELECT tenant_id FROM user_profiles WHERE id = auth.uid())
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM products p
      WHERE p.id = deconditionings.pack_product_id
      AND p.tenant_id = (SELECT tenant_id FROM user_profiles WHERE id = auth.uid())
    )
  );

DROP POLICY IF EXISTS "delete_own_deconditionings" ON deconditionings;
CREATE POLICY "delete_own_deconditionings" ON deconditionings FOR DELETE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM products p
      WHERE p.id = deconditionings.pack_product_id
      AND p.tenant_id = (SELECT tenant_id FROM user_profiles WHERE id = auth.uid())
    )
  );

CREATE INDEX IF NOT EXISTS idx_deconditionings_pack ON deconditionings(pack_product_id);
CREATE INDEX IF NOT EXISTS idx_deconditionings_detail ON deconditionings(detail_product_id);
CREATE INDEX IF NOT EXISTS idx_deconditionings_date ON deconditionings(created_at);