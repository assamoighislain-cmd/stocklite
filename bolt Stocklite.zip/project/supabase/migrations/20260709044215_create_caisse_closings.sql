CREATE TABLE IF NOT EXISTS caisse_closings (
  id            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID         REFERENCES auth.users(id),
  date          DATE         NOT NULL DEFAULT CURRENT_DATE,
  period_start  TIMESTAMPTZ  NOT NULL,
  period_end    TIMESTAMPTZ  NOT NULL,
  status        TEXT         NOT NULL DEFAULT 'brouillon' CHECK (status IN ('brouillon', 'cloturee')),
  notes         TEXT         NOT NULL DEFAULT '',
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS caisse_closing_lines (
  id               UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  closing_id       UUID         NOT NULL REFERENCES caisse_closings(id) ON DELETE CASCADE,
  method           TEXT         NOT NULL,
  expected_amount  NUMERIC(12,2) NOT NULL DEFAULT 0,
  counted_amount   NUMERIC(12,2) NOT NULL DEFAULT 0,
  difference       NUMERIC(12,2) GENERATED ALWAYS AS (counted_amount - expected_amount) STORED,
  created_at       TIMESTAMPTZ  NOT NULL DEFAULT now()
);

ALTER TABLE caisse_closings  ENABLE ROW LEVEL SECURITY;
ALTER TABLE caisse_closing_lines ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_closings" ON caisse_closings FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_closings" ON caisse_closings FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_closings" ON caisse_closings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_closings" ON caisse_closings FOR DELETE TO authenticated USING (true);

CREATE POLICY "select_closing_lines" ON caisse_closing_lines FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_closing_lines" ON caisse_closing_lines FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_closing_lines" ON caisse_closing_lines FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_closing_lines" ON caisse_closing_lines FOR DELETE TO authenticated USING (true);
