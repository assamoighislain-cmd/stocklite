/*
# Stocklite POS — Schéma complet

## Vue d'ensemble
Crée les tables nécessaires pour un logiciel de point de vente avec
facturation A4, relevés de compte client et suivi des règlements.

## Nouvelles tables

### company_settings
Informations de l'entreprise utilisées dans l'en-tête des factures.
- `name` — raison sociale
- `address`, `city` — adresse
- `phone`, `email` — coordonnées
- `tax_id` — numéro SIRET / NIF
- `invoice_footer` — texte de pied de facture

### products
Catalogue articles / services.
- `name`, `description` — désignation
- `unit` — unité (pcs, h, kg…)
- `price` — prix unitaire HT
- `active` — article actif/inactif

### customers
Répertoire clients.
- `name`, `email`, `phone` — coordonnées
- `address`, `city` — adresse de facturation
- `notes` — notes internes

### invoices
En-têtes de factures avec numérotation automatique (FAC-00001…).
- `invoice_number` — numéro unique auto-généré
- `customer_id` — client facturé
- `date`, `due_date` — dates
- `status` — brouillon / envoyee / payee / partielle / annulee
- `subtotal`, `tax_rate`, `tax_amount`, `total` — montants HT/TVA/TTC
- `amount_paid` — montant déjà réglé
- `balance_due` — solde restant dû (colonne générée)

### invoice_items
Lignes de facture.
- `invoice_id` — facture parente (suppression en cascade)
- `product_id` — article lié (optionnel)
- `description`, `quantity`, `unit_price`, `total` — détail ligne

### payments
Règlements reçus.
- `customer_id`, `invoice_id` — client / facture concernée
- `amount`, `method` — montant et mode de paiement
- `payment_date` — date du règlement

## Sécurité
RLS activé sur toutes les tables. App mono-utilisateur (sans auth) :
politiques `TO anon, authenticated` avec `USING (true)`.
*/

-- Séquence pour numérotation des factures
CREATE SEQUENCE IF NOT EXISTS invoice_seq START 1;

-- Paramètres entreprise
CREATE TABLE IF NOT EXISTS company_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'Mon Entreprise',
  address text NOT NULL DEFAULT '',
  city text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  tax_id text NOT NULL DEFAULT '',
  invoice_footer text NOT NULL DEFAULT 'Merci pour votre confiance.',
  created_at timestamptz DEFAULT now()
);

-- Insérer une ligne de config par défaut si elle n'existe pas
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM company_settings LIMIT 1) THEN
    INSERT INTO company_settings DEFAULT VALUES;
  END IF;
END $$;

-- Articles
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  unit text NOT NULL DEFAULT 'pcs',
  price numeric(12,2) NOT NULL DEFAULT 0 CHECK (price >= 0),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Clients
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  address text NOT NULL DEFAULT '',
  city text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Factures
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text UNIQUE NOT NULL DEFAULT 'FAC-' || LPAD(nextval('invoice_seq')::text, 5, '0'),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
  date date NOT NULL DEFAULT current_date,
  due_date date,
  status text NOT NULL DEFAULT 'brouillon'
    CHECK (status IN ('brouillon','envoyee','payee','partielle','annulee')),
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  tax_rate numeric(5,2) NOT NULL DEFAULT 0,
  tax_amount numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  amount_paid numeric(12,2) NOT NULL DEFAULT 0,
  balance_due numeric(12,2) GENERATED ALWAYS AS (total - amount_paid) STORED,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Lignes de facture
CREATE TABLE IF NOT EXISTS invoice_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,4) NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price numeric(12,2) NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
  total numeric(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Règlements
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
  invoice_id uuid REFERENCES invoices(id) ON DELETE SET NULL,
  amount numeric(12,2) NOT NULL CHECK (amount > 0),
  method text NOT NULL DEFAULT 'especes'
    CHECK (method IN ('especes','carte','virement','cheque','autre')),
  payment_date date NOT NULL DEFAULT current_date,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Index
CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice ON invoice_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_payments_customer ON payments(customer_id);
CREATE INDEX IF NOT EXISTS idx_payments_invoice ON payments(invoice_id);

-- RLS
ALTER TABLE company_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Politiques company_settings
DROP POLICY IF EXISTS "anon_select_settings" ON company_settings;
CREATE POLICY "anon_select_settings" ON company_settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_settings" ON company_settings;
CREATE POLICY "anon_insert_settings" ON company_settings FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_settings" ON company_settings;
CREATE POLICY "anon_update_settings" ON company_settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_settings" ON company_settings;
CREATE POLICY "anon_delete_settings" ON company_settings FOR DELETE TO anon, authenticated USING (true);

-- Politiques products
DROP POLICY IF EXISTS "anon_select_products" ON products;
CREATE POLICY "anon_select_products" ON products FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_products" ON products;
CREATE POLICY "anon_insert_products" ON products FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_products" ON products;
CREATE POLICY "anon_update_products" ON products FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_products" ON products;
CREATE POLICY "anon_delete_products" ON products FOR DELETE TO anon, authenticated USING (true);

-- Politiques customers
DROP POLICY IF EXISTS "anon_select_customers" ON customers;
CREATE POLICY "anon_select_customers" ON customers FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_customers" ON customers;
CREATE POLICY "anon_insert_customers" ON customers FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_customers" ON customers;
CREATE POLICY "anon_update_customers" ON customers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_customers" ON customers;
CREATE POLICY "anon_delete_customers" ON customers FOR DELETE TO anon, authenticated USING (true);

-- Politiques invoices
DROP POLICY IF EXISTS "anon_select_invoices" ON invoices;
CREATE POLICY "anon_select_invoices" ON invoices FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_invoices" ON invoices;
CREATE POLICY "anon_insert_invoices" ON invoices FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_invoices" ON invoices;
CREATE POLICY "anon_update_invoices" ON invoices FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_invoices" ON invoices;
CREATE POLICY "anon_delete_invoices" ON invoices FOR DELETE TO anon, authenticated USING (true);

-- Politiques invoice_items
DROP POLICY IF EXISTS "anon_select_items" ON invoice_items;
CREATE POLICY "anon_select_items" ON invoice_items FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_items" ON invoice_items;
CREATE POLICY "anon_insert_items" ON invoice_items FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_items" ON invoice_items;
CREATE POLICY "anon_update_items" ON invoice_items FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_items" ON invoice_items;
CREATE POLICY "anon_delete_items" ON invoice_items FOR DELETE TO anon, authenticated USING (true);

-- Politiques payments
DROP POLICY IF EXISTS "anon_select_payments" ON payments;
CREATE POLICY "anon_select_payments" ON payments FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_payments" ON payments;
CREATE POLICY "anon_insert_payments" ON payments FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_payments" ON payments;
CREATE POLICY "anon_update_payments" ON payments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_payments" ON payments;
CREATE POLICY "anon_delete_payments" ON payments FOR DELETE TO anon, authenticated USING (true);
