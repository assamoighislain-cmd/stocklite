/*
# Cascade Delete Tenant with All Data

1. Purpose
   Allows a super administrator to permanently delete a tenant (company) and ALL its data
   across every tenant-scoped table in a single atomic operation.

2. New Function
   - `cascade_delete_tenant(p_tenant_id uuid)` — SECURITY DEFINER function that:
     a. Verifies the caller is a super_admin (via is_super_admin()).
     b. Deletes rows from every tenant-scoped table in dependency order (children before parents).
     c. Deletes auth.users accounts for all user_profiles belonging to the tenant.
     d. Deletes the tenant row itself last.
     e. Returns a summary of deleted counts.

3. Security
   - SECURITY DEFINER so it can delete from all tables (bypassing RLS).
   - Execution restricted: only callable by authenticated role, but internally
     checks is_super_admin() and raises an exception if the caller is not a super admin.
   - No new tables, no RLS policy changes.

4. Important Notes
   - This is a destructive, irreversible operation.
   - The function deletes auth.users via the Supabase auth admin API is not available
     inside PL/pgSQL, so user_profiles are deleted but auth.users entries are deleted
     via a separate admin call from the edge function. The function handles all
     database-side data; the edge function handles auth.users deletion.
   - Order: child tables (items, lines) deleted before parent tables (invoices, orders, etc.)
     to avoid FK constraint violations.
*/

CREATE OR REPLACE FUNCTION public.cascade_delete_tenant(p_tenant_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_counts jsonb := '{}'::jsonb;
  v_user_ids text[] := ARRAY[]::text[];
  v_count int;
BEGIN
  -- Verify caller is super admin
  IF NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Permission denied: only super admins can delete tenants';
  END IF;

  -- Collect user IDs for later auth deletion
  SELECT COALESCE(array_agg(id), ARRAY[]::text[])
  INTO v_user_ids
  FROM public.user_profiles
  WHERE tenant_id = p_tenant_id;

  -- Delete child tables first (items, lines, etc.)
  DELETE FROM public.pos_sale_items WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('pos_sale_items', v_count);

  DELETE FROM public.pos_payments WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('pos_payments', v_count);

  DELETE FROM public.invoice_items WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('invoice_items', v_count);

  DELETE FROM public.order_items WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('order_items', v_count);

  DELETE FROM public.delivery_note_items WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('delivery_note_items', v_count);

  DELETE FROM public.dotation_items WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('dotation_items', v_count);

  DELETE FROM public.caisse_closing_lines WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('caisse_closing_lines', v_count);

  DELETE FROM public.location_product_price_types WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('location_product_price_types', v_count);

  DELETE FROM public.location_stock_variants WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('location_stock_variants', v_count);

  DELETE FROM public.location_stock WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('location_stock', v_count);

  DELETE FROM public.product_price_types WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('product_price_types', v_count);

  DELETE FROM public.product_variants WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('product_variants', v_count);

  DELETE FROM public.stock_movements WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('stock_movements', v_count);

  DELETE FROM public.stock_transfers WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('stock_transfers', v_count);

  -- Delete parent tables
  DELETE FROM public.payments WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('payments', v_count);

  DELETE FROM public.invoices WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('invoices', v_count);

  DELETE FROM public.orders WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('orders', v_count);

  DELETE FROM public.pos_sales WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('pos_sales', v_count);

  DELETE FROM public.delivery_notes WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('delivery_notes', v_count);

  DELETE FROM public.dotations WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('dotations', v_count);

  DELETE FROM public.caisse_closings WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('caisse_closings', v_count);

  DELETE FROM public.accounting_entries WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('accounting_entries', v_count);

  DELETE FROM public.held_carts WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('held_carts', v_count);

  DELETE FROM public.cashes WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('cashes', v_count);

  DELETE FROM public.caisss WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('caisses', v_count);

  -- Delete entity tables
  DELETE FROM public.customers WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('customers', v_count);

  DELETE FROM public.products WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('products', v_count);

  DELETE FROM public.product_families WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('product_families', v_count);

  DELETE FROM public.price_types WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('price_types', v_count);

  DELETE FROM public.supplier_payments WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('supplier_payments', v_count);

  DELETE FROM public.suppliers WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('suppliers', v_count);

  DELETE FROM public.commerciaux WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('commerciaux', v_count);

  DELETE FROM public.services WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('services', v_count);

  DELETE FROM public.sales_locations WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('sales_locations', v_count);

  DELETE FROM public.custom_units WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('custom_units', v_count);

  DELETE FROM public.push_subscriptions WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('push_subscriptions', v_count);

  DELETE FROM public.admin_notifications WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('admin_notifications', v_count);

  DELETE FROM public.license_payments WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('license_payments', v_count);

  DELETE FROM public.subscriptions WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('subscriptions', v_count);

  DELETE FROM public.company_settings WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('company_settings', v_count);

  DELETE FROM public.deletes_log WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('deletes_log', v_count);

  -- Delete user_profiles (auth.users handled by edge function)
  DELETE FROM public.user_profiles WHERE tenant_id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('user_profiles', v_count);

  -- Finally delete the tenant
  DELETE FROM public.tenants WHERE id = p_tenant_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  v_counts := v_counts || jsonb_build_object('tenants', v_count);

  RETURN jsonb_build_object(
    'success', true,
    'tenant_id', p_tenant_id,
    'deleted_counts', v_counts,
    'user_ids_to_delete_from_auth', to_jsonb(v_user_ids)
  );
END;
$$;

-- Restrict execution to authenticated role only
REVOKE EXECUTE ON FUNCTION public.cascade_delete_tenant(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.cascade_delete_tenant(uuid) TO authenticated;
