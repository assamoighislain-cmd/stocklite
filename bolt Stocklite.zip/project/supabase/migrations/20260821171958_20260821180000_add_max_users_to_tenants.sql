/*
# Add max_users quota to tenants

1. Modified Tables
   - `tenants`: add `max_users` (integer, default 5) — maximum users allowed per subscription plan

2. Changes
   - Adds a quota column so the super-admin can set user limits per company
   - Default is 5 users for new tenants (starter plan)

3. Notes
   - The frontend will check this limit before allowing new user creation
   - Super-admin can adjust per tenant based on their subscription
*/

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tenants' AND column_name = 'max_users'
  ) THEN
    ALTER TABLE tenants ADD COLUMN max_users integer NOT NULL DEFAULT 5;
  END IF;
END $$;
