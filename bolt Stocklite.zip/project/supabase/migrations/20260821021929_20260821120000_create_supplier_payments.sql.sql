/*
# Create supplier_payments table

1. New Tables
- `supplier_payments` — records règlements (payments) made to suppliers.
  - `id` (uuid PK)
  - `supplier_id` (uuid, FK to suppliers)
  - `delivery_note_id` (uuid, nullable, optional link to a specific delivery note)
  - `amount` (numeric, the payment amount)
  - `method` (text, payment method: especes, virement, cheque, etc.)
  - `payment_date` (date, when the payment was made)
  - `notes` (text, optional reference or remark)
  - `location_id` (uuid, nullable, the boutique scope)
  - `created_by` (uuid, nullable, the user who recorded it)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz, for sync tracking)

2. Indexes
- Index on `supplier_id` for fast per-supplier lookups.
- Index on `payment_date` for period-based queries.

3. Security
- RLS enabled.
- 4 CRUD policies scoped to `authenticated` (the app has a sign-in screen).
- Ownership is implied: any authenticated user can manage supplier payments
  (access control is enforced at the application layer by role).
*/

CREATE TABLE IF NOT EXISTS supplier_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  delivery_note_id uuid REFERENCES delivery_notes(id) ON DELETE SET NULL,
  amount numeric NOT NULL DEFAULT 0,
  method text NOT NULL DEFAULT 'especes',
  payment_date date NOT NULL DEFAULT CURRENT_DATE,
  notes text NOT NULL DEFAULT '',
  location_id uuid,
  created_by uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_supplier_payments_supplier ON supplier_payments (supplier_id);
CREATE INDEX IF NOT EXISTS idx_supplier_payments_date ON supplier_payments (payment_date);

ALTER TABLE supplier_payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_supplier_payments" ON supplier_payments;
CREATE POLICY "select_supplier_payments" ON supplier_payments FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_supplier_payments" ON supplier_payments;
CREATE POLICY "insert_supplier_payments" ON supplier_payments FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_supplier_payments" ON supplier_payments;
CREATE POLICY "update_supplier_payments" ON supplier_payments FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_supplier_payments" ON supplier_payments;
CREATE POLICY "delete_supplier_payments" ON supplier_payments FOR DELETE
  TO authenticated USING (true);
