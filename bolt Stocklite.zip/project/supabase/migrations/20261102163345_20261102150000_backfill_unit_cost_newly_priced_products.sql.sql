/*
# Backfill unit_cost for sale items with newly-priced products

1. Purpose
   Some products (e.g. CHARGEUR, ITEL) had purchase_price = 0 when the previous
   backfill ran, so their sale items stayed at unit_cost = 0. The products have
   since been given a purchase_price. This migration re-runs the backfill so
   those sale items now reflect the correct cost.

2. Changes
   - `pos_sale_items`: UPDATE unit_cost = product.purchase_price for rows where
     unit_cost = 0 AND the linked product has a non-zero purchase_price.
   - `invoice_items`: same backfill.

3. Safety
   - No schema changes. Only updates rows where unit_cost is still 0.
   - Rows without a linked product remain at 0 (no source for the cost).
*/

UPDATE pos_sale_items psi
  SET unit_cost = p.purchase_price
  FROM products p
  WHERE psi.product_id = p.id
    AND psi.unit_cost = 0
    AND p.purchase_price > 0;

UPDATE invoice_items ii
  SET unit_cost = p.purchase_price
  FROM products p
  WHERE ii.product_id = p.id
    AND ii.unit_cost = 0
    AND p.purchase_price > 0;
