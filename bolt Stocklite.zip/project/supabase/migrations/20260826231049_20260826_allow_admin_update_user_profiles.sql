/*
# Allow admin to update user_profiles within their tenant

## Purpose
Currently only super_admin can update other users' profiles (policy
`user_profiles_update_admin` requires `is_super_admin()`). Company admins
need to assign users to sales locations, change roles, and update status
for users within their own tenant. The existing `user_profiles_update_own`
policy only allows updating one's own profile.

## Security
- Admin can only update profiles where `tenant_id` matches their own.
- The WITH CHECK clause enforces the same condition on the resulting row,
  preventing an admin from moving a user into a different tenant.
- Super_admin retains full access via the existing policy.
*/

DROP POLICY IF EXISTS "user_profiles_update_admin_same_tenant" ON user_profiles;

CREATE POLICY "user_profiles_update_admin_same_tenant" ON user_profiles FOR UPDATE
  TO authenticated
  USING (
    is_admin() AND tenant_id = get_user_tenant_id()
  )
  WITH CHECK (
    is_admin() AND tenant_id = get_user_tenant_id()
  );
