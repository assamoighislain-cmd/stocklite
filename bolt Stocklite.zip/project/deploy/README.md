# Déploiement LAN sans internet - StockLite

Architecture client-serveur 100% locale. Aucune installation sur les postes bureau :
un navigateur suffit.

```
┌─────────────────────────────┐
│  Serveur LAN (1 machine)    │
│  Docker + Supabase + nginx  │
│  http://<IP-SERVEUR>        │
└──────────────┬──────────────┘
               │ switch LAN
   ┌───────────┴───────────┐
   ▼                       ▼
┌─────────┐           ┌─────────┐
│ Poste 1 │           │ Poste 2 │   (navigateur uniquement)
└─────────┘           └─────────┘
```

## Prérequis serveur

- Docker + Docker Compose installés une fois (avec internet, pour pull les images)
- Une machine Linux/Mac/Windows restant allumée pendant les heures d'ouverture
- Une IP fixe sur le LAN (ex: `192.168.1.50`)

## Installation serveur (une seule fois)

### 1. Récupérer les images Docker (avec internet)

```bash
docker compose pull
```
À faire une seule fois. Les images sont ensuite mises en cache localement.

### 2. Configurer

```bash
cp .env.example .env
# Éditer .env :
#   SERVER_HOST     -> IP fixe du serveur sur le LAN
#   POSTGRES_PASSWORD -> mot de passe fort
#   JWT_SECRET      -> générer avec : openssl rand -base64 32
```

### 3. Démarrer la stack

```bash
docker compose up -d
```

Vérifier : `docker compose ps` (4 conteneurs : db, auth, rest, nginx).

### 4. Récupérer la clé anon

L'app frontend a besoin de la clé anon Supabase. La récupérer :

```bash
curl -s http://localhost/auth/v1/health   # vérifie que auth tourne
```

La clé anon est dérivée du `JWT_SECRET`. Pour la générer, utiliser le script
`gen-anon-key.sh` fourni, ou la récupérer depuis Supabase Studio si installé.

### 5. Construire le frontend

Sur une machine de développement (avec Node.js + npm) :

```bash
# À la racine du projet
cp deploy/.env.example .env.production   # adapter les valeurs
npm run build
```

Copier le dossier `dist/` généré dans `deploy/dist/` sur le serveur :

```bash
scp -r dist/ user@<IP-SERVEUR>:/chemin/vers/deploy/dist/
```

### 6. Appliquer les migrations de base de données

Les migrations SQL sont dans `supabase/migrations/`. Les appliquer via `psql` :

```bash
# Depuis le serveur
for f in ../supabase/migrations/*.sql; do
  docker exec -i stocklite-db psql -U postgres -d postgres < "$f"
done
```

Ou un par un dans l'ordre chronologique.

### 7. Redémarrer nginx pour servir le nouveau build

```bash
docker compose restart nginx
```

## Côté postes bureau : RIEN à installer

Sur chaque poste du LAN, ouvrir le navigateur à :

```
http://<IP-SERVEUR>
```

C'est tout. Le navigateur charge l'app, le cache IndexedDB se peuple, l'auth
fonctionne. Pas d'exécutable, pas de runtime, pas de dépendance système.

## Opérations courantes

| Action | Commande |
|---|---|
| Démarrer | `docker compose up -d` |
| Arrêter | `docker compose down` |
| Logs | `docker compose logs -f` |
| Sauvegarde DB | `docker exec stocklite-db pg_dump -U postgres postgres > backup.sql` |
| Restauration DB | `docker exec -i stocklite-db psql -U postgres postgres < backup.sql` |
| Mettre à jour l'app | Rebuild `dist/`, copier dans `deploy/dist/`, `docker compose restart nginx` |

## Notes

- **Pas de HTTPS** : en LAN simple, nginx sert en HTTP. Suffisant tant qu'on
  reste sur un réseau privé de confiance. Pour HTTPS, ajouter un certificat
  auto-signé et servir sur 443.
- **Pas de Service Worker** : un client qui n'a jamais visité l'app ne peut pas
  démarrer hors-ligne. Prévoir une première visite connectée sur chaque poste
  pour peupler le cache IndexedDB.
- **SMTP désactivé** : la confirmation email est off (autoconfirm). Les comptes
  sont créés directement via l'écran d'auth de l'app.
- **Sauvegardes** : le volume Docker `db_data` contient toute la base. Le
  sauvegarder régulièrement (voir commande `pg_dump` ci-dessus).
