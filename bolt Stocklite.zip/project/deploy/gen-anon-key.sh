#!/usr/bin/env bash
# Génère une clé anon JWT valide pour le JWT_SECRET configuré dans .env
# Usage : ./gen-anon-key.sh
set -euo pipefail

if [ ! -f .env ]; then
  echo "Erreur : .env introuvable. Lancez : cp .env.example .env"
  exit 1
fi

JWT_SECRET=$(grep '^JWT_SECRET=' .env | cut -d= -f2-)
if [ -z "$JWT_SECRET" ] || [[ "$JWT_SECRET" == generer-* ]]; then
  echo "Erreur : JWT_SECRET non configuré dans .env"
  echo "Générez-le avec : openssl rand -base64 32"
  exit 1
fi

# Construit le payload JWT anon (role=anon, exp=2099)
HEADER='{"alg":"HS256","typ":"JWT"}'
PAYLOAD='{"iss":"supabase","role":"anon","iat":1783510334,"exp":4099800000}'
 
b64() { printf '%s' "$1" | openssl base64 -e 2>/dev/null | tr -d '=' | tr '/+' '_-'; }

HEADER_B64=$(b64 "$HEADER")
PAYLOAD_B64=$(b64 "$PAYLOAD")
SIGNING_INPUT="${HEADER_B64}.${PAYLOAD_B64}"
SIGNATURE=$(printf '%s' "$SIGNING_INPUT" | openssl dgst -sha256 -hmac "$JWT_SECRET" -binary | openssl base64 -e 2>/dev/null | tr -d '=' | tr '/+' '_-')

ANON_KEY="${SIGNING_INPUT}.${SIGNATURE}"

echo "Clé anon Supabase :"
echo "$ANON_KEY"
echo
echo "Copiez cette valeur dans deploy/.env :"
echo "  VITE_SUPABASE_ANON_KEY=$ANON_KEY"
